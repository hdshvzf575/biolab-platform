# Security Specification & Threat Model
## Platform: منصة مختبر الأحياء – الأستاذ وسام سهيل العامري
### Environment: Firebase Firestore & Firebase Storage
### Project ID: `prismatic-clone-5lcf1` | Database ID: `ai-studio-85798a9e-7365-46c6-bde9-0a484132186b`

---

## 1. Data Invariants

1. **Identity & User Isolation**: A student can only read and write their own profile document (`users/{userId}` where `userId == request.auth.uid`). Listing (`list`) all users is forbidden for non-admins to prevent bulk PII harvesting.
2. **Strict Privilege Immutability**: Students cannot self-elevate permissions, set `role: "admin"`, set `isVip: true`, or unlock lectures without administrative authorization.
3. **VIP Code Confidentiality**: The `lecture_codes` collection contains sensitive single-use and group unlock codes. Direct client `read`, `list`, or `write` by students is completely blocked (`allow read, write: if isVerifiedAdmin()`). Code verification must be handled by secure server endpoints.
4. **Curriculum & Lecture Authoritativeness**: Lectures (`lectures`), Books (`curriculum_books`), and Institute Posts (`institute_posts`) can be publicly read by all students, but mutations (`create`, `update`, `delete`) are strictly restricted to verified administrators.
5. **Audit & Backup Immutability**: The `backups` collection is read/write accessible only by the verified administrator. No student or client can tamper with or delete snapshots.
6. **Storage Resource Guardrails**: Firebase Storage requires strict verification of MIME type, file size ceilings (Books <= 100MB, Covers <= 10MB, Videos <= 300MB), and path boundaries (`books/`, `covers/`, `videos/`).

---

## 2. The "Dirty Dozen" Attack Payloads (Simulated & Blocked)

| # | Attack Vector | Target Path | Injected Malicious Payload | Expected Response | Enforced Security Rule Gate |
|---|---|---|---|---|---|
| 1 | Self-Assigned Role Escalation | `users/STU-ATTACK` | `{ "name": "Attacker", "role": "admin", "isVip": true }` | **PERMISSION_DENIED** | `isValidUserCreation() && incoming().role == 'student' && incoming().isVip == false` |
| 2 | Shadow Update / VIP Theft | `users/UID-BIO-1001` | `{ "isVip": true, "role": "vip", "unlockedLectures": [101, 102, 103] }` | **PERMISSION_DENIED** | `incoming().diff(existing()).affectedKeys().hasOnly(['name', 'birthDate', 'grade', 'deviceType', 'lastActive'])` |
| 3 | VIP Secret Code Scraping | `lecture_codes/VIP-BIO-2026-HCVK` | `GET /lecture_codes` or `GET /lecture_codes/*` | **PERMISSION_DENIED** | `match /lecture_codes/{codeId} { allow read: if isVerifiedAdmin(); }` |
| 4 | Lecture Destruction Attack | `lectures/1793693034970` | `DELETE /lectures/1793693034970` as student | **PERMISSION_DENIED** | `allow delete: if isVerifiedAdmin();` |
| 5 | Curriculum Defacement | `curriculum_books/b6` | `UPDATE /curriculum_books/b6 { "pdfUrl": "https://evil.com/phishing.pdf" }` | **PERMISSION_DENIED** | `allow write: if isVerifiedAdmin();` |
| 6 | Cross-Student PII Harvesting | `users/UID-BIO-1002` | `GET /users/UID-BIO-1002` requested by `UID-BIO-1001` | **PERMISSION_DENIED** | `allow get: if isVerifiedAdmin() || (isSignedIn() && request.auth.uid == userId);` |
| 7 | ID Poisoning (Malformed URI) | `users/$$$INVALID_ID$$$` | `setDoc(doc(db, 'users', '$$$INVALID_ID$$$'), {...})` | **PERMISSION_DENIED** | `isValidId(userId)` regex `^[a-zA-Z0-9_\-]+$` |
| 8 | Denial of Wallet (Data Bloat) | `users/UID-BIO-1001` | `{ "name": "A".repeat(50000), "unlockedLectures": [1,2,...10000] }` | **PERMISSION_DENIED** | `incoming().name.size() <= 100` |
| 9 | Unverified Admin Email Spoof | `backups/backup_test` | `request.auth.token.email = 'abdullahmiqdad2007@gmail.com'` with `email_verified: false` | **PERMISSION_DENIED** | `request.auth.token.email_verified == true` |
| 10 | Administrative Backup Erasure | `backups/backup_1793693034970`| `DELETE /backups/backup_1793693034970` | **PERMISSION_DENIED** | `allow write, delete: if isVerifiedAdmin();` |
| 11 | Malicious Executable Storage | `books/payload.exe` | Upload with `contentType: "application/x-msdownload"` | **PERMISSION_DENIED** | `request.resource.contentType == 'application/pdf'` |
| 12 | Storage Denial of Service | `covers/oversized.jpg` | Upload with size `50 * 1024 * 1024` (50MB) | **PERMISSION_DENIED** | `request.resource.size <= 10 * 1024 * 1024` |

---

## 3. Test Runner Design & Invariants Verification

All 12 attack vectors are systematically covered in `scripts/test_firestore_rules_simulation.ts`.
Every simulated attempt must return `PERMISSION_DENIED` (or reject with status 403), while legitimate student and administrator operations must succeed.
