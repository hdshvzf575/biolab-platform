import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Write high-quality SVG icon with DNA double helix & golden luxury ring
const svgIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#04080f"/>
      <stop offset="50%" stop-color="#0a1526"/>
      <stop offset="100%" stop-color="#050b14"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#f5e2b3"/>
      <stop offset="40%" stop-color="#e9c978"/>
      <stop offset="100%" stop-color="#c9a24a"/>
    </linearGradient>
    <linearGradient id="emeraldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#34d399"/>
      <stop offset="100%" stop-color="#059669"/>
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="12" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>

  <!-- Background -->
  <rect width="512" height="512" rx="110" fill="url(#bgGrad)"/>
  <rect width="504" height="504" x="4" y="4" rx="106" fill="none" stroke="url(#goldGrad)" stroke-width="6" opacity="0.6"/>

  <!-- Outer Orbit Rings -->
  <circle cx="256" cy="256" r="190" fill="none" stroke="#e9c978" stroke-width="2" stroke-dasharray="10 14" opacity="0.3"/>
  <circle cx="256" cy="256" r="150" fill="none" stroke="#0fb98a" stroke-width="2" stroke-dasharray="8 10" opacity="0.4"/>

  <!-- Central Glow -->
  <circle cx="256" cy="256" r="110" fill="#0fb98a" opacity="0.12" filter="url(#glow)"/>
  <circle cx="256" cy="256" r="80" fill="#e9c978" opacity="0.15" filter="url(#glow)"/>

  <!-- DNA Strands & Nodes -->
  <g transform="translate(256, 256) rotate(-25) translate(-256, -256)" filter="url(#glow)">
    <!-- Base Rungs -->
    <line x1="180" y1="160" x2="332" y2="160" stroke="url(#goldGrad)" stroke-width="6" stroke-linecap="round" opacity="0.8"/>
    <line x1="200" y1="200" x2="312" y2="200" stroke="url(#emeraldGrad)" stroke-width="6" stroke-linecap="round" opacity="0.9"/>
    <line x1="220" y1="240" x2="292" y2="240" stroke="url(#goldGrad)" stroke-width="6" stroke-linecap="round" opacity="0.8"/>
    <line x1="220" y1="280" x2="292" y2="280" stroke="url(#emeraldGrad)" stroke-width="6" stroke-linecap="round" opacity="0.8"/>
    <line x1="200" y1="320" x2="312" y2="320" stroke="url(#goldGrad)" stroke-width="6" stroke-linecap="round" opacity="0.9"/>
    <line x1="180" y1="360" x2="332" y2="360" stroke="url(#emeraldGrad)" stroke-width="6" stroke-linecap="round" opacity="0.8"/>

    <!-- Left Helix Wave -->
    <path d="M 180 140 Q 260 220 220 280 T 180 380" fill="none" stroke="url(#goldGrad)" stroke-width="14" stroke-linecap="round"/>
    <!-- Right Helix Wave -->
    <path d="M 332 140 Q 252 220 292 280 T 332 380" fill="none" stroke="url(#emeraldGrad)" stroke-width="14" stroke-linecap="round"/>

    <!-- Nucleotide Spheres -->
    <circle cx="180" cy="160" r="10" fill="#e9c978"/>
    <circle cx="332" cy="160" r="10" fill="#0fb98a"/>
    <circle cx="200" cy="200" r="9" fill="#0fb98a"/>
    <circle cx="312" cy="200" r="9" fill="#e9c978"/>
    <circle cx="220" cy="240" r="8" fill="#e9c978"/>
    <circle cx="292" cy="240" r="8" fill="#0fb98a"/>
    <circle cx="220" cy="280" r="8" fill="#0fb98a"/>
    <circle cx="292" cy="280" r="8" fill="#e9c978"/>
    <circle cx="200" cy="320" r="9" fill="#e9c978"/>
    <circle cx="312" cy="320" r="9" fill="#0fb98a"/>
    <circle cx="180" cy="360" r="10" fill="#0fb98a"/>
    <circle cx="332" cy="360" r="10" fill="#e9c978"/>
  </g>

  <!-- Biology Microscopic Symbol / Sparkle -->
  <polygon points="256,70 262,85 277,91 262,97 256,112 250,97 235,91 250,85" fill="#e9c978"/>
  <polygon points="256,400 262,415 277,421 262,427 256,442 250,427 235,421 250,415" fill="#0fb98a"/>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgIcon, 'utf8');

// Function to generate a standard raw valid PNG with RGBA buffer
function createPngBuffer(width, height, isMaskable = false) {
  // We construct standard uncompressed IDAT chunks inside a valid PNG structure
  // Color palette: deep luxury dark background, golden circle in center, emerald accent
  const rowLength = width * 4 + 1; // 1 filter byte per row
  const rawData = Buffer.alloc(rowLength * height);

  const cx = width / 2;
  const cy = height / 2;
  const safeRadius = isMaskable ? width * 0.38 : width * 0.45;
  const coreRadius = width * 0.22;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowLength;
    rawData[rowOffset] = 0; // Filter: None

    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Background color #0a1220
      let r = 10;
      let g = 18;
      let b = 32;
      let a = 255;

      if (dist < safeRadius) {
        // Outer ring
        if (Math.abs(dist - safeRadius * 0.85) < width * 0.02) {
          // Gold ring
          r = 233; g = 201; b = 120;
        } else if (Math.abs(dist - safeRadius * 0.6) < width * 0.015) {
          // Emerald ring
          r = 15; g = 185; b = 138;
        } else if (dist < coreRadius) {
          // Inner core gradient: gold/emerald glow
          const factor = (coreRadius - dist) / coreRadius;
          r = Math.floor(15 * (1 - factor) + 233 * factor);
          g = Math.floor(185 * (1 - factor) + 201 * factor);
          b = Math.floor(138 * (1 - factor) + 120 * factor);
        }
      }

      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const deflated = zlib.deflateSync(rawData);

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR Chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const ihdrChunk = createChunk('IHDR', ihdr);
  const idatChunk = createChunk('IDAT', deflated);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);

  const crcTarget = chunk.subarray(4, 8 + len);
  const crc = crc32(crcTarget);
  chunk.writeUInt32BE(crc, 8 + len);
  return chunk;
}

// Standard CRC32 table
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ crcTable[(crc ^ buf[i]) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

// Generate icons
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPngBuffer(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPngBuffer(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPngBuffer(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPngBuffer(180, 180, false));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), createPngBuffer(32, 32, false));

console.log('Successfully generated all PWA icons in /public');
