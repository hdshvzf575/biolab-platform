#!/usr/bin/env python3
"""
Generates valid, distinct PDF-1.4 textbooks for Iraqi Curriculum across all stages:
Primary (P1 to P6), Intermediate (M1 to M3), Preparatory (S4 to S6), and University.
Each book has its own distinct content, chapters, page structure, and metadata.
"""

import os
import sys

OUTPUT_DIR = os.path.join(os.getcwd(), 'public', 'uploads', 'books')
os.makedirs(OUTPUT_DIR, exist_ok=True)

class SimplePDFBuilder:
    def __init__(self, title, grade, subject, author="Ministry of Education - Iraq"):
        self.title = title
        self.grade = grade
        self.subject = subject
        self.author = author
        self.pages_data = []

    def add_page(self, chapter_title, sections):
        self.pages_data.append({
            'chapter': chapter_title,
            'sections': sections
        })

    def build(self, filename):
        objects = []
        # obj 1: Catalog
        # obj 2: Outlines
        # obj 3: Pages
        # obj 4: Font F1 (Helvetica)
        # obj 5: Font F2 (Helvetica-Bold)
        # obj 6: Font F3 (Helvetica-Oblique)
        
        num_pages = len(self.pages_data)
        page_obj_indices = []
        content_obj_indices = []
        
        # Start allocating object IDs after catalog, outlines, pages, fonts
        current_obj_id = 7
        for _ in range(num_pages):
            page_obj_indices.append(current_obj_id)
            content_obj_indices.append(current_obj_id + 1)
            current_obj_id += 2

        # Pre-build contents
        contents_bytes = []
        for i, page in enumerate(self.pages_data):
            page_num = i + 1
            stream_lines = []
            
            # Header
            stream_lines.append("BT /F2 16 Tf 50 790 Td ({}) Tj ET".format(self._escape(self.title)))
            stream_lines.append("BT /F1 11 Tf 50 770 Td ({}) Tj ET".format(self._escape(f"{self.subject} - {self.grade} - Official Textbook")))
            stream_lines.append("BT /F3 9 Tf 50 754 Td ({}) Tj ET".format(self._escape(f"Author: {self.author} | Edition: 2024-2025 Approved")))
            
            # Gold Divider Bar
            stream_lines.append("0.9 0.7 0.2 RG 2 w 50 742 m 550 742 l S")
            
            # Chapter Title
            stream_lines.append("0 0 0 rg")
            stream_lines.append("BT /F2 13 Tf 50 715 Td ({}) Tj ET".format(self._escape(page['chapter'])))
            
            # Sections
            y = 685
            for sec_title, sec_body in page['sections']:
                stream_lines.append("0.1 0.3 0.6 rg")
                stream_lines.append("BT /F2 11 Tf 50 {} Td ({}) Tj ET".format(y, self._escape(f"* {sec_title}")))
                y -= 20
                stream_lines.append("0.1 0.1 0.1 rg")
                
                # Wrap body lines
                words = sec_body.split(' ')
                current_line = []
                for w in words:
                    current_line.append(w)
                    if len(' '.join(current_line)) > 75:
                        line_text = ' '.join(current_line)
                        stream_lines.append("BT /F1 10 Tf 65 {} Td ({}) Tj ET".format(y, self._escape(line_text)))
                        y -= 16
                        current_line = []
                if current_line:
                    line_text = ' '.join(current_line)
                    stream_lines.append("BT /F1 10 Tf 65 {} Td ({}) Tj ET".format(y, self._escape(line_text)))
                    y -= 22
                else:
                    y -= 6

            # Footer
            stream_lines.append("0.7 0.7 0.7 RG 1 w 50 55 m 550 55 l S")
            stream_lines.append("0.4 0.4 0.4 rg")
            stream_lines.append("BT /F1 9 Tf 50 40 Td (Ministry of Education - General Directorate of Curricula) Tj ET")
            stream_lines.append("BT /F2 9 Tf 480 40 Td (Page {} of {}) Tj ET".format(page_num, num_pages))
            
            content_str = "\n".join(stream_lines)
            content_data = content_str.encode('latin1', 'replace')
            contents_bytes.append(content_data)

        # Assemble PDF file
        pdf = bytearray()
        pdf.extend(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        
        xref_offsets = {}
        
        def write_obj(obj_id, body_bytes):
            xref_offsets[obj_id] = len(pdf)
            pdf.extend(f"{obj_id} 0 obj\n".encode('ascii'))
            pdf.extend(body_bytes)
            pdf.extend(b"\nendobj\n")

        # 1: Catalog
        write_obj(1, b"<< /Type /Catalog /Pages 3 0 R /Outlines 2 0 R >>")
        # 2: Outlines
        write_obj(2, b"<< /Type /Outlines /Count 0 >>")
        # 3: Pages
        kids_str = " ".join([f"{pid} 0 R" for pid in page_obj_indices])
        write_obj(3, f"<< /Type /Pages /Kids [ {kids_str} ] /Count {num_pages} >>".encode('ascii'))
        # 4: F1
        write_obj(4, b"<< /Type /Font /Subtype /Type1 /Name /F1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        # 5: F2
        write_obj(5, b"<< /Type /Font /Subtype /Type1 /Name /F2 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
        # 6: F3
        write_obj(6, b"<< /Type /Font /Subtype /Type1 /Name /F3 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>")

        # Pages and Contents
        for i in range(num_pages):
            pid = page_obj_indices[i]
            cid = content_obj_indices[i]
            cdata = contents_bytes[i]
            
            page_dict = f"<< /Type /Page /Parent 3 0 R /MediaBox [ 0 0 595 842 ] /Resources << /Font << /F1 4 0 R /F2 5 0 R /F3 6 0 R >> >> /Contents {cid} 0 R >>".encode('ascii')
            write_obj(pid, page_dict)
            
            content_obj = f"<< /Length {len(cdata)} >>\nstream\n".encode('ascii') + cdata + b"\nendstream"
            write_obj(cid, content_obj)

        # xref
        xref_start = len(pdf)
        max_id = current_obj_id - 1
        pdf.extend(f"xref\n0 {max_id + 1}\n".encode('ascii'))
        pdf.extend(b"0000000000 65535 f \n")
        for oid in range(1, max_id + 1):
            offset = xref_offsets.get(oid, 0)
            pdf.extend(f"{offset:010d} 00000 n \n".encode('ascii'))
            
        pdf.extend(b"trailer\n")
        pdf.extend(f"<< /Size {max_id + 1} /Root 1 0 R >>\nstartxref\n{xref_start}\n%%EOF\n".encode('ascii'))
        
        filepath = os.path.join(OUTPUT_DIR, filename)
        with open(filepath, 'wb') as f:
            f.write(pdf)
        print(f"Generated {filename} ({len(pdf)} bytes, {num_pages} pages)")

    def _escape(self, s):
        return s.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)')


def build_all_curriculum():
    # 1. Primary 1: Science
    p1 = SimplePDFBuilder("Science - Primary Grade 1 (Al-Uloom)", "Grade 1 Primary", "General Science")
    p1.add_page("Unit 1: Living Things and Their Needs", [
        ("Living Things vs Non-Living Things", "Living things grow, feed, breathe, and reproduce. Plants and animals are living organisms that need water, food, and sunlight to survive."),
        ("Parts of the Plant", "Plants have roots, stems, leaves, flowers, and fruits. Roots absorb water from soil while leaves make food using light."),
        ("Human Body Senses", "Humans have five senses: sight (eyes), hearing (ears), smell (nose), taste (tongue), and touch (skin).")
    ])
    p1.add_page("Unit 2: Animals and Their Habitats", [
        ("Where Animals Live", "Some animals live on land like camels, horses, and sheep, while others live in water like fish and whales."),
        ("How Animals Move and Feed", "Birds fly using wings, fish swim using fins, and animals walk on legs. Herbivores eat plants and carnivores eat meat.")
    ])
    p1.build("science_p1.pdf")

    # 2. Primary 2: Science
    p2 = SimplePDFBuilder("Science - Primary Grade 2 (Al-Uloom)", "Grade 2 Primary", "General Science")
    p2.add_page("Unit 1: Human Body Health and Growth", [
        ("The Heart and Blood Circulation", "The heart pumps blood through blood vessels to all parts of the human body. Pulse beats can be felt on the wrist."),
        ("The Lungs and Breathing", "Lungs absorb oxygen from inhaled fresh air and release carbon dioxide during exhalation."),
        ("The Stomach and Digestion", "The stomach churns chewed food with digestive juices to convert it into simple absorbable nutrients.")
    ])
    p2.add_page("Unit 2: Earth and Environmental Balance", [
        ("Soil and Rocks", "Soil is formed by weathering of rocks over long periods. Fertile soil supports plant growth and agricultural crops."),
        ("Sun, Day and Night", "Earth rotates on its tilted axis every 24 hours, causing the succession of day and night.")
    ])
    p2.build("science_p2.pdf")

    # 3. Primary 3: Science
    p3 = SimplePDFBuilder("Science - Primary Grade 3 (Al-Uloom)", "Grade 3 Primary", "General Science")
    p3.add_page("Unit 1: Nutrition and Photosynthesis", [
        ("Plant Nutrition", "Green plants produce glucose sugar and oxygen through photosynthesis in chloroplasts using sunlight, water, and CO2."),
        ("Animal Feeding Habits", "Herbivores have flat molars for grinding leaves. Carnivores possess sharp canines for tearing prey flesh.")
    ])
    p3.add_page("Unit 2: Forces, Motion, and Simple Machines", [
        ("Force and Gravity", "Gravity pulls objects towards the Earth's center. Friction slows down moving bodies on rough surfaces."),
        ("Simple Machines", "Levers, pulleys, inclined planes, and wheel-axles reduce effort and make manual work easier.")
    ])
    p3.build("science_p3.pdf")

    # 4. Primary 4: Science
    p4 = SimplePDFBuilder("Science - Primary Grade 4 (Al-Uloom)", "Grade 4 Primary", "General Science")
    p4.add_page("Unit 1: Classification and Compound Plants", [
        ("Compound Plants Structure", "Compound plants contain complex roots, stems, leaves, and vascular tissues. Conifers and flowering angiosperms."),
        ("Invertebrate Animal Life Cycles", "Butterflies undergo complete metamorphosis: Egg -> Larva (caterpillar) -> Pupa (chrysalis) -> Adult winged butterfly.")
    ])
    p4.add_page("Unit 2: Ecosystems and Energy Chains", [
        ("Producers and Consumers", "Producers are photosynthetic plants. Primary consumers are herbivores. Secondary consumers are apex predators."),
        ("Decomposers and Recycling", "Fungi and soil bacteria decompose organic debris to return minerals to the soil.")
    ])
    p4.build("science_p4.pdf")

    # 5. Primary 5: Science
    p5 = SimplePDFBuilder("Science - Primary Grade 5 (Al-Uloom)", "Grade 5 Primary", "General Science")
    p5.add_page("Unit 1: Human Circulatory and Respiratory Systems", [
        ("Circulatory Anatomy", "The four-chambered heart consists of right/left atria and right/left ventricles, connected to arteries and veins."),
        ("Respiratory Mechanism", "Diaphragm muscle contracts downwards to expand the thoracic cavity during inspiration."),
        ("Excretory Urinary System", "Kidneys filter nitrogenous wastes from the bloodstream to form urine, which travels via ureters to the bladder.")
    ])
    p5.add_page("Unit 2: Chemical Mixtures and Solutions", [
        ("Homogeneous vs Heterogeneous", "Solutions like saltwater are homogeneous. Suspensions like sand in water are heterogeneous and separate by filtration.")
    ])
    p5.build("science_p5.pdf")

    # 6. Primary 6: Science (Ministerial Exam)
    p6 = SimplePDFBuilder("Science - Primary Grade 6 (Baccalaureate Edition)", "Grade 6 Primary", "General Science")
    p6.add_page("Unit 1: Vegetative Reproduction in Plants", [
        ("Natural Vegetative Reproduction", "Tubers (potatoes) and bulbs (onions/garlic) propagate plants without flowers or sexual seeds."),
        ("Artificial Vegetative Methods", "Grafting (attaching a scion to a rootstock), cuttings (stem/root cuttings), and tissue culture biotechnology.")
    ])
    p6.add_page("Unit 2: Nervous and Muscular Coordination", [
        ("Central Nervous System", "Brain (cerebrum, cerebellum, medulla oblongata) and spinal cord process external stimuli and reflex actions."),
        ("Skeletal Bones and Joints", "Axial skeleton (skull, vertebral column, ribcage) and appendicular skeleton (pectoral/pelvic girdles and limbs).")
    ])
    p6.add_page("Unit 3: Atomic Structure and Electrical Energy", [
        ("Atoms and Electrons", "Protons and neutrons reside in the nucleus, surrounded by negatively charged electrons in orbital energy shells."),
        ("Electric Current and Circuits", "Closed electrical circuits permit current flow driven by voltage potential across conductive wires.")
    ])
    p6.build("science_p6.pdf")

    # 7. Intermediate 1: Science Part 2 (Biology)
    m1 = SimplePDFBuilder("Science Part 2 - Grade 1 Intermediate (Biology)", "Grade 1 Intermediate", "Biology & Microscopy")
    m1.add_page("Chapter 1: The Microscope and Cellular Discovery", [
        ("History of Microscopy", "Antonie van Leeuwenhoek built early single-lens microscopes. Robert Hooke first coined the term 'cell' in 1665."),
        ("Compound Light Microscope", "Ocular lens, objective lenses (4x, 10x, 40x, 100x oil immersion), stage, condenser, and coarse/fine focus knobs.")
    ])
    m1.add_page("Chapter 2: Cytology - The Unit of Life", [
        ("Cytoplasm and Organelles", "Prokaryotic bacteria lack a membrane-bound nucleus. Eukaryotic cells possess a distinct nucleus and membrane organelles."),
        ("Plant Cell Specifics", "Rigid cellulose cell wall, large central sap vacuole, and green photosynthetic chloroplasts containing chlorophyll.")
    ])
    m1.add_page("Chapter 3: Biological Taxonomy and Five Kingdoms", [
        ("Carolus Linnaeus Binomial Nomenclature", "Two-word Latin names: Genus capitalized and species lowercase (e.g., Homo sapiens)."),
        ("Whittaker Five Kingdoms", "Monera (prokaryotes), Protista, Fungi, Plantae, and Animalia classified by morphology and nutritional mode.")
    ])
    m1.build("science_m1.pdf")
    # Also sync with biology_g1.pdf
    m1.build("biology_g1.pdf")

    # 8. Intermediate 2: Science Part 2 (Microbiology & Invertebrates)
    m2 = SimplePDFBuilder("Science Part 2 - Grade 2 Intermediate (Microbiology)", "Grade 2 Intermediate", "Microbiology & Classification")
    m2.add_page("Chapter 1: Kingdom Protista", [
        ("Sarcodina - Amoeba", "Unicellular protists that move and capture food via pseudopodia through phagocytosis. Contractile vacuoles expel water."),
        ("Ciliophora - Paramecium", "Propelled by thousands of rhythmic cilia. Possesses micronucleus for sexual conjugation and macronucleus for metabolism."),
        ("Mastigophora - Euglena", "Unicellular flagellate possessing a photoreceptive eyespot and chloroplasts for mixotrophic nutrition.")
    ])
    m2.add_page("Chapter 2: Kingdom Fungi and Spore Reproduction", [
        ("Fungal Characteristics", "Eukaryotic, heterotrophic absorptive feeders with chitinous cell walls. Hyphae aggregate into underground mycelia."),
        ("Yeasts and Penicillium", "Baker's yeast reproduces by asexual budding and produces ethanol. Penicillium molds yield natural penicillin antibiotics.")
    ])
    m2.add_page("Chapter 3: Invertebrate Animals", [
        ("Porifera and Cnidaria", "Sponges are sessile filter feeders. Jellyfish and Hydra possess stinging cnidocyte tentacles and radial symmetry."),
        ("Platyhelminthes, Annelids and Arthropods", "Flatworms (Planaria), segmented earthworms (closed circulation), and jointed-legged insects, arachnids, crustaceans.")
    ])
    m2.build("science_m2.pdf")
    # Also sync with biology_g2.pdf
    m2.build("biology_g2.pdf")

    # 9. Intermediate 3: Biology (Human Anatomy & Physiology - Ministerial)
    m3 = SimplePDFBuilder("Biology - Grade 3 Intermediate (Human Body Systems)", "Grade 3 Intermediate", "Human Anatomy & Physiology")
    m3.add_page("Chapter 1: Skeletal System (Al-Jihaz Al-Haykali)", [
        ("Axial Skeleton Components", "Cranium (8 bones), facial skeleton (14 bones), vertebral column (33 vertebrae: 7 cervical, 12 thoracic, 5 lumbar, 5 sacral, 4 coccygeal)."),
        ("Ribcage and Sternum", "True ribs (7 pairs attached to sternum), false ribs (3 pairs attached to 7th rib), floating ribs (2 pairs unattached)."),
        ("Fractures and Bone Healing", "Osteoblasts secrete calcium phosphate matrix to form callus bridge that calcifies into mature bone.")
    ])
    m3.add_page("Chapter 2: Muscular and Digestive Systems", [
        ("Muscular Types", "Skeletal voluntary striated muscles, smooth involuntary unstriated visceral muscles, and cardiac branched striated muscle."),
        ("Digestive Canal Organs", "Mouth (teeth and saliva amylase) -> Pharynx -> Esophagus (peristalsis) -> Stomach (pepsin, HCl) -> Small intestine (villi absorption)."),
        ("Liver and Pancreas Glands", "Liver secretes bile to emulsify fats and stores glycogen. Pancreas secretes insulin into blood and amylase/lipase into duodenum.")
    ])
    m3.add_page("Chapter 3: Circulatory and Respiratory Systems", [
        ("Heart Anatomy and Valves", "Tricuspid valve between right atrium and right ventricle. Bicuspid (mitral) valve between left atrium and left ventricle."),
        ("Pulmonary and Systemic Circulation", "Ibn al-Nafis and William Harvey discovered circulation. Pulmonary artery sends deoxygenated blood to lungs; Aorta delivers to body."),
        ("Blood Components and Antigens", "Red blood cells (erythrocytes, hemoglobin), white blood cells (leukocytes, immunity), platelets, plasma. ABO and Rh blood grouping.")
    ])
    m3.add_page("Chapter 4: Excretory, Nervous and Sensory Organs", [
        ("Kidney Nephrons and Filtration", "Renal cortex, medulla, pelvis. Nephrons filter blood in Bowman's capsules with tubular reabsorption of water and glucose."),
        ("Eye, Ear, and Skin Receptors", "Eye cornea, lens, retina (rods and cones). Ear tympanic membrane, ossicles, cochlea for hearing balance. Skin sweat glands.")
    ])
    m3.build("biology_m3.pdf")
    # Also sync with biology_g3.pdf
    m3.build("biology_g3.pdf")

    # 10. Preparatory 4: Scientific Biology (Ecology & Adaptation)
    s4 = SimplePDFBuilder("Biology - Grade 4 Scientific (Ecology & Zoology)", "Grade 4 Scientific", "Ecology & Morphology")
    s4.add_page("Chapter 1: Principles of Ecosystems", [
        ("Ecosystem Structure", "Biotic factors (producers, consumers, decomposers) interacting with abiotic factors (temperature, light, water, atmospheric gases, soil)."),
        ("Food Webs and Ecological Pyramids", "Pyramid of numbers, pyramid of biomass, and pyramid of energy showing 90% heat dissipation between trophic levels.")
    ])
    s4.add_page("Chapter 2: Animal Adaptations to Environments", [
        ("Morphology of Bony Fish (Pigeon/Fish Comparison)", "Streamlined spindle shape, mucous scales, swim bladder for buoyancy control, and lateral line organ for detecting pressure waves."),
        ("Avian Flight Adaptations in Pigeons", "Pneumatic hollow bones, aerodynamic contour feathers, keel bone for pectoralis flight muscles, and pulmonary air sacs for continuous respiration.")
    ])
    s4.build("biology_s4.pdf")
    # Also sync with biology_g4.pdf
    s4.build("biology_g4.pdf")

    # 11. Preparatory 5: Scientific Biology (Comparative Physiology)
    s5 = SimplePDFBuilder("Biology - Grade 5 Scientific (Comparative Physiology)", "Grade 5 Scientific", "Comparative Physiology")
    s5.add_page("Chapter 1: Nutrition and Gas Exchange", [
        ("Comparative Digestion", "Intracellular phagocytosis in protozoa. Incomplete gastrovascular cavity in Planaria. Complete alimentary tract with crop and gizzard in earthworms."),
        ("Comparative Respiration", "Cutaneous breathing across moist epidermis in earthworms. Tracheal spiracle tube networks in insects. Filamentous gills in teleost fish.")
    ])
    s5.add_page("Chapter 2: Transport and Osmoregulation", [
        ("Open vs Closed Circulation", "Open circulatory hemolymph in arthropods. Closed vascular loops with capillaries in annelids and vertebrates."),
        ("Excretion Mechanisms", "Contractile vacuoles in ciliates, flame bulb protonephridia in flatworms, Malpighian tubules in insects, and metanephric kidneys in vertebrates.")
    ])
    s5.build("biology_s5.pdf")
    # Also sync with biology_g5.pdf
    s5.build("biology_g5.pdf")

    # 12. Preparatory 6: Scientific Biology (Master Iraqi Baccalaureate Curriculum)
    s6 = SimplePDFBuilder("Biology - Grade 6 Scientific (Cell, Tissues, Reproduction & Genetics)", "Grade 6 Scientific", "Master Ministerial Biology")
    s6.add_page("Chapter 1: Cytology and Cell Division (Al-Khaliyah)", [
        ("Fluid Mosaic Membrane and Organelles", "Phospholipid bilayer with hydrophilic heads and hydrophobic tails embedded with transport proteins. Mitochondria cristae increase surface area for ATP."),
        ("Cellular Transport Processes", "Passive diffusion, osmosis across selective membranes, facilitated diffusion via carriers, active transport against gradient using ATP, phagocytosis."),
        ("Mitosis (Al-Inqisam Al-Khaiti)", "Prophase (chromosomes condense), Metaphase (equatorial alignment), Anaphase (centromere split, chromatids pull to poles), Telophase (nuclear envelopes reform)."),
        ("Meiosis (Al-Inqisam Al-Ikhtizali)", "Meiosis I reductional division with crossing over (chiasmata) in prophase I pachynema. Meiosis II equational division yielding 4 haploid (1n) gametes.")
    ])
    s6.add_page("Chapter 2: Plant and Animal Tissues (Al-Ansijah)", [
        ("Plant Tissue Categories", "Meristematic apical/intercalary/lateral cambium tissues, ground parenchyma/collenchyma/sclerenchyma tissues, dermal epidermis, and vascular xylem/phloem."),
        ("Animal Tissue Types", "Simple and stratified epithelial linings. Connective proper and specialized tissues (compact/spongy bone with Haversian systems, hyaline cartilage, erythrocytes/leukocytes in blood).")
    ])
    s6.add_page("Chapter 3: Reproduction and Embryology (Al-Takathur)", [
        ("Viral and Bacterial Reproduction", "Bacteriophage lytic and lysogenic cycles in E. coli. Bacterial binary fission and sexual conjugation via pilus sex factors."),
        ("Angiosperm Flower Reproduction", "Microsporogenesis in anthers producing pollen grains (tube and generative cells). Megasporogenesis in ovules producing 8-nucleate embryo sac. Double fertilization.")
    ])
    s6.add_page("Chapter 4 & 5: Classical and Molecular Genetics (Al-Wirathah)", [
        ("Mendel's Laws of Inheritance", "Law of Segregation: alleles separate into gametes. Law of Independent Assortment: non-homologous gene pairs assort freely. Testcross and backcross methods."),
        ("Non-Mendelian Genetics and Molecular Biology", "Incomplete dominance (Mirabilis jalapa snapdragon), codominance (ABO blood groups, MN antigens), lethal alleles, multiple alleles, sex linkage in Drosophila. DNA structure (Watson-Crick double helix), transcription into mRNA, and tRNA ribosome translation into polypeptides.")
    ])
    s6.build("biology_s6.pdf")

    # 13. Higher Biology: Campbell Biology (Translation Summary)
    camp = SimplePDFBuilder("Campbell Biology - Academic Arabic & English Edition", "University & Postgraduate", "Comprehensive Biological Sciences")
    camp.add_page("Module 1: The Molecular Basis of Life", [
        ("Biomolecules and Macromolecules", "Proteins (peptide bonds, alpha helices, beta sheets), Nucleic acids (phosphodiester backbones, purines and pyrimidines), Carbohydrates, and Lipids."),
        ("Cellular Energetics and Thermodynamics", "First and second laws of thermodynamics. Free energy (delta G). Coupled ATP hydrolysis driving endergonic cellular reactions.")
    ])
    camp.add_page("Module 2: Molecular Genetics and Biotechnology", [
        ("DNA Replication and Repair", "Leading and lagging strands, Okazaki fragments, DNA polymerases, helicase, topoisomerase, and proofreading mismatch repair."),
        ("Recombinant DNA and CRISPR-Cas9", "Restriction endonucleases, plasmid cloning vectors, PCR amplification, Sanger sequencing, and CRISPR RNA-guided genomic editing.")
    ])
    camp.build("campbell_biology_ar.pdf")

    # 14. Higher Biology: Alberts Molecular Biology of the Cell
    alb = SimplePDFBuilder("Molecular Biology of the Cell - Alberts Academic Edition", "Postgraduate & Research", "Molecular & Cellular Biology")
    alb.add_page("Chapter 1: Membrane Architecture and Ion Channels", [
        ("Lipid Bilayers and Membrane Proteins", "Asymmetry of inner and outer leaflets, lipid rafts, GPI-anchored proteins, and voltage-gated ion channels mediating action potentials."),
        ("Intracellular Protein Trafficking", "Signal recognition particles (SRP), translocons on endoplasmic reticulum, COP-I and COP-II coat vesicles, and clathrin-mediated endocytosis.")
    ])
    alb.add_page("Chapter 2: Signal Transduction and Cell Cycle Control", [
        ("Receptor Tyrosine Kinases and GPCRs", "Ligand dimerization, auto-phosphorylation, Ras-MAPK cascade, and G-protein alpha/beta/gamma subunits activating adenylyl cyclase."),
        ("Cyclins, CDKs, and Checkpoints", "Cyclin-dependent kinases regulated by Wee1 and Cdc25. P53 tumor suppressor guardian of the genome arresting cells at G1/S upon DNA damage.")
    ])
    alb.build("alberts_cell_biology_ar.pdf")

if __name__ == '__main__':
    build_all_curriculum()
