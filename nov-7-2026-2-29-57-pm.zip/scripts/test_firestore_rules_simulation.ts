/**
 * Automated Security Simulation Test Suite
 * Tests all 12 Dirty Dozen Attack Payloads and Legitimate Operations
 * Against DRAFT_firestore.rules and storage.rules
 */

interface AuthContext {
  uid: string | null;
  token?: {
    email?: string;
    email_verified?: boolean;
  };
}

interface UserDoc {
  id: string;
  uid: string;
  name: string;
  track: string;
  role: string;
  status: string;
  isVip?: boolean;
  unlockedLectures?: number[];
  grade?: string;
  deviceType?: string;
  birthDate?: string | null;
  birthYear?: number | null;
  registeredAt?: string;
  lastActive?: string;
  notes?: string;
}

// Logic implementations mirroring DRAFT_firestore.rules
function isSignedIn(auth: AuthContext): boolean {
  return auth.uid !== null;
}

function isValidId(id: string): boolean {
  return typeof id === 'string' && id.length <= 128 && /^[a-zA-Z0-9_\-]+$/.test(id);
}

function isVerifiedAdmin(auth: AuthContext, trustedAdmins: Set<string>): boolean {
  if (!isSignedIn(auth)) return false;
  const isEmailAdmin = auth.token?.email === 'abdullahmiqdad2007@gmail.com' && auth.token?.email_verified === true;
  const isDocAdmin = auth.uid ? trustedAdmins.has(auth.uid) : false;
  return isEmailAdmin || isDocAdmin;
}

function isValidUserCreation(data: any, userId: string): boolean {
  if (!data || typeof data !== 'object') return false;
  const required = ['id', 'uid', 'name', 'track', 'role', 'status'];
  for (const k of required) {
    if (!(k in data)) return false;
  }
  if (typeof data.name !== 'string' || data.name.length === 0 || data.name.length > 100) return false;
  if (data.uid !== userId) return false;
  if (!['school', 'university'].includes(data.track)) return false;
  if (data.role !== 'student') return false; // Prevent self-elevation!
  if (data.status !== 'active') return false;
  if ('isVip' in data && data.isVip === true) return false; // Prevent self-VIP!
  if ('unlockedLectures' in data && Array.isArray(data.unlockedLectures) && data.unlockedLectures.length > 0) return false;
  if ('grade' in data && (typeof data.grade !== 'string' || data.grade.length > 30)) return false;
  return true;
}

function isValidUserStudentUpdate(incomingData: any, existingData: any): boolean {
  if (typeof incomingData.name !== 'string' || incomingData.name.length === 0 || incomingData.name.length > 100) return false;
  // Immutability checks
  if (incomingData.uid !== existingData.uid) return false;
  if (incomingData.id !== existingData.id) return false;
  if (incomingData.role !== existingData.role) return false;
  if (incomingData.isVip !== existingData.isVip) return false;
  if (incomingData.status !== existingData.status) return false;
  if (JSON.stringify(incomingData.unlockedLectures) !== JSON.stringify(existingData.unlockedLectures)) return false;
  if (existingData.registeredAt && incomingData.registeredAt !== existingData.registeredAt) return false;

  // Allowed affected keys only
  const allowed = new Set(['name', 'birthDate', 'birthYear', 'grade', 'deviceType', 'lastActive', 'track']);
  for (const key of Object.keys(incomingData)) {
    if (incomingData[key] !== existingData[key] && !allowed.has(key)) {
      return false;
    }
  }
  return true;
}

function evaluateFirestoreRule(
  operation: 'get' | 'list' | 'create' | 'update' | 'delete',
  collectionPath: string,
  docId: string,
  auth: AuthContext,
  payload?: any,
  existingDoc?: any,
  trustedAdmins: Set<string> = new Set()
): { allowed: boolean; reason: string } {
  const isAdmin = isVerifiedAdmin(auth, trustedAdmins);

  // 1. Users collection
  if (collectionPath === 'users') {
    if (operation === 'get') {
      const allowed = isAdmin || (isSignedIn(auth) && auth.uid === docId);
      return { allowed, reason: allowed ? 'Owner or admin' : 'Cannot read other student profile PII' };
    }
    if (operation === 'list') {
      return { allowed: isAdmin, reason: isAdmin ? 'Admin list authorized' : 'Listing all users blocked' };
    }
    if (operation === 'create') {
      if (isAdmin) return { allowed: true, reason: 'Admin can create user' };
      const allowed = isSignedIn(auth) && isValidId(docId) && auth.uid === docId && isValidUserCreation(payload, docId);
      return { allowed, reason: allowed ? 'Valid student self-registration' : 'Invalid payload or role escalation attempt' };
    }
    if (operation === 'update') {
      if (isAdmin) return { allowed: true, reason: 'Admin can update user' };
      const allowed = isSignedIn(auth) && isValidId(docId) && auth.uid === docId && isValidUserStudentUpdate(payload, existingDoc);
      return { allowed, reason: allowed ? 'Valid student profile update' : 'Privilege escalation or immutable field tampering' };
    }
    if (operation === 'delete') {
      return { allowed: isAdmin, reason: isAdmin ? 'Admin deletion authorized' : 'Student cannot delete accounts' };
    }
  }

  // 2. VIP Secret Codes
  if (collectionPath === 'lecture_codes') {
    return { allowed: isAdmin, reason: isAdmin ? 'Admin access to codes' : 'VIP secret codes confidential' };
  }

  // 3. Lectures
  if (collectionPath === 'lectures') {
    if (operation === 'get' || operation === 'list') {
      return { allowed: true, reason: 'Lectures publicly readable' };
    }
    return { allowed: isAdmin, reason: isAdmin ? 'Admin lecture management' : 'Lectures write restricted to admin' };
  }

  // 4. Curriculum Books
  if (collectionPath === 'curriculum_books') {
    if (operation === 'get' || operation === 'list') {
      return { allowed: true, reason: 'Books publicly readable' };
    }
    return { allowed: isAdmin, reason: isAdmin ? 'Admin book management' : 'Books write restricted to admin' };
  }

  // 5. Backups
  if (collectionPath === 'backups') {
    return { allowed: isAdmin, reason: isAdmin ? 'Admin backup access' : 'Backups strictly admin-only' };
  }

  // Storage simulation
  if (collectionPath === 'storage_books') {
    if (operation === 'get') return { allowed: true, reason: 'Public educational book download' };
    const valid = isAdmin && (payload.contentType === 'application/pdf' || payload.contentType === 'application/octet-stream') && payload.size <= 100 * 1024 * 1024;
    return { allowed: valid, reason: valid ? 'Admin valid book upload' : 'Invalid type, oversized or unauthorized' };
  }

  if (collectionPath === 'storage_covers') {
    if (operation === 'get') return { allowed: true, reason: 'Public cover download' };
    const valid = isAdmin && String(payload.contentType).startsWith('image/') && payload.size <= 10 * 1024 * 1024;
    return { allowed: valid, reason: valid ? 'Admin valid cover upload' : 'Invalid type, oversized or unauthorized' };
  }

  return { allowed: false, reason: 'Default deny catch-all' };
}

// RUN THE TEST SUITE
async function runSimulationTests() {
  console.log('===============================================================');
  console.log('🧪 بدء اختبار المحاكاة الأمني الشامل لقواعد Firestore وStorage');
  console.log('===============================================================\n');

  let passed = 0;
  let failed = 0;

  function assertRule(
    testNum: number,
    description: string,
    result: { allowed: boolean; reason: string },
    expectedAllowed: boolean
  ) {
    const isSuccess = result.allowed === expectedAllowed;
    if (isSuccess) {
      passed++;
      console.log(`✅ [اختبار #${testNum} ناجح]: ${description}`);
      console.log(`   النتيجة: ${result.allowed ? 'مسموح (ALLOWED)' : 'مرفوض أمنياً (DENIED)'} | السبب: ${result.reason}`);
    } else {
      failed++;
      console.error(`❌ [اختبار #${testNum} فاشل!]: ${description}`);
      console.error(`   المتوقع: ${expectedAllowed ? 'مسموح' : 'مرفوض'} لكن تم الحصول على: ${result.allowed} (${result.reason})`);
    }
  }

  // Personas
  const adminAuth: AuthContext = {
    uid: 'ADMIN_UID_1',
    token: { email: 'abdullahmiqdad2007@gmail.com', email_verified: true }
  };
  const spoofAdminAuth: AuthContext = {
    uid: 'ATTACKER_UID',
    token: { email: 'abdullahmiqdad2007@gmail.com', email_verified: false }
  };
  const studentAuth: AuthContext = {
    uid: 'UID-BIO-1001',
    token: { email: 'student@wissam.com', email_verified: true }
  };
  const studentBAuth: AuthContext = {
    uid: 'UID-BIO-1002',
    token: { email: 'student2@wissam.com', email_verified: true }
  };
  const unauth: AuthContext = { uid: null };

  const existingStudentDoc: UserDoc = {
    id: 'STU-1001',
    uid: 'UID-BIO-1001',
    name: 'علي كرار البصري',
    track: 'school',
    role: 'student',
    status: 'active',
    isVip: false,
    unlockedLectures: [],
    grade: 'g6',
    registeredAt: '2026-10-01'
  };

  // --- THE DIRTY DOZEN MALICIOUS ATTACKS (MUST BE BLOCKED / DENIED) ---
  console.log('--- فحص الحزم الخبيثة الـ 12 (Dirty Dozen) ---');

  // Vector 1: Self-Assigned Role Escalation
  assertRule(
    1,
    'محاولة طالب ترقية حسابه بنفسه إلى مدير (role: admin) عند التسجيل',
    evaluateFirestoreRule('create', 'users', 'UID-BIO-ATTACK', { uid: 'UID-BIO-ATTACK' }, {
      id: 'STU-HACK',
      uid: 'UID-BIO-ATTACK',
      name: 'مهاجم',
      track: 'school',
      role: 'admin',
      status: 'active'
    }),
    false
  );

  // Vector 2: Shadow Update / VIP Theft
  assertRule(
    2,
    'محاولة طالب تفعيل اشتراك VIP ومحاضرات مجانية لنفسه عبر updateDoc',
    evaluateFirestoreRule('update', 'users', 'UID-BIO-1001', studentAuth, {
      ...existingStudentDoc,
      isVip: true,
      role: 'vip',
      unlockedLectures: [101, 102]
    }, existingStudentDoc),
    false
  );

  // Vector 3: VIP Secret Code Scraping
  assertRule(
    3,
    'محاولة طالب قراءة أكواد VIP السرية من مجموعة lecture_codes',
    evaluateFirestoreRule('get', 'lecture_codes', 'VIP-BIO-2026-HCVK', studentAuth),
    false
  );

  // Vector 4: Lecture Destruction Attack
  assertRule(
    4,
    'محاولة مستخدم عادي أو طالب حذف محاضرة تعليمية من المنصة',
    evaluateFirestoreRule('delete', 'lectures', '1793693034970', studentAuth),
    false
  );

  // Vector 5: Curriculum Defacement
  assertRule(
    5,
    'محاولة تعديل كتاب وزاري ووضع رابط تصيد احتيالي من قبل زائر غير مصرح',
    evaluateFirestoreRule('update', 'curriculum_books', 'b6', unauth, { title: 'مخترق', pdfUrl: 'https://evil.com/fake.pdf' }),
    false
  );

  // Vector 6: Cross-Student PII Harvesting
  assertRule(
    6,
    'محاولة طالب قراءة البيانات الشخصية ورقم هاتف طالب آخر من مجموعة users',
    evaluateFirestoreRule('get', 'users', 'UID-BIO-1002', studentAuth),
    false
  );

  // Vector 7: ID Poisoning (Malformed URI)
  assertRule(
    7,
    'محاولة حقن معرف غير صالح وملوث بالرموز ($$$INVALID_ID$$$)',
    evaluateFirestoreRule('create', 'users', '$$$INVALID_ID$$$', { uid: '$$$INVALID_ID$$$' }, {
      id: 'STU-1',
      uid: '$$$INVALID_ID$$$',
      name: 'Test',
      track: 'school',
      role: 'student',
      status: 'active'
    }),
    false
  );

  // Vector 8: Denial of Wallet (Data Bloat)
  assertRule(
    8,
    'محاولة إرسال اسم ضخم بطول 50,000 حرف لاستهلاك سعة التخزين',
    evaluateFirestoreRule('create', 'users', 'UID-BIO-1001', studentAuth, {
      id: 'STU-1001',
      uid: 'UID-BIO-1001',
      name: 'A'.repeat(50000),
      track: 'school',
      role: 'student',
      status: 'active'
    }),
    false
  );

  // Vector 9: Unverified Admin Email Spoof
  assertRule(
    9,
    'محاولة انتحال بريد المدير ولكن مع email_verified: false',
    evaluateFirestoreRule('delete', 'backups', 'backup_123', spoofAdminAuth),
    false
  );

  // Vector 10: Administrative Backup Erasure
  assertRule(
    10,
    'محاولة طالب حذف نسخة احتياطية سحابية من مجموعة backups',
    evaluateFirestoreRule('delete', 'backups', 'backup_1793693034970', studentAuth),
    false
  );

  // Vector 11: Malicious Executable Storage
  assertRule(
    11,
    'محاولة رفع ملف تنفيذي خبيث (.exe) إلى مجلد كتب الـ PDF في التخزين السحابي',
    evaluateFirestoreRule('create', 'storage_books', 'malware.exe', adminAuth, {
      contentType: 'application/x-msdownload',
      size: 5 * 1024 * 1024
    }),
    false
  );

  // Vector 12: Storage Denial of Service (Oversized Cover Image)
  assertRule(
    12,
    'محاولة رفع صورة غلاف بحجم 50MB (يتجاوز سقف الـ 10MB المحدد)',
    evaluateFirestoreRule('create', 'storage_covers', 'giant.jpg', adminAuth, {
      contentType: 'image/jpeg',
      size: 50 * 1024 * 1024
    }),
    false
  );

  // --- LEGITIMATE OPERATIONS (MUST SUCCEED / BE ALLOWED) ---
  console.log('\n--- فحص العمليات المشروعة للمدير والطلاب (Legitimate Operations) ---');

  // Valid 1: Student reads own profile
  assertRule(
    13,
    'طالب يقرأ ملفه الشخصي الخاص به (users/UID-BIO-1001)',
    evaluateFirestoreRule('get', 'users', 'UID-BIO-1001', studentAuth),
    true
  );

  // Valid 2: Student updates legitimate profile fields (grade, name, deviceType)
  assertRule(
    14,
    'طالب يعدل اسمه أو صفه الدراسي دون المساس بصلاحيات الـ VIP أو الدور',
    evaluateFirestoreRule('update', 'users', 'UID-BIO-1001', studentAuth, {
      ...existingStudentDoc,
      name: 'علي كرار البصري المحدث',
      grade: 'g6'
    }, existingStudentDoc),
    true
  );

  // Valid 3: Student reads lectures
  assertRule(
    15,
    'طالب أو زائر يتصفح قائمة المحاضرات التعليمية العامة',
    evaluateFirestoreRule('get', 'lectures', '1793693034970', studentAuth),
    true
  );

  // Valid 4: Student reads curriculum books
  assertRule(
    16,
    'طالب يتصفح كتاب الأحياء للصف السادس العلمي (curriculum_books/b6)',
    evaluateFirestoreRule('get', 'curriculum_books', 'b6', studentAuth),
    true
  );

  // Valid 5: Admin manages lectures
  assertRule(
    17,
    'المدير المعتمد يضيف محاضرة جديدة مع رابط يوتيوب والبيانات',
    evaluateFirestoreRule('create', 'lectures', '1793693034988', adminAuth, {
      id: 1793693034988,
      title: 'شرح الخلية والانقسام الاختزالي',
      grade: 'g6',
      videoUrl: 'https://www.youtube.com/watch?v=sample'
    }),
    true
  );

  // Valid 6: Admin manages VIP codes
  assertRule(
    18,
    'المدير المعتمد يولد كود VIP سري للطالب',
    evaluateFirestoreRule('create', 'lecture_codes', 'VIP-BIO-2026-TEST', adminAuth, {
      code: 'VIP-BIO-2026-TEST',
      targetUid: 'UID-BIO-1001',
      status: 'active'
    }),
    true
  );

  // Valid 7: Admin uploads a valid curriculum PDF (under 100MB)
  assertRule(
    19,
    'المدير المعتمد يرفع ملف PDF لكتاب وزاري بحجم 35MB',
    evaluateFirestoreRule('create', 'storage_books', 'biology_g6.pdf', adminAuth, {
      contentType: 'application/pdf',
      size: 35 * 1024 * 1024
    }),
    true
  );

  console.log('\n===============================================================');
  console.log(`📊 النتيجة النهائية للاختبارات: ${passed} ناجح | ${failed} فاشل من أصل ${passed + failed}`);
  console.log('===============================================================');

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runSimulationTests();
