import fs from 'fs';
import path from 'path';

interface AuditResult {
  category: string;
  item: string;
  status: 'OK' | 'WARNING' | 'FAIL';
  detail: string;
}

const results: AuditResult[] = [];

// 1. Check local data files and uploads
const uploadsDir = path.resolve(process.cwd(), 'public', 'uploads');
const booksDir = path.join(uploadsDir, 'books');
const videosDir = path.join(uploadsDir, 'videos');
const coversDir = path.join(uploadsDir, 'covers');

const booksFiles = fs.existsSync(booksDir) ? fs.readdirSync(booksDir) : [];
const videosFiles = fs.existsSync(videosDir) ? fs.readdirSync(videosDir) : [];
const coversFiles = fs.existsSync(coversDir) ? fs.readdirSync(coversDir) : [];

// Read JSON databases
const lecturesFile = path.resolve(process.cwd(), 'data', 'lectures.json');
const curriculumBooksFile = path.resolve(process.cwd(), 'data', 'curriculum_books.json');
const usersFile = path.resolve(process.cwd(), 'data', 'users.json');

const lectures = fs.existsSync(lecturesFile) ? JSON.parse(fs.readFileSync(lecturesFile, 'utf-8')) : [];
const books = fs.existsSync(curriculumBooksFile) ? JSON.parse(fs.readFileSync(curriculumBooksFile, 'utf-8')) : [];
const users = fs.existsSync(usersFile) ? JSON.parse(fs.readFileSync(usersFile, 'utf-8')) : [];

console.log(`\n--- فحص السجلات والملفات المحلية والسحابية ---`);
console.log(`المحاضرات المحلية: ${lectures.length}`);
console.log(`الكتب المحلية: ${books.length}`);
console.log(`الطلاب المحليون: ${users.length}`);
console.log(`ملفات PDF في uploads/books: ${booksFiles.length} (${booksFiles.join(', ')})`);
console.log(`ملفات الفيديو في uploads/videos: ${videosFiles.length} (${videosFiles.join(', ')})`);
console.log(`صور الغلاف في uploads/covers: ${coversFiles.length} (${coversFiles.join(', ')})`);

// 2. Check for missing files in books
for (const book of books) {
  if (book.pdfUrl && book.pdfUrl.startsWith('/uploads/')) {
    const localPath = path.resolve(process.cwd(), 'public', book.pdfUrl.replace(/^\/+/, ''));
    if (!fs.existsSync(localPath)) {
      results.push({
        category: 'Orphan Record',
        item: `Book: ${book.title} (${book.id})`,
        status: 'WARNING',
        detail: `يشير إلى ملف محلي غير موجود: ${book.pdfUrl}`
      });
    }
  }
}

// 3. Check for orphan files in uploads/books
for (const file of booksFiles) {
  const isReferencedInBooks = books.some((b: any) => b.pdfUrl?.includes(file) || b.fileUrl?.includes(file));
  if (!isReferencedInBooks) {
    results.push({
      category: 'Unlinked Storage File',
      item: `File: /uploads/books/${file}`,
      status: 'WARNING',
      detail: `الملف موجود في القرص لكنه غير مسند لأي كتاب في قاعدة البيانات`
    });
  }
}

// 4. Check for orphan files in uploads/videos
for (const file of videosFiles) {
  const isReferenced = lectures.some((l: any) => l.videoUrl?.includes(file));
  if (!isReferenced) {
    results.push({
      category: 'Unlinked Storage File',
      item: `File: /uploads/videos/${file}`,
      status: 'WARNING',
      detail: `ملف فيديو مخزن في uploads/videos غير مرتبط بأي محاضرة حالياً`
    });
  }
}

// 5. Check lectures video URLs
for (const lec of lectures) {
  if (!lec.videoUrl || !lec.videoUrl.trim()) {
    results.push({
      category: 'Orphan Lecture',
      item: `Lecture: ${lec.title} (${lec.id})`,
      status: 'FAIL',
      detail: `المحاضرة بدون رابط فيديو!`
    });
  }
}

console.log('\n--- نتائج التدقيق المكتشفة ---');
for (const res of results) {
  console.log(`[${res.status}] ${res.category} -> ${res.item}: ${res.detail}`);
}
if (results.length === 0) {
  console.log('✅ جميع السجلات والملفات متطابقة ولا توجد ملفات يتيمة أو روابط مكسورة');
}
