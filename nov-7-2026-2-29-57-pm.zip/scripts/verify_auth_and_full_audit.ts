import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, collection, getDocs, doc, getDoc, setDoc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import firebaseConfig from '../firebase-applet-config.json';
import { 
  isUserAdmin, 
  translateAuthError,
  syncAuthUserWithProfile
} from '../src/services/firebase';

async function runComprehensiveAudit() {
  console.log('====================================================');
  console.log('🧪 بدء الفحص والتدقيق الهندسي الشامل لمنصة الكائنات');
  console.log('====================================================\n');

  let passedTests = 0;
  let totalTests = 0;

  function assert(condition: boolean, testName: string, details?: any) {
    totalTests++;
    if (condition) {
      passedTests++;
      console.log(`✅ [نجاح] ${testName}`);
    } else {
      console.error(`❌ [فشل] ${testName}`);
      if (details) console.error('  التفاصيل:', details);
    }
  }

  // 1. Firebase App & Services Initialization
  console.log('--- 1. فحص تهيئة خدمات Firebase ---');
  const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  assert(Boolean(app), 'تهيئة تطبيق Firebase App');

  const auth = getAuth(app);
  assert(Boolean(auth), 'تهيئة محرك Firebase Authentication');

  const rawDbId = (firebaseConfig as any)?.firestoreDatabaseId || 'ai-studio-85798a9e-7365-46c6-bde9-0a484132186b';
  const db = getFirestore(app, rawDbId);
  assert(Boolean(db), `تهيئة قاعدة بيانات Firestore مع المعرف (${rawDbId})`);

  // 2. Admin Permission Resolver
  console.log('\n--- 2. فحص صلاحيات الإدارة ومطابقة البريد ---');
  const adminTestUser = { email: 'abdullahmiqdad2007@gmail.com', uid: 'admin_test_uid' } as any;
  const adminEmailTest = isUserAdmin(adminTestUser);
  assert(adminEmailTest === true, 'التعرف على بريد الأستاذ عبدالله مقداد كمدير للمنصة (abdullahmiqdad2007@gmail.com)');

  const secondaryAdminUser = { email: 'admin@wissam.com', uid: 'admin2_test_uid' } as any;
  assert(isUserAdmin(secondaryAdminUser) === true, 'التعرف على بريد إدارة وسام كمدير بديل (admin@wissam.com)');

  const normalStudentUser = { email: 'student123@gmail.com', uid: 'student_test_uid' } as any;
  assert(isUserAdmin(normalStudentUser) === false, 'حساب الطالب العادي لا يحصل على صلاحية مدير');

  // 3. Error Translation Mapping
  console.log('\n--- 3. فحص ترجمة أخطاء Firebase Auth للغة العربية ---');
  const err1 = translateAuthError({ code: 'auth/wrong-password' });
  assert(err1.includes('كلمة المرور غير صحيحة'), 'ترجمة خطأ كلمة المرور غير صحيحة');

  const err2 = translateAuthError({ code: 'auth/email-already-in-use' });
  assert(err2.includes('مسجل لدينا بالفعل'), 'ترجمة خطأ البريد مستخدم مسبقاً');

  const err3 = translateAuthError({ code: 'auth/invalid-email' });
  assert(err3.includes('صيغة البريد'), 'ترجمة خطأ صيغة البريد غير صالحة');

  const err4 = translateAuthError({ code: 'auth/weak-password' });
  assert(err4.includes('ضعيفة'), 'ترجمة خطأ كلمة المرور ضعيفة');

  const err5 = translateAuthError({ code: 'auth/popup-closed-by-user' });
  assert(err5.includes('تم إغلاق نافذة'), 'ترجمة خطأ إغلاق النافذة المنبثقة');

  // 4. Verify Firestore Collections & 15 Students Preservation
  console.log('\n--- 4. فحص حفظ وعدم فقدان سجلات الطلاب الـ 15 ومجموعات Firestore ---');
  try {
    const usersSnap = await getDocs(collection(db, 'users'));
    console.log(`  عدد سجلات الطلاب الحالية في Firestore: ${usersSnap.size}`);
    assert(usersSnap.size >= 15, `الحفاظ على الطلاب الـ 15 في قاعدة البيانات (العدد الفعلي: ${usersSnap.size})`);

    let hasBioPrefix = 0;
    usersSnap.forEach((d) => {
      const data = d.data();
      if ((data.uid && data.uid.startsWith('UID-BIO-')) || d.id.startsWith('UID-BIO-')) {
        hasBioPrefix++;
      }
    });
    assert(hasBioPrefix >= 10, `التحقق من بادئة معرّف المنصة UID-BIO- (العدد: ${hasBioPrefix})`);
  } catch (err: any) {
    assert(false, 'فحص سجلات الطلاب في Firestore', err?.message);
  }

  // 5. Verify Curriculum Books & Lectures in Firestore
  console.log('\n--- 5. فحص المناهج والكتب والمحاضرات في Firestore ---');
  try {
    const booksSnap = await getDocs(collection(db, 'curriculum_books'));
    assert(booksSnap.size >= 6, `كتب وملازم المناهج الوزارية موجودة في Firestore (العدد: ${booksSnap.size})`);

    const lecturesSnap = await getDocs(collection(db, 'lectures'));
    assert(lecturesSnap.size >= 1, `محاضرات المنصة مسجلة في Firestore (العدد: ${lecturesSnap.size})`);
  } catch (err: any) {
    assert(false, 'فحص الكتب والمحاضرات في Firestore', err?.message);
  }

  // 6. Test Server HTTP Endpoints
  console.log('\n--- 6. فحص واجهات السيرفر HTTP API (localhost:3000) ---');
  try {
    const resLectures = await fetch('http://localhost:3000/api/lectures');
    const dataLectures = await resLectures.json();
    assert(resLectures.ok && dataLectures.success, 'GET /api/lectures تعمل بنجاح');

    const resUsers = await fetch('http://localhost:3000/api/users');
    const dataUsers = await resUsers.json();
    assert(resUsers.ok && dataUsers.success && Array.isArray(dataUsers.users), 'GET /api/users تعمل بنجاح مع إحصائيات الطلاب');

    const resSettings = await fetch('http://localhost:3000/api/settings');
    const dataSettings = await resSettings.json();
    assert(resSettings.ok && dataSettings.success, 'GET /api/settings تعمل بنجاح');

    const adminToken = 'wissam_bio_admin_token_2026_secure';
    const resHealth = await fetch('http://localhost:3000/api/admin/cloud/health', {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const dataHealth = await resHealth.json();
    assert(resHealth.ok && dataHealth.success && dataHealth.status === 'healthy' && dataHealth.services?.firestore?.status === 'connected', 'GET /api/admin/cloud/health تعمل بحالة صحية ممتازة مع اتصال Firestore');

    const resFiles = await fetch('http://localhost:3000/api/admin/cloud/files', {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const dataFiles = await resFiles.json();
    assert(resFiles.ok && dataFiles.success && Array.isArray(dataFiles.files), 'GET /api/admin/cloud/files تعمل بنجاح مع تتبع الملفات');

    const resIntegrity = await fetch('http://localhost:3000/api/admin/cloud/integrity-audit', {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const dataIntegrity = await resIntegrity.json();
    assert(resIntegrity.ok && dataIntegrity.success && dataIntegrity.summary && typeof dataIntegrity.integrityScore === 'number', 'GET /api/admin/cloud/integrity-audit تعمل بنجاح مع فحص الروابط اليتيمة وسلامة المراجع');

    // Test session sync API
    const resSync = await fetch('http://localhost:3000/api/users/sync-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: 'TEST-AUDIT-SESSION',
        uid: 'UID-BIO-TEST-0001',
        name: 'طالب تدقيق تجريبي',
        track: 'school',
        grade: 'g6',
        deviceType: 'web-desktop'
      })
    });
    const dataSync = await resSync.json();
    assert(resSync.ok && dataSync.success, 'POST /api/users/sync-session مزامنة جلسة الطالب مع السيرفر');
  } catch (err: any) {
    assert(false, 'فحص واجهات السيرفر HTTP API', err?.message);
  }

  console.log('\n====================================================');
  console.log(`📊 النتيجة النهائية للفحص الهندسي: ${passedTests}/${totalTests} اختبار اجتاز بنجاح`);
  console.log('====================================================\n');

  if (passedTests === totalTests) {
    console.log('🎯 جميع الاختبارات اجتازت بنجاح بنسبة 100%! النظام جاهز ومكتمل ومتماسك.');
    process.exit(0);
  } else {
    console.error('⚠️ هناك اختبارات لم تجتز بنجاح!');
    process.exit(1);
  }
}

runComprehensiveAudit().catch((e) => {
  console.error('Fatal audit failure:', e);
  process.exit(1);
});
