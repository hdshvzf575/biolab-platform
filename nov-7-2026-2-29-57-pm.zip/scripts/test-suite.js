import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const baseDir = path.resolve(__dirname, '..');

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;

function assert(condition, message) {
  totalTests++;
  if (condition) {
    console.log(`  ✓ PASS: ${message}`);
    passedTests++;
  } else {
    console.error(`  ✗ FAIL: ${message}`);
    failedTests++;
  }
}

async function testHttpEndpoint(endpoint, expectedType, minBytes) {
  return new Promise((resolve) => {
    http.get(`http://localhost:3000${endpoint}`, (res) => {
      let dataChunks = [];
      res.on('data', chunk => dataChunks.push(chunk));
      res.on('end', () => {
        const buffer = Buffer.concat(dataChunks);
        const is200 = res.statusCode === 200;
        const typeMatch = res.headers['content-type'] && res.headers['content-type'].includes(expectedType);
        const sizeValid = buffer.length >= minBytes;
        const isPkHeader = buffer.slice(0, 2).toString('ascii') === 'PK';

        assert(is200, `${endpoint} returns HTTP 200 OK (got ${res.statusCode})`);
        assert(typeMatch, `${endpoint} Content-Type is ${res.headers['content-type']}`);
        assert(sizeValid, `${endpoint} size is valid (${buffer.length} bytes)`);
        assert(isPkHeader, `${endpoint} contains valid ZIP/APK magic header ('PK')`);
        resolve();
      });
    }).on('error', (err) => {
      assert(false, `Request to ${endpoint} failed: ${err.message}`);
      resolve();
    });
  });
}

function makeHttpRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, headers: res.headers, data: JSON.parse(body) });
        } catch (e) {
          resolve({ status: res.statusCode, headers: res.headers, text: body });
        }
      });
    });
    req.on('error', reject);
    if (postData) {
      req.write(typeof postData === 'string' ? postData : JSON.stringify(postData));
    }
    req.end();
  });
}

async function runTests() {
  console.log('\n--- 1. Testing APK & Project Download Endpoints ---');
  await testHttpEndpoint('/biolab.apk', 'application/vnd.android.package-archive', 1000);
  await testHttpEndpoint('/app-release.apk', 'application/vnd.android.package-archive', 1000);
  await testHttpEndpoint('/android-project.zip', 'application/zip', 5000);

  console.log('\n--- 2. Testing APK File Contents & Structure ---');
  const apkPath = path.join(baseDir, 'public', 'biolab.apk');
  assert(fs.existsSync(apkPath), `biolab.apk exists on disk at ${apkPath}`);
  const apkStat = fs.statSync(apkPath);
  assert(apkStat.size > 1000, `biolab.apk size is ${apkStat.size} bytes (not empty)`);

  console.log('\n--- 3. Testing Cloud Server Health & Lectures API ---');
  try {
    const healthRes = await makeHttpRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/health',
      method: 'GET'
    });
    assert(healthRes.status === 200 && healthRes.data?.online === true, '/api/health returns HTTP 200 with online: true');

    const lecturesRes = await makeHttpRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/lectures',
      method: 'GET'
    });
    assert(lecturesRes.status === 200 && lecturesRes.data?.success === true, 'GET /api/lectures returns HTTP 200 with success: true');
    assert(Array.isArray(lecturesRes.data?.lectures) && lecturesRes.data.lectures.length > 0, `GET /api/lectures returned ${lecturesRes.data?.lectures?.length} synced lectures`);

    // Test POST /api/lectures (Publishing video lecture over internet)
    const testLecturePayload = {
      title: 'محاضرة اختبارية: التنفس الخلوي في حقيقيات النواة',
      desc: 'فيديو تجريبي لفحص المزامنة الحية عبر الإنترنت',
      grade: 'g6',
      videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      isPaid: false
    };

    const addLecRes = await makeHttpRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/lectures',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, testLecturePayload);

    assert(addLecRes.status === 201 && addLecRes.data?.success === true, 'POST /api/lectures successfully publishes new video to cloud');
    const createdLectureId = addLecRes.data?.lecture?.id;
    assert(typeof createdLectureId === 'number', `Created lecture has valid numeric ID: ${createdLectureId}`);

    // Clean up created test lecture
    if (createdLectureId) {
      const delLecRes = await makeHttpRequest({
        hostname: 'localhost',
        port: 3000,
        path: `/api/lectures/${createdLectureId}`,
        method: 'DELETE'
      });
      assert(delLecRes.status === 200 && delLecRes.data?.success === true, `DELETE /api/lectures/${createdLectureId} deletes lecture from cloud`);
    }
  } catch (err) {
    assert(false, `Cloud Lectures API test failed: ${err.message}`);
  }

  console.log('\n--- 4. Testing User Management API (إدارة المستخدمين) ---');
  try {
    const usersRes = await makeHttpRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/users',
      method: 'GET'
    });
    assert(usersRes.status === 200 && usersRes.data?.success === true, 'GET /api/users returns HTTP 200 with success: true');
    assert(Array.isArray(usersRes.data?.users) && usersRes.data.users.length > 0, `GET /api/users returned ${usersRes.data?.users?.length} users`);
    assert(usersRes.data?.stats && usersRes.data.stats.total > 0, 'GET /api/users contains live real-time stats object');

    // Test POST /api/users (Add new student)
    const newStudentPayload = {
      name: 'طالب اختباري للأستاذ وسام',
      emailOrPhone: '+964 770 000 1122',
      grade: 'g6',
      isVip: true,
      deviceType: 'android-apk',
      notes: 'طالب مسجل للفحص الآلي'
    };

    const addStudentRes = await makeHttpRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/users',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, newStudentPayload);

    assert(addStudentRes.status === 201 && addStudentRes.data?.success === true, 'POST /api/users successfully creates student record');
    const createdUserId = addStudentRes.data?.user?.id;
    assert(typeof createdUserId === 'string' && createdUserId.startsWith('STU-'), `Created student has ID: ${createdUserId}`);

    // Test PUT /api/users/:id (Toggle status / block student)
    const updateStudentRes = await makeHttpRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/users/${createdUserId}`,
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' }
    }, { status: 'blocked' });

    assert(updateStudentRes.status === 200 && updateStudentRes.data?.user?.status === 'blocked', `PUT /api/users/${createdUserId} toggles student status to blocked`);

    // Clean up created test student
    const delStudentRes = await makeHttpRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/users/${createdUserId}`,
      method: 'DELETE'
    });
    assert(delStudentRes.status === 200 && delStudentRes.data?.success === true, `DELETE /api/users/${createdUserId} removes student from cloud`);
  } catch (err) {
    assert(false, `User Management API test failed: ${err.message}`);
  }

  console.log('\n--- 5. Testing Admin Login Credentials & Security ---');
  const allowedEmails = ['abdullahmiqdad2007@gmail.com', 'admin@wissam.com'];
  const correctPassword = 'admin123';

  // Test 1: User's email
  const userEmail = 'abdullahmiqdad2007@gmail.com';
  const isUserValid = allowedEmails.some(e => e.toLowerCase() === userEmail.toLowerCase()) && correctPassword === 'admin123';
  assert(isUserValid, `Login with ${userEmail} and 'admin123' grants access`);

  // Test 2: Teacher email
  const teacherEmail = 'admin@wissam.com';
  const isTeacherValid = allowedEmails.some(e => e.toLowerCase() === teacherEmail.toLowerCase()) && correctPassword === 'admin123';
  assert(isTeacherValid, `Login with ${teacherEmail} and 'admin123' grants access`);

  // Test 3: Unauthorized user
  const randomEmail = 'student@example.com';
  const isRandomDenied = !allowedEmails.some(e => e.toLowerCase() === randomEmail.toLowerCase());
  assert(isRandomDenied, `Login with unauthorized email (${randomEmail}) is correctly blocked`);

  // Test 4: Wrong password
  const wrongPassDenied = !(allowedEmails.includes(userEmail) && 'wrongpassword' === correctPassword);
  assert(wrongPassDenied, `Login with incorrect password is correctly rejected`);

  console.log('\n--- 6. Testing App Sections & Curriculum Data ---');
  const platformDataPath = path.join(baseDir, 'src', 'data', 'platformData.ts');
  const platformDataContent = fs.readFileSync(platformDataPath, 'utf-8');
  assert(platformDataContent.includes('g1') && platformDataContent.includes('g6'), 'All 6 grades (g1 to g6) defined in platformData.ts');
  assert(platformDataContent.includes('1APm6D9sooNqWdK0pWaBB5I7Sd08HsPcQ'), 'Textbook Google Drive ID for First Intermediate present');
  assert(platformDataContent.includes('1qwd_GN91iNb-st0Mvw7P3KINVvY1VDnX'), 'Textbook Google Drive ID for Sixth Scientific present');

  const appPath = path.join(baseDir, 'src', 'App.tsx');
  const appContent = fs.readFileSync(appPath, 'utf-8');
  const sections = ['#home', '#lectures', '#grades', '#lessons', '#books', '#institute', '#about', '#contact'];
  sections.forEach(s => {
    assert(appContent.includes(s.replace('#', '')), `Section ${s} mounted in App.tsx`);
  });

  console.log('\n=============================================');
  console.log(`Test Execution Finished: ${passedTests}/${totalTests} Passed (${failedTests} Failed)`);
  console.log('=============================================\n');

  if (failedTests > 0) {
    process.exit(1);
  }
}

runTests();
