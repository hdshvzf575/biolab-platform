import { db } from '../src/services/firebase';
import { collection, getDocs } from 'firebase/firestore';

async function auditFirestoreLive() {
  console.log('--- فحص مباشر لقاعدة بيانات Firebase Firestore ---');
  try {
    const collectionsToAudit = [
      'lectures',
      'curriculum_books',
      'users',
      'lecture_codes',
      'institute_posts',
      'institute_students',
      'backups'
    ];

    for (const colName of collectionsToAudit) {
      try {
        const snap = await getDocs(collection(db, colName));
        console.log(`مجموعة [${colName}]: إجمالي السجلات = ${snap.size}`);
        
        if (colName === 'lectures' && snap.size > 0) {
          snap.forEach(docSnap => {
            const d = docSnap.data();
            console.log(`  - محاضرة [${docSnap.id}]: "${d.title}" | رابط: ${d.videoUrl} | VIP: ${d.isPaid} | كود: ${d.secretCode}`);
          });
        }

        if (colName === 'curriculum_books' && snap.size > 0) {
          snap.forEach(docSnap => {
            const d = docSnap.data();
            console.log(`  - كتاب [${docSnap.id}]: "${d.title}" | PDF: ${d.pdfUrl || d.fileUrl || 'لا يوجد'} | الغلاف: ${d.coverUrl ? 'موجود' : 'لا يوجد'}`);
          });
        }
      } catch (colErr: any) {
        console.warn(`تعذر قراءة المجموعة [${colName}]:`, colErr?.message || colErr);
      }
    }
  } catch (err: any) {
    console.error('خطأ عام أثناء فحص Firestore:', err);
  }
}

auditFirestoreLive();
