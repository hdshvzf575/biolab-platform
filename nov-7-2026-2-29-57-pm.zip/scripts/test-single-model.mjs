import dotenv from 'dotenv';
dotenv.config();
import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI();

async function test(modelName) {
  console.log(`Starting generateContent with model: ${modelName}...`);
  const start = Date.now();
  try {
    const res = await ai.models.generateContent({
      model: modelName,
      contents: 'أهلاً بك، أجب بكلمة واحدة فقط: ما اسم عاصمة العراق؟'
    });
    console.log(`[${modelName}] Success in ${Date.now() - start}ms:`, res.text);
    return true;
  } catch (err) {
    console.error(`[${modelName}] Error (${Date.now() - start}ms):`, err.status || err.code || err.message);
    return false;
  }
}

async function main() {
  const models = ['gemini-flash-latest', 'gemini-3.8-flash', 'gemini-3.1-flash-lite'];
  for (const m of models) {
    const ok = await test(m);
    if (ok) break;
  }
  process.exit(0);
}

main();
