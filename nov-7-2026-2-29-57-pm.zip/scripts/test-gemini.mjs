import dotenv from 'dotenv';
dotenv.config();
import { GoogleGenAI } from '@google/genai';

console.log('Script started. API Key present:', !!process.env.GEMINI_API_KEY);

const ai = new GoogleGenAI();

async function run() {
  const models = ['gemini-2.5-flash', 'gemini-3.8-flash', 'gemini-flash-latest'];
  for (const m of models) {
    console.log(`Testing model: ${m}...`);
    try {
      const startTime = Date.now();
      const res = await ai.models.generateContent({
        model: m,
        contents: 'أجب بكلمة واحدة: ما هي وحدة بناء الكائن الحي؟'
      });
      console.log(`Model ${m} succeeded in ${Date.now() - startTime}ms:`, res.text?.trim());
      break;
    } catch (e) {
      console.error(`Model ${m} error:`, e.status, e.message);
    }
  }
  process.exit(0);
}

run().catch((e) => {
  console.error('Fatal error:', e);
  process.exit(1);
});
