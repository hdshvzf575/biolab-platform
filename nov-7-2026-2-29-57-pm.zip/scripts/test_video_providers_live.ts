import { VideoUrlResolver } from '../src/services/video/VideoUrlResolver';

interface ProviderTestCase {
  provider: string;
  testInput: string;
  expectedMode: string;
  expectedUrlPattern: RegExp;
  canEmbed: boolean;
}

const testCases: ProviderTestCase[] = [
  {
    provider: 'Direct HTML5 MP4',
    testInput: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    expectedMode: 'html5_video',
    expectedUrlPattern: /\.mp4$/i,
    canEmbed: true
  },
  {
    provider: 'Direct HTML5 WebM',
    testInput: 'https://example.com/videos/sample_cell.webm',
    expectedMode: 'html5_video',
    expectedUrlPattern: /\.webm$/i,
    canEmbed: true
  },
  {
    provider: 'Direct HLS M3U8',
    testInput: 'https://example.com/live/lecture_chapter1.m3u8',
    expectedMode: 'html5_video',
    expectedUrlPattern: /\.m3u8$/i,
    canEmbed: true
  },
  {
    provider: 'YouTube Standard Watch',
    testInput: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    expectedMode: 'official_iframe',
    expectedUrlPattern: /youtube-nocookie\.com\/embed\/dQw4w9WgXcQ/,
    canEmbed: true
  },
  {
    provider: 'YouTube Shorts',
    testInput: 'https://www.youtube.com/shorts/dQw4w9WgXcQ',
    expectedMode: 'official_iframe',
    expectedUrlPattern: /youtube-nocookie\.com\/embed\/dQw4w9WgXcQ/,
    canEmbed: true
  },
  {
    provider: 'YouTube youtu.be',
    testInput: 'https://youtu.be/dQw4w9WgXcQ?t=10',
    expectedMode: 'official_iframe',
    expectedUrlPattern: /youtube-nocookie\.com\/embed\/dQw4w9WgXcQ/,
    canEmbed: true
  },
  {
    provider: 'AnonMP4 View Page',
    testInput: 'https://anonmp4.com/view/7a8b9c0d1e2f',
    expectedMode: 'anon_mp4_embed',
    expectedUrlPattern: /anonmp4\.com\/embed\/7a8b9c0d1e2f/,
    canEmbed: true
  },
  {
    provider: 'AnonMP4 CDN Direct Media',
    testInput: 'https://cdn.anonmp4.com/media/file_998877.mp4',
    expectedMode: 'html5_video',
    expectedUrlPattern: /\.mp4$/,
    canEmbed: true
  },
  {
    provider: 'Google Drive View Link',
    testInput: 'https://drive.google.com/file/d/1k_k6VTpBaAJAxL_mm-lK8WwbzoBkLqHv/view?usp=drivesdk',
    expectedMode: 'official_iframe',
    expectedUrlPattern: /drive\.google\.com\/file\/d\/1k_k6VTpBaAJAxL_mm-lK8WwbzoBkLqHv\/preview/,
    canEmbed: true
  },
  {
    provider: 'Vimeo',
    testInput: 'https://vimeo.com/76979871',
    expectedMode: 'official_iframe',
    expectedUrlPattern: /player\.vimeo\.com\/video\/76979871/,
    canEmbed: true
  },
  {
    provider: 'Dailymotion',
    testInput: 'https://www.dailymotion.com/video/x8n1234',
    expectedMode: 'official_iframe',
    expectedUrlPattern: /dailymotion\.com\/embed\/video\/x8n1234/,
    canEmbed: true
  },
  {
    provider: 'Streamable',
    testInput: 'https://streamable.com/moo7b',
    expectedMode: 'official_iframe',
    expectedUrlPattern: /streamable\.com\/e\/moo7b/,
    canEmbed: true
  },
  {
    provider: 'Raw HTML Iframe Code',
    testInput: '<iframe width="560" height="315" src="https://player.host.com/embed/12345" frameborder="0"></iframe>',
    expectedMode: 'official_iframe',
    expectedUrlPattern: /player\.host\.com\/embed\/12345/,
    canEmbed: true
  },
  {
    provider: 'Generic Unknown HTTPS Video Page',
    testInput: 'https://mybiologyportal.edu/course/lecture10',
    expectedMode: 'official_iframe',
    expectedUrlPattern: /mybiologyportal\.edu\/course\/lecture10/,
    canEmbed: true
  }
];

async function runIndependentProviderAudit() {
  console.log('===============================================================');
  console.log('🔬 فحص مستقل لمزودي الفيديو: التحليل، فك الترميز، وإمكانية التضمين');
  console.log('===============================================================\n');

  let passed = 0;
  let failed = 0;

  for (const tc of testCases) {
    const resolved = await VideoUrlResolver.resolve(tc.testInput);
    const modeMatches = resolved.playbackMode === tc.expectedMode;
    const urlMatches = tc.expectedUrlPattern.test(resolved.playbackUrl);
    const embedMatches = resolved.canEmbed === tc.canEmbed;
    const preserved = resolved.originalUrl === tc.testInput;

    const isOk = modeMatches && urlMatches && embedMatches && preserved;

    if (isOk) {
      console.log(`✅ [نجح] ${tc.provider}`);
      console.log(`   - الوضع الناتج: ${resolved.playbackMode}`);
      console.log(`   - رابط التشغيل: ${resolved.playbackUrl}`);
      console.log(`   - الرابط الأصلي محفوظ: ${preserved}`);
      passed++;
    } else {
      console.error(`❌ [فشل] ${tc.provider}`);
      console.error(`   - المتوقع: mode=${tc.expectedMode}, pattern=${tc.expectedUrlPattern}`);
      console.error(`   - الفعلي: mode=${resolved.playbackMode}, url=${resolved.playbackUrl}`);
      failed++;
    }
    console.log('---------------------------------------------------------------');
  }

  console.log(`\nالنتيجة: ${passed} مزود نجح | ${failed} فشل`);
  if (failed > 0) process.exit(1);
}

runIndependentProviderAudit();
