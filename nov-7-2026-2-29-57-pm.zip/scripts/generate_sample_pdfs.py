#!/usr/bin/env python3
import os

def create_simple_pdf(filepath, title_text, subtitle_text, pages_content):
    """
    Generates a clean, valid PDF-1.4 file with multiple pages, text, and layout
    without needing heavy external libraries.
    """
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    # We will build objects
    objects = []
    
    def add_obj(content):
        objects.append(content)
        return len(objects) # 1-indexed object id

    # 1: Catalog (will be set)
    # 2: Outlines
    # 3: Pages
    
    # Let's allocate slots
    # obj 1: Catalog
    # obj 2: Outlines
    # obj 3: Pages
    # obj 4: Font Helvetica
    # obj 5: Font Helvetica-Bold
    
    page_obj_ids = []
    content_obj_ids = []
    
    # Font 1: Helvetica
    font1_id = 4
    font2_id = 5
    
    total_pages = len(pages_content)
    
    # Page objects will start after font objects
    # For each page: Page object, then Content stream object
    current_id = 6
    for i in range(total_pages):
        page_obj_ids.append(current_id)
        content_obj_ids.append(current_id + 1)
        current_id += 2
        
    # Build objects array
    obj_catalog = f"1 0 obj\n<< /Type /Catalog /Pages 3 0 R /Outlines 2 0 R >>\nendobj"
    obj_outlines = f"2 0 obj\n<< /Type /Outlines /Count 0 >>\nendobj"
    
    kids_str = " ".join([f"{pid} 0 R" for pid in page_obj_ids])
    obj_pages = f"3 0 obj\n<< /Type /Pages /Kids [ {kids_str} ] /Count {total_pages} >>\nendobj"
    
    obj_font1 = f"4 0 obj\n<< /Type /Font /Subtype /Type1 /Name /F1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj"
    obj_font2 = f"5 0 obj\n<< /Type /Font /Subtype /Type1 /Name /F2 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj"
    
    full_objs = [obj_catalog, obj_outlines, obj_pages, obj_font1, obj_font2]
    
    for i in range(total_pages):
        p_num = i + 1
        page_data = pages_content[i]
        
        # Build stream text
        stream_lines = [
            "BT",
            "/F2 20 Tf",
            "50 780 Td",
            f"({title_text} - Page {p_num}) Tj",
            "ET",
            "BT",
            "/F1 12 Tf",
            "50 755 Td",
            f"({subtitle_text}) Tj",
            "ET",
            # Line separator
            "0.8 0.6 0.2 RG",
            "2 w",
            "50 745 m 550 745 l S",
            # Body text
            "0 0 0 rg"
        ]
        
        y_pos = 710
        for line in page_data:
            safe_line = line.replace("(", "\(").replace(")", "\)")
            stream_lines.extend([
                "BT",
                "/F1 11 Tf",
                f"50 {y_pos} Td",
                f"({safe_line}) Tj",
                "ET"
            ])
            y_pos -= 24
            
        # Footer
        stream_lines.extend([
            "0.5 0.5 0.5 rg",
            "BT",
            "/F1 9 Tf",
            "250 40 Td",
            f"(Page {p_num} of {total_pages} - BioLab Academy) Tj",
            "ET"
        ])
        
        stream_content = "\n".join(stream_lines)
        stream_len = len(stream_content.encode('utf-8'))
        
        c_id = content_obj_ids[i]
        p_id = page_obj_ids[i]
        
        page_obj = f"{p_id} 0 obj\n<< /Type /Page /Parent 3 0 R /MediaBox [ 0 0 595 842 ] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents {c_id} 0 R >>\nendobj"
        content_obj = f"{c_id} 0 obj\n<< /Length {stream_len} >>\nstream\n{stream_content}\nendstream\nendobj"
        
        full_objs.append(page_obj)
        full_objs.append(content_obj)
        
    # Write complete PDF with xref table
    with open(filepath, 'wb') as f:
        f.write(b"%PDF-1.4\n")
        f.write(b"%\xe2\xe3\xcf\xd3\n")
        
        offsets = [0]
        for obj_str in full_objs:
            offsets.append(f.tell())
            f.write(obj_str.encode('utf-8'))
            f.write(b"\n")
            
        xref_offset = f.tell()
        total_objs = len(full_objs) + 1
        
        f.write(f"xref\n0 {total_objs}\n".encode('utf-8'))
        f.write(b"0000000000 65535 f \n")
        for off in offsets[1:]:
            f.write(f"{off:010d} 00000 n \n".encode('utf-8'))
            
        f.write(f"trailer\n<< /Size {total_objs} /Root 1 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n".encode('utf-8'))
    
    print(f"Generated: {filepath} ({os.path.getsize(filepath)} bytes)")

books_to_generate = [
    {
        "filename": "public/uploads/books/biology_g1.pdf",
        "title": "General Biology - Grade 1 Intermediate",
        "subtitle": "Ministry of Education - Biology Foundations",
        "pages": [
            [
                "Welcome to Grade 1 Biology Textbook.",
                "Chapter 1: The Living World and Taxonomy.",
                "Definition of Biology: The scientific study of life and living organisms.",
                "Characteristics of Living Things: Cellular organization, Metabolism, Homeostasis, Growth.",
                "Levels of Biological Organization: Atom -> Molecule -> Cell -> Tissue -> Organ -> Organism."
            ],
            [
                "Chapter 2: Cell Structure and Function.",
                "The Cell Theory: All organisms are composed of one or more cells.",
                "Plant Cells vs Animal Cells: Cell wall, Chloroplasts, Vacuoles, Mitochondria.",
                "Microscopy in Biology: Light microscopes and Electron microscopes."
            ],
            [
                "Chapter 3: Tissues and Biological Systems.",
                "Epithelial Tissues: Protective surfaces and absorptive linings.",
                "Connective Tissues: Bones, cartilage, blood, and adipose tissue.",
                "Summary and Review Questions for First Intermediate Grade."
            ]
        ]
    },
    {
        "filename": "public/uploads/books/biology_g2.pdf",
        "title": "Microbiology - Grade 2 Intermediate",
        "subtitle": "Ministry of Education - Microorganisms & Kingdoms",
        "pages": [
            [
                "Welcome to Grade 2 Biology Textbook.",
                "Chapter 1: Principles of Classification (Taxonomy).",
                "Linnaean System: Kingdom, Phylum, Class, Order, Family, Genus, Species.",
                "Bionomial Nomenclature: Scientific naming conventions."
            ],
            [
                "Chapter 2: Microscopic Kingdoms.",
                "Kingdom Monera: Bacteria and Archaea.",
                "Bacterial Shapes: Bacilli (rods), Cocci (spheres), Spirilla (spirals).",
                "Beneficial and Pathogenic Bacteria in Ecosystems."
            ],
            [
                "Chapter 3: Fungi and Simple Plants.",
                "Kingdom Fungi: Yeast, molds, mushrooms.",
                "Lichens and Symbiotic Associations.",
                "Summary and Key Examination Concepts."
            ]
        ]
    },
    {
        "filename": "public/uploads/books/biology_g3.pdf",
        "title": "Human Biology & Physiology - Grade 3 Intermediate",
        "subtitle": "Ministry of Education - Human Anatomy and Systems",
        "pages": [
            [
                "Grade 3 Intermediate Biology - Human Body Systems.",
                "Chapter 1: The Skeletal System.",
                "Axial Skeleton: Skull, Vertebral Column, Rib Cage.",
                "Appendicular Skeleton: Pectoral Girdle, Pelvic Girdle, Limbs.",
                "Joints and Bone Structure: Compact bone, spongy bone, marrow."
            ],
            [
                "Chapter 2: The Circulatory System.",
                "Structure of the Heart: Atria, Ventricles, Valves, Pericardium.",
                "Blood Vessels: Arteries, Veins, Capillaries.",
                "Composition of Blood: Erythrocytes, Leukocytes, Thrombocytes, Plasma.",
                "Pulmonary and Systemic Circulations."
            ],
            [
                "Chapter 3: The Nervous and Digestive Systems.",
                "Central Nervous System: Brain and Spinal Cord.",
                "Digestive Canal: Mouth, Pharynx, Esophagus, Stomach, Intestines.",
                "Essential Review Tables for Official Examinations."
            ]
        ]
    },
    {
        "filename": "public/uploads/books/biology_g4.pdf",
        "title": "Ecology and Zoology - Grade 4 Scientific",
        "subtitle": "Ministry of Education - Ecology and Adaptation",
        "pages": [
            [
                "Grade 4 Scientific Biology Textbook.",
                "Chapter 1: Principles of Ecology.",
                "Ecosystem Dynamics: Energy flow, Food chains, Trophic levels.",
                "Biogeochemical Cycles: Carbon, Nitrogen, Water cycles.",
                "Limiting Factors in Ecological Environments."
            ],
            [
                "Chapter 2: Morphological Adaptations.",
                "Animal Adaptations to Terrestrial and Aquatic Habitats.",
                "Osmoregulation in Freshwater and Marine Fish.",
                "Thermoregulation: Ectotherms vs Endotherms."
            ]
        ]
    },
    {
        "filename": "public/uploads/books/biology_g5.pdf",
        "title": "Comparative Physiology - Grade 5 Scientific",
        "subtitle": "Ministry of Education - Nutrition, Respiration & Transport",
        "pages": [
            [
                "Grade 5 Scientific Biology Textbook.",
                "Chapter 1: Nutrition and Digestion in Animals.",
                "Intracellular vs Extracellular Digestion.",
                "Digestive Enzymes and Nutrient Absorption.",
                "Hormonal Regulation of Digestive Secretions."
            ],
            [
                "Chapter 2: Respiratory Mechanisms.",
                "Cutaneous, Tracheal, Branchial, and Pulmonary Respiration.",
                "Gas Exchange Mechanics and Hemoglobin Affinity.",
                "Excretion and Renal Physiology in Vertebrates."
            ]
        ]
    },
    {
        "filename": "public/uploads/books/biology_g6.pdf",
        "title": "Cell Biology and Genetics - Grade 6 Scientific (Baccalaureate)",
        "subtitle": "Ministry of Education - The Cell, Reproduction & Mendelian Genetics",
        "pages": [
            [
                "Grade 6 Scientific Biology - Master Textbook.",
                "Chapter 1: The Cell (Cytology).",
                "Prokaryotic vs Eukaryotic Cells.",
                "Cell Organelles: Plasma Membrane, Mitochondria, Golgi Apparatus, Lysosomes.",
                "Cell Division: Mitosis (Prophase, Metaphase, Anaphase, Telophase).",
                "Meiosis I and Meiosis II: Crossing over and genetic recombination."
            ],
            [
                "Chapter 2: Biological Tissues.",
                "Plant Tissues: Meristematic, Fundamental, Dermal, Vascular (Xylem, Phloem).",
                "Animal Tissues: Epithelial, Connective, Muscular (Smooth, Skeletal, Cardiac), Nervous."
            ],
            [
                "Chapter 3: Reproduction and Embryology.",
                "Asexual vs Sexual Reproduction in Plants and Animals.",
                "Gametogenesis: Spermatogenesis and Oogenesis.",
                "Double Fertilization in Angiosperms."
            ],
            [
                "Chapter 4: Genetics and Molecular Biology.",
                "Mendel's First Law: Law of Segregation.",
                "Mendel's Second Law: Law of Independent Assortment.",
                "Non-Mendelian Genetics: Incomplete dominance, Codominance, Multiple alleles.",
                "DNA Replication, Transcription, Translation and Protein Synthesis."
            ]
        ]
    },
    {
        "filename": "public/uploads/books/campbell_biology_ar.pdf",
        "title": "Campbell Biology - University Reference Edition",
        "subtitle": "Undergraduate Foundation in Biological Sciences",
        "pages": [
            [
                "Campbell Biology - Comprehensive University Edition.",
                "Unit 1: The Chemistry of Life.",
                "Water and Life: Hydrogen bonding, Cohesion, Temperature stabilization.",
                "Carbon and the Molecular Diversity of Life: Carbohydrates, Lipids, Proteins, Nucleic Acids."
            ],
            [
                "Unit 2: The Cell and Bioenergetics.",
                "Membrane Structure and Function: Fluid Mosaic Model.",
                "Cellular Respiration and Fermentation: Glycolysis, Citric Acid Cycle, Oxidative Phosphorylation.",
                "Photosynthesis: Light reactions and Calvin Cycle."
            ],
            [
                "Unit 3: Genetics, Evolution and Biotechnology.",
                "Molecular Basis of Inheritance: Watson-Crick double helix.",
                "From Gene to Protein: Genetic code, RNA processing, Ribosome mechanics.",
                "DNA Tools and Biotechnology: PCR, Gel Electrophoresis, Recombinant DNA."
            ]
        ]
    },
    {
        "filename": "public/uploads/books/alberts_cell_biology_ar.pdf",
        "title": "Molecular Biology of the Cell - Advanced Graduate Reference",
        "subtitle": "Master & PhD Specialization in Molecular Cytology",
        "pages": [
            [
                "Molecular Biology of the Cell - Graduate Reference Series.",
                "Chapter 1: Cells, Genomes, and the Diversity of Life.",
                "The Universal Features of Cells on Earth.",
                "Genomic Information Storage and Transmission."
            ],
            [
                "Chapter 2: Protein Structure and Function.",
                "Primary, Secondary, Tertiary, and Quaternary Conformations.",
                "Allosteric Regulation and Enzyme Kinetics (Michaelis-Menten).",
                "Signal Transduction: G-protein coupled receptors, Tyrosine kinases, Second messengers."
            ]
        ]
    }
]

for b in books_to_generate:
    create_simple_pdf(b["filename"], b["title"], b["subtitle"], b["pages"])

print("All sample PDF files generated successfully!")
