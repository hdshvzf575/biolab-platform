import { VideoUrlResolver } from '../src/services/video/VideoUrlResolver';
import fs from 'fs';
import path from 'path';

let passCount = 0;
let failCount = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passCount++;
  } else {
    console.error(`❌ [FAIL] ${testName}${detail ? ` - Detail: ${detail}` : ''}`);
    failCount++;
  }
}

async function runTests() {
  console.log('========================================================');
  console.log('🧪 منصة الكائنات | فحص واختبار نظام الفيديو والملفات الشامل');
  console.log('========================================================\n');

  // Test 1: Direct MP4 / WebM / M3U8
  console.log('--- 1. اختبار حل روابط الفيديو المباشرة ---');
  const mp4Url = 'https://storage.googleapis.com/biolab-videos/cells_chapter1.mp4';
  const mp4Result = await VideoUrlResolver.resolve(mp4Url);
  assert(mp4Result.playbackMode === 'html5_video', 'Direct MP4 playback mode is html5_video');
  assert(mp4Result.providerId === 'direct_video', 'Direct MP4 detected as direct_video provider');
  assert(mp4Result.playbackUrl === mp4Url, 'Direct MP4 preserved playback URL');

  const m3u8Url = 'https://stream.example.com/live/lecture_dna.m3u8';
  const m3u8Result = await VideoUrlResolver.resolve(m3u8Url);
  assert(m3u8Result.playbackMode === 'html5_video', 'M3U8 stream playback mode is html5_video');

  // Test 2: AnonMP4 Provider
  console.log('\n--- 2. اختبار مزود AnonMP4 المخصص ---');
  const anonViewUrl = 'https://anonmp4.com/view/7a8b9c0d1e2f';
  const anonResult = await VideoUrlResolver.resolve(anonViewUrl);
  assert(anonResult.providerId === 'anon_mp4', 'AnonMP4 detected as anon_mp4 provider');
  assert(anonResult.playbackMode === 'anon_mp4_embed', 'AnonMP4 playback mode is anon_mp4_embed');
  assert(anonResult.playbackUrl.includes('/embed/7a8b9c0d1e2f'), 'AnonMP4 converted view URL to embed URL', anonResult.playbackUrl);

  const anonCdnUrl = 'https://cdn.anonmp4.com/media/lecture_cells.mp4';
  const anonCdnResult = await VideoUrlResolver.resolve(anonCdnUrl);
  assert(anonCdnResult.providerId === 'anon_mp4', 'AnonMP4 CDN detected as anon_mp4 provider');
  assert(anonCdnResult.playbackMode === 'html5_video', 'AnonMP4 direct media file uses html5_video');

  // Test 3: YouTube Resolution (Standard, Shorts, Embed)
  console.log('\n--- 3. اختبار مزود YouTube الرسمي والـ Shorts ---');
  const ytWatch = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
  const ytResult = await VideoUrlResolver.resolve(ytWatch);
  assert(ytResult.providerId === 'youtube', 'YouTube watch URL detected');
  assert(ytResult.playbackUrl.includes('youtube-nocookie.com/embed/dQw4w9WgXcQ'), 'YouTube converted to privacy-enhanced embed URL', ytResult.playbackUrl);
  assert(Boolean(ytResult.thumbnailUrl && ytResult.thumbnailUrl.includes('dQw4w9WgXcQ')), 'YouTube thumbnail generated');

  const ytShorts = 'https://youtube.com/shorts/dQw4w9WgXcQ?feature=share';
  const ytShortsResult = await VideoUrlResolver.resolve(ytShorts);
  assert(ytShortsResult.playbackUrl.includes('youtube-nocookie.com/embed/dQw4w9WgXcQ'), 'YouTube Shorts converted to embed');

  // Test 4: Google Drive Preview
  console.log('\n--- 4. اختبار مزود Google Drive ---');
  const gdriveUrl = 'https://drive.google.com/file/d/1k_k6VTpBaAJAxL_mm-lK8WwbzoBkLqHv/view?usp=drivesdk';
  const gdriveResult = await VideoUrlResolver.resolve(gdriveUrl);
  assert(gdriveResult.providerId === 'google_drive', 'Google Drive detected');
  assert(gdriveResult.playbackUrl === 'https://drive.google.com/file/d/1k_k6VTpBaAJAxL_mm-lK8WwbzoBkLqHv/preview', 'Google Drive converted /view to /preview', gdriveResult.playbackUrl);

  // Test 5: Vimeo & Streamable
  console.log('\n--- 5. اختبار Vimeo و Streamable ---');
  const vimeoUrl = 'https://vimeo.com/76979871';
  const vimeoResult = await VideoUrlResolver.resolve(vimeoUrl);
  assert(vimeoResult.providerId === 'vimeo', 'Vimeo detected');
  assert(vimeoResult.playbackUrl.includes('player.vimeo.com/video/76979871'), 'Vimeo embed URL generated');

  const streamableUrl = 'https://streamable.com/moo7b';
  const streamableResult = await VideoUrlResolver.resolve(streamableUrl);
  assert(streamableResult.providerId === 'streamable', 'Streamable detected');
  assert(streamableResult.playbackUrl === 'https://streamable.com/e/moo7b', 'Streamable embed URL generated');

  // Test 6: Raw Iframe Code Extraction
  console.log('\n--- 6. اختبار استخراج رابط الفيديو من كود <iframe> خام ---');
  const rawIframe = '<iframe width="560" height="315" src="https://player.host.com/embed/998877" frameborder="0" allowfullscreen></iframe>';
  const iframeResult = await VideoUrlResolver.resolve(rawIframe);
  assert(iframeResult.playbackUrl === 'https://player.host.com/embed/998877', 'Raw iframe src extracted correctly', iframeResult.playbackUrl);

  // Test 7: Sanitization and Live Provider Detection
  console.log('\n--- 7. اختبار كشف المزود المباشر وتعقيم الروابط ---');
  const detected = VideoUrlResolver.detectProvider('https://anonmp4.com/view/test1234');
  assert(detected.id === 'anon_mp4', 'Live detection identifies AnonMP4 correctly');
  assert(detected.name === 'منصة AnonMP4', 'Live detection provides Arabic name');

  const sanitized = VideoUrlResolver.sanitizeUrl(rawIframe);
  assert(sanitized === 'https://player.host.com/embed/998877', 'Sanitizer strips iframe wrapper');

  // Test 8: Codebase Inspection for File Picker Overlay Pattern
  console.log('\n--- 8. اختبار فحص أزرار الرفع وإصلاح مشكلة Android WebView ---');
  const adminPanelSrc = fs.readFileSync(path.resolve('./src/components/AdminPanelModal.tsx'), 'utf-8');
  assert(
    adminPanelSrc.includes('className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"') &&
    adminPanelSrc.includes('id="admin-lecture-video-picker"'),
    'AdminPanelModal: Video file input has absolute inset-0 overlay pattern'
  );

  const adminBooksSrc = fs.readFileSync(path.resolve('./src/components/AdminBooksTab.tsx'), 'utf-8');
  assert(
    adminBooksSrc.includes('id="admin-pdf-file-picker"') &&
    adminBooksSrc.includes('className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"'),
    'AdminBooksTab: PDF file input has absolute inset-0 overlay pattern'
  );
  assert(
    adminBooksSrc.includes('id="admin-cover-file-picker"') &&
    adminBooksSrc.includes('className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"'),
    'AdminBooksTab: Cover image input has absolute inset-0 overlay pattern'
  );

  // Test 9: Android Native Code Inspection
  console.log('\n--- 9. اختبار فحص كود Kotlin في MainActivity.kt ---');
  const mainActivitySrc = fs.readFileSync(path.resolve('./android/app/src/main/java/com/wissam/biolab/MainActivity.kt'), 'utf-8');
  assert(
    mainActivitySrc.includes('intent.data != null') && mainActivitySrc.includes('intent.clipData != null'),
    'MainActivity.kt: filePickerLauncher handles intent.data and clipData fallback'
  );
  assert(
    mainActivitySrc.includes('Intent.CATEGORY_OPENABLE'),
    'MainActivity.kt: onShowFileChooser sets CATEGORY_OPENABLE for Storage Access Framework'
  );

  // Test 10: LecturesSection UniversalVideoPlayer Integration
  console.log('\n--- 10. اختبار تكامل المشغل الموحد في واجهة المحاضرات ---');
  const lecturesSectionSrc = fs.readFileSync(path.resolve('./src/components/LecturesSection.tsx'), 'utf-8');
  assert(
    lecturesSectionSrc.includes('UniversalVideoPlayer') &&
    lecturesSectionSrc.includes('url={lec.videoUrl}'),
    'LecturesSection.tsx: uses UniversalVideoPlayer for rendering lecture cards'
  );

  console.log('\n========================================================');
  console.log(`📊 النتيجة النهائية: ${passCount} اختبار ناجح | ${failCount} فاشل`);
  console.log('========================================================');

  if (failCount > 0) {
    process.exit(1);
  }
}

runTests();
