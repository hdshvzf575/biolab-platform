export interface ThemePreset {
  id: 'royal' | 'cyber' | 'bio' | 'cosmic' | 'minimal';
  name: string;
  subtitle: string;
  description: string;
  icon: string;
  colors: {
    primary: string;
    secondary: string;
    bgDark: string;
    bgCard: string;
    border: string;
    glow: string;
    textPrimary: string;
    textAccent: string;
    gradientHeading: string;
    dockGradient: string;
    badgeBg: string;
  };
  cardShape: {
    shapeName: string;
    roundedClass: string;
    borderClass: string;
    shadowClass: string;
    glassClass: string;
  };
  transition: {
    id: 'cinematic' | 'cyber' | 'elastic' | 'cosmic' | 'minimal';
    name: string;
    description: string;
    durationMs: number;
    motionVariant: any;
  };
  soundStyle: 'velvet' | 'cyber' | 'bio' | 'cosmic' | 'minimal';
  soundName: string;
  previewTags: string[];
}

export const themePresets: ThemePreset[] = [
  {
    id: 'royal',
    name: 'النمط الملكي الزمردي',
    subtitle: 'الأصلي الفاخر · الذهب العراقي والأخضر الزمردي',
    description: 'تصميم عريق يجمع فخامة الذهب العراقي الأصيل ولمسات الزمرد المضيء مع حواف مقوسة بانسيابية كلاسيكية.',
    icon: '👑',
    colors: {
      primary: '#e9c978',
      secondary: '#0fb98a',
      bgDark: '#04080f',
      bgCard: '#0a1220',
      border: 'rgba(233, 201, 120, 0.24)',
      glow: 'rgba(233, 201, 120, 0.35)',
      textPrimary: '#eaf0f8',
      textAccent: '#e9c978',
      gradientHeading: 'from-[#e9c978] via-[#f3dc98] to-[#c9a24a]',
      dockGradient: 'from-[#e9c978] via-[#f3dc98] to-[#c9a24a]',
      badgeBg: 'bg-[#e9c978]/15 text-[#e9c978] border-[#e9c978]/30'
    },
    cardShape: {
      shapeName: 'انسيابي ملكي مقوس',
      roundedClass: 'rounded-2xl',
      borderClass: 'border border-[#e9c978]/25',
      shadowClass: 'shadow-[0_12px_32px_rgba(0,0,0,0.55)]',
      glassClass: 'bg-[#0a1220]/85 backdrop-blur-xl border border-[#e9c978]/20'
    },
    transition: {
      id: 'cinematic',
      name: 'انتقال سينمائي ناعم',
      description: 'تلاشٍ هادئ مدمج بانزلاق عمودي متزن وعالي السلاسة',
      durationMs: 280,
      motionVariant: {
        initial: { opacity: 0, y: 16, scale: 0.985 },
        animate: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.28, ease: [0.22, 1, 0.36, 1] } },
        exit: { opacity: 0, y: -12, scale: 0.99, transition: { duration: 0.18, ease: [0.4, 0, 1, 1] } }
      }
    },
    soundStyle: 'velvet',
    soundName: 'نقر مخملي ناعم',
    previewTags: ['ذهب ملكي', 'زمرد فخم', 'سينمائي ناعم']
  },
  {
    id: 'cyber',
    name: 'النمط السيبراني الديجيتال',
    subtitle: 'أزرق الذكاء الاصطناعي · تكنولوجيا المستقبل',
    description: 'واجهة رقمية مستقبلية متطورة مستوحاة من كبرى مراكز أبحاث التكنولوجيا الحيوية، بحدود هندسية مضيئة وزرقة نيون خاطفة.',
    icon: '⚡',
    colors: {
      primary: '#00f0ff',
      secondary: '#3b82f6',
      bgDark: '#050814',
      bgCard: '#0b1126',
      border: 'rgba(0, 240, 255, 0.32)',
      glow: 'rgba(0, 240, 255, 0.45)',
      textPrimary: '#f0f9ff',
      textAccent: '#00f0ff',
      gradientHeading: 'from-[#00f0ff] via-[#38bdf8] to-[#3b82f6]',
      dockGradient: 'from-[#00f0ff] via-[#38bdf8] to-[#2563eb]',
      badgeBg: 'bg-[#00f0ff]/15 text-[#00f0ff] border-[#00f0ff]/35'
    },
    cardShape: {
      shapeName: 'هندسي تكنولوجي مشذّب',
      roundedClass: 'rounded-xl',
      borderClass: 'border border-[#00f0ff]/30',
      shadowClass: 'shadow-[0_0_24px_rgba(0,240,255,0.18)]',
      glassClass: 'bg-[#0b1126]/90 backdrop-blur-xl border border-[#00f0ff]/25'
    },
    transition: {
      id: 'cyber',
      name: 'انزلاق رقمي سريع',
      description: 'حركة خاطفة تكنولوجية مع استجابة بصرية مجهرية فورية',
      durationMs: 210,
      motionVariant: {
        initial: { opacity: 0, x: -24, scale: 0.98 },
        animate: { opacity: 1, x: 0, scale: 1, transition: { duration: 0.21, ease: [0.16, 1, 0.3, 1] } },
        exit: { opacity: 0, x: 20, scale: 0.98, transition: { duration: 0.14, ease: [0.4, 0, 1, 1] } }
      }
    },
    soundStyle: 'cyber',
    soundName: 'نقرة رقمية إلكترونية',
    previewTags: ['نيون أزرق', 'تكنولوجي ذكي', 'انزلاق خاطف']
  },
  {
    id: 'bio',
    name: 'المختبر الحيوي الطبيعي',
    subtitle: 'اليشم الأخضر · غشاء الخلية والبلاستيدات الخضراء',
    description: 'تصميم حيوي مستلهم من علم الأحياء الدقيقة وعالم الخلايا، بحواف فائقة الانحناء ونضارة نباتية مريحة لعين الطالب.',
    icon: '🌿',
    colors: {
      primary: '#10b981',
      secondary: '#84cc16',
      bgDark: '#04110d',
      bgCard: '#08211a',
      border: 'rgba(16, 185, 129, 0.32)',
      glow: 'rgba(16, 185, 129, 0.4)',
      textPrimary: '#f0fdf4',
      textAccent: '#34d399',
      gradientHeading: 'from-[#34d399] via-[#10b981] to-[#84cc16]',
      dockGradient: 'from-[#34d399] via-[#10b981] to-[#059669]',
      badgeBg: 'bg-[#10b981]/15 text-[#34d399] border-[#10b981]/35'
    },
    cardShape: {
      shapeName: 'عضوي فائق الاستدارة (غشاء خلوي)',
      roundedClass: 'rounded-3xl',
      borderClass: 'border border-[#10b981]/30',
      shadowClass: 'shadow-[0_12px_36px_rgba(4,24,18,0.7)]',
      glassClass: 'bg-[#08211a]/85 backdrop-blur-2xl border border-[#10b981]/25'
    },
    transition: {
      id: 'elastic',
      name: 'ارتداد نبضي مرن',
      description: 'حركة انسيابية نابضة بفيزياء ارتدادية تحاكي تمدد الخلية',
      durationMs: 340,
      motionVariant: {
        initial: { opacity: 0, scale: 0.94, y: 12 },
        animate: { opacity: 1, scale: 1, y: 0, transition: { type: 'spring', stiffness: 380, damping: 26 } },
        exit: { opacity: 0, scale: 0.96, transition: { duration: 0.16 } }
      }
    },
    soundStyle: 'bio',
    soundName: 'فقاعة خلوية مائية',
    previewTags: ['يشم أخضر', 'عضوي حيوي', 'ارتداد مرن']
  },
  {
    id: 'cosmic',
    name: 'الكوني الفلكي والأورورا',
    subtitle: 'سديم النجوم · مدارات المعرفة والماجنتا',
    description: 'رحلة بصرية داخل سديم كوني ساحر بتدرجات البنفسجي الفلكي والوردي النجمي مع مؤثرات زجاجية عميقة تعزز متعة التعلم.',
    icon: '🌌',
    colors: {
      primary: '#c084fc',
      secondary: '#f43f5e',
      bgDark: '#0b0517',
      bgCard: '#150a2b',
      border: 'rgba(192, 132, 252, 0.32)',
      glow: 'rgba(192, 132, 252, 0.45)',
      textPrimary: '#faf5ff',
      textAccent: '#e879f9',
      gradientHeading: 'from-[#e879f9] via-[#c084fc] to-[#f43f5e]',
      dockGradient: 'from-[#c084fc] via-[#e879f9] to-[#ec4899]',
      badgeBg: 'bg-[#c084fc]/15 text-[#e879f9] border-[#c084fc]/35'
    },
    cardShape: {
      shapeName: 'كريستالي زجاجي عميق',
      roundedClass: 'rounded-2xl',
      borderClass: 'border border-[#c084fc]/30',
      shadowClass: 'shadow-[0_12px_40px_rgba(192,132,252,0.22)]',
      glassClass: 'bg-[#150a2b]/85 backdrop-blur-2xl border border-[#c084fc]/25'
    },
    transition: {
      id: 'cosmic',
      name: 'تعويم فضائي عميق',
      description: 'انتقال ثلاثي الأبعاد مع عمق وانسيابية مدارية كأنك تطفو في الفضاء',
      durationMs: 320,
      motionVariant: {
        initial: { opacity: 0, y: 20, scale: 0.97 },
        animate: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.32, ease: [0.25, 0.8, 0.25, 1] } },
        exit: { opacity: 0, y: -16, scale: 1.02, transition: { duration: 0.2, ease: [0.4, 0, 1, 1] } }
      }
    },
    soundStyle: 'cosmic',
    soundName: 'رنين بلوري نقي',
    previewTags: ['بنفسجي أورورا', 'زجاجي عميق', 'تعويم مداري']
  },
  {
    id: 'minimal',
    name: 'التيتانيوم المترف المينيمالي',
    subtitle: 'الأسود الماسي والبلاتين · صفاء أكاديمي فائق',
    description: 'قمة الصفاء الأكاديمي والهدوء البصري، بدون أي تشتيت، بخطوط تيتانيوم مصقولة وبساطة سويسرية فائقة التركيز والسرعة.',
    icon: '💎',
    colors: {
      primary: '#f8fafc',
      secondary: '#94a3b8',
      bgDark: '#09090b',
      bgCard: '#141418',
      border: 'rgba(255, 255, 255, 0.18)',
      glow: 'rgba(255, 255, 255, 0.22)',
      textPrimary: '#ffffff',
      textAccent: '#f8fafc',
      gradientHeading: 'from-[#ffffff] via-[#e2e8f0] to-[#94a3b8]',
      dockGradient: 'from-[#ffffff] via-[#e2e8f0] to-[#cbd5e1]',
      badgeBg: 'bg-white/10 text-white border-white/20'
    },
    cardShape: {
      shapeName: 'دقة هندسية صارمة',
      roundedClass: 'rounded-lg',
      borderClass: 'border border-white/20',
      shadowClass: 'shadow-[0_8px_24px_rgba(0,0,0,0.6)]',
      glassClass: 'bg-[#141418]/90 backdrop-blur-md border border-white/15'
    },
    transition: {
      id: 'minimal',
      name: 'تلاشٍ خاطف فائق السرعة',
      description: 'تبديل فوري انسيابي بدون أي إبطاء أو حركات استعراضية',
      durationMs: 170,
      motionVariant: {
        initial: { opacity: 0 },
        animate: { opacity: 1, transition: { duration: 0.17, ease: 'linear' } },
        exit: { opacity: 0, transition: { duration: 0.1 } }
      }
    },
    soundStyle: 'minimal',
    soundName: 'تكة ميكانيكية دقيقة',
    previewTags: ['بلاتين وتيتانيوم', 'مينيمال مطلق', 'تلاشٍ خاطف']
  }
];

export const getThemePresetById = (id: string): ThemePreset => {
  return themePresets.find(p => p.id === id) || themePresets[0];
};

/**
 * Apply theme CSS variables directly to the root element for dynamic re-coloring
 */
export const applyThemeToDocument = (preset: ThemePreset) => {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;

  root.style.setProperty('--gold', preset.colors.primary);
  root.style.setProperty('--gold-deep', preset.colors.secondary);
  root.style.setProperty('--bg-dark', preset.colors.bgDark);
  root.style.setProperty('--bg-card', preset.colors.bgCard);
  root.style.setProperty('--theme-glow', preset.colors.glow);
  root.style.setProperty('--theme-border', preset.colors.border);
  root.setAttribute('data-biolab-theme', preset.id);
  root.setAttribute('data-transition-style', preset.transition.id);
};
