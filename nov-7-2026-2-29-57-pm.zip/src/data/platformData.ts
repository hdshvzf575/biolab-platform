export interface ChapterInfo {
  title: string;
  desc: string;
}

export interface GradeCurriculum {
  name: string;
  icon: string;
  chapters: ChapterInfo[];
}

export interface BookItem {
  id: string;
  gradeKey: string;
  grade: string;
  icon: string;
  title: string;
  author?: string;
  specialization?: string;
  academicLevel?: string;
  description?: string;
  pages?: number | string;
  fileSize?: string;
  fileId?: string;
  pdfUrl?: string;
  fileUrl?: string;
  coverUrl?: string;
  year?: number | string;
  sourceType?: 'direct-pdf' | 'school-repo' | 'open-access' | 'external-source';
  status?: 'published' | 'draft' | 'hidden';
  driveUrl?: string;
  driveId?: string;
  driveAccessStatus?: 'accessible' | 'restricted' | 'not_found' | 'local_fallback';
  driveStatusMessage?: string;
}

export interface LectureItem {
  id: number;
  title: string;
  desc: string;
  grade: string;
  videoUrl: string;
  isPaid: boolean;
  secretCode?: string | null;
  createdAt?: string;
  viewsCount?: number;
  _docId?: string;
  isMalformed?: boolean;
}

export interface UserItem {
  id: string;
  uid?: string;
  firebaseUid?: string;
  name: string;
  age?: number | string;
  birthDate?: string;
  birthYear?: number;
  track?: 'school';
  emailOrPhone: string;
  photoURL?: string;
  authProvider?: 'google' | 'password' | 'guest';
  grade: string;
  role: 'student' | 'vip' | 'teacher';
  status: 'active' | 'blocked';
  isVip: boolean;
  deviceType: 'android-apk' | 'web-mobile' | 'web-desktop' | 'ios' | string;
  registeredAt: string;
  lastActive: string;
  unlockedLectures: (number | string)[];
  notes?: string;
}

export interface UserStats {
  total: number;
  active: number;
  blocked: number;
  vip: number;
  apk: number;
  web: number;
  schoolCount?: number;
  universityCount?: number;
}

export const gradeNames: Record<string, string> = {
  g1: 'الأول المتوسط',
  g2: 'الثاني المتوسط',
  g3: 'الثالث المتوسط',
  g4: 'الرابع العلمي',
  g5: 'الخامس العلمي',
  g6: 'السادس العلمي'
};

export const gradeIcons: Record<string, string> = {
  g1: '📘',
  g2: '🦠',
  g3: '🌿',
  g4: '🧪',
  g5: '🐟',
  g6: '🧬'
};

export const gradeSubs: Record<string, string> = {
  g1: 'أساسيات علم الأحياء',
  g2: 'الكائنات الحية الدقيقة',
  g3: 'أجهزة جسم الإنسان',
  g4: 'الوراثة والتكاثر',
  g5: 'علم الحيوان',
  g6: 'التنوع الأحيائي والوراثة'
};

export const curriculumData: Record<string, GradeCurriculum> = {
  g1: {
    name: 'الأول المتوسط',
    icon: '📘',
    chapters: [
      { title: 'مقدمة في علم الأحياء', desc: 'تعريف علم الأحياء وفروعه' },
      { title: 'الخلية وتركيبها', desc: 'الخلية النباتية والحيوانية' },
      { title: 'الأنسجة والأعضاء', desc: 'مستويات التنظيم' },
      { title: 'التصنيف والتنوع', desc: 'ممالك الكائنات الحية' }
    ]
  },
  g2: {
    name: 'الثاني المتوسط',
    icon: '🦠',
    chapters: [
      { title: 'علم التصنيف', desc: 'مبادئ تصنيف الكائنات' },
      { title: 'الكائنات الحية البسيطة', desc: 'البدائيات والبكتيريا' },
      { title: 'مملكة النباتات', desc: 'النباتات اللاوعائية والوعائية' },
      { title: 'مملكة الفطريات', desc: 'خصائص الفطريات' }
    ]
  },
  g3: {
    name: 'الثالث المتوسط',
    icon: '🌿',
    chapters: [
      { title: 'الجهاز العصبي', desc: 'تركيب الجهاز العصبي' },
      { title: 'الجهاز الهيكلي', desc: 'العظام والمفاصل' },
      { title: 'الجهاز الهضمي', desc: 'أعضاء الهضم' },
      { title: 'جهاز الدوران', desc: 'القلب والأوعية الدموية' }
    ]
  },
  g4: {
    name: 'الرابع العلمي',
    icon: '🧪',
    chapters: [
      { title: 'تصنيف الكائنات الحية', desc: 'مبادئ التصنيف' },
      { title: 'علم البيئة', desc: 'المكونات الحيوية وغير الحيوية' },
      { title: 'تلاؤم الحيوان', desc: 'التكيفات الشكلية' },
      { title: 'التلوث البيئي', desc: 'أنواع التلوث' }
    ]
  },
  g5: {
    name: 'الخامس العلمي',
    icon: '🐟',
    chapters: [
      { title: 'التغذية والهضم', desc: 'الجهاز الهضمي' },
      { title: 'التنفس', desc: 'الجهاز التنفسي' },
      { title: 'الإخراج', desc: 'الكليتان والجلد' },
      { title: 'الحركة', desc: 'الجهاز الهيكلي والعضلي' }
    ]
  },
  g6: {
    name: 'السادس العلمي',
    icon: '🧬',
    chapters: [
      { title: 'الخلية', desc: 'النظرية الخلوية' },
      { title: 'الأنسجة', desc: 'الأنسجة النباتية والحيوانية' },
      { title: 'التكاثر', desc: 'أنواع التكاثر' },
      { title: 'الوراثة', desc: 'قوانين مندل' }
    ]
  }
};

export const booksData: BookItem[] = [
  {
    id: 'b1',
    gradeKey: 'g1',
    grade: 'الأول المتوسط',
    icon: '📘',
    title: 'كتاب الأحياء - الصف الأول المتوسط (المنهج الوزاري)',
    author: 'وزارة التربية العراقية',
    specialization: 'علم الأحياء العام',
    academicLevel: 'المتوسطة',
    pages: 140,
    fileSize: '3.3 MB',
    year: 2024,
    pdfUrl: '/uploads/books/biology_g1.pdf',
    fileUrl: '/uploads/books/biology_g1.pdf',
    driveUrl: 'https://drive.google.com/file/d/1APm6D9sooNqWkdK0pWaBB5I7Sd08HsPcQ/view?usp=drivesdk',
    driveId: '1APm6D9sooNqWkdK0pWaBB5I7Sd08HsPcQ',
    driveAccessStatus: 'not_found',
    driveStatusMessage: 'ملف Google Drive تم حذفه أو تغييره في السحابة — تم تفعيل النسخة المعتمدة محلياً للقراءة والتنزيل المباشر.',
    sourceType: 'direct-pdf',
    coverUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
    description: 'المنهج الرسمي المعتمد لمادة الأحياء للصف الأول المتوسط؛ يشمل مبادئ الخلية، مستويات التنظيم في الكائنات الحية، ومدخل التصنيف.',
    status: 'published'
  },
  {
    id: 'b2',
    gradeKey: 'g2',
    grade: 'الثاني المتوسط',
    icon: '🦠',
    title: 'كتاب الأحياء - الصف الثاني المتوسط (الكائنات المجهرية)',
    author: 'وزارة التربية العراقية',
    specialization: 'الأحياء المجهرية والتصنيف',
    academicLevel: 'المتوسطة',
    pages: 168,
    fileSize: '3.1 MB',
    year: 2024,
    pdfUrl: '/uploads/books/biology_g2.pdf',
    fileUrl: '/uploads/books/biology_g2.pdf',
    driveUrl: 'https://drive.google.com/file/d/1k_k6VTpBaAJAxL_mm-lK8WwbzoBkLqHv/view?usp=drivesdk',
    driveId: '1k_k6VTpBaAJAxL_mm-lK8WwbzoBkLqHv',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    sourceType: 'direct-pdf',
    coverUrl: 'https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=600&q=80',
    description: 'منهج مادة الأحياء لطلبة الثاني المتوسط حول الكائنات المجهرية الدقيقة، البكتيريا، الفطريات، ومملكة النباتات.',
    status: 'published'
  },
  {
    id: 'b3',
    gradeKey: 'g3',
    grade: 'الثالث المتوسط',
    icon: '🌿',
    title: 'كتاب الأحياء - الصف الثالث المتوسط (أجهزة جسم الإنسان)',
    author: 'وزارة التربية العراقية',
    specialization: 'فسلجة جسم الإنسان',
    academicLevel: 'المتوسطة (وزاري)',
    pages: 196,
    fileSize: '3.3 MB',
    year: 2024,
    pdfUrl: '/uploads/books/biology_g3.pdf',
    fileUrl: '/uploads/books/biology_g3.pdf',
    driveUrl: 'https://drive.google.com/file/d/1bF3TOH47Bn0KQ-IcwuRNRBe9gm5tOFS5/view?usp=drivesdk',
    driveId: '1bF3TOH47Bn0KQ-IcwuRNRBe9gm5tOFS5',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    sourceType: 'direct-pdf',
    coverUrl: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=600&q=80',
    description: 'المرجع الوزاري الكامل لطلبة الثالث المتوسط حول أجهزة جسم الإنسان: الهيكلي، العضلي، الدوري، الهضمي، والتنفسي.',
    status: 'published'
  },
  {
    id: 'b4',
    gradeKey: 'g4',
    grade: 'الرابع العلمي',
    icon: '🧪',
    title: 'كتاب الأحياء - الصف الرابع العلمي (علم البيئة)',
    author: 'وزارة التربية العراقية',
    specialization: 'علم البيئة والتكيف الحيواني',
    academicLevel: 'الإعدادية',
    pages: 184,
    fileSize: '2.3 MB',
    year: 2024,
    pdfUrl: '/uploads/books/biology_g4.pdf',
    fileUrl: '/uploads/books/biology_g4.pdf',
    driveUrl: 'https://drive.google.com/file/d/1IJDdvL4PrUL68wlISVWh6bAIEtoCFh1h/view?usp=drivesdk',
    driveId: '1IJDdvL4PrUL68wlISVWh6bAIEtoCFh1h',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    sourceType: 'direct-pdf',
    coverUrl: 'https://images.unsplash.com/photo-1530210124550-912dc1381cb8?auto=format&fit=crop&w=600&q=80',
    description: 'كتاب الأحياء للرابع العلمي متضمناً علم البيئة وتدفق الطاقة والتكيفات المورفولوجية والوظيفية في الكائنات الحية.',
    status: 'published'
  },
  {
    id: 'b5',
    gradeKey: 'g5',
    grade: 'الخامس العلمي',
    icon: '🐟',
    title: 'كتاب الأحياء - الصف الخامس العلمي (الفسلجة المقارنة)',
    author: 'وزارة التربية العراقية',
    specialization: 'الفسلجة المقارنة',
    academicLevel: 'الإعدادية',
    pages: 212,
    fileSize: '2.3 MB',
    year: 2024,
    pdfUrl: '/uploads/books/biology_g5.pdf',
    fileUrl: '/uploads/books/biology_g5.pdf',
    driveUrl: 'https://drive.google.com/file/d/1Xtjy9PKMVi-8wvwHxU3IjWL052ueUXNe/view?usp=drivesdk',
    driveId: '1Xtjy9PKMVi-8wvwHxU3IjWL052ueUXNe',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    sourceType: 'direct-pdf',
    coverUrl: 'https://images.unsplash.com/photo-1507668077129-56e32842fceb?auto=format&fit=crop&w=600&q=80',
    description: 'الفسلجة المقارنة: التغذية، التنفس، النقل، الدوران، والإخراج والتوازن الأسموزي في الفقريات واللافقريات.',
    status: 'published'
  },
  {
    id: 'b6',
    gradeKey: 'g6',
    grade: 'السادس العلمي',
    icon: '🧬',
    title: 'كتاب الأحياء - الصف السادس العلمي (الخلية، الأنسجة، التكاثر، الوراثة)',
    author: 'وزارة التربية العراقية',
    specialization: 'الخلية، الأنسجة، التكاثر، الوراثة',
    academicLevel: 'السادس العلمي (الوزاري)',
    pages: 256,
    fileSize: '4.4 MB',
    year: 2024,
    pdfUrl: '/uploads/books/biology_g6.pdf',
    fileUrl: '/uploads/books/biology_g6.pdf',
    driveUrl: 'https://drive.google.com/file/d/1qwd_GN91iNb-st0Mvw7P3KINVvY1VDnX/view?usp=drivesdk',
    driveId: '1qwd_GN91iNb-st0Mvw7P3KINVvY1VDnX',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    sourceType: 'direct-pdf',
    coverUrl: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=600&q=80',
    description: 'الكتاب المنهجي الشامل لطلبة السادس العلمي والوزاري: النظرية الخلوية، الأنسجة، التكاثر، والوراثة المندلية والجزيئية.',
    status: 'published'
  }
];

export const initialLectures: LectureItem[] = [
  {
    id: 101,
    title: 'المحاضرة الأولى: مقدمة في تركيب الخلية والنظرية الخلوية',
    desc: 'شرح مفصل ومبسّط للنظرية الخلوية ومكونات السيتوبلازم والأغشية الحيوية.',
    grade: 'g6',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    isPaid: false,
    secretCode: null
  },
  {
    id: 102,
    title: 'محاضرة VIP: الأسرار الذهبية لحل مسائل الوراثة ومندل',
    desc: 'مراجعة مركزة وشرح المسائل الوراثية وتطبيقات قوانين مندل الأولى والثانية.',
    grade: 'g6',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    isPaid: true,
    secretCode: 'BIO2026'
  },
  {
    id: 103,
    title: 'جهاز الدوران والقلب وأوعية الدم في جسم الإنسان',
    desc: 'توضيح تفاعلي لمسار الدورة الدموية الكبرى والصغرى وصمامات القلب.',
    grade: 'g3',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    isPaid: false,
    secretCode: null
  }
];

export const initialUsers: UserItem[] = [
  {
    id: "STU-1001",
    uid: "UID-BIO-1001",
    name: "علي كرار البصري",
    emailOrPhone: "+964 770 123 4567",
    grade: "g6",
    track: "school",
    birthDate: "2007-04-15",
    birthYear: 2007,
    role: "vip",
    status: "active",
    isVip: true,
    deviceType: "android-apk",
    registeredAt: "2026-10-01",
    lastActive: "متصل الآن",
    unlockedLectures: [101, 102],
    notes: "طالب مجتهد مسجل في الدورة الشتوية"
  },
  {
    id: "STU-1002",
    uid: "UID-BIO-1002",
    name: "زينب حيدر الموسوي",
    emailOrPhone: "zainab.bio@gmail.com",
    grade: "g6",
    track: "school",
    birthDate: "2007-08-22",
    birthYear: 2007,
    role: "vip",
    status: "active",
    isVip: true,
    deviceType: "android-apk",
    registeredAt: "2026-10-03",
    lastActive: "منذ 10 دقائق",
    unlockedLectures: [101, 102],
    notes: "مشتركة VIP في محاضرات الوراثة"
  },
  {
    id: "STU-1003",
    uid: "UID-BIO-1003",
    name: "مصطفى أحمد الكرخي",
    emailOrPhone: "+964 780 987 6543",
    grade: "g3",
    track: "school",
    birthDate: "2010-02-18",
    birthYear: 2010,
    role: "student",
    status: "active",
    isVip: false,
    deviceType: "web-mobile",
    registeredAt: "2026-10-08",
    lastActive: "منذ ساعة",
    unlockedLectures: [103],
    notes: "متابع لمحاضرات جهاز الدوران"
  },
  {
    id: "STU-1004",
    uid: "UID-BIO-1004",
    name: "فاطمة عمار الكعبي",
    emailOrPhone: "+964 750 443 2211",
    grade: "g5",
    track: "school",
    birthDate: "2008-11-05",
    birthYear: 2008,
    role: "student",
    status: "active",
    isVip: false,
    deviceType: "android-apk",
    registeredAt: "2026-10-10",
    lastActive: "منذ ساعتين",
    unlockedLectures: [],
    notes: "تطبيق مثبت عبر APK"
  },
  {
    id: "STU-1005",
    uid: "UID-BIO-1005",
    name: "حسين علي الزيدي",
    emailOrPhone: "hussein.alzaidi@yahoo.com",
    grade: "g6",
    track: "school",
    birthDate: "2007-01-30",
    birthYear: 2007,
    role: "student",
    status: "blocked",
    isVip: false,
    deviceType: "web-desktop",
    registeredAt: "2026-09-25",
    lastActive: "أمس",
    unlockedLectures: [],
    notes: "حساب تم تعليقه مؤقتاً"
  },
  {
    id: "STU-1006",
    uid: "UID-BIO-1006",
    name: "سارة قاسم النجفي",
    emailOrPhone: "+964 771 556 7788",
    grade: "g4",
    track: "school",
    birthDate: "2009-06-12",
    birthYear: 2009,
    role: "student",
    status: "active",
    isVip: false,
    deviceType: "android-apk",
    registeredAt: "2026-10-12",
    lastActive: "منذ 3 ساعات",
    unlockedLectures: [],
    notes: "طالبة في الرابع العلمي - علم البيئة"
  },
  {
    id: "STU-1007",
    uid: "UID-BIO-1007",
    name: "كرار ميثم العامري",
    emailOrPhone: "+964 772 889 9001",
    grade: "g6",
    track: "school",
    birthDate: "2007-09-09",
    birthYear: 2007,
    role: "vip",
    status: "active",
    isVip: true,
    deviceType: "android-apk",
    registeredAt: "2026-10-15",
    lastActive: "منذ 5 دقائق",
    unlockedLectures: [101, 102],
    notes: "حاصل على 100 في الاختبار التجريبي"
  },
  {
    id: "STU-2001",
    uid: "UID-BIO-2001",
    name: "أحمد باسم الخفاجي",
    emailOrPhone: "ahmed.biochem@gmail.com",
    grade: "g6",
    track: "school",
    birthDate: "2007-05-14",
    birthYear: 2007,
    role: "vip",
    status: "active",
    isVip: true,
    deviceType: "web-desktop",
    registeredAt: "2026-10-16",
    lastActive: "منذ 20 دقيقة",
    unlockedLectures: [101],
    notes: "طالب متميز في السادس العلمي"
  },
  {
    id: "STU-2002",
    uid: "UID-BIO-2002",
    name: "مريم عماد البغدادي",
    emailOrPhone: "maryam.student@gmail.com",
    grade: "g5",
    track: "school",
    birthDate: "2008-10-28",
    birthYear: 2008,
    role: "student",
    status: "active",
    isVip: false,
    deviceType: "web-mobile",
    registeredAt: "2026-10-17",
    lastActive: "اليوم",
    unlockedLectures: [],
    notes: "طالبة في الخامس العلمي"
  }
];

export function formatYouTubeEmbedUrl(url: string): string {
  if (!url) return '';
  const trimmed = url.trim();
  
  // Already in embed format
  if (trimmed.includes('/embed/')) {
    return trimmed;
  }

  // Google Drive video link - direct in-app stream
  const driveMatch = trimmed.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (driveMatch && driveMatch[1]) {
    return `/api/stream-drive/${driveMatch[1]}`;
  }
  
  // YouTube match: regular watch, shorts, live, youtu.be
  const ytMatch = trimmed.match(/(?:youtube\.com\/(?:watch\?.*v=|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/i);
  if (ytMatch && ytMatch[1]) {
    return `https://www.youtube.com/embed/${ytMatch[1]}`;
  }
  
  return trimmed;
}
