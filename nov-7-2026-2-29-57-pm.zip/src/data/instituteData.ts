export interface InstituteStageConfig {
  id: string; // 'g1', 'g2', 'g3', 'g4', 'g5', 'g6'
  name: string;
  alias: string;
  icon: string;
  color: string;
  glow: string;
  badge: string;
  isActive: boolean;
}

export interface StudentGradeRecord {
  studentName?: string; // اسم الطالب (مثال: علي حيدر الزبيدي)
  gradeClass?: string; // صفه (مثال: السادس العلمي)
  section?: string; // شعبته (مثال: أ أو ب أو A)
  score: number; // درجته (مثال: 98)
  maxScore?: number;
  rating?: string; // التقدير (ممتاز، جيد جداً...)
  note?: string; // ملاحظات
  studentCode?: string; // كود اختياري
}

export type InstitutePostType = 'grade' | 'homework';
export type InstitutePostStatus = 'published' | 'draft' | 'archived' | 'hidden';
export type GradeDisplayMode = 'table' | 'summary' | 'file' | 'image';

export interface InstitutePost {
  id: string;
  type: InstitutePostType;
  stageId: string;
  subject: string;
  title: string;
  examType?: string; // نوع الامتحان: يومي / شهري / فصلي / شامل / وزاري تجريبي
  date: string; // تاريخ الاختبار أو تاريخ نشر الواجب (YYYY-MM-DD)
  publishDate: string;
  status: InstitutePostStatus;
  notes?: string;
  attachmentUrl?: string;
  attachmentType?: 'image' | 'pdf' | 'link';
  attachmentName?: string;
  createdAt: string;
  updatedAt: string;

  // Grade-specific fields
  displayMode?: GradeDisplayMode;
  maxScore?: number;
  minPassingScore?: number;
  averageScore?: number;
  highestScore?: number;
  successRate?: number;
  studentCount?: number;
  records?: StudentGradeRecord[];

  // Homework-specific fields
  details?: string;
  dueDate?: string; // موعد التسليم (YYYY-MM-DD)
}

export interface InstituteAuditLog {
  id: string;
  action: string;
  targetTitle: string;
  targetType: 'grade' | 'homework' | 'stage';
  adminName: string;
  timestamp: string;
}

export const defaultInstituteStages: InstituteStageConfig[] = [
  {
    id: 'g1',
    name: 'الأول المتوسط',
    alias: 'الصف الأول المتوسط',
    icon: '📘',
    color: '#3fa9f5',
    glow: 'rgba(63, 169, 245, 0.25)',
    badge: 'المرحلة المتوسطة',
    isActive: true
  },
  {
    id: 'g2',
    name: 'الثاني المتوسط',
    alias: 'الصف الثاني المتوسط',
    icon: '🦠',
    color: '#0fb98a',
    glow: 'rgba(15, 185, 138, 0.25)',
    badge: 'المرحلة المتوسطة',
    isActive: true
  },
  {
    id: 'g3',
    name: 'الثالث المتوسط',
    alias: 'الصف الثالث المتوسط (وزاري)',
    icon: '🌿',
    color: '#8b6cf0',
    glow: 'rgba(139, 108, 240, 0.25)',
    badge: 'وزاري وتأسيسي',
    isActive: true
  },
  {
    id: 'g4',
    name: 'الرابع الإعدادي',
    alias: 'الرابع الإعدادي (العلمي)',
    icon: '🧪',
    color: '#e9c978',
    glow: 'rgba(233, 201, 120, 0.25)',
    badge: 'المرحلة الإعدادية',
    isActive: true
  },
  {
    id: 'g5',
    name: 'الخامس الإعدادي',
    alias: 'الخامس الإعدادي (العلمي)',
    icon: '🐟',
    color: '#f05d5d',
    glow: 'rgba(240, 93, 93, 0.25)',
    badge: 'المرحلة الإعدادية',
    isActive: true
  },
  {
    id: 'g6',
    name: 'السادس الإعدادي',
    alias: 'السادس العلمي (الوزاري الأهم)',
    icon: '🧬',
    color: '#00d2ff',
    glow: 'rgba(0, 210, 255, 0.25)',
    badge: 'المرحلة الوزارية الذهبية',
    isActive: true
  }
];

export const initialInstitutePosts: InstitutePost[] = [
  // Sixth Grade (السادس الإعدادي)
  {
    id: 'post-g6-grade-1',
    type: 'grade',
    stageId: 'g6',
    subject: 'علم الأحياء',
    title: 'نتائج الاختبار الشامل للفصل الأول - الخلية وتركيبها',
    date: '2026-10-15',
    publishDate: '2026-10-16',
    status: 'published',
    displayMode: 'table',
    maxScore: 100,
    minPassingScore: 50,
    averageScore: 88.5,
    highestScore: 100,
    successRate: 94,
    studentCount: 38,
    notes: 'مستوى متميز جداً لطلاب المعهد في الامتحان الوزاري التجريبي الأول. تم توفير الاستعلام الفردي بالأكواد للحفاظ على الخصوصية الكاملة.',
    attachmentUrl: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=1200&q=80',
    attachmentType: 'image',
    attachmentName: 'لوحة شرف الأوائل - معهد قمة النجاح',
    createdAt: '2026-10-16T10:00:00.000Z',
    updatedAt: '2026-10-16T10:00:00.000Z',
    records: [
      { studentName: 'علي حيدر الزبيدي', gradeClass: 'السادس العلمي', section: 'أ', studentCode: 'BIO-601', score: 100, rating: 'ممتاز ⭐️', note: 'الدرجة الكاملة بجدارة' },
      { studentName: 'فاطمة أحمد الساعدي', gradeClass: 'السادس العلمي', section: 'أ', studentCode: 'BIO-602', score: 98, rating: 'ممتاز', note: 'إجابة نموذجية ممتازة' },
      { studentName: 'حسين محمد الكرخي', gradeClass: 'السادس العلمي', section: 'ب', studentCode: 'BIO-603', score: 95, rating: 'ممتاز', note: 'رسم بيولوجي دقيق' },
      { studentName: 'زينب جاسم العامري', gradeClass: 'السادس العلمي', section: 'أ', studentCode: 'BIO-604', score: 92, rating: 'ممتاز', note: 'تركيز ممتاز بالتعاليل' },
      { studentName: 'عبد الله قحطان الربيعي', gradeClass: 'السادس العلمي', section: 'ب', studentCode: 'BIO-605', score: 89, rating: 'جيد جداً مرتفع', note: 'مستوى متصاعد' },
      { studentName: 'مريم حسن الخفاجي', gradeClass: 'السادس العلمي', section: 'ج', studentCode: 'BIO-606', score: 85, rating: 'جيد جداً', note: 'مراجعة نقطة الغشاء البلازمي' },
      { studentName: 'سجاد كريم الدراجي', gradeClass: 'السادس العلمي', section: 'ب', studentCode: 'BIO-607', score: 80, rating: 'جيد جداً', note: 'أداء طيب' },
      { studentName: 'نور الهدى إياد البياتي', gradeClass: 'السادس العلمي', section: 'أ', studentCode: 'BIO-608', score: 76, rating: 'جيد', note: 'المزيد من التركيز بالرسومات' }
    ]
  },
  {
    id: 'post-g6-hw-1',
    type: 'homework',
    stageId: 'g6',
    subject: 'علم الأحياء',
    title: 'واجب تحضير مسائل الوراثة المندلية (التهجين الأحادي والثنائي)',
    date: '2026-10-18',
    publishDate: '2026-10-18',
    dueDate: '2026-10-22',
    status: 'published',
    details: 'حل المسائل الوزارية من الصفحة 45 إلى الصفحة 52 من ملزمة الوراثة الذهبية، مع التركيز على خطوات التضريب وتحديد الطرز المظهرية والوراثية ونسب الأبناء.',
    notes: 'يرجى مراجعة محاضرة VIP رقم 102 في قسم المحاضرات قبل البدء بالحل.',
    attachmentUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80',
    attachmentType: 'image',
    attachmentName: 'مخطط مسائل الوراثة الاسترشادي.pdf',
    createdAt: '2026-10-18T14:00:00.000Z',
    updatedAt: '2026-10-18T14:00:00.000Z'
  },
  {
    id: 'post-g6-hw-2',
    type: 'homework',
    stageId: 'g6',
    subject: 'علم الأحياء',
    title: 'رسم ومراجعة أطوار الانقسام الاختزالي الأول والثاني',
    date: '2026-10-12',
    publishDate: '2026-10-12',
    dueDate: '2026-10-15',
    status: 'published',
    details: 'إتقان رسم الطور التمهيدي الأول بأدواره الخمسة (القلادي، الازدواجي، التغلظي، الانفراجي، الحركي) مع تأشير ظاهرة العبور والتعابر.',
    notes: 'تمت مناقشة الرسومات داخل قاعة المعهد.',
    createdAt: '2026-10-12T09:00:00.000Z',
    updatedAt: '2026-10-12T09:00:00.000Z'
  },

  // Third Grade (الثالث المتوسط)
  {
    id: 'post-g3-grade-1',
    type: 'grade',
    stageId: 'g3',
    subject: 'علم الأحياء',
    title: 'نتائج الاختبار الشهري الأول - الجهاز الهيكلي والعظمي',
    date: '2026-10-14',
    publishDate: '2026-10-15',
    status: 'published',
    displayMode: 'summary',
    maxScore: 100,
    minPassingScore: 50,
    averageScore: 84.2,
    highestScore: 100,
    successRate: 91,
    studentCount: 42,
    notes: 'ألف مبارك لطلابنا الأعزاء. النتائج معروضة كملخص إحصائي للحفاظ على الخصوصية، ويمكن لكل طالب الاستعلام عن نتيجته عبر الكود الامتحاني.',
    records: [
      { studentCode: 'G3-101', score: 100, rating: 'ممتاز ⭐️' },
      { studentCode: 'G3-102', score: 96, rating: 'ممتاز' },
      { studentCode: 'G3-103', score: 91, rating: 'ممتاز' },
      { studentCode: 'G3-104', score: 88, rating: 'جيد جداً' },
      { studentCode: 'G3-105', score: 82, rating: 'جيد جداً' }
    ],
    createdAt: '2026-10-15T11:00:00.000Z',
    updatedAt: '2026-10-15T11:00:00.000Z'
  },
  {
    id: 'post-g3-hw-1',
    type: 'homework',
    stageId: 'g3',
    subject: 'علم الأحياء',
    title: 'تحضير وحفظ تعاليل ورسومات جهاز الدوران والقلب',
    date: '2026-10-17',
    publishDate: '2026-10-17',
    dueDate: '2026-10-21',
    status: 'published',
    details: 'حفظ مكونات الدم (الكريات الحمراء والبيضاء والصفيحات الدموية)، ومقارنة وظائف الشرايين والأوردة، ورسم تركيب القلب من الداخل.',
    notes: 'امتحان يومي سريع (كويز) في بداية المحاضرة القادمة.',
    createdAt: '2026-10-17T12:00:00.000Z',
    updatedAt: '2026-10-17T12:00:00.000Z'
  },

  // Fourth Grade (الرابع الإعدادي)
  {
    id: 'post-g4-hw-1',
    type: 'homework',
    stageId: 'g4',
    subject: 'علم الأحياء',
    title: 'واجب الفصل الثاني - السلاسل الغذائية والدورات البيوجيوكيميائية',
    date: '2026-10-18',
    publishDate: '2026-10-18',
    dueDate: '2026-10-23',
    status: 'published',
    details: 'كتابة ملخص عن دورة النيتروجين ودورة الفسفور في الطبيعة، مع حل أسئلة نهاية الفصل من الكتاب المنهجي.',
    notes: 'يرجى الالتزام بالموعد المحدد للتسليم.',
    createdAt: '2026-10-18T16:00:00.000Z',
    updatedAt: '2026-10-18T16:00:00.000Z'
  },
  {
    id: 'post-g4-grade-1',
    type: 'grade',
    stageId: 'g4',
    subject: 'علم الأحياء',
    title: 'نتائج كويز علم البيئة والتصنيف الأحيائي',
    date: '2026-10-11',
    publishDate: '2026-10-12',
    status: 'published',
    displayMode: 'table',
    maxScore: 20,
    minPassingScore: 10,
    averageScore: 17.5,
    highestScore: 20,
    successRate: 96,
    studentCount: 28,
    notes: 'اختبار يومي سريع لضبط مصطلحات النظام البيئي.',
    records: [
      { studentCode: 'G4-401', score: 20, rating: 'كاملة ⭐️' },
      { studentCode: 'G4-402', score: 19, rating: 'ممتاز' },
      { studentCode: 'G4-403', score: 18, rating: 'جيد جداً' },
      { studentCode: 'G4-404', score: 17, rating: 'جيد جداً' }
    ],
    createdAt: '2026-10-12T10:00:00.000Z',
    updatedAt: '2026-10-12T10:00:00.000Z'
  },

  // Fifth Grade (الخامس الإعدادي)
  {
    id: 'post-g5-hw-1',
    type: 'homework',
    stageId: 'g5',
    subject: 'علم الأحياء',
    title: 'تحضير آليات التنفس في الحيوانات الفقرية واللافقرية',
    date: '2026-10-16',
    publishDate: '2026-10-16',
    dueDate: '2026-10-20',
    status: 'published',
    details: 'المقارنة بين التنفس الخيشومي والجلدي والرئوي مع ذكر أمثلة لكل نوع، وحفظ معادلة تبادل الغازات.',
    createdAt: '2026-10-16T15:00:00.000Z',
    updatedAt: '2026-10-16T15:00:00.000Z'
  },

  // First & Second Grade (الأول والثاني المتوسط)
  {
    id: 'post-g1-hw-1',
    type: 'homework',
    stageId: 'g1',
    subject: 'العلوم والأحياء',
    title: 'واجب تركيب المجهر الضوئي وأجزائه',
    date: '2026-10-17',
    publishDate: '2026-10-17',
    dueDate: '2026-10-22',
    status: 'published',
    details: 'حفظ الأجزاء الميكانيكية والبصرية للمجهر المركب ووظيفة كل جزء مع رسم توضيحي مبسط.',
    createdAt: '2026-10-17T08:00:00.000Z',
    updatedAt: '2026-10-17T08:00:00.000Z'
  },
  {
    id: 'post-g2-hw-1',
    type: 'homework',
    stageId: 'g2',
    subject: 'العلوم والأحياء',
    title: 'واجب تصنيف البكتيريا وأشكالها التغذوية والتركيبية',
    date: '2026-10-18',
    publishDate: '2026-10-18',
    dueDate: '2026-10-24',
    status: 'published',
    details: 'حفظ الفروقات بين البكتيريا الكروية والعصوية والحلزونية مع رسم توضيحي.',
    createdAt: '2026-10-18T11:00:00.000Z',
    updatedAt: '2026-10-18T11:00:00.000Z'
  }
];

export const initialInstituteAuditLogs: InstituteAuditLog[] = [
  {
    id: 'audit-1',
    action: 'نشر درجات امتحان شامل',
    targetTitle: 'نتائج الاختبار الشامل للفصل الأول - الخلية وتركيبها',
    targetType: 'grade',
    adminName: 'الأستاذ وسام سهيل العامري',
    timestamp: '2026-10-16T10:00:00.000Z'
  },
  {
    id: 'audit-2',
    action: 'نشر واجب دراسي جديد',
    targetTitle: 'واجب تحضير مسائل الوراثة المندلية',
    targetType: 'homework',
    adminName: 'الأستاذ وسام سهيل العامري',
    timestamp: '2026-10-18T14:00:00.000Z'
  }
];
