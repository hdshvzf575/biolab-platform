import React, { useState, useEffect, useCallback, useMemo, Suspense, lazy } from 'react';
import { 
  ArrowUp, 
  WifiOff, 
  Bell,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { Navbar } from './components/Navbar';
import { ScreenHeader } from './components/ScreenHeader';
import { NavigationDock } from './components/NavigationDock';

// Lazy loading of sections for radical performance & bundle size reduction
const Hero = lazy(() => import('./components/Hero').then(m => ({ default: m.Hero })));
const LecturesSection = lazy(() => import('./components/LecturesSection').then(m => ({ default: m.LecturesSection })));
const InstituteStudentsSection = lazy(() => import('./components/InstituteStudentsSection').then(m => ({ default: m.InstituteStudentsSection })));
const GradesSection = lazy(() => import('./components/GradesSection').then(m => ({ default: m.GradesSection })));
const CurriculumSection = lazy(() => import('./components/CurriculumSection').then(m => ({ default: m.CurriculumSection })));
const BooksSection = lazy(() => import('./components/BooksSection').then(m => ({ default: m.BooksSection })));
const InstituteSection = lazy(() => import('./components/InstituteSection').then(m => ({ default: m.InstituteSection })));
const AboutTeacher = lazy(() => import('./components/AboutTeacher').then(m => ({ default: m.AboutTeacher })));
const TeacherContact = lazy(() => import('./components/TeacherContact').then(m => ({ default: m.TeacherContact })));

// Modals are lazy loaded only when needed
const PdfViewerModal = lazy(() => import('./components/PdfViewerModal').then(m => ({ default: m.PdfViewerModal })));
const VipUnlockModal = lazy(() => import('./components/VipUnlockModal').then(m => ({ default: m.VipUnlockModal })));
const AdminPanelModal = lazy(() => import('./components/AdminPanelModal').then(m => ({ default: m.AdminPanelModal })));
const InstallAPKModal = lazy(() => import('./components/InstallAPKModal').then(m => ({ default: m.InstallAPKModal })));
const StudentOnboardingModal = lazy(() => import('./components/StudentOnboardingModal').then(m => ({ default: m.StudentOnboardingModal })));
const AppUpdateModal = lazy(() => import('./components/AppUpdateModal').then(m => ({ default: m.AppUpdateModal })));
const AIAssistantModal = lazy(() => import('./components/AIAssistantModal').then(m => ({ default: m.AIAssistantModal })));
const AndroidPermissionModal = lazy(() => import('./components/AndroidPermissionModal').then(m => ({ default: m.AndroidPermissionModal })));
const AuthModal = lazy(() => import('./components/AuthModal').then(m => ({ default: m.AuthModal })));

import { androidPermissionBridge } from './services/androidPermissionBridge';
import { UserProfile } from './components/StudentOnboardingModal';
import { AppUpdateData } from './components/AppUpdateModal';
import { 
  shouldShowAppUpdateModal, 
  dismissUpdateVersion, 
  getInstalledVersion,
  applyAppUpdateSafely,
  verifyAndPurgeStaleVersionCache,
  CURRENT_APP_VERSION
} from './utils/versionManager';

import { 
  LectureItem, 
  BookItem, 
  initialLectures,
  initialUsers,
  booksData
} from './data/platformData';
import { 
  getThemePresetById, 
  applyThemeToDocument 
} from './data/themePresets';
import { 
  soundManager, 
  playClickSound 
} from './utils/audioEffects';
import { useOnlineStatus } from './hooks/usePWAInstall';
import {
  testFirestoreConnection,
  seedCloudDatabaseIfEmpty,
  subscribeToLectures,
  addLectureToCloud,
  updateLectureInCloud,
  deleteLectureFromCloud,
  registerStudentInCloud,
  subscribeToAppUpdate,
  onAuthStatusChanged,
  logoutUser,
  isUserAdmin,
  syncAuthUserWithProfile,
  checkRedirectAuthResult,
  FirebaseUser
} from './services/firebase';

// Elegant, lightweight skeleton loader matching the active theme
const SectionLoadingFallback = () => (
  <div className="w-[min(1240px,92%)] mx-auto py-20 space-y-8 animate-pulse text-center">
    <div className="inline-block h-6 w-36 bg-white/10 rounded-full mx-auto" />
    <div className="h-10 w-72 sm:w-96 bg-white/10 rounded-2xl mx-auto" />
    <div className="h-4 w-60 bg-white/5 rounded-full mx-auto" />
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-6">
      <div className="h-60 rounded-3xl bg-white/5 border border-white/5" />
      <div className="h-60 rounded-3xl bg-white/5 border border-white/5" />
      <div className="h-60 rounded-3xl bg-white/5 border border-white/5" />
    </div>
  </div>
);

const VALID_SCREENS = [
  'home', 
  'institute-students', 
  'books',
  'lectures', 
  'grades', 
  'lessons', 
  'institute', 
  'about', 
  'contact'
];

export default function App() {
  // Screen router state
  const [currentScreen, setCurrentScreen] = useState<string>('home');

  // Theme mode (dark / light)
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // 5 Graphical Themes & Visual Style preset
  const [activeThemeId, setActiveThemeId] = useState<'royal' | 'cyber' | 'bio' | 'cosmic' | 'minimal'>('royal');

  // Transition style
  const [transitionStyle, setTransitionStyle] = useState<'cinematic' | 'cyber' | 'elastic' | 'cosmic' | 'minimal'>('cinematic');

  // Audio click sound & mute state
  const [isSoundMuted, setIsSoundMuted] = useState<boolean>(soundManager.getIsMuted());
  const [soundVolume, setSoundVolume] = useState<number>(soundManager.getVolume());

  // Fullscreen state
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Preloader state
  const [showPreloader, setShowPreloader] = useState(true);

  // Scroll to top visibility
  const [showToTop, setShowToTop] = useState(false);

  // Curriculum filter & Lectures filter
  const [curriculumFilter, setCurriculumFilter] = useState('all');
  const [lecturesFilter, setLecturesFilter] = useState('all');

  // Modals state
  const [selectedPdfBook, setSelectedPdfBook] = useState<BookItem | null>(null);
  const [vipModalLectureId, setVipModalLectureId] = useState<number | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [isAPKModalOpen, setIsAPKModalOpen] = useState(false);
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);

  // Firebase Authentication State
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register' | 'forgot'>('login');

  // User Profile, Track & Onboarding State
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('biolab_user_profile');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);

  // Check if active user is Admin (by Firebase Auth email or stored token)
  const isAdmin = useMemo(() => {
    if (isUserAdmin(currentUser)) return true;
    try {
      const token = typeof sessionStorage !== 'undefined' ? sessionStorage.getItem('biolab_admin_token') : null;
      return token === 'wissam_bio_admin_token_2026_secure';
    } catch (e) {
      return false;
    }
  }, [currentUser]);

  // In-App Live Update state
  const [appUpdateData, setAppUpdateData] = useState<AppUpdateData | null>(null);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);

  // Data state: Lectures and Unlocked VIPs
  const [lectures, setLectures] = useState<LectureItem[]>([]);
  const [isLecturesLive, setIsLecturesLive] = useState(false);
  const [unlockedVip, setUnlockedVip] = useState<number[]>([]);
  const [isRefreshingLectures, setIsRefreshingLectures] = useState(false);

  // Broadcast announcement banner state
  const [activeAnnouncement, setActiveAnnouncement] = useState<string | null>(null);

  // Android & System Permissions state (Notifications & Scoped Storage)
  const [isPermissionModalOpen, setIsPermissionModalOpen] = useState(false);
  const [permissionModalType, setPermissionModalType] = useState<'notifications' | 'storage'>('notifications');
  const [permissionTargetTitle, setPermissionTargetTitle] = useState<string | undefined>(undefined);
  const [isNotificationsEnabled, setIsNotificationsEnabled] = useState<boolean>(false);

  const isOnline = useOnlineStatus();

  // Navigation router with Browser & Android Back Button integration
  const navigateTo = useCallback((screenId: string) => {
    if (screenId === currentScreen) return;
    playClickSound();
    window.scrollTo({ top: 0, behavior: 'instant' });
    setCurrentScreen(screenId);
    try {
      window.history.pushState({ screen: screenId }, '', `#${screenId}`);
    } catch (e) {}
  }, [currentScreen]);

  // Sync settings (themes, transition, sound) from server
  const fetchSettingsFromServer = useCallback(async () => {
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.settings) {
          if (data.settings.activeThemeId) {
            setActiveThemeId(data.settings.activeThemeId);
            applyThemeToDocument(getThemePresetById(data.settings.activeThemeId));
            soundManager.setActiveTheme(data.settings.activeThemeId);
          }
          if (data.settings.transitionStyle) {
            setTransitionStyle(data.settings.transitionStyle);
            document.documentElement.setAttribute('data-transition-style', data.settings.transitionStyle);
          }
          if (data.settings.soundEnabled !== undefined) {
            const isMuted = !data.settings.soundEnabled;
            setIsSoundMuted(isMuted);
            soundManager.setIsMuted(isMuted);
          }
          if (data.settings.soundVolume !== undefined) {
            setSoundVolume(data.settings.soundVolume);
            soundManager.setVolume(data.settings.soundVolume);
          }
        }
      }
    } catch (e) {}
  }, []);

  // Fetch lectures from Server API (Online internet synchronization with safe fallback)
  const fetchLecturesFromServer = useCallback(async (showLoading = false) => {
    if (showLoading) setIsRefreshingLectures(true);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4500);

    try {
      const res = await fetch('/api/lectures', { signal: controller.signal });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.lectures)) {
          // If we have live data from Firestore, don't overwrite with potentially stale server data
          // Unless it's a forced manual refresh (showLoading is true)
          if (!isLecturesLive || showLoading) {
            setLectures(data.lectures);
          }
          
          try {
            localStorage.setItem('platform_lectures', JSON.stringify(data.lectures));
            localStorage.setItem('biolab_lectures_initialized', 'true');
          } catch (e) {}
        }
      }
    } catch (err: any) {
      console.warn('Notice: Server lectures sync offline, falling back to local storage:', err?.message || err);
      try {
        const saved = localStorage.getItem('platform_lectures');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            if (!isLecturesLive || showLoading) {
              setLectures(parsed);
            }
            return;
          }
        }
      } catch (e) {}
    } finally {
      clearTimeout(timeoutId);
      if (showLoading) {
        setTimeout(() => setIsRefreshingLectures(false), 800);
      }
    }
  }, [isLecturesLive]);

  // Register client session with server (Adds user to Admin User Management with offline resilience)
  const syncUserSessionWithServer = useCallback(async () => {
    try {
      let savedProfile: UserProfile | null = null;
      try {
        const raw = localStorage.getItem('biolab_user_profile');
        if (raw) savedProfile = JSON.parse(raw);
      } catch (e) {}

      let sessionId = savedProfile?.uid || localStorage.getItem('biolab_session_id');
      if (!sessionId) {
        sessionId = `UID-BIO-${Math.floor(1000 + Math.random() * 9000)}`;
        try {
          localStorage.setItem('biolab_session_id', sessionId);
        } catch (e) {}
      }

      // Safe environment check for Android APK across all WebView engines
      let isAndroidAPK = false;
      try {
        isAndroidAPK = Boolean(
          (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) ||
          (typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().includes('android'))
        );
      } catch (e) {}

      const deviceType = isAndroidAPK ? 'android-apk' : (typeof window !== 'undefined' && window.innerWidth < 768 ? 'web-mobile' : 'web-desktop');

      // Abort controller with timeout to guarantee zero hang if offline
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      try {
        await fetch('/api/users/sync-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            id: sessionId,
            uid: sessionId,
            name: savedProfile?.name,
            track: savedProfile?.track || 'school',
            grade: savedProfile?.grade || 'g6',
            deviceType
          })
        });
      } catch (fetchErr: any) {
        // Silently tolerate offline state without breaking app
        console.warn('Session sync notice (offline mode active):', fetchErr?.message || fetchErr);
      } finally {
        clearTimeout(timeoutId);
      }

      // Also register student directly to Firestore if online
      if (savedProfile) {
        registerStudentInCloud(savedProfile).catch(() => {});
      }
    } catch (e) {
      console.warn('syncUserSessionWithServer caught safely:', e);
    }
  }, []);

  // Check in-app live update from server API with no-store cache busting silently
  const checkAppUpdate = useCallback(async () => {
    try {
      const res = await fetch('/api/app-update', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.update) {
          setAppUpdateData(data.update);
        }
      }
    } catch (e) {}
  }, []);

  // Onboarding completion callback: saves to Firestore central cloud & server API
  const handleCompleteOnboarding = useCallback(async (profile: UserProfile) => {
    setUserProfile(profile);
    setIsOnboardingOpen(false);

    try {
      localStorage.setItem('biolab_user_profile', JSON.stringify(profile));
    } catch (e) {}

    // 1) Save to central Firestore database
    try {
      await registerStudentInCloud(profile);
    } catch (err) {
      console.warn('Could not register to cloud directly:', err);
    }

    // 2) Sync to server API
    try {
      await fetch('/api/users/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile)
      });
    } catch (err) {}

    navigateTo('home');
  }, [navigateTo]);

  // Android & Browser Back Button handler
  useEffect(() => {
    const handlePopState = (e: PopStateEvent) => {
      if (e.state && e.state.screen && VALID_SCREENS.includes(e.state.screen)) {
        setCurrentScreen(e.state.screen);
      } else {
        const hash = window.location.hash.replace('#', '');
        if (hash && VALID_SCREENS.includes(hash)) {
          setCurrentScreen(hash);
        } else {
          setCurrentScreen('home');
        }
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Initial load
  useEffect(() => {
    // 1) Load theme mode and 5 Graphical Themes preset
    try {
      const savedTheme = localStorage.getItem('bio-theme') as 'dark' | 'light' | null;
      if (savedTheme) {
        setTheme(savedTheme);
        document.documentElement.setAttribute('data-theme', savedTheme);
      } else {
        document.documentElement.setAttribute('data-theme', 'dark');
      }

      // Load active graphical theme (Royal, Cyber, Bio, Cosmic, Minimal)
      const savedPresetId = (localStorage.getItem('biolab_active_theme_id') || 'royal') as any;
      setActiveThemeId(savedPresetId);
      applyThemeToDocument(getThemePresetById(savedPresetId));
      soundManager.setActiveTheme(savedPresetId);

      // Load transition style
      const savedTransition = (localStorage.getItem('biolab_transition_style') || 'cinematic') as any;
      setTransitionStyle(savedTransition);
      document.documentElement.setAttribute('data-transition-style', savedTransition);
    } catch (e) {}

    // Listen for global sound state changes
    const onSoundChange = (e: any) => {
      if (e.detail && typeof e.detail.isMuted === 'boolean') {
        setIsSoundMuted(e.detail.isMuted);
      }
    };
    window.addEventListener('biolab-sound-state-change', onSoundChange);

    // Inspect current notification permission status (Android 13+ & Web)
    androidPermissionBridge.checkNotificationPermission().then((status) => {
      setIsNotificationsEnabled(status === 'granted');
    });

    const onNotificationStateChanged = (e: any) => {
      if (e.detail && typeof e.detail.granted === 'boolean') {
        setIsNotificationsEnabled(e.detail.granted);
      }
    };
    window.addEventListener('biolab_notification_state_changed', onNotificationStateChanged);

    const onPermissionRequested = (e: any) => {
      const type = e.detail?.type || 'notifications';
      const title = e.detail?.title;
      setPermissionModalType(type);
      setPermissionTargetTitle(title);
      setIsPermissionModalOpen(true);
    };
    window.addEventListener('biolab_request_permission', onPermissionRequested);

    // 2) Load initial lectures from local storage immediately for zero-delay UX
    try {
      const savedLectures = localStorage.getItem('platform_lectures');
      if (savedLectures) {
        const parsed = JSON.parse(savedLectures);
        setLectures(Array.isArray(parsed) ? parsed : []);
      } else {
        setLectures([]);
      }
    } catch (e) {
      setLectures([]);
    }

    // 3) Load unlocked VIPs
    try {
      const savedVip = localStorage.getItem('unlocked_vip_lectures');
      if (savedVip) {
        setUnlockedVip(JSON.parse(savedVip));
      }
    } catch (e) {}

    // 4) Check broadcast announcements
    try {
      const savedAnnouncement = localStorage.getItem('admin_broadcast_announcement');
      if (savedAnnouncement) {
        const parsed = JSON.parse(savedAnnouncement);
        if (parsed.text) setActiveAnnouncement(parsed.text);
      }
    } catch (e) {}

    // 5) Connect to Central Cloud Database (Firebase Firestore) & Seed once if empty
    testFirestoreConnection().then(() => {
      seedCloudDatabaseIfEmpty(initialLectures, initialUsers, booksData);
    });

    // 5.0) Real-time listener for Firebase Authentication state & Student Profile Link
    const unsubscribeAuth = onAuthStatusChanged(async (fbUser) => {
      setCurrentUser(fbUser);
      if (fbUser) {
        try {
          const profile = await syncAuthUserWithProfile(fbUser);
          setUserProfile(profile);
        } catch (err) {
          console.warn('Profile sync on auth change notice:', err);
        }
      }
    });

    // 5.0) Startup Cache Invalidation: Purge obsolete bundle caches if app was upgraded
    verifyAndPurgeStaleVersionCache().catch(() => {});

    // Check Google Auth redirect result (for mobile WebView & redirect flows)
    checkRedirectAuthResult().then(async (result) => {
      if (result?.user) {
        try {
          const profile = await syncAuthUserWithProfile(result.user);
          setUserProfile(profile);
        } catch (e) {}
      }
    });

    // 5.1) Real-time listener for central cloud lectures across all devices & Android APK
    const unsubscribeLectures = subscribeToLectures(
      (cloudLectures) => {
        if (Array.isArray(cloudLectures)) {
          setLectures(cloudLectures);
          setIsLecturesLive(true);
          try {
            localStorage.setItem('platform_lectures', JSON.stringify(cloudLectures));
            localStorage.setItem('biolab_lectures_initialized', 'true');
          } catch (e) {}
        }
      },
      (error) => {
        console.warn('Firestore lectures listener offline/error notice (preserving local curriculum):', error?.message || error);
      }
    );

    // 5.2) Real-time listener for live app updates
    const unsubscribeAppUpdate = subscribeToAppUpdate(
      (update) => {
        if (update) {
          setAppUpdateData(update);
        }
      },
      (error) => {
        console.warn('Firestore app update subscription notice:', error?.message || error);
      }
    );

    // 5.3) Server synchronization fallback
    fetchLecturesFromServer(false);
    fetchSettingsFromServer();
    syncUserSessionWithServer();
    checkAppUpdate();

    // 5.4) Check if student profile & track are registered
    try {
      const savedProfile = localStorage.getItem('biolab_user_profile');
      if (!savedProfile) {
        setIsOnboardingOpen(true);
      } else {
        const parsed = JSON.parse(savedProfile);
        setUserProfile(parsed);
      }
    } catch (e) {
      setIsOnboardingOpen(true);
    }

    // 6) Real-time sync on visibility change (when user returns to tab or wakes up phone)
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        fetchLecturesFromServer(false);
        syncUserSessionWithServer();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // 6.2) Automatic silent background re-sync upon internet connection recovery
    const handleOnlineReconnect = () => {
      console.log('🌐 تم استعادة الاتصال بالإنترنت: جاري مزامنة المحتوى في الخلفية...');
      fetchLecturesFromServer(false);
      fetchSettingsFromServer();
      syncUserSessionWithServer();
    };
    window.addEventListener('online', handleOnlineReconnect);

    // 6.3) Fast background poll (every 10 seconds) as redundant fallback
    const pollInterval = setInterval(() => {
      fetchLecturesFromServer(false);
    }, 10000);

    // 7) Check initial URL hash
    const initialHash = window.location.hash.replace('#', '');
    if (initialHash && VALID_SCREENS.includes(initialHash)) {
      setCurrentScreen(initialHash);
    }

    // Dismiss preloader after brief delay
    const preloaderTimer = setTimeout(() => {
      setShowPreloader(false);
    }, 450);

    return () => {
      clearTimeout(preloaderTimer);
      clearInterval(pollInterval);
      if (typeof unsubscribeAuth === 'function') {
        try { unsubscribeAuth(); } catch (e) {}
      }
      if (typeof unsubscribeLectures === 'function') {
        try { unsubscribeLectures(); } catch (e) {}
      }
      if (typeof unsubscribeAppUpdate === 'function') {
        try { unsubscribeAppUpdate(); } catch (e) {}
      }
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('online', handleOnlineReconnect);
      window.removeEventListener('biolab-sound-state-change', onSoundChange);
      window.removeEventListener('biolab_notification_state_changed', onNotificationStateChanged);
      window.removeEventListener('biolab_request_permission', onPermissionRequested);
    };
  }, [fetchLecturesFromServer, fetchSettingsFromServer, syncUserSessionWithServer]);

  // Scroll to top button visibility
  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY || window.pageYOffset;
      setShowToTop(y > 350);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Theme toggle
  const toggleTheme = useCallback(() => {
    setTheme(prev => {
      const next = prev === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      try {
        localStorage.setItem('bio-theme', next);
      } catch (e) {}
      return next;
    });
  }, []);

  // Fullscreen toggle
  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
      setIsFullscreen(false);
    }
  }, []);

  // Helper to obtain admin authorization header
  const getAdminHeaders = useCallback(() => {
    const token = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    };
  }, []);

  // Log out current user from Firebase Auth
  const handleLogout = useCallback(async () => {
    playClickSound();
    try {
      await logoutUser();
      setCurrentUser(null);
    } catch (e) {
      console.warn('Logout notice:', e);
    }
  }, []);

  // Handle successful login or registration from AuthModal
  const handleAuthSuccess = useCallback((profile: UserProfile, adminStatus: boolean) => {
    setUserProfile(profile);
    if (adminStatus) {
      setIsAdminPanelOpen(true);
    }
  }, []);

  // Save new lecture to central cloud & server
  const handleAddLecture = useCallback(async (newLecture: LectureItem) => {
    setLectures(prev => {
      const filtered = prev.filter(l => l.id !== newLecture.id && String(l.id) !== String(newLecture.id));
      const updated = [newLecture, ...filtered];
      try {
        localStorage.setItem('platform_lectures', JSON.stringify(updated));
        localStorage.setItem('biolab_lectures_initialized', 'true');
      } catch (e) {}
      return updated;
    });

    // 1) Write to central cloud database (Firebase Firestore)
    try {
      await addLectureToCloud(newLecture);
    } catch (cloudErr) {
      console.warn('Direct cloud add notice:', cloudErr);
    }

    // 2) Write to server API with admin authentication token
    try {
      const res = await fetch('/api/lectures', {
        method: 'POST',
        headers: getAdminHeaders(),
        body: JSON.stringify(newLecture)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.lecture) {
          setLectures(prev => {
            const listWithout = prev.filter(l => l.id !== newLecture.id && l.id !== data.lecture.id);
            const updated = [data.lecture, ...listWithout];
            try {
              localStorage.setItem('platform_lectures', JSON.stringify(updated));
            } catch (e) {}
            return updated;
          });
        }
      }
    } catch (err) {
      console.warn('Lecture saved locally; will sync when server is reachable');
    }
  }, [getAdminHeaders]);

  // Delete lecture from central cloud & server permanently
  const handleDeleteLecture = useCallback(async (id: number) => {
    setLectures(prev => {
      const updated = prev.filter(l => l.id !== id && String(l.id) !== String(id));
      try {
        localStorage.setItem('platform_lectures', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    setUnlockedVip(prev => {
      const updatedVip = prev.filter(vId => vId !== id && String(vId) !== String(id));
      try {
        localStorage.setItem('unlocked_vip_lectures', JSON.stringify(updatedVip));
      } catch (e) {}
      return updatedVip;
    });

    // 1) Delete from central cloud database (Firebase Firestore)
    try {
      await deleteLectureFromCloud(id);
    } catch (cloudErr) {
      console.warn('Direct cloud delete notice:', cloudErr);
    }

    // 2) Delete from server API with admin authentication token
    try {
      await fetch(`/api/lectures/${id}`, { 
        method: 'DELETE',
        headers: getAdminHeaders()
      });
    } catch (e) {}
  }, [getAdminHeaders]);

  // Delete all lectures from central cloud & server
  const handleDeleteAllLectures = useCallback(async () => {
    const listToDelete = [...lectures];
    setLectures([]);
    setUnlockedVip([]);
    try {
      localStorage.setItem('platform_lectures', JSON.stringify([]));
      localStorage.setItem('unlocked_vip_lectures', JSON.stringify([]));
      localStorage.setItem('biolab_lectures_initialized', 'true');
    } catch (e) {}

    // Delete all from cloud
    for (const lec of listToDelete) {
      try {
        await deleteLectureFromCloud(lec.id);
      } catch (e) {}
    }

    try {
      await fetch('/api/lectures', { 
        method: 'DELETE',
        headers: getAdminHeaders()
      });
    } catch (e) {}
  }, [getAdminHeaders, lectures]);

  // Edit lecture on central cloud & server
  const handleEditLecture = useCallback(async (id: number, updates: Partial<LectureItem>) => {
    setLectures(prev => {
      const updated = prev.map(l => l.id === id ? { ...l, ...updates } : l);
      try {
        localStorage.setItem('platform_lectures', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    // 1) Update in central cloud database (Firebase Firestore)
    try {
      await updateLectureInCloud(id, updates);
    } catch (cloudErr) {
      console.warn('Direct cloud update notice:', cloudErr);
    }

    // 2) Update on server API with admin authentication token
    try {
      const res = await fetch(`/api/lectures/${id}`, {
        method: 'PUT',
        headers: getAdminHeaders(),
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.lecture) {
          setLectures(prev => prev.map(l => l.id === id ? data.lecture : l));
        }
      }
    } catch (err) {
      console.warn('Lecture updated locally; will sync when server is reachable');
    }
  }, [getAdminHeaders]);

  // Unlock VIP lecture
  const handleUnlockVipSuccess = useCallback((lectureId: number) => {
    setUnlockedVip(prev => {
      if (!prev.includes(lectureId)) {
        const updated = [...prev, lectureId];
        try {
          localStorage.setItem('unlocked_vip_lectures', JSON.stringify(updated));
        } catch (e) {}
        return updated;
      }
      return prev;
    });
  }, []);

  // Memoized Theme Presets
  const activePreset = useMemo(() => {
    return getThemePresetById(activeThemeId);
  }, [activeThemeId]);

  // Memoized Motion transition variant
  const motionVariant = useMemo(() => {
    switch (transitionStyle) {
      case 'cyber':
        return {
          initial: { opacity: 0, x: -28, scale: 0.98 },
          animate: { opacity: 1, x: 0, scale: 1 },
          exit: { opacity: 0, x: 24, scale: 0.98 },
          transition: { duration: 0.2, ease: 'easeOut' as const }
        };
      case 'elastic':
        return {
          initial: { opacity: 0, scale: 0.92, y: 16 },
          animate: { opacity: 1, scale: 1, y: 0 },
          exit: { opacity: 0, scale: 0.96 },
          transition: { type: 'spring' as const, stiffness: 380, damping: 26 }
        };
      case 'cosmic':
        return {
          initial: { opacity: 0, y: 24, scale: 0.96 },
          animate: { opacity: 1, y: 0, scale: 1 },
          exit: { opacity: 0, y: -20, scale: 1.02 },
          transition: { duration: 0.3, ease: 'easeInOut' as const }
        };
      case 'minimal':
        return {
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0 },
          transition: { duration: 0.15, ease: 'linear' as const }
        };
      case 'cinematic':
      default:
        return {
          initial: { opacity: 0, scale: 0.985, y: 12 },
          animate: { opacity: 1, scale: 1, y: 0 },
          exit: { opacity: 0, scale: 0.99, y: -8 },
          transition: { duration: 0.2, ease: 'easeOut' as const }
        };
    }
  }, [transitionStyle]);

  return (
    <div className={`min-h-screen text-[#eaf0f8] relative selection:bg-[#e9c978] selection:text-[#04080f] ${
      theme === 'light' ? 'bg-[#eef2f9] text-[#0a1220]' : 'bg-[#04080f] text-[#eaf0f8]'
    }`}
    style={{
      backgroundColor: theme === 'light' ? undefined : activePreset.colors.bgDark
    }}
    >
      
      {/* Preloader */}
      {showPreloader && (
        <div className="fixed inset-0 z-[9999] bg-[#04080f] flex flex-col items-center justify-center transition-opacity duration-500">
          <div className="text-6xl animate-bounce mb-4 filter drop-shadow-[0_0_24px_rgba(233,201,120,0.55)]">
            🧬
          </div>
          <div className="w-48 h-1.5 rounded-full bg-white/10 overflow-hidden mb-3">
            <div className="h-full bg-gradient-to-r from-[#e9c978] to-[#0fb98a] rounded-full animate-pulse w-3/4" />
          </div>
          <p className="text-sm text-[#e9c978] font-bold">جاري تحضير المنصة السحابية...</p>
        </div>
      )}

      {/* Background Decorative Blur Orbs dynamically adapted to active theme */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div 
          className="absolute -top-32 -right-32 w-[min(520px,55vw)] h-[min(520px,55vw)] rounded-full blur-[100px] transition-colors duration-700"
          style={{ backgroundColor: `${activePreset.colors.secondary}22` }} 
        />
        <div 
          className="absolute -bottom-40 -left-40 w-[min(600px,65vw)] h-[min(600px,65vw)] rounded-full blur-[120px] transition-colors duration-700"
          style={{ backgroundColor: `${activePreset.colors.primary}1c` }} 
        />
      </div>

      {/* Top Announcement Banner from Admin (if present) */}
      {activeAnnouncement && (
        <div className="relative z-[800] bg-gradient-to-r from-purple-900/90 via-indigo-900/90 to-purple-900/90 border-b border-purple-500/30 text-white px-4 py-2 text-xs flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-2 mx-auto">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping"></span>
            <Bell className="w-4 h-4 text-purple-300 shrink-0" />
            <span className="font-bold text-purple-200">إشعار من الأستاذ:</span>
            <span>{activeAnnouncement}</span>
          </div>
          <button 
            onClick={() => setActiveAnnouncement(null)}
            className="p-1 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white"
            title="إغلاق التنبيه"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Offline Notification if disconnected */}
      {!isOnline && (
        <div className="fixed top-20 left-4 z-[850] bg-amber-500/90 text-black px-4 py-2 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-bold backdrop-blur-md">
          <WifiOff className="w-4 h-4" />
          <span>الوضع بدون إنترنت: المناهج والكتب والبيانات محفوظة ومتاحة على هاتفك</span>
        </div>
      )}

      {/* Header / Navbar with Direct Screen Navigation */}
      <Navbar
        currentScreen={currentScreen}
        onNavigate={navigateTo}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onOpenAIAssistant={() => setIsAIAssistantOpen(true)}
        onOpenNotificationModal={() => {
          setPermissionModalType('notifications');
          setIsPermissionModalOpen(true);
        }}
        isNotificationsEnabled={isNotificationsEnabled}
        theme={theme}
        onToggleTheme={toggleTheme}
        isFullscreen={isFullscreen}
        onToggleFullscreen={toggleFullscreen}
        isSoundMuted={isSoundMuted}
        onToggleSound={() => setIsSoundMuted(soundManager.toggleMute())}
        userProfile={userProfile}
        onOpenProfileModal={() => setIsOnboardingOpen(true)}
        currentUser={currentUser}
        isAdmin={isAdmin}
        onOpenAuthModal={() => {
          setAuthModalTab('login');
          setIsAuthModalOpen(true);
        }}
        onLogout={handleLogout}
        onOpenAdminPanel={() => setIsAdminPanelOpen(true)}
      />

      {/* Modern, Fluid, Cinematic Animated Screen Container with Dynamic Theme Transitions */}
      <AnimatePresence mode="wait">
        <motion.main
          key={currentScreen}
          initial={motionVariant.initial}
          animate={motionVariant.animate}
          exit={motionVariant.exit}
          transition={motionVariant.transition}
          className="min-h-[85vh] relative z-10 pb-16"
        >
          <Suspense fallback={<SectionLoadingFallback />}>
            {/* 1) Home Hub Screen */}
            {currentScreen === 'home' && (
              <Hero onNavigate={navigateTo} />
            )}

            {/* 2) Private Institute Students Screen (طلاب المعهد الخاص) */}
            {currentScreen === 'institute-students' && (
              <div>
                <ScreenHeader
                  tag="طلاب المعهد الخاص"
                  title="قسم طلاب المعهد الخاص"
                  subtitle="جدول درجات الامتحانات والاختبارات الدورية والواجبات اليومية لكافة المراحل"
                  currentScreenId={currentScreen}
                  onBack={() => navigateTo('home')}
                  onNavigate={navigateTo}
                />
                <InstituteStudentsSection
                  onBackToHome={() => navigateTo('home')}
                />
              </div>
            )}

            {/* 3) Curriculum Books & Booklets Screen (الكتب المنهجية والملازم) */}
            {currentScreen === 'books' && (
              <div>
                <ScreenHeader
                  tag="المكتبة المنهجية والذهبية"
                  title="الكتب المنهجية والملازم"
                  subtitle="تصفح وقراءة وتنزيل الكتب المدرسية والملازم والملخصات لجميع المراحل من الأول المتوسط حتى السادس العلمي"
                  currentScreenId={currentScreen}
                  onBack={() => navigateTo('home')}
                  onNavigate={navigateTo}
                />
                <BooksSection
                  onBackToHome={() => navigateTo('home')}
                  onOpenPdfModal={(book) => setSelectedPdfBook(book as any)}
                />
              </div>
            )}

            {/* 3) Lectures Independent Screen */}
            {currentScreen === 'lectures' && (
              <div>
                <ScreenHeader
                  tag="فيديوهات وشروحات"
                  title="المحاضرات المرئية"
                  subtitle="المحاضرات المضافة حديثاً من قبل الأستاذ عبر الإنترنت"
                  currentScreenId={currentScreen}
                  onBack={() => navigateTo('home')}
                  onNavigate={navigateTo}
                />
                <LecturesSection
                  lectures={lectures}
                  unlockedVip={unlockedVip}
                  onOpenVipModal={(id) => setVipModalLectureId(id)}
                  selectedGradeFilter={lecturesFilter}
                  onFilterChange={(g) => setLecturesFilter(g)}
                  onRefreshLectures={() => fetchLecturesFromServer(true)}
                  isRefreshing={isRefreshingLectures}
                />
              </div>
            )}

            {/* 4) Grades Independent Screen */}
            {currentScreen === 'grades' && (
              <div>
                <ScreenHeader
                  tag="المراحل الدراسية"
                  title="المراحل التعليمية"
                  subtitle="اختر مرحلتك الدراسية للوصول للمنهج والملازم"
                  currentScreenId={currentScreen}
                  onBack={() => navigateTo('home')}
                  onNavigate={navigateTo}
                />
                <GradesSection
                  onSelectGrade={(gradeKey) => {
                    setCurriculumFilter(gradeKey);
                    navigateTo('lessons');
                  }}
                />
              </div>
            )}

            {/* 5) Lessons & Curriculum Screen */}
            {currentScreen === 'lessons' && (
              <div>
                <ScreenHeader
                  tag="الفصول والدروس"
                  title="المنهج الدراسي والدروس"
                  subtitle="استعراض فصول المنهج لجميع المراحل الدراسية"
                  currentScreenId={currentScreen}
                  onBack={() => navigateTo('home')}
                  onNavigate={navigateTo}
                />
                <CurriculumSection
                  selectedFilter={curriculumFilter}
                  onFilterChange={(val) => setCurriculumFilter(val)}
                />
              </div>
            )}

            {/* 6) Institute Screen (معهد أنوار السلام) */}
            {currentScreen === 'institute' && (
              <div>
                <ScreenHeader
                  tag="التسجيل والتدريس"
                  title="معهد أنوار السلام"
                  subtitle="الموقع الرسمي لمعهد الأستاذ وسام سهيل العامري"
                  currentScreenId={currentScreen}
                  onBack={() => navigateTo('home')}
                  onNavigate={navigateTo}
                />
                <InstituteSection />
              </div>
            )}

            {/* 8) About Teacher Screen */}
            {currentScreen === 'about' && (
              <div>
                <ScreenHeader
                  tag="السيرة الذاتية"
                  title="عن الأستاذ وسام سهيل العامري"
                  subtitle="المشرف والمدرس لمادة الأحياء لكافة المراحل"
                  currentScreenId={currentScreen}
                  onBack={() => navigateTo('home')}
                  onNavigate={navigateTo}
                />
                <AboutTeacher />
              </div>
            )}

            {/* 9) Contact Screen */}
            {currentScreen === 'contact' && (
              <div>
                <ScreenHeader
                  tag="قنوات التواصل"
                  title="تواصل مع الأستاذ"
                  subtitle="قنوات التلغرام، واتساب، والحسابات الرسمية للاستفسارات"
                  currentScreenId={currentScreen}
                  onBack={() => navigateTo('home')}
                  onNavigate={navigateTo}
                />
                <TeacherContact />
              </div>
            )}
          </Suspense>
        </motion.main>
      </AnimatePresence>

      {/* Modern, Floating Quick Navigation Dock */}
      <NavigationDock
        currentScreen={currentScreen}
        onNavigate={navigateTo}
      />

      {/* Floating Action Buttons */}
      {/* 1) Scroll to Top Button */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className={`fixed bottom-20 sm:bottom-24 left-5 z-[750] w-11 h-11 rounded-2xl bg-[#e9c978] shadow-xl shadow-[#e9c978]/30 flex items-center justify-center transition-all duration-300 hover:scale-105 active:scale-95 ${
          showToTop ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-8 pointer-events-none'
        }`}
        title="الصعود للأعلى"
      >
        <ArrowUp className="w-5 h-5 text-[#08111e] stroke-[3]" />
      </button>

      {/* 2) WhatsApp Floating Button */}
      <a
        href="https://wa.me/9647704597073"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-20 sm:bottom-24 right-5 z-[750] w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#128C7E] to-[#25D366] text-white shadow-xl shadow-[#25D366]/40 flex items-center justify-center text-2xl hover:scale-105 active:scale-95 transition"
        title="واتساب الأستاذ"
      >
        💬
      </a>

      {/* 3) AI Assistant Floating Button */}
      <button
        onClick={() => {
          playClickSound();
          setIsAIAssistantOpen(true);
        }}
        className="fixed bottom-20 sm:bottom-24 right-18 sm:right-20 z-[750] h-11 px-3 sm:px-4 rounded-2xl bg-gradient-to-r from-[#c9a24a] via-[#e9c978] to-[#0fb98a] text-[#08111e] font-black text-xs shadow-xl shadow-[#c9a24a]/30 flex items-center justify-center gap-1.5 hover:scale-105 active:scale-95 transition border border-white/30"
        title="المساعد الذكي لمنصة الأحياء"
      >
        <span className="text-lg">🧬</span>
        <span className="hidden sm:inline font-bold">المساعد الذكي</span>
      </button>

      {/* Modals with Suspense for optimal bundle splitting */}
      <Suspense fallback={null}>
        {/* AI Assistant Chat Modal */}
        {isAIAssistantOpen && (
          <AIAssistantModal
            isOpen={isAIAssistantOpen}
            onClose={() => setIsAIAssistantOpen(false)}
            onOpenLecture={(id) => {
              const targetLec = lectures.find((l) => l.id === id);
              if (targetLec) {
                setLecturesFilter(targetLec.grade || 'all');
              }
              navigateTo('lectures');
              setIsAIAssistantOpen(false);
            }}
            onNavigateToScreen={(screen) => navigateTo(screen)}
            studentGrade={userProfile?.grade || 'g6'}
          />
        )}
        {/* PDF Book Viewer Modal */}
        {selectedPdfBook && (
          <PdfViewerModal
            book={selectedPdfBook}
            onClose={() => setSelectedPdfBook(null)}
          />
        )}

        {/* VIP Unlock Code Modal */}
        {vipModalLectureId !== null && (
          <VipUnlockModal
            lectureId={vipModalLectureId}
            lectures={lectures}
            userUid={userProfile?.uid}
            onUnlockSuccess={handleUnlockVipSuccess}
            onClose={() => setVipModalLectureId(null)}
          />
        )}

        {/* Admin Panel & Login Modal */}
        {(isLoginModalOpen || isAdminPanelOpen) && (
          <AdminPanelModal
            isLoginOpen={isLoginModalOpen}
            onCloseLogin={() => setIsLoginModalOpen(false)}
            isAdminOpen={isAdminPanelOpen}
            onCloseAdmin={() => setIsAdminPanelOpen(false)}
            lectures={lectures}
            onAddLecture={handleAddLecture}
            onDeleteLecture={handleDeleteLecture}
            onDeleteAllLectures={handleDeleteAllLectures}
            onEditLecture={handleEditLecture}
            onLoginSuccess={() => {
              setIsLoginModalOpen(false);
              setIsAdminPanelOpen(true);
            }}
            onOpenAPKModal={() => setIsAPKModalOpen(true)}
            activeThemeId={activeThemeId}
            onSelectTheme={(themeId) => {
              setActiveThemeId(themeId);
              applyThemeToDocument(getThemePresetById(themeId));
            }}
            activeTransitionStyle={transitionStyle}
            onSelectTransitionStyle={(styleId) => setTransitionStyle(styleId)}
            isSoundMuted={isSoundMuted}
            onToggleSound={() => setIsSoundMuted(soundManager.toggleMute())}
            soundVolume={soundVolume}
            onChangeVolume={(vol) => setSoundVolume(vol)}
          />
        )}

        {/* Android APK Modal */}
        {isAPKModalOpen && (
          <InstallAPKModal
            isOpen={isAPKModalOpen}
            onClose={() => setIsAPKModalOpen(false)}
          />
        )}

        {/* Student Onboarding & Track Selection Modal (شاشة اختيار المسار وتسجيل الطالب) */}
        <StudentOnboardingModal
          isOpen={isOnboardingOpen}
          initialProfile={userProfile}
          onComplete={handleCompleteOnboarding}
          onClose={userProfile ? () => setIsOnboardingOpen(false) : undefined}
        />



        {/* Android Native & System Permissions Rationale Modal */}
        {isPermissionModalOpen && (
          <AndroidPermissionModal
            isOpen={isPermissionModalOpen}
            permissionType={permissionModalType}
            targetTitle={permissionTargetTitle}
            onClose={() => setIsPermissionModalOpen(false)}
            onPermissionGranted={() => {
              if (permissionModalType === 'notifications') {
                setIsNotificationsEnabled(true);
              }
            }}
          />
        )}

        {/* Student & Admin Firebase Authentication Modal */}
        {isAuthModalOpen && (
          <AuthModal
            isOpen={isAuthModalOpen}
            onClose={() => setIsAuthModalOpen(false)}
            onAuthSuccess={handleAuthSuccess}
            initialTab={authModalTab}
          />
        )}
      </Suspense>

    </div>
  );
}
