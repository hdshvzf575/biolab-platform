// Web Audio API Audio Synthesizer for UI sound effects & click audio
// 100% self-contained, 0KB external assets, instant zero-latency feedback

type SoundStyle = 'theme' | 'velvet' | 'cyber' | 'bio' | 'cosmic' | 'minimal';

class SoundManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private volume: number = 0.65;
  private currentStyle: SoundStyle = 'theme';
  private activeThemeId: string = 'royal';

  constructor() {
    // Load persisted preferences
    if (typeof window !== 'undefined') {
      try {
        const savedMuted = localStorage.getItem('biolab_sound_muted');
        if (savedMuted !== null) {
          this.isMuted = savedMuted === 'true';
        }
        const savedVol = localStorage.getItem('biolab_sound_volume');
        if (savedVol !== null) {
          const parsed = parseFloat(savedVol);
          if (!isNaN(parsed) && parsed >= 0 && parsed <= 1) {
            this.volume = parsed;
          }
        }
        const savedStyle = localStorage.getItem('biolab_sound_style') as SoundStyle | null;
        if (savedStyle) {
          this.currentStyle = savedStyle;
        }
        const savedTheme = localStorage.getItem('biolab_active_theme_id');
        if (savedTheme) {
          this.activeThemeId = savedTheme;
        }
      } catch (e) {
        // localStorage unavailable
      }
    }
  }

  private initContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public setIsMuted(muted: boolean): void {
    this.isMuted = muted;
    try {
      localStorage.setItem('biolab_sound_muted', String(muted));
      window.dispatchEvent(new CustomEvent('biolab-sound-state-change', { detail: { isMuted: muted } }));
    } catch (e) {}
  }

  public toggleMute(): boolean {
    this.setIsMuted(!this.isMuted);
    if (!this.isMuted) {
      // Play a quick test sound when unmuting
      setTimeout(() => this.playClickSound(), 50);
    }
    return this.isMuted;
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    try {
      localStorage.setItem('biolab_sound_volume', String(this.volume));
    } catch (e) {}
  }

  public getSoundStyle(): SoundStyle {
    return this.currentStyle;
  }

  public setSoundStyle(style: SoundStyle): void {
    this.currentStyle = style;
    try {
      localStorage.setItem('biolab_sound_style', style);
    } catch (e) {}
  }

  public setActiveTheme(themeId: string): void {
    this.activeThemeId = themeId;
    try {
      localStorage.setItem('biolab_active_theme_id', themeId);
    } catch (e) {}
  }

  /**
   * Synthesize click audio based on current theme or style
   */
  public playClickSound(forcedStyle?: SoundStyle): void {
    if (this.isMuted) return;

    try {
      const ctx = this.initContext();
      if (!ctx) return;

      const effectiveStyle = forcedStyle || (this.currentStyle === 'theme' ? this.mapThemeToStyle(this.activeThemeId) : this.currentStyle);

      const now = ctx.currentTime;
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(this.volume * 0.45, now);
      masterGain.connect(ctx.destination);

      switch (effectiveStyle) {
        case 'cyber': {
          // Sharp futuristic digital blip (880Hz -> 1320Hz)
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(800, now);
          osc.frequency.exponentialRampToValueAtTime(1400, now + 0.035);

          const filter = ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(2200, now);

          gain.gain.setValueAtTime(0.3, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.045);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(masterGain);

          osc.start(now);
          osc.stop(now + 0.05);
          break;
        }

        case 'bio': {
          // Cellular fluid pop / water droplet sound
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(620, now);
          osc.frequency.exponentialRampToValueAtTime(240, now + 0.055);

          const filter = ctx.createBiquadFilter();
          filter.type = 'bandpass';
          filter.frequency.setValueAtTime(450, now);
          filter.Q.setValueAtTime(3.5, now);

          gain.gain.setValueAtTime(0.4, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(masterGain);

          osc.start(now);
          osc.stop(now + 0.065);
          break;
        }

        case 'cosmic': {
          // Ethereal dual crystal harmonic chime
          const osc1 = ctx.createOscillator();
          const osc2 = ctx.createOscillator();
          const gain = ctx.createGain();

          osc1.type = 'sine';
          osc2.type = 'triangle';
          osc1.frequency.setValueAtTime(987.77, now); // B5 note
          osc2.frequency.setValueAtTime(1479.98, now); // F#6 harmonic

          gain.gain.setValueAtTime(0.3, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

          osc1.connect(gain);
          osc2.connect(gain);
          gain.connect(masterGain);

          osc1.start(now);
          osc2.start(now);
          osc1.stop(now + 0.095);
          osc2.stop(now + 0.095);
          break;
        }

        case 'minimal': {
          // Crisp ultra-fast mechanical precision tick
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(1600, now);
          osc.frequency.exponentialRampToValueAtTime(600, now + 0.015);

          gain.gain.setValueAtTime(0.35, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.018);

          osc.connect(gain);
          gain.connect(masterGain);

          osc.start(now);
          osc.stop(now + 0.02);
          break;
        }

        case 'velvet':
        default: {
          // Warm luxurious tactile click (Gold & Emerald Royal default)
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(540, now);
          osc.frequency.exponentialRampToValueAtTime(260, now + 0.038);

          gain.gain.setValueAtTime(0.35, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

          osc.connect(gain);
          gain.connect(masterGain);

          osc.start(now);
          osc.stop(now + 0.045);
          break;
        }
      }
    } catch (e) {
      // Audio failed gracefully
    }
  }

  /**
   * Play positive confirmation sound when applying theme or settings
   */
  public playSuccessSound(): void {
    if (this.isMuted) return;
    try {
      const ctx = this.initContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(this.volume * 0.4, now);
      masterGain.connect(ctx.destination);

      // Two-note upward chime
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      const gain2 = ctx.createGain();

      osc1.type = 'sine';
      osc2.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now); // D5
      osc2.frequency.setValueAtTime(880, now + 0.07); // A5

      gain1.gain.setValueAtTime(0.28, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

      gain2.gain.setValueAtTime(0, now);
      gain2.gain.setValueAtTime(0.32, now + 0.07);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      osc1.connect(gain1);
      gain1.connect(masterGain);
      osc2.connect(gain2);
      gain2.connect(masterGain);

      osc1.start(now);
      osc1.stop(now + 0.13);
      osc2.start(now + 0.07);
      osc2.stop(now + 0.23);
    } catch (e) {}
  }

  private mapThemeToStyle(themeId: string): SoundStyle {
    switch (themeId) {
      case 'cyber': return 'cyber';
      case 'bio': return 'bio';
      case 'cosmic': return 'cosmic';
      case 'minimal': return 'minimal';
      case 'royal':
      default: return 'velvet';
    }
  }
}

export const soundManager = new SoundManager();

export const playClickSound = (forcedStyle?: SoundStyle) => {
  soundManager.playClickSound(forcedStyle);
};

export const playSuccessSound = () => {
  soundManager.playSuccessSound();
};
