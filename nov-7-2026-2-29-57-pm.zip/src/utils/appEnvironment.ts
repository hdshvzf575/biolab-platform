/**
 * App Environment and Device Installation Utilities
 * Accurately detects whether the application is running in:
 * 1. Native Android APK (via AndroidBridge)
 * 2. Installed Progressive Web App (standalone display mode)
 * 3. Web Preview / Browser mode
 */

const GOOGLE_LINKED_KEY = 'biolab_google_account_linked';
const GOOGLE_ACCESS_TOKEN_KEY = 'biolab_google_drive_token';

/**
 * Checks if the app is currently running inside an installed environment
 * (Android Native APK container or Standalone PWA) rather than an open browser tab/preview.
 */
export function isInstalledApp(): boolean {
  if (typeof window === 'undefined') return false;

  // 1. Android Native WebView via AndroidBridge
  if (
    (window as any).AndroidBridge &&
    typeof (window as any).AndroidBridge.isAndroidApp === 'function' &&
    (window as any).AndroidBridge.isAndroidApp()
  ) {
    return true;
  }

  // 2. Standalone PWA mode (Display mode check)
  if (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) {
    return true;
  }

  // 3. iOS standalone mode
  if ((window.navigator as any)?.standalone === true) {
    return true;
  }

  // 4. Check if marked by launch parameter or local preference
  try {
    if (localStorage.getItem('biolab_installed_app_mode') === 'true') {
      return true;
    }
    const params = new URLSearchParams(window.location.search);
    if (params.get('mode') === 'installed' || params.get('source') === 'apk') {
      localStorage.setItem('biolab_installed_app_mode', 'true');
      return true;
    }
  } catch (e) {}

  return false;
}

/**
 * Checks if the user has completed the one-time Google Account link on this device
 */
export function hasLinkedGoogleAccount(): boolean {
  try {
    return localStorage.getItem(GOOGLE_LINKED_KEY) === 'true';
  } catch (e) {
    return false;
  }
}

/**
 * Saves whether the user has linked their Google Account
 */
export function setGoogleAccountLinked(linked: boolean): void {
  try {
    if (linked) {
      localStorage.setItem(GOOGLE_LINKED_KEY, 'true');
    } else {
      localStorage.removeItem(GOOGLE_LINKED_KEY);
    }
  } catch (e) {}
}

/**
 * Returns cached Google OAuth Access Token for Google Drive requests
 */
export function getCachedGoogleToken(): string | null {
  try {
    return localStorage.getItem(GOOGLE_ACCESS_TOKEN_KEY) || sessionStorage.getItem(GOOGLE_ACCESS_TOKEN_KEY);
  } catch (e) {
    return null;
  }
}

/**
 * Saves or clears cached Google OAuth Access Token
 */
export function setCachedGoogleToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(GOOGLE_ACCESS_TOKEN_KEY, token);
      sessionStorage.setItem(GOOGLE_ACCESS_TOKEN_KEY, token);
      setGoogleAccountLinked(true);
    } else {
      localStorage.removeItem(GOOGLE_ACCESS_TOKEN_KEY);
      sessionStorage.removeItem(GOOGLE_ACCESS_TOKEN_KEY);
    }
  } catch (e) {}
}
