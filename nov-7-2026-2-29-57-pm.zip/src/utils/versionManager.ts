/**
 * Version Management & Update Controller for BioLab Platform
 * Ensures reliable version checking, persists update state in localStorage,
 * completely eliminates update modal looping, and decouples content sync from app releases.
 */

export const CURRENT_APP_VERSION = '2.6.0';

export interface AppUpdatePayload {
  version: string;
  title: string;
  releaseNotes: string[];
  releaseDate: string;
  forceUpdate: boolean;
  apkUrl?: string;
  minSupportedVersion?: string;
}

/**
 * Parses semantic version string (e.g., '2.6.0', '2.6.0-cloud') into comparable numbers.
 */
export function parseSemver(v: string): number[] {
  if (!v) return [0, 0, 0];
  const cleaned = v.split('-')[0].trim();
  const parts = cleaned.split('.').map((p) => {
    const num = parseInt(p, 10);
    return isNaN(num) ? 0 : num;
  });
  while (parts.length < 3) parts.push(0);
  return parts.slice(0, 3);
}

/**
 * Returns:
 *  1 if v1 > v2
 * -1 if v1 < v2
 *  0 if v1 === v2
 */
export function compareVersions(v1: string, v2: string): number {
  const p1 = parseSemver(v1);
  const p2 = parseSemver(v2);

  for (let i = 0; i < 3; i++) {
    if (p1[i] > p2[i]) return 1;
    if (p1[i] < p2[i]) return -1;
  }
  return 0;
}

/**
 * Checks if a remote version is strictly newer than current installed version
 */
export function isNewerVersion(remoteVersion: string, installedVersion: string): boolean {
  return compareVersions(remoteVersion, installedVersion) > 0;
}

/**
 * Reads currently installed version from localStorage or defaults to CURRENT_APP_VERSION
 */
export function getInstalledVersion(): string {
  try {
    const saved = localStorage.getItem('biolab_installed_version');
    if (saved && saved.trim()) return saved.trim();
  } catch (e) {}
  return CURRENT_APP_VERSION;
}

/**
 * Checks if the user previously dismissed this exact version using "لاحقاً"
 */
export function isVersionDismissed(version: string): boolean {
  if (!version) return true;
  try {
    const dismissedVersion = localStorage.getItem('biolab_dismissed_version');
    if (dismissedVersion === version) return true;

    const specificKey = localStorage.getItem(`biolab_dismissed_update_${version}`);
    if (specificKey === 'true') return true;

    // Also check session storage just in case
    const sessionKey = sessionStorage.getItem(`biolab_dismissed_update_${version}`);
    if (sessionKey === 'true') return true;
  } catch (e) {}
  return false;
}

/**
 * Permanently remembers that the user chose "لاحقاً" for this version
 */
export function dismissUpdateVersion(version: string): void {
  if (!version) return;
  try {
    localStorage.setItem('biolab_dismissed_version', version);
    localStorage.setItem(`biolab_dismissed_update_${version}`, 'true');
    sessionStorage.setItem(`biolab_dismissed_update_${version}`, 'true');
    console.log(`[VersionManager] Version ${version} dismissed by user.`);
  } catch (e) {
    console.warn('[VersionManager] Could not save dismissed state to localStorage:', e);
  }
}

/**
 * حفظ رقم إصدار التحديث الحالي في LocalStorage عند اختيار "لاحقاً"،
 * لمنع تكرار ظهور نافذة التحديث لنفس الإصدار نهائياً حتى يتم إطلاق إصدار أحدث فعلياً.
 */
export function saveDismissedUpdateVersion(version: string): void {
  dismissUpdateVersion(version);
}

/**
 * Stamps this version as successfully installed on this device
 */
export function stampInstalledVersion(version: string): void {
  if (!version) return;
  try {
    localStorage.setItem('biolab_installed_version', version);
    // Clear any dismissed flags for this version since it is now installed
    localStorage.removeItem(`biolab_dismissed_update_${version}`);
    sessionStorage.removeItem(`biolab_dismissed_update_${version}`);
    console.log(`[VersionManager] Version ${version} successfully installed.`);
  } catch (e) {
    console.warn('[VersionManager] Could not save installed state:', e);
  }
}

/**
 * Evaluates whether the update modal should be shown to the user.
 * Returns true ONLY if:
 * 1. An update payload is present.
 * 2. It is not already dismissed (unless forceUpdate is true).
 * 3. The remote version is strictly newer than the installed version (unless forceUpdate is true).
 */
export function shouldShowAppUpdateModal(_update: AppUpdatePayload | null): boolean {
  // Modal popups on startup are permanently disabled per user requirement
  return false;
}

/**
 * Performs graceful in-place cache busting and service worker update
 * without wiping student profile or unlocked lectures.
 */
export async function applyAppUpdateSafely(update: AppUpdatePayload): Promise<boolean> {
  try {
    // 1. Stamp version
    stampInstalledVersion(update.version);

    // 2. Refresh or update ServiceWorker registrations
    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      try {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const reg of registrations) {
          await reg.update().catch(() => {});
        }
      } catch (swErr) {
        console.warn('[VersionManager] Service worker update check notice:', swErr);
      }
    }

    // 3. Clear all browser CacheStorage caches to flush stale bundle chunks
    try {
      if (typeof window !== 'undefined' && 'caches' in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map((k) => caches.delete(k)));
        console.log('[VersionManager] Flushed all CacheStorage keys successfully.');
      }
    } catch (cacheErr) {
      console.warn('[VersionManager] Cache keys cleanup notice:', cacheErr);
    }

    // 4. If running inside Android WebView bridge, clear native cache
    try {
      if (typeof window !== 'undefined' && window.AndroidBridge && typeof (window.AndroidBridge as any).clearCacheAndReload === 'function') {
        (window.AndroidBridge as any).clearCacheAndReload();
        return true;
      }
    } catch (bridgeErr) {
      console.warn('[VersionManager] AndroidBridge clearCache notice:', bridgeErr);
    }

    return true;
  } catch (err) {
    console.error('[VersionManager] Error applying app update:', err);
    return false;
  }
}

/**
 * Automatic startup verification:
 * Compares current codebase version (CURRENT_APP_VERSION) against local storage stamp.
 * If codebase is newer than previously stamped version, purges stale caches immediately
 * so the installed client never runs stale code.
 */
export async function verifyAndPurgeStaleVersionCache(): Promise<boolean> {
  if (typeof window === 'undefined') return false;
  try {
    const installed = getInstalledVersion();
    if (compareVersions(CURRENT_APP_VERSION, installed) > 0) {
      console.log(`[VersionManager] App upgraded from ${installed} to ${CURRENT_APP_VERSION}. Purging stale cache...`);
      stampInstalledVersion(CURRENT_APP_VERSION);

      // Flush caches
      if ('caches' in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map((k) => caches.delete(k)));
      }

      // Check service worker
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const reg of registrations) {
          await reg.update().catch(() => {});
        }
      }
      return true;
    }
  } catch (err) {
    console.warn('[VersionManager] Startup version audit notice:', err);
  }
  return false;
}
