/**
 * File Downloader Utility
 * Provides seamless direct downloading of PDFs, videos, and academic references
 * directly to the user's phone or computer (Downloads folder) without intermediate redirects.
 * 
 * Automatically integrates with Android Native DownloadManager on Android APK,
 * conforming with modern Scoped Storage (Android 10, 11, 12, 13, 14, 15, 16)
 * and legacy runtime permissions (Android 9 and below).
 */

import { androidPermissionBridge } from '../services/androidPermissionBridge';

export interface DirectDownloadOptions {
  url?: string;
  file?: string;
  title: string;
  fileType?: string;
  onProgress?: (progressText: string) => void;
  onSuccess?: (msg: string) => void;
  onError?: (err: string) => void;
}

export async function downloadFileDirectly({
  url,
  file,
  title,
  fileType = 'pdf',
  onProgress,
  onSuccess,
  onError
}: DirectDownloadOptions): Promise<boolean> {
  try {
    const cleanTitle = title.trim() || 'كتاب_علم_الأحياء';
    const fileNameWithExt = `${cleanTitle}.${fileType === 'mp4' ? 'mp4' : 'pdf'}`;
    const mimeType = fileType === 'mp4' ? 'video/mp4' : 'application/pdf';

    if (onProgress) onProgress('جاري تحضير وبدء تنزيل الملف إلى جهازك...');

    // Determine target URL for our download
    let downloadTargetUrl = '';
    
    if (file || (url && url.startsWith('/uploads/'))) {
      const targetPath = file || url;
      downloadTargetUrl = `/api/download?file=${encodeURIComponent(targetPath || '')}&title=${encodeURIComponent(cleanTitle)}`;
    } else if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
      downloadTargetUrl = `/api/download?url=${encodeURIComponent(url)}&title=${encodeURIComponent(cleanTitle)}`;
    } else if (file) {
      downloadTargetUrl = `/api/download?file=${encodeURIComponent(file)}&title=${encodeURIComponent(cleanTitle)}`;
    } else {
      if (onError) onError('رابط الملف غير متاح للتنزيل');
      return false;
    }

    // 1. Android Native Integration
    if (androidPermissionBridge.isAndroidNative()) {
      const success = await androidPermissionBridge.downloadFile({
        url: downloadTargetUrl,
        fileName: fileNameWithExt,
        mimeType,
        description: `تنزيل ${cleanTitle} - منصة الأستاذ وسام سهيل العامري`
      });

      if (success) {
        if (onSuccess) {
          onSuccess(`بدأ تحميل "${cleanTitle}" في مجلد التنزيلات بالهاتف 📥`);
        }
        return true;
      }
    }

    // 2. Standard Web / Desktop / PWA Browser Download Flow
    const link = document.createElement('a');
    link.href = downloadTargetUrl;
    link.setAttribute('download', fileNameWithExt);
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (onSuccess) {
      onSuccess(`بدأ تنزيل "${cleanTitle}" وحفظه في مجلد التنزيلات على جهازك 📥`);
    }
    return true;
  } catch (err: any) {
    console.error('Direct download failed:', err);
    if (onError) onError('تعذر إكمال التنزيل المباشر، تحقق من اتصالك بالإنترنت');
    return false;
  }
}
