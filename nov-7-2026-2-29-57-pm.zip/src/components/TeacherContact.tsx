import React from 'react';
import { Send, MessageSquare } from 'lucide-react';

export const TeacherContact: React.FC = () => {
  return (
    <section id="contact" className="py-24 relative border-t border-white/5 bg-gradient-to-b from-transparent via-white/[0.02] to-transparent">
      <div className="w-[min(1240px,92%)] mx-auto space-y-12">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full text-xs font-bold text-[#e9c978] bg-[#e9c978]/10 border border-[#e9c978]/25 shadow-sm">
            <span>تواصل معنا</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold font-amiri text-white">
            للأسئلة والاستفسارات
          </h2>
        </div>

        {/* Contact Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
          
          {/* WhatsApp Card */}
          <a
            href="https://wa.me/9647704597073"
            target="_blank"
            rel="noopener noreferrer"
            className="p-8 rounded-3xl bg-[#0a1220] border border-white/10 hover:border-[#25D366]/60 shadow-xl transition-all duration-300 hover:-translate-y-2 text-center flex flex-col items-center group"
          >
            <div className="w-16 h-16 rounded-2xl bg-[#25D366]/15 border border-[#25D366]/30 text-3xl flex items-center justify-center mb-4 group-hover:scale-110 transition">
              💬
            </div>
            <h4 className="font-bold text-lg sm:text-xl text-white mb-2 group-hover:text-[#25D366] transition">
              واتساب الأستاذ
            </h4>
            <p className="text-sm font-bold text-gray-300 tracking-wider" dir="ltr">
              +964 770 459 7073
            </p>
          </a>

          {/* Telegram Card */}
          <a
            href="https://t.me/Scorpiones90"
            target="_blank"
            rel="noopener noreferrer"
            className="p-8 rounded-3xl bg-[#0a1220] border border-white/10 hover:border-[#3fa9f5]/60 shadow-xl transition-all duration-300 hover:-translate-y-2 text-center flex flex-col items-center group"
          >
            <div className="w-16 h-16 rounded-2xl bg-[#3fa9f5]/15 border border-[#3fa9f5]/30 text-3xl flex items-center justify-center mb-4 group-hover:scale-110 transition">
              📢
            </div>
            <h4 className="font-bold text-lg sm:text-xl text-white mb-2 group-hover:text-[#3fa9f5] transition">
              قناة تلغرام
            </h4>
            <p className="text-sm text-gray-300">
              الملازم والملخصات
            </p>
          </a>

        </div>

      </div>
    </section>
  );
};
