import React, { useState } from 'react';
import { 
  X, 
  BookOpen, 
  Award, 
  CheckCircle, 
  PenTool, 
  HelpCircle, 
  Bookmark, 
  BookmarkCheck, 
  Share2,
  Clock,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Chapter } from '../data/biologyCurriculum';

interface ChapterModalProps {
  chapter: Chapter | null;
  onClose: () => void;
  isBookmarked: boolean;
  onToggleBookmark: (chapterId: number) => void;
  onOpenQuiz: (chapterId: number) => void;
}

export const ChapterModal: React.FC<ChapterModalProps> = ({
  chapter,
  onClose,
  isBookmarked,
  onToggleBookmark,
  onOpenQuiz
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'ministerial' | 'drawings'>('overview');
  const [expandedQuestions, setExpandedQuestions] = useState<Record<string, boolean>>({});

  if (!chapter) return null;

  const toggleQuestion = (id: string) => {
    setExpandedQuestions(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  return (
    <div className="fixed inset-0 z-[950] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md">
      <div 
        className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl text-[#eaf0f8] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-white/10 bg-gradient-to-r from-white/[0.04] to-transparent">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#c9a24a] to-[#e9c978] text-[#04080f] flex items-center justify-center text-3xl shadow-lg shrink-0">
                {chapter.icon}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#e9c978]/20 text-[#e9c978] border border-[#e9c978]/30">
                    {chapter.code}
                  </span>
                  <span className="text-xs text-gray-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {chapter.estimatedHours} ساعات دراسية
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold font-amiri text-white mt-1">
                  {chapter.title}
                </h2>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => onToggleBookmark(chapter.id)}
                className={`p-2.5 rounded-xl border transition ${
                  isBookmarked 
                    ? 'bg-[#e9c978]/20 border-[#e9c978] text-[#e9c978]' 
                    : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                }`}
                title={isBookmarked ? 'محفوظ في مفضلتي' : 'حفظ الفصل'}
              >
                {isBookmarked ? <BookmarkCheck className="w-5 h-5" /> : <Bookmark className="w-5 h-5" />}
              </button>
              <button
                onClick={onClose}
                className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 transition"
                title="إغلاق"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Sub Navigation */}
          <div className="flex rounded-xl bg-white/5 p-1 mt-6 border border-white/10 text-xs sm:text-sm font-semibold">
            <button
              onClick={() => setActiveTab('overview')}
              className={`flex-1 py-2 px-3 rounded-lg transition flex items-center justify-center gap-1.5 ${
                activeTab === 'overview'
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] shadow'
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>نظرة ومفاهيم</span>
            </button>
            <button
              onClick={() => setActiveTab('ministerial')}
              className={`flex-1 py-2 px-3 rounded-lg transition flex items-center justify-center gap-1.5 ${
                activeTab === 'ministerial'
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] shadow'
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>الأسئلة الوزارية ({chapter.ministerialQuestions.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('drawings')}
              className={`flex-1 py-2 px-3 rounded-lg transition flex items-center justify-center gap-1.5 ${
                activeTab === 'drawings'
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] shadow'
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              <PenTool className="w-4 h-4" />
              <span>الرسومات ({chapter.drawings.length})</span>
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                <h4 className="text-sm font-bold text-[#e9c978] mb-2 flex items-center gap-2">
                  <BookOpen className="w-4 h-4" />
                  ملخص الفصل ومحتواه العلمي
                </h4>
                <p className="text-sm text-gray-200 leading-relaxed">
                  {chapter.overview}
                </p>
              </div>

              <div>
                <h4 className="text-base font-bold text-white mb-3 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#0fb98a]" />
                  المفاهيم والنقاط الجوهرية للاختبار الوزاري
                </h4>
                <div className="grid gap-2.5">
                  {chapter.coreConcepts.map((concept, idx) => (
                    <div 
                      key={idx}
                      className="p-3.5 rounded-xl bg-white/5 border border-white/5 hover:border-[#e9c978]/30 transition flex items-start gap-3"
                    >
                      <span className="w-6 h-6 rounded-lg bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="text-sm text-gray-200 leading-normal">
                        {concept}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Start Quiz CTA button */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0fb98a]/20 via-[#0fb98a]/10 to-transparent border border-[#0fb98a]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h5 className="font-bold text-white text-base">جاهز لاختبار فهمك لهذا الفصل؟</h5>
                  <p className="text-xs text-gray-300">أسئلة وزارية مؤتمتة وتصحيح فوري لتقييم مستواك</p>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onOpenQuiz(chapter.id);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#0d9488] text-white font-bold text-sm shadow-lg hover:brightness-110 transition shrink-0"
                >
                  بدء الاختبار التفاعلي ⚡
                </button>
              </div>
            </div>
          )}

          {activeTab === 'ministerial' && (
            <div className="space-y-4">
              <div className="text-xs text-gray-400 bg-white/5 p-3 rounded-xl border border-white/10 flex items-center justify-between">
                <span>تجميعة الأسئلة المكررة بالامتحان الوزاري مع الأجوبة النموذجية</span>
                <span className="text-[#e9c978] font-bold">إشراف أ. وسام سهيل</span>
              </div>

              {chapter.ministerialQuestions.map((q) => {
                const isOpen = !!expandedQuestions[q.id];
                return (
                  <div 
                    key={q.id}
                    className="rounded-2xl border border-white/10 bg-white/5 overflow-hidden transition hover:border-[#e9c978]/30"
                  >
                    <button
                      onClick={() => toggleQuestion(q.id)}
                      className="w-full p-4 text-right flex items-start justify-between gap-3 select-none"
                    >
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                            q.type === 'definition' ? 'bg-[#3fa9f5]/20 text-[#3fa9f5]' :
                            q.type === 'reason' ? 'bg-[#e9c978]/20 text-[#e9c978]' :
                            q.type === 'comparison' ? 'bg-[#8b6cf0]/20 text-[#8b6cf0]' :
                            'bg-[#0fb98a]/20 text-[#0fb98a]'
                          }`}>
                            {q.type === 'definition' ? 'تعريف وزاري' :
                             q.type === 'reason' ? 'تعليل وزاري' :
                             q.type === 'comparison' ? 'مقارنة هامة' : 'موقع ووظيفة'}
                          </span>
                          <div className="flex gap-1 text-[11px] text-gray-400">
                            {q.years.map((y, yIdx) => (
                              <span key={yIdx} className="bg-black/30 px-1.5 py-0.5 rounded text-gray-300">
                                {y}
                              </span>
                            ))}
                          </div>
                        </div>
                        <h4 className="text-sm sm:text-base font-bold text-white pt-1">
                          {q.question}
                        </h4>
                      </div>
                      <div className="p-1 rounded-lg bg-white/5 text-gray-400 shrink-0 mt-1">
                        {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </div>
                    </button>

                    {isOpen && (
                      <div className="p-4 pt-1 border-t border-white/10 bg-black/30 text-sm text-gray-200 leading-relaxed">
                        <div className="font-semibold text-[#0fb98a] text-xs mb-1">الجواب النموذجي المعتمد:</div>
                        <p>{q.answer}</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'drawings' && (
            <div className="space-y-3">
              <div className="text-xs text-gray-300 bg-white/5 p-3.5 rounded-xl border border-white/10">
                الرسومات تمثل ما يقارب 12 إلى 16 درجة في الدفتر الوزاري، تأكد من إتقان التأشيرات كاملة.
              </div>

              {chapter.drawings.map((draw, idx) => (
                <div 
                  key={idx}
                  className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-[#e9c978]/30 transition space-y-2"
                >
                  <div className="flex items-center justify-between gap-3">
                    <h4 className="font-bold text-white text-base flex items-center gap-2">
                      <PenTool className="w-4 h-4 text-[#e9c978]" />
                      {draw.name}
                    </h4>
                    <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                      draw.importance === 'عالية جداً' 
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : 'bg-[#e9c978]/20 text-[#e9c978] border border-[#e9c978]/30'
                    }`}>
                      أهمية {draw.importance}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-400 pt-1">
                    <span>ملاحظة الأستاذ: {draw.notes}</span>
                    <span className="font-mono text-[#0fb98a]">{draw.pageHint} في الكتاب</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-[#04080f]/80 flex items-center justify-between text-xs">
          <span className="text-gray-400">إشراف الأستاذ وسام سهيل العامري</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
