import React, { useState, useEffect, useRef } from 'react';
import { 
  BookOpen, 
  Plus, 
  Trash2, 
  Edit3, 
  ExternalLink, 
  Upload, 
  Search, 
  Filter, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Eye, 
  Download, 
  Layers, 
  GraduationCap, 
  X,
  FileCheck,
  FileUp,
  Image as ImageIcon
} from 'lucide-react';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { 
  addCurriculumBookToCloud, 
  updateCurriculumBookInCloud, 
  deleteCurriculumBookFromCloud,
  uploadFileWithFirebaseStorage,
  updateFirestoreBookWithFileUrl,
  subscribeToCurriculumBooks
} from '../services/firebase';

export interface CurriculumBookRecord {
  id: string;
  stage: 'primary' | 'intermediate' | 'preparatory';
  stageName: string;
  gradeKey: string;
  grade: string;
  contentType: 'book' | 'booklet' | 'summary' | 'exam_bank';
  contentTypeName?: string;
  subject: string;
  icon?: string;
  title: string;
  edition: string;
  author: string;
  specialization?: string;
  academicLevel?: string;
  pages: number;
  fileSize: string;
  year: number;
  pdfUrl: string | null;
  fileUrl?: string | null;
  officialSource?: string;
  isAvailable: boolean;
  verificationStatus?: 'verified' | 'pending' | 'unavailable';
  verificationNotes?: string;
  coverUrl: string;
  description: string;
  status: 'published' | 'draft';
  createdAt?: string;
}

const GRADE_OPTIONS = [
  { key: 'm1', label: 'الأول المتوسط', stage: 'intermediate', stageName: 'المرحلة المتوسطة', icon: '📘' },
  { key: 'm2', label: 'الثاني المتوسط', stage: 'intermediate', stageName: 'المرحلة المتوسطة', icon: '🦠' },
  { key: 'm3', label: 'الثالث المتوسط', stage: 'intermediate', stageName: 'المرحلة المتوسطة', icon: '🧬' },
  { key: 'g4', label: 'الرابع العلمي', stage: 'preparatory', stageName: 'المرحلة الإعدادية', icon: '🔬' },
  { key: 'g5', label: 'الخامس العلمي', stage: 'preparatory', stageName: 'المرحلة الإعدادية', icon: '🌿' },
  { key: 'g6', label: 'السادس العلمي (الوزاري)', stage: 'preparatory', stageName: 'المرحلة الإعدادية', icon: '👑' },
  { key: 'primary_all', label: 'المرحلة الابتدائية (العلوم)', stage: 'primary', stageName: 'المرحلة الابتدائية', icon: '🌱' },
];

const CONTENT_TYPES = [
  { key: 'book', label: 'كتاب منهجي وزاري', icon: '📘', badgeColor: 'bg-blue-500/15 text-blue-300 border-blue-500/30' },
  { key: 'booklet', label: 'ملزمة ذهبية متكاملة', icon: '📒', badgeColor: 'bg-[#e9c978]/15 text-[#e9c978] border-[#e9c978]/30' },
  { key: 'summary', label: 'ملخص ومراجعة مركزة', icon: '📑', badgeColor: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' },
  { key: 'exam_bank', label: 'بنك الأسئلة والحلول الوزارية', icon: '🎯', badgeColor: 'bg-purple-500/15 text-purple-300 border-purple-500/30' }
];

interface AdminBooksTabProps {
  onShowToast: (msg: string) => void;
}

export const AdminBooksTab: React.FC<AdminBooksTabProps> = ({ onShowToast }) => {
  const [books, setBooks] = useState<CurriculumBookRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Modal State for Add / Edit
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingBook, setEditingBook] = useState<CurriculumBookRecord | null>(null);

  // Form Fields
  const [formGradeKey, setFormGradeKey] = useState<string>('g6');
  const [formContentType, setFormContentType] = useState<'book' | 'booklet' | 'summary' | 'exam_bank'>('book');
  const [formTitle, setFormTitle] = useState<string>('');
  const [formEdition, setFormEdition] = useState<string>('طبعة 2024-2025 المعتمدة');
  const [formAuthor, setFormAuthor] = useState<string>('وزارة التربية العراقية / إعداد أ. وسام سهيل العامري');
  const [formPages, setFormPages] = useState<number>(180);
  const [formFileSize, setFormFileSize] = useState<string>('5.2 MB');
  const [formYear, setFormYear] = useState<number>(2024);
  const [formDescription, setFormDescription] = useState<string>('');
  const [formCoverUrl, setFormCoverUrl] = useState<string>('');
  const [formPdfUrl, setFormPdfUrl] = useState<string>('');
  const [formOfficialSource, setFormOfficialSource] = useState<string>('https://manahj.edu.iq/');
  const [formIsAvailable, setFormIsAvailable] = useState<boolean>(true);
  const [formVerificationStatus, setFormVerificationStatus] = useState<'verified' | 'pending' | 'unavailable'>('verified');

  // Upload States
  const [isUploadingPdf, setIsUploadingPdf] = useState<boolean>(false);
  const [pdfUploadProgress, setPdfUploadProgress] = useState<number>(0);
  const [pdfUploadError, setPdfUploadError] = useState<string | null>(null);

  const [isUploadingCover, setIsUploadingCover] = useState<boolean>(false);
  const [coverUploadError, setCoverUploadError] = useState<string | null>(null);

  // File Input Refs
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  // Fetch books from Server
  const fetchBooks = async () => {
    setIsLoading(true);
    try {
      const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';
      const res = await fetch('/api/admin/books', {
        headers: { 'Authorization': `Bearer ${adminToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.books)) {
          setBooks(data.books);
        }
      } else {
        // Fallback to public curriculum endpoint
        const pubRes = await fetch('/api/books/curriculum');
        if (pubRes.ok) {
          const pubData = await pubRes.json();
          if (pubData.success && Array.isArray(pubData.books)) {
            setBooks(pubData.books);
          }
        }
      }
    } catch (e) {
      console.error('Error fetching admin books:', e);
      onShowToast('تعذر جلب قائمة الكتب من السيرفر حالياً');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBooks();
    const unsub = subscribeToCurriculumBooks((cloudBooks) => {
      if (Array.isArray(cloudBooks)) {
        setBooks(cloudBooks);
        setIsLoading(false);
      }
    });
    return () => unsub();
  }, []);

  // Open modal in Add mode
  const handleOpenAdd = () => {
    playClickSound();
    setEditingBook(null);
    setFormGradeKey('g6');
    setFormContentType('book');
    setFormTitle('');
    setFormEdition('طبعة 2024-2025 المعتمدة');
    setFormAuthor('وزارة التربية العراقية / إعداد أ. وسام سهيل العامري');
    setFormPages(180);
    setFormFileSize('5.0 MB');
    setFormYear(2024);
    setFormDescription('');
    setFormCoverUrl('https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=600&q=80');
    setFormPdfUrl('');
    setFormOfficialSource('https://manahj.edu.iq/');
    setFormIsAvailable(true);
    setFormVerificationStatus('verified');
    setPdfUploadProgress(0);
    setPdfUploadError(null);
    setCoverUploadError(null);
    setIsModalOpen(true);
  };

  // Open modal in Edit mode
  const handleOpenEdit = (b: CurriculumBookRecord) => {
    playClickSound();
    setEditingBook(b);
    setFormGradeKey(b.gradeKey || 'g6');
    setFormContentType(b.contentType || 'book');
    setFormTitle(b.title || '');
    setFormEdition(b.edition || 'طبعة 2024 المعتمدة');
    setFormAuthor(b.author || '');
    setFormPages(b.pages || 150);
    setFormFileSize(b.fileSize || 'غير محدد');
    setFormYear(b.year || 2024);
    setFormDescription(b.description || '');
    setFormCoverUrl(b.coverUrl || '');
    setFormPdfUrl(b.pdfUrl || b.fileUrl || '');
    setFormOfficialSource(b.officialSource || 'https://manahj.edu.iq/');
    setFormIsAvailable(b.isAvailable !== false);
    setFormVerificationStatus(b.verificationStatus || 'verified');
    setPdfUploadProgress(0);
    setPdfUploadError(null);
    setCoverUploadError(null);
    setIsModalOpen(true);
  };

  // Upload PDF using Firebase Storage with resilient streaming fallback
  const handlePdfFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.pdf') && file.type !== 'application/pdf') {
      onShowToast('يرجى اختيار ملف PDF صالح');
      return;
    }

    setIsUploadingPdf(true);
    setPdfUploadProgress(0);
    setPdfUploadError(null);

    try {
      const uploadResult = await uploadFileWithFirebaseStorage(
        file,
        'books',
        (percent) => setPdfUploadProgress(percent)
      );

      setPdfUploadProgress(100);
      setFormPdfUrl(uploadResult.url);
      const computedSize = uploadResult.fileSize || `${(file.size / (1024 * 1024)).toFixed(2)} MB`;
      setFormFileSize(computedSize);

      if (!formTitle.trim()) {
        setFormTitle(file.name.replace(/\.[^/.]+$/, '').replace(/[_\\-]/g, ' '));
      }

      // If editing an existing book, update Firestore immediately with the generated download URL!
      if (editingBook) {
        await updateFirestoreBookWithFileUrl(editingBook.id, 'pdf', uploadResult.url, {
          fileSize: computedSize
        });
      }

      playSuccessSound();
      onShowToast(`تم رفع ملف الـ PDF بنجاح 📚 (${computedSize})`);
    } catch (err: any) {
      console.error('Error uploading PDF file:', err);
      const errorMsg = err?.message || 'فشل رفع ملف الـ PDF';
      setPdfUploadError(errorMsg);
      onShowToast(errorMsg);
    } finally {
      setIsUploadingPdf(false);
    }
  };

  // Upload Cover Image using Firebase Storage with resilient streaming fallback
  const handleCoverFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingCover(true);
    setCoverUploadError(null);

    try {
      const uploadResult = await uploadFileWithFirebaseStorage(
        file,
        'covers',
        undefined
      );

      setFormCoverUrl(uploadResult.url);

      // If editing an existing book, update Firestore immediately with the generated download URL!
      if (editingBook) {
        await updateFirestoreBookWithFileUrl(editingBook.id, 'cover', uploadResult.url);
      }

      playSuccessSound();
      onShowToast('تم رفع صورة الغلاف بنجاح 🖼️');
    } catch (err: any) {
      console.error('Error uploading cover image:', err);
      const errorMsg = err?.message || 'فشل رفع صورة الغلاف';
      setCoverUploadError(errorMsg);
      onShowToast(errorMsg);
    } finally {
      setIsUploadingCover(false);
    }
  };

  // Submit Add or Edit Form
  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      onShowToast('يرجى إدخال عنوان الكتاب أو الملزمة');
      return;
    }

    const selectedGradeInfo = GRADE_OPTIONS.find(g => g.key === formGradeKey) || GRADE_OPTIONS[5];
    const selectedTypeInfo = CONTENT_TYPES.find(t => t.key === formContentType) || CONTENT_TYPES[0];

    const bookPayload: CurriculumBookRecord = {
      id: editingBook ? editingBook.id : `book-${formGradeKey}-${Date.now()}`,
      stage: selectedGradeInfo.stage as any,
      stageName: selectedGradeInfo.stageName,
      gradeKey: formGradeKey,
      grade: selectedGradeInfo.label,
      contentType: formContentType,
      contentTypeName: selectedTypeInfo.label,
      subject: 'علم الأحياء',
      icon: selectedGradeInfo.icon,
      title: formTitle.trim(),
      edition: formEdition.trim() || 'طبعة 2024 المعتمدة',
      author: formAuthor.trim() || 'الأستاذ وسام سهيل العامري',
      pages: Number(formPages) || 150,
      fileSize: formFileSize.trim() || '5.0 MB',
      year: Number(formYear) || 2024,
      pdfUrl: formPdfUrl.trim() || null,
      fileUrl: formPdfUrl.trim() || null,
      officialSource: formOfficialSource.trim() || 'https://manahj.edu.iq/',
      isAvailable: formIsAvailable,
      verificationStatus: formVerificationStatus,
      verificationNotes: formIsAvailable ? 'تم التدقيق والاعتماد في مكتبة المنصة الرسمية' : 'قيد التدقيق والتجهيز',
      coverUrl: formCoverUrl.trim() || 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=600&q=80',
      description: formDescription.trim(),
      status: 'published',
      createdAt: editingBook?.createdAt || new Date().toISOString()
    };

    const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

    try {
      if (editingBook) {
        // Update on Server
        const res = await fetch(`/api/admin/books/${editingBook.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${adminToken}`
          },
          body: JSON.stringify(bookPayload)
        });

        if (res.ok) {
          setBooks(prev => prev.map(b => b.id === editingBook.id ? bookPayload : b));
        }

        // Update in Firestore
        try {
          await updateCurriculumBookInCloud(editingBook.id, bookPayload);
        } catch (cloudErr) {
          console.warn('Notice syncing book update to Firestore:', cloudErr);
        }

        playSuccessSound();
        onShowToast(`تم تحديث «${bookPayload.title}» بنجاح ✅`);
      } else {
        // Add to Server
        const res = await fetch('/api/admin/books', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${adminToken}`
          },
          body: JSON.stringify(bookPayload)
        });

        if (res.ok) {
          const data = await res.json();
          const savedBook = data.book || bookPayload;
          setBooks(prev => [savedBook, ...prev]);
        } else {
          setBooks(prev => [bookPayload, ...prev]);
        }

        // Add to Firestore
        try {
          await addCurriculumBookToCloud(bookPayload);
        } catch (cloudErr) {
          console.warn('Notice syncing book add to Firestore:', cloudErr);
        }

        playSuccessSound();
        onShowToast(`تم نشر «${bookPayload.title}» بنجاح لجميع الطلاب 📚`);
      }

      setIsModalOpen(false);
    } catch (err: any) {
      console.error('Error saving book:', err);
      onShowToast('حدث خطأ أثناء حفظ الكتاب على السيرفر');
    }
  };

  // Delete Book
  const handleDeleteBook = async (id: string, title: string) => {
    if (!window.confirm(`هل أنت متأكد من حذف «${title}» نهائياً من مكتبة المناهج والملازم؟`)) {
      return;
    }

    const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

    try {
      // 1. Blacklist ID locally to prevent ghost resurfacing
      try {
        const deletedIds: string[] = JSON.parse(localStorage.getItem('biolab_deleted_book_ids') || '[]');
        if (!deletedIds.includes(id)) {
          deletedIds.push(id);
          localStorage.setItem('biolab_deleted_book_ids', JSON.stringify(deletedIds));
        }
      } catch (e) {}

      // 2. Broadcast event for BooksSection real-time sync
      window.dispatchEvent(new CustomEvent('biolab_curriculum_book_deleted', { detail: { id } }));

      setBooks(prev => prev.filter(b => b.id !== id));

      await fetch(`/api/admin/books/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${adminToken}` }
      });

      try {
        await deleteCurriculumBookFromCloud(id);
      } catch (cloudErr) {
        console.warn('Notice deleting book from Firestore:', cloudErr);
      }

      playClickSound();
      onShowToast(`تم حذف «${title}» بنجاح من المنصة`);
    } catch (err) {
      onShowToast('حدث خطأ أثناء حذف الكتاب');
    }
  };

  // Filtered books
  const filteredBooks = books.filter(b => {
    // Stage Filter
    if (stageFilter !== 'all') {
      if (stageFilter === 'intermediate' && b.stage !== 'intermediate') return false;
      if (stageFilter === 'preparatory' && b.stage !== 'preparatory') return false;
      if (stageFilter === 'g6' && b.gradeKey !== 'g6') return false;
      if (stageFilter === 'g5' && b.gradeKey !== 'g5') return false;
      if (stageFilter === 'g4' && b.gradeKey !== 'g4') return false;
      if (stageFilter === 'm3' && b.gradeKey !== 'm3') return false;
      if (stageFilter === 'm2' && b.gradeKey !== 'm2') return false;
      if (stageFilter === 'm1' && b.gradeKey !== 'm1') return false;
    }

    // Content Type Filter
    if (typeFilter !== 'all') {
      const cType = b.contentType || 'book';
      if (cType !== typeFilter) return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = (b.title || '').toLowerCase().includes(q);
      const matchGrade = (b.grade || '').toLowerCase().includes(q);
      const matchAuthor = (b.author || '').toLowerCase().includes(q);
      const matchDesc = (b.description || '').toLowerCase().includes(q);
      if (!matchTitle && !matchGrade && !matchAuthor && !matchDesc) return false;
    }

    return true;
  });

  const totalBooksCount = books.filter(b => !b.contentType || b.contentType === 'book').length;
  const totalBookletsCount = books.filter(b => b.contentType === 'booklet').length;
  const totalSummariesCount = books.filter(b => b.contentType === 'summary').length;
  const totalExamBanksCount = books.filter(b => b.contentType === 'exam_bank').length;

  return (
    <div className="space-y-6">
      
      {/* Header & Stats Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-950/40 via-[#04080f] to-amber-950/30 border border-emerald-500/20 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#0fb98a] to-[#2dd4bf] text-black flex items-center justify-center text-2xl font-bold shadow-lg shadow-[#0fb98a]/20 shrink-0">
              📚
            </div>
            <div>
              <h3 className="font-amiri font-bold text-xl sm:text-2xl text-white flex items-center gap-2">
                <span>إدارة الكتب والملازم الوزارية</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#0fb98a]/15 text-[#0fb98a] border border-[#0fb98a]/30 font-sans font-bold">
                  {books.length} ملف منشور
                </span>
              </h3>
              <p className="text-xs text-gray-300">
                نشر وتعديل الكتب المنهجية والملازم الذهبية من الأول المتوسط حتى السادس العلمي مع دعم التخزين السحابي الحقيقي والقراءة الفورية داخل التطبيق.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={fetchBooks}
              disabled={isLoading}
              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 transition"
              title="تحديث البيانات"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-[#0fb98a]' : ''}`} />
            </button>
            <button
              type="button"
              onClick={handleOpenAdd}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#059669] text-black font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-[#0fb98a]/25 hover:brightness-110 active:scale-95 transition"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>إضافة كتاب أو ملزمة جديدة</span>
            </button>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5 mt-4 border-t border-white/10 text-xs">
          <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between">
            <span className="text-gray-400">كتب وزارية رسمية</span>
            <strong className="text-blue-400 font-mono text-sm">{totalBooksCount}</strong>
          </div>
          <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between">
            <span className="text-gray-400">ملازم ذهبية</span>
            <strong className="text-[#e9c978] font-mono text-sm">{totalBookletsCount}</strong>
          </div>
          <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between">
            <span className="text-gray-400">ملخصات ومراجعات</span>
            <strong className="text-emerald-400 font-mono text-sm">{totalSummariesCount}</strong>
          </div>
          <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between">
            <span className="text-gray-400">بنوك أسئلة وزارية</span>
            <strong className="text-purple-400 font-mono text-sm">{totalExamBanksCount}</strong>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث بالاسم، المرحلة، المؤلف، أو الكلمات المفتاحية..."
              className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#0fb98a]"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white text-xs"
              >
                مسح
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            {/* Stage filter dropdown */}
            <select
              value={stageFilter}
              onChange={(e) => setStageFilter(e.target.value)}
              className="py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-xs text-gray-200 focus:outline-none focus:border-[#0fb98a]"
            >
              <option value="all">جميع المراحل الدراسية</option>
              <option value="g6">السادس العلمي (الوزاري)</option>
              <option value="g5">الخامس العلمي</option>
              <option value="g4">الرابع العلمي</option>
              <option value="m3">الثالث المتوسط</option>
              <option value="m2">الثاني المتوسط</option>
              <option value="m1">الأول المتوسط</option>
              <option value="intermediate">كافة المتوسطة</option>
              <option value="preparatory">كافة الإعدادية</option>
            </select>

            {/* Content type filter dropdown */}
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-xs text-gray-200 focus:outline-none focus:border-[#0fb98a]"
            >
              <option value="all">كافة أنواع المحتوى</option>
              <option value="book">كتب منهجية وزارية</option>
              <option value="booklet">ملازم ذهبية</option>
              <option value="summary">ملخصات مركزة</option>
              <option value="exam_bank">بنوك الأسئلة الوزارية</option>
            </select>
          </div>
        </div>
      </div>

      {/* Books Table / Grid */}
      {isLoading ? (
        <div className="py-20 text-center space-y-3">
          <RefreshCw className="w-8 h-8 text-[#0fb98a] animate-spin mx-auto" />
          <p className="text-xs text-gray-400 font-bold">جاري تحميل مستودع الكتب والملازم...</p>
        </div>
      ) : filteredBooks.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white/5 border border-white/10 space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-white/5 text-gray-400 flex items-center justify-center text-3xl mx-auto">
            📖
          </div>
          <h4 className="font-bold text-base text-white">لا توجد ملفات مطابقة لبحثك</h4>
          <p className="text-xs text-gray-400 max-w-sm mx-auto">
            لم نتمكن من العثور على كتب أو ملازم تطابق شروط الفلترة المحددة. يمكنك تعديل البحث أو إضافة كتاب جديد.
          </p>
          <button
            type="button"
            onClick={handleOpenAdd}
            className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#059669] text-black font-black text-xs inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة كتاب جديد الآن</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredBooks.map((book) => {
            const typeInfo = CONTENT_TYPES.find(t => t.key === (book.contentType || 'book')) || CONTENT_TYPES[0];
            const hasPdf = Boolean(book.pdfUrl || book.fileUrl);

            return (
              <div 
                key={book.id}
                className="group p-4 rounded-3xl bg-black/40 hover:bg-black/60 border border-white/10 hover:border-[#0fb98a]/40 transition flex flex-col justify-between gap-4 relative overflow-hidden"
              >
                <div className="space-y-3">
                  {/* Top row: Cover Thumbnail + Badges */}
                  <div className="flex items-start gap-3">
                    <div className="w-16 h-22 rounded-xl overflow-hidden bg-black/60 border border-white/10 shrink-0 relative shadow-md">
                      <img
                        src={book.coverUrl || 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=300&q=80'}
                        alt={book.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=300&q=80';
                        }}
                      />
                      {hasPdf && (
                        <div className="absolute top-1 right-1 px-1 py-0.5 rounded bg-black/75 text-[9px] text-[#0fb98a] font-mono font-bold">
                          PDF
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0 space-y-1.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border font-bold ${typeInfo.badgeColor}`}>
                          {typeInfo.label}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-gray-300 border border-white/10 font-bold">
                          {book.grade}
                        </span>
                      </div>

                      <h4 className="font-bold text-sm text-white line-clamp-2 leading-snug group-hover:text-[#0fb98a] transition-colors">
                        {book.title}
                      </h4>

                      <p className="text-[11px] text-gray-400 line-clamp-1">
                        {book.author || 'إعداد الأستاذ وسام سهيل العامري'}
                      </p>
                    </div>
                  </div>

                  {/* Metadata chips */}
                  <div className="grid grid-cols-3 gap-2 py-2 px-3 rounded-2xl bg-white/5 border border-white/5 text-[11px] text-center">
                    <div>
                      <span className="text-gray-400 block text-[10px]">الصفحات</span>
                      <strong className="text-gray-200 font-mono">{book.pages || '—'}</strong>
                    </div>
                    <div>
                      <span className="text-gray-400 block text-[10px]">الحجم</span>
                      <strong className="text-emerald-400 font-mono">{book.fileSize || '—'}</strong>
                    </div>
                    <div>
                      <span className="text-gray-400 block text-[10px]">الطبعة</span>
                      <strong className="text-[#e9c978] font-mono">{book.year || '2024'}</strong>
                    </div>
                  </div>

                  {/* Status Note */}
                  <div className="flex items-center justify-between text-[11px] px-1">
                    <span className="flex items-center gap-1 text-gray-400">
                      <span className={`w-2 h-2 rounded-full ${hasPdf && book.isAvailable ? 'bg-[#0fb98a]' : 'bg-amber-400'}`}></span>
                      <span>{hasPdf && book.isAvailable ? 'جاهز للقراءة والتنزيل' : 'رابط خارجي أو قيد التجهيز'}</span>
                    </span>
                    <span className="text-[10px] text-gray-500 font-mono">
                      {book.id}
                    </span>
                  </div>
                </div>

                {/* Actions Footer */}
                <div className="flex items-center gap-2 pt-3 border-t border-white/10">
                  {hasPdf && (
                    <a
                      href={book.pdfUrl || book.fileUrl || '#'}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-bold transition flex items-center justify-center gap-1.5"
                      title="معاينة الملف"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>معاينة</span>
                    </a>
                  )}

                  <button
                    type="button"
                    onClick={() => handleOpenEdit(book)}
                    className="p-2 rounded-xl bg-[#0fb98a]/15 hover:bg-[#0fb98a]/25 text-[#0fb98a] border border-[#0fb98a]/30 transition"
                    title="تعديل بيانات الكتاب"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDeleteBook(book.id, book.title)}
                    className="p-2 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-400 border border-red-500/30 transition"
                    title="حذف الكتاب نهائياً"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Book Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[1200] bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="w-full max-w-2xl bg-[#04080f] border border-white/15 rounded-3xl p-5 sm:p-7 space-y-5 text-white shadow-2xl relative my-auto">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#0fb98a] to-[#2dd4bf] text-black flex items-center justify-center text-xl font-bold">
                  {editingBook ? '✏️' : '📚'}
                </div>
                <div>
                  <h3 className="font-bold text-base sm:text-lg text-white">
                    {editingBook ? 'تعديل بيانات الكتاب أو الملزمة' : 'إضافة كتاب أو ملزمة جديدة للمنصة'}
                  </h3>
                  <p className="text-xs text-gray-400">
                    ستظهر الإضافة أو التعديل لجميع الطلاب على الفور في تطبيق الأندرويد والويب.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmitForm} className="space-y-4 text-xs">
              
              {/* Row 1: Grade & Content Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">
                    المرحلة الدراسية <span className="text-red-400">*</span>
                  </label>
                  <select
                    value={formGradeKey}
                    onChange={(e) => setFormGradeKey(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 text-white focus:outline-none focus:border-[#0fb98a]"
                  >
                    {GRADE_OPTIONS.map((g) => (
                      <option key={g.key} value={g.key}>
                        {g.icon} {g.label} ({g.stageName})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">
                    نوع المحتوى <span className="text-red-400">*</span>
                  </label>
                  <select
                    value={formContentType}
                    onChange={(e) => setFormContentType(e.target.value as any)}
                    className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 text-white focus:outline-none focus:border-[#0fb98a]"
                  >
                    {CONTENT_TYPES.map((t) => (
                      <option key={t.key} value={t.key}>
                        {t.icon} {t.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row 2: Title */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">
                  عنوان الكتاب أو الملزمة <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="مثال: الملزمة الذهبية في الأحياء - الفصل الثالث (التكاثر)"
                  className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 text-white placeholder-gray-500 focus:outline-none focus:border-[#0fb98a]"
                />
              </div>

              {/* Row 3: Edition, Author, Pages, Year */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">الطبعة المعتمدة</label>
                  <input
                    type="text"
                    value={formEdition}
                    onChange={(e) => setFormEdition(e.target.value)}
                    placeholder="طبعة 2024-2025"
                    className="w-full py-2 px-2.5 rounded-xl bg-black/60 border border-white/15 text-white focus:outline-none focus:border-[#0fb98a]"
                  />
                </div>
                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">المؤلف / المدرس</label>
                  <input
                    type="text"
                    value={formAuthor}
                    onChange={(e) => setFormAuthor(e.target.value)}
                    placeholder="أ. وسام سهيل العامري"
                    className="w-full py-2 px-2.5 rounded-xl bg-black/60 border border-white/15 text-white focus:outline-none focus:border-[#0fb98a]"
                  />
                </div>
                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">عدد الصفحات</label>
                  <input
                    type="number"
                    value={formPages}
                    onChange={(e) => setFormPages(Number(e.target.value))}
                    min={1}
                    className="w-full py-2 px-2.5 rounded-xl bg-black/60 border border-white/15 text-white font-mono focus:outline-none focus:border-[#0fb98a]"
                  />
                </div>
                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">حجم الملف</label>
                  <input
                    type="text"
                    value={formFileSize}
                    onChange={(e) => setFormFileSize(e.target.value)}
                    placeholder="5.4 MB"
                    className="w-full py-2 px-2.5 rounded-xl bg-black/60 border border-white/15 text-white font-mono focus:outline-none focus:border-[#0fb98a]"
                  />
                </div>
              </div>

              {/* Section: Upload PDF File (Direct Device vs External URL) */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-gray-200 font-bold flex items-center gap-2">
                    <FileText className="w-4 h-4 text-[#0fb98a]" />
                    <span>ملف الـ PDF (رفع من الجهاز أو رابط مباشر)</span>
                  </label>
                  {formPdfUrl && (
                    <span className="text-[11px] text-[#0fb98a] font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>الملف محدد وجاهز</span>
                    </span>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-2">
                  <div className="relative w-full sm:w-auto overflow-hidden">
                    <input
                      id="admin-pdf-file-picker"
                      type="file"
                      ref={pdfInputRef}
                      accept="application/pdf,.pdf"
                      onChange={(e) => {
                        handlePdfFileSelect(e);
                        e.target.value = '';
                      }}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                      title="اختيار ملف PDF من الجهاز"
                      disabled={isUploadingPdf}
                    />
                    <button
                      type="button"
                      disabled={isUploadingPdf}
                      className={`w-full sm:w-auto py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#059669] text-black font-black flex items-center justify-center gap-2 shadow hover:brightness-110 active:scale-95 transition cursor-pointer select-none pointer-events-none ${
                        isUploadingPdf ? 'opacity-70' : ''
                      }`}
                    >
                      <Upload className="w-4 h-4" />
                      <span>{isUploadingPdf ? `جاري الرفع (${pdfUploadProgress}%)...` : '📁 اختيار ورفع PDF من الجهاز'}</span>
                    </button>
                  </div>

                  <div className="flex-1 w-full">
                    <input
                      type="text"
                      value={formPdfUrl}
                      onChange={(e) => setFormPdfUrl(e.target.value)}
                      placeholder="أو الصق رابط PDF مباشر أو رابط Google Drive صالح..."
                      className="w-full py-2 px-3 rounded-xl bg-black/60 border border-white/15 text-white placeholder-gray-500 font-mono text-[11px] focus:outline-none focus:border-[#0fb98a]"
                    />
                  </div>
                </div>

                {/* PDF Progress Bar */}
                {isUploadingPdf && (
                  <div className="space-y-1.5 pt-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-gray-300 font-bold flex items-center gap-1.5">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#0fb98a]" />
                        <span>جاري رفع ملف الـ PDF إلى السيرفر...</span>
                      </span>
                      <span className="font-mono font-bold text-[#0fb98a]">{pdfUploadProgress}%</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#0fb98a] to-[#34d399] transition-all duration-300"
                        style={{ width: `${pdfUploadProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                {pdfUploadError && (
                  <p className="text-[11px] text-red-400 font-bold">
                    ⚠️ {pdfUploadError}
                  </p>
                )}
              </div>

              {/* Section: Cover Image (Upload vs URL) */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <label className="text-gray-200 font-bold flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-[#e9c978]" />
                  <span>صورة الغلاف</span>
                </label>

                <div className="flex items-center gap-3">
                  {formCoverUrl && (
                    <div className="w-12 h-16 rounded-lg overflow-hidden bg-black/60 border border-white/15 shrink-0 shadow">
                      <img
                        src={formCoverUrl}
                        alt="معاينة الغلاف"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=200&q=80';
                        }}
                      />
                    </div>
                  )}

                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="relative overflow-hidden inline-block">
                        <input
                          id="admin-cover-file-picker"
                          type="file"
                          ref={coverInputRef}
                          accept="image/*,image/jpeg,image/png,image/webp"
                          onChange={(e) => {
                            handleCoverFileSelect(e);
                            e.target.value = '';
                          }}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                          title="رفع صورة غلاف من الجهاز"
                          disabled={isUploadingCover}
                        />
                        <button
                          type="button"
                          disabled={isUploadingCover}
                          className={`py-2 px-3.5 rounded-lg bg-white/10 hover:bg-white/15 text-white font-bold flex items-center gap-1.5 transition text-[11px] cursor-pointer select-none pointer-events-none ${
                            isUploadingCover ? 'opacity-70' : ''
                          }`}
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>{isUploadingCover ? 'جاري الرفع...' : 'رفع صورة من الجهاز'}</span>
                        </button>
                      </div>
                      <span className="text-[10px] text-gray-400">أو الصق رابط الصورة أدناه</span>
                    </div>

                    <input
                      type="text"
                      value={formCoverUrl}
                      onChange={(e) => setFormCoverUrl(e.target.value)}
                      placeholder="https://images.unsplash.com/photo-..."
                      className="w-full py-1.5 px-2.5 rounded-lg bg-black/60 border border-white/15 text-white text-[11px] font-mono focus:outline-none focus:border-[#e9c978]"
                    />
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">
                  وصف مختصر ومحتويات الكتاب / الملزمة
                </label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="مثال: ملزمة شاملة لكافة شروحات ورسومات وأسئلة وزاريات علم التكاثر مدعمة بمخططات ذهبية وحلول نموذجية."
                  className="w-full py-2 px-3 rounded-xl bg-black/60 border border-white/15 text-white placeholder-gray-500 focus:outline-none focus:border-[#0fb98a]"
                />
              </div>

              {/* Options: Availability Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/10">
                <div>
                  <span className="font-bold text-white block">حالة النشر والإتاحة للطلاب</span>
                  <span className="text-[11px] text-gray-400">
                    عند التفعيل، سيكون بإمكان جميع الطلاب فتح الكتاب وقراءته وتنزيله فوراً.
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsAvailable}
                    onChange={(e) => setFormIsAvailable(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#0fb98a]"></div>
                </label>
              </div>

              {/* Modal Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 hover:text-white font-bold transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#059669] text-black font-black shadow-lg shadow-[#0fb98a]/20 hover:brightness-110 active:scale-95 transition flex items-center gap-2"
                >
                  <FileCheck className="w-4 h-4 stroke-[2.5]" />
                  <span>{editingBook ? 'حفظ التعديلات' : 'نشر الكتاب الآن'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
