import React from 'react';
import { ArrowLeft, BookOpen } from 'lucide-react';
import { curriculumData, gradeNames } from '../data/platformData';

interface CurriculumSectionProps {
  currentFilter?: string;
  selectedFilter?: string;
  onFilterChange: (gradeKey: string) => void;
  onSelectChapterAction?: () => void;
}

export const CurriculumSection: React.FC<CurriculumSectionProps> = ({
  currentFilter,
  selectedFilter,
  onFilterChange,
  onSelectChapterAction
}) => {
  const activeFilter = currentFilter || selectedFilter || 'all';
  // Determine chapters to show
  let displayedChapters: {
    gradeKey: string;
    gradeName: string;
    icon: string;
    num: string;
    title: string;
    desc: string;
  }[] = [];

  if (activeFilter === 'all') {
    Object.entries(curriculumData).forEach(([key, grade]) => {
      grade.chapters.forEach((ch, idx) => {
        displayedChapters.push({
          gradeKey: key,
          gradeName: grade.name,
          icon: grade.icon,
          num: (idx + 1).toString().padStart(2, '0'),
          title: ch.title,
          desc: ch.desc
        });
      });
    });
  } else if (curriculumData[activeFilter]) {
    const grade = curriculumData[activeFilter];
    grade.chapters.forEach((ch, idx) => {
      displayedChapters.push({
        gradeKey: activeFilter,
        gradeName: grade.name,
        icon: grade.icon,
        num: (idx + 1).toString().padStart(2, '0'),
        title: ch.title,
        desc: ch.desc
      });
    });
  }

  const subtitleText = activeFilter === 'all'
    ? 'اختر مرحلة من الأعلى أو استعرض كافة فصول المناهج أدناه.'
    : `أنت تستعرض فصول: ${curriculumData[activeFilter]?.name || ''}`;

  return (
    <section id="lessons" className="py-24 relative border-t border-white/5">
      <div className="w-[min(1240px,92%)] mx-auto space-y-12">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full text-xs font-bold text-[#e9c978] bg-[#e9c978]/10 border border-[#e9c978]/25 shadow-sm">
            <span>المنهج الدراسي</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold font-amiri text-white">
            فصول مادة الأحياء
          </h2>
          <p id="lessonsSubtitle" className="text-sm sm:text-base text-gray-300 max-w-xl mx-auto">
            {subtitleText}
          </p>
        </div>

        {/* Filter Chips */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          <button
            onClick={() => onFilterChange('all')}
            className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold transition ${
              activeFilter === 'all'
                ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md'
                : 'bg-white/5 text-gray-300 hover:text-white border border-white/10'
            }`}
          >
            جميع الفصول
          </button>
          {Object.entries(gradeNames).map(([key, name]) => (
            <button
              key={key}
              onClick={() => onFilterChange(key)}
              className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold transition ${
                activeFilter === key
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md'
                  : 'bg-white/5 text-gray-300 hover:text-white border border-white/10'
              }`}
            >
              {name}
            </button>
          ))}
        </div>

        {/* Lessons Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {displayedChapters.map((item, index) => (
            <div
              key={`${item.gradeKey}-${index}`}
              className="rounded-3xl bg-[#0a1220] border border-white/10 hover:border-[#e9c978]/40 p-6 flex flex-col justify-between shadow-xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group"
            >
              <div>
                {/* Lesson Top */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#e9c978]/20 to-[#0fb98a]/15 border border-[#e9c978]/30 text-3xl flex items-center justify-center group-hover:scale-105 transition">
                    {item.icon}
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="font-amiri font-bold text-3xl text-gray-500/70 group-hover:text-[#e9c978] transition">
                      {item.num}
                    </span>
                    <span className="text-[10px] text-gray-400 font-semibold">
                      {item.gradeName}
                    </span>
                  </div>
                </div>

                {/* Lesson Title */}
                <h3 className="font-bold text-lg font-amiri text-white mb-2 leading-snug group-hover:text-[#e9c978] transition">
                  {item.title}
                </h3>

                {/* Lesson Description */}
                <p className="text-xs sm:text-sm text-gray-300 leading-relaxed mb-6">
                  {item.desc}
                </p>
              </div>

              {/* Lesson Foot */}
              <div className="pt-4 border-t border-dashed border-white/10 flex items-center justify-center">
                <a
                  href="#institute"
                  onClick={(e) => {
                    e.preventDefault();
                    if (onSelectChapterAction) onSelectChapterAction();
                  }}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-[#e9c978] bg-[#e9c978]/10 border border-[#e9c978]/30 hover:bg-[#e9c978] hover:text-[#08111e] transition"
                >
                  <span>ابدأ الآن</span>
                  <ArrowLeft className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
