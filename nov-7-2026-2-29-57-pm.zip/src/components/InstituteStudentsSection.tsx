import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  GraduationCap, 
  ArrowRight, 
  Search, 
  Filter, 
  Calendar, 
  BookOpen, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Download, 
  ExternalLink, 
  Eye, 
  ShieldCheck, 
  Award, 
  ChevronLeft, 
  ChevronRight, 
  RefreshCw, 
  HelpCircle, 
  Layers, 
  TrendingUp, 
  Users, 
  FileCheck,
  Check,
  Home
} from 'lucide-react';
import { 
  InstitutePost, 
  InstituteStageConfig, 
  defaultInstituteStages, 
  initialInstitutePosts 
} from '../data/instituteData';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { subscribeToInstitutePosts, subscribeToInstituteStages } from '../services/firebase';

interface InstituteStudentsSectionProps {
  onBackToHome: () => void;
  initialStageId?: string | null;
  onSelectStageCallback?: (stageId: string | null) => void;
}

export const InstituteStudentsSection: React.FC<InstituteStudentsSectionProps> = ({
  onBackToHome,
  initialStageId = null,
  onSelectStageCallback
}) => {
  // Navigation & selection state
  const [selectedStageId, setSelectedStageId] = useState<string | null>(initialStageId);
  const [activeTab, setActiveTab] = useState<'grades' | 'homework'>('grades');

  // Stages & Posts data state
  const [stages, setStages] = useState<InstituteStageConfig[]>(defaultInstituteStages);
  const [posts, setPosts] = useState<InstitutePost[]>(initialInstitutePosts);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'latest' | 'oldest'>('latest');

  // Interactive Private Student Score Lookup
  const [studentCodeInput, setStudentCodeInput] = useState('');
  const [isCheckingScore, setIsCheckingScore] = useState(false);
  const [scoreLookupResult, setScoreLookupResult] = useState<any | null>(null);
  const [scoreLookupError, setScoreLookupError] = useState<string | null>(null);

  // Modal for previewing attached images or result sheets
  const [previewAttachmentUrl, setPreviewAttachmentUrl] = useState<{ url: string; title: string; type?: string } | null>(null);

  // Sync stage selection callback if provided
  const handleSelectStage = useCallback((stageId: string | null) => {
    playClickSound();
    setSelectedStageId(stageId);
    if (onSelectStageCallback) {
      onSelectStageCallback(stageId);
    }
    // Reset filters and scroll to top smoothly
    setSearchQuery('');
    setSubjectFilter('all');
    window.scrollTo({ top: 120, behavior: 'smooth' });
  }, [onSelectStageCallback]);

  // Fetch stages & posts from server
  const fetchInstituteData = useCallback(async (isRefresh = false) => {
    if (isRefresh) setIsRefreshing(true);
    else setIsLoading(true);

    try {
      // 1. Fetch stages
      const stagesRes = await fetch('/api/institute/stages');
      if (stagesRes.ok) {
        const data = await stagesRes.json();
        if (data.success && Array.isArray(data.stages) && data.stages.length > 0) {
          setStages(data.stages);
        }
      }

      // 2. Fetch posts
      const postsRes = await fetch('/api/institute/posts');
      if (postsRes.ok) {
        const data = await postsRes.json();
        if (data.success && Array.isArray(data.posts)) {
          setPosts(data.posts);
          try {
            localStorage.setItem('institute_posts_cache', JSON.stringify(data.posts));
          } catch (e) {}
        }
      }
    } catch (err) {
      // Offline fallback: load from localStorage
      try {
        const cached = localStorage.getItem('institute_posts_cache');
        if (cached) {
          setPosts(JSON.parse(cached));
        }
      } catch (e) {}
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    // 1. Initial fetch from server
    fetchInstituteData(false);

    // 2. Direct real-time listener from Firestore
    const unsubPosts = subscribeToInstitutePosts((cloudPosts) => {
      if (Array.isArray(cloudPosts) && cloudPosts.length > 0) {
        setPosts(cloudPosts);
        try {
          localStorage.setItem('institute_posts_cache', JSON.stringify(cloudPosts));
        } catch (e) {}
      }
    });

    const unsubStages = subscribeToInstituteStages((cloudStages) => {
      if (Array.isArray(cloudStages) && cloudStages.length > 0) {
        setStages(cloudStages);
      }
    });

    return () => {
      unsubPosts();
      unsubStages();
    };
  }, [fetchInstituteData]);

  // Find currently selected stage object
  const currentStage = useMemo(() => {
    if (!selectedStageId) return null;
    return stages.find(s => s.id === selectedStageId) || null;
  }, [selectedStageId, stages]);

  // Count posts per stage for stage cards
  const stageStats = useMemo(() => {
    const stats: Record<string, { gradesCount: number; homeworkCount: number }> = {};
    for (const stage of stages) {
      const stagePosts = posts.filter(p => p.stageId === stage.id && p.status === 'published');
      stats[stage.id] = {
        gradesCount: stagePosts.filter(p => p.type === 'grade').length,
        homeworkCount: stagePosts.filter(p => p.type === 'homework').length
      };
    }
    return stats;
  }, [stages, posts]);

  // Unique subjects in the current stage & tab
  const availableSubjects = useMemo(() => {
    if (!selectedStageId) return [];
    const stagePosts = posts.filter(
      p => p.stageId === selectedStageId && p.type === activeTab && p.status === 'published'
    );
    const set = new Set<string>();
    stagePosts.forEach(p => {
      if (p.subject) set.add(p.subject);
    });
    return Array.from(set);
  }, [selectedStageId, posts, activeTab]);

  // Filtered & sorted posts for the selected stage and active tab
  const filteredPosts = useMemo(() => {
    if (!selectedStageId) return [];

    let result = posts.filter(
      p => p.stageId === selectedStageId && p.type === activeTab && p.status === 'published'
    );

    // Filter by subject
    if (subjectFilter !== 'all') {
      result = result.filter(p => p.subject === subjectFilter);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        p =>
          p.title.toLowerCase().includes(q) ||
          p.subject.toLowerCase().includes(q) ||
          (p.details && p.details.toLowerCase().includes(q)) ||
          (p.notes && p.notes.toLowerCase().includes(q))
      );
    }

    // Sorting
    result.sort((a, b) => {
      const dateA = new Date(a.date || a.createdAt).getTime();
      const dateB = new Date(b.date || b.createdAt).getTime();
      return dateFilter === 'latest' ? dateB - dateA : dateA - dateB;
    });

    return result;
  }, [posts, selectedStageId, activeTab, subjectFilter, searchQuery, dateFilter]);

  // Compute status badge for homework (واجب جديد، موعد التسليم قريب، انتهى موعد التسليم)
  const getHomeworkStatus = useCallback((post: InstitutePost) => {
    if (!post.dueDate) {
      return { label: 'تحضير دراسي', color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' };
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(post.dueDate);
    due.setHours(0, 0, 0, 0);

    const diffDays = Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { label: 'انتهى موعد التسليم', color: 'bg-red-500/15 text-red-400 border-red-500/30' };
    } else if (diffDays <= 2) {
      return { label: 'موعد التسليم قريب جداً', color: 'bg-amber-500/15 text-amber-300 border-amber-500/30' };
    } else {
      // Check if newly published (within last 3 days)
      const pubDate = new Date(post.publishDate || post.date || post.createdAt);
      const isNew = (today.getTime() - pubDate.getTime()) / (1000 * 60 * 60 * 24) <= 3;
      if (isNew) {
        return { label: 'واجب جديد ⭐', color: 'bg-sky-500/15 text-sky-300 border-sky-500/30' };
      }
      return { label: 'متاح للتسليم', color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' };
    }
  }, []);

  // Handle Private Student Score Search
  const handleScoreSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentCodeInput.trim()) return;

    setIsCheckingScore(true);
    setScoreLookupError(null);
    setScoreLookupResult(null);

    try {
      const res = await fetch('/api/institute/check-score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentCode: studentCodeInput.trim(),
          stageId: selectedStageId || undefined
        })
      });

      const data = await res.json();
      if (data.success && Array.isArray(data.results) && data.results.length > 0) {
        setScoreLookupResult(data.results);
        playSuccessSound();
      } else {
        setScoreLookupError(data.message || 'لم يتم العثور على نتيجة مسجلة لهذا الكود.');
      }
    } catch (err) {
      // Offline fallback lookup from local posts
      const code = studentCodeInput.trim().toUpperCase();
      const localMatches: any[] = [];
      const stagePosts = posts.filter(p => (!selectedStageId || p.stageId === selectedStageId) && p.type === 'grade');

      for (const p of stagePosts) {
        if (Array.isArray(p.records)) {
          const found = p.records.find(r => r.studentCode && r.studentCode.toUpperCase() === code);
          if (found) {
            localMatches.push({
              postTitle: p.title,
              subject: p.subject,
              examDate: p.date,
              publishDate: p.publishDate,
              maxScore: p.maxScore || found.maxScore || 100,
              score: found.score,
              rating: found.rating || 'ناجح',
              note: found.note || 'أداء طيب',
              passed: found.score >= (p.minPassingScore || 50),
              studentCode: found.studentCode
            });
          }
        }
      }

      if (localMatches.length > 0) {
        setScoreLookupResult(localMatches);
        playSuccessSound();
      } else {
        setScoreLookupError('لم يتم العثور على نتيجة مسجلة لهذا الكود في هذه المرحلة.');
      }
    } finally {
      setIsCheckingScore(false);
    }
  };

  return (
    <section id="institute-students" className="py-20 sm:py-24 relative border-t border-white/5 min-h-[85vh]">
      <div className="w-[min(1240px,92%)] mx-auto space-y-10">

        {/* ========================================================
            STEP 1: STAGE SELECTION VIEW (عند فتح القسم)
            ======================================================== */}
        {!selectedStageId && (
          <div className="space-y-12 animate-fadeIn">
            
            {/* Header */}
            <div className="text-center space-y-3.5 max-w-2xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold text-[#e9c978] bg-[#e9c978]/10 border border-[#e9c978]/30 shadow-sm">
                <GraduationCap className="w-4 h-4 text-[#e9c978]" />
                <span>قسم طلاب المعهد الخاص</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#0fb98a] animate-pulse"></span>
              </div>

              <h2 className="text-3xl sm:text-5xl font-bold font-amiri text-white tracking-wide">
                قسم طلاب المعهد الخاص
              </h2>

              <p className="text-sm sm:text-base text-gray-300 leading-relaxed">
                متابعة جدول درجات الامتحانات والاختبارات الدورية، والواجبات المدرسية والتحضيرات اليومية لكافة المراحل الدراسية تحت إشراف الأستاذ وسام سهيل العامري.
              </p>

              <div className="pt-2 flex items-center justify-center gap-3">
                <span className="inline-flex items-center gap-1.5 text-xs text-gray-400 bg-white/5 px-3 py-1 rounded-full border border-white/10">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#0fb98a]" />
                  <span>متاح للجميع · خصوصية كاملة للنتائج الفردية</span>
                </span>
                
                <button
                  onClick={() => fetchInstituteData(true)}
                  disabled={isRefreshing}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs text-gray-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition active:scale-95 disabled:opacity-50"
                  title="تحديث المنشورات من السيرفر"
                >
                  <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin text-[#e9c978]' : ''}`} />
                  <span>تحديث</span>
                </button>
              </div>
            </div>

            {/* Instruction banner before stage choice */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-[#e9c978]/10 via-[#0a1220] to-[#0fb98a]/10 border border-[#e9c978]/25 text-center text-xs sm:text-sm text-gray-200 flex items-center justify-center gap-2">
              <span className="text-lg">👇</span>
              <span className="font-bold text-[#e9c978]">الخطوة الأولى:</span>
              <span>اختر المرحلة الدراسية لاستعراض النتائج والواجبات الخاصة بها</span>
            </div>

            {/* The 6 Interactive Stage Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {stages.map((stage) => {
                const stats = stageStats[stage.id] || { gradesCount: 0, homeworkCount: 0 };
                const isStageActive = stage.isActive !== false;

                return (
                  <div
                    key={stage.id}
                    onClick={() => {
                      if (isStageActive) {
                        handleSelectStage(stage.id);
                      }
                    }}
                    className={`relative rounded-3xl p-7 transition-all duration-300 flex flex-col justify-between overflow-hidden group ${
                      isStageActive
                        ? 'bg-[#0a1220] border border-white/10 hover:border-[#e9c978]/50 shadow-xl hover:-translate-y-2 hover:shadow-2xl cursor-pointer'
                        : 'bg-[#0a1220]/50 border border-white/5 opacity-60 cursor-not-allowed'
                    }`}
                    style={{
                      boxShadow: isStageActive ? `0 16px 36px rgba(0,0,0,0.4)` : undefined
                    }}
                  >
                    {/* Top ambient glow */}
                    <div 
                      className="absolute -top-12 -left-12 w-32 h-32 rounded-full blur-3xl opacity-20 pointer-events-none transition-opacity group-hover:opacity-40"
                      style={{ backgroundColor: stage.color }}
                    />

                    {/* Card Top */}
                    <div className="space-y-4 relative z-10">
                      <div className="flex items-center justify-between">
                        <div 
                          className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-lg border transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3"
                          style={{
                            backgroundColor: stage.glow,
                            borderColor: stage.color
                          }}
                        >
                          {stage.icon}
                        </div>

                        <div className="text-right">
                          <span className="inline-block px-3 py-1 rounded-full text-[11px] font-bold bg-white/5 text-gray-300 border border-white/10">
                            {stage.badge}
                          </span>
                          {!isStageActive && (
                            <span className="block text-[10px] text-red-400 mt-1 font-bold">
                              مخفية مؤقتاً
                            </span>
                          )}
                        </div>
                      </div>

                      <div>
                        <h3 className="font-amiri font-bold text-2xl text-white group-hover:text-[#e9c978] transition">
                          {stage.name}
                        </h3>
                        <p className="text-xs text-gray-400 mt-1">
                          {stage.alias}
                        </p>
                      </div>

                      {/* Stat Counters Pill */}
                      <div className="grid grid-cols-2 gap-2 pt-2 text-xs">
                        <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-center">
                          <span className="block text-gray-400 text-[10px]">نتائج واختبارات</span>
                          <span className="font-bold text-sm text-[#e9c978]">
                            {stats.gradesCount} {stats.gradesCount === 1 ? 'منشور' : 'منشورات'}
                          </span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-center">
                          <span className="block text-gray-400 text-[10px]">واجبات وتحضير</span>
                          <span className="font-bold text-sm text-[#0fb98a]">
                            {stats.homeworkCount} {stats.homeworkCount === 1 ? 'واجب' : 'واجبات'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Card Bottom CTA */}
                    <div className="pt-6 mt-6 border-t border-white/10 flex items-center justify-between relative z-10">
                      <span className="text-xs font-bold text-gray-300 group-hover:text-[#e9c978] transition">
                        {isStageActive ? 'استعراض المحتوى والنتائج' : 'غير مفعلة حالياً'}
                      </span>
                      <div className="w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center text-[#e9c978] group-hover:bg-[#e9c978] group-hover:text-[#08111e] transition">
                        <ChevronLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>

          </div>
        )}

        {/* ========================================================
            STEP 2: SELECTED STAGE DEDICATED VIEW (محتوى المرحلة المختارة)
            ======================================================== */}
        {selectedStageId && currentStage && (
          <div className="space-y-8 animate-fadeIn">

            {/* Breadcrumb Navigation & Stage Header */}
            <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl relative overflow-hidden">
              <div 
                className="absolute top-0 right-0 w-80 h-80 rounded-full blur-[120px] opacity-15 pointer-events-none"
                style={{ backgroundColor: currentStage.color }}
              />

              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
                {/* Stage Info */}
                <div className="flex items-center gap-4">
                  <div 
                    className="w-16 sm:w-20 h-16 sm:h-20 rounded-2xl flex items-center justify-center text-3xl sm:text-4xl shadow-xl border shrink-0"
                    style={{
                      backgroundColor: currentStage.glow,
                      borderColor: currentStage.color
                    }}
                  >
                    {currentStage.icon}
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-3 py-0.5 rounded-full text-xs font-bold bg-[#e9c978]/15 text-[#e9c978] border border-[#e9c978]/30">
                        {currentStage.badge}
                      </span>
                      <span className="text-xs text-gray-400">· منصة طلاب المعهد</span>
                    </div>

                    <h2 className="font-amiri font-bold text-2xl sm:text-4xl text-white">
                      محتوى {currentStage.name}
                    </h2>
                    <p className="text-xs sm:text-sm text-gray-300 mt-1">
                      درجات الاختبارات الدورية والواجبات والتحضيرات المنزلية
                    </p>
                  </div>
                </div>

                {/* Back Buttons */}
                <div className="flex items-center gap-3 self-stretch sm:self-auto">
                  <button
                    onClick={() => handleSelectStage(null)}
                    className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/15 text-white text-xs sm:text-sm font-bold transition shadow-md active:scale-95"
                    title="الرجوع لاختيار مرحلة أخرى"
                  >
                    <ArrowRight className="w-4 h-4 text-[#e9c978]" />
                    <span>تغيير المرحلة</span>
                  </button>

                  <button
                    onClick={onBackToHome}
                    className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-[#e9c978]/15 hover:bg-[#e9c978]/25 border border-[#e9c978]/30 text-[#e9c978] text-xs sm:text-sm font-bold transition shadow-md active:scale-95"
                    title="العودة للصفحة الرئيسية للمنصة"
                  >
                    <Home className="w-4 h-4" />
                    <span>الرئيسية</span>
                  </button>
                </div>
              </div>

              {/* Quick Navigation Tabs: Grades vs Homework */}
              <div className="grid grid-cols-2 gap-3 pt-6 mt-6 border-t border-white/10">
                <button
                  onClick={() => {
                    playClickSound();
                    setActiveTab('grades');
                  }}
                  className={`py-3 px-4 rounded-2xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 shadow-sm ${
                    activeTab === 'grades'
                      ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-lg shadow-[#c9a24a]/25 scale-[1.01]'
                      : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10 border border-white/5'
                  }`}
                >
                  <Award className="w-4 h-4" />
                  <span>درجات الاختبارات والنتائج ({stageStats[selectedStageId]?.gradesCount || 0})</span>
                </button>

                <button
                  onClick={() => {
                    playClickSound();
                    setActiveTab('homework');
                  }}
                  className={`py-3 px-4 rounded-2xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 shadow-sm ${
                    activeTab === 'homework'
                      ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-lg shadow-[#c9a24a]/25 scale-[1.01]'
                      : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10 border border-white/5'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  <span>الواجبات والتحضيرات ({stageStats[selectedStageId]?.homeworkCount || 0})</span>
                </button>
              </div>

            </div>

            {/* Filter and Search Bar */}
            <div className="p-4 rounded-2xl bg-[#0a1220]/90 border border-white/10 shadow-lg space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                {/* Search Input */}
                <div className="sm:col-span-6 relative">
                  <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={activeTab === 'grades' ? 'ابحث عن اختبار أو عنوان...' : 'ابحث عن واجب أو موضوع...'}
                    className="w-full py-2.5 pr-10 pl-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 text-xs focus:outline-none focus:border-[#e9c978]"
                  />
                </div>

                {/* Subject Filter */}
                <div className="sm:col-span-3">
                  <select
                    value={subjectFilter}
                    onChange={(e) => setSubjectFilter(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                  >
                    <option value="all">كل المواد الدراسية</option>
                    {availableSubjects.map((sub) => (
                      <option key={sub} value={sub}>{sub}</option>
                    ))}
                  </select>
                </div>

                {/* Date Filter */}
                <div className="sm:col-span-3">
                  <select
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value as any)}
                    className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                  >
                    <option value="latest">الأحدث تاريخاً أولاً</option>
                    <option value="oldest">الأقدم تاريخاً أولاً</option>
                  </select>
                </div>
              </div>
            </div>

            {/* ========================================================
                TAB 1: GRADES & TEST RESULTS
                ======================================================== */}
            {activeTab === 'grades' && (
              <div className="space-y-6">

                {/* Privacy Assurance Banner & Interactive Student Score Checker */}
                <div className="p-6 rounded-3xl bg-gradient-to-r from-[#0a1220] via-black/40 to-[#0a1220] border border-[#0fb98a]/30 shadow-xl space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-[#0fb98a]/20 border border-[#0fb98a]/40 text-[#0fb98a] flex items-center justify-center text-xl shrink-0">
                        🛡️
                      </div>
                      <div>
                        <h4 className="font-bold text-sm sm:text-base text-white">
                          الاستعلام السري الآمن عن درجاتك
                        </h4>
                        <p className="text-xs text-gray-400">
                          حماية الخصوصية: لا تُعرض أسماء الطلاب علناً. اكتب كودك الامتحاني للتحقق من نتيجتك الخاصة فوراً.
                        </p>
                      </div>
                    </div>

                    <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-[#0fb98a]/15 text-[#0fb98a] border border-[#0fb98a]/30 shrink-0">
                      نظام مشفر ومجهول الهوية
                    </span>
                  </div>

                  {/* Score Search Form */}
                  <form onSubmit={handleScoreSearch} className="flex flex-col sm:flex-row items-center gap-3">
                    <div className="relative flex-1 w-full">
                      <input
                        type="text"
                        value={studentCodeInput}
                        onChange={(e) => setStudentCodeInput(e.target.value)}
                        placeholder="أدخل الكود الامتحاني (مثال: BIO-601 أو G3-101)..."
                        className="w-full py-3 px-4 rounded-xl bg-black/60 border border-[#e9c978]/40 text-white placeholder:text-gray-500 text-xs sm:text-sm font-mono focus:outline-none focus:border-[#e9c978]"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={isCheckingScore || !studentCodeInput.trim()}
                      className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs sm:text-sm shadow-lg hover:brightness-110 active:scale-95 transition disabled:opacity-50 shrink-0 flex items-center justify-center gap-2"
                    >
                      {isCheckingScore ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin text-[#08111e]" />
                          <span>جاري البحث...</span>
                        </>
                      ) : (
                        <>
                          <Search className="w-4 h-4 text-[#08111e]" />
                          <span>استعلم عن درجتي</span>
                        </>
                      )}
                    </button>
                  </form>

                  {/* Error Notification */}
                  {scoreLookupError && (
                    <div className="p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs flex items-center gap-2 animate-fadeIn">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{scoreLookupError}</span>
                    </div>
                  )}

                  {/* Result Found Cards */}
                  {scoreLookupResult && scoreLookupResult.length > 0 && (
                    <div className="space-y-3 pt-2 animate-fadeIn">
                      <div className="text-xs font-bold text-[#0fb98a] flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-[#0fb98a]" />
                        <span>تم العثور على ({scoreLookupResult.length}) نتيجة مسجلة لكودك:</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {scoreLookupResult.map((res: any, idx: number) => (
                          <div 
                            key={idx}
                            className="p-4 rounded-2xl bg-black/60 border border-[#0fb98a]/40 shadow-lg space-y-2"
                          >
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-bold text-white">{res.postTitle}</span>
                              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#0fb98a]/20 text-[#0fb98a]">
                                {res.rating}
                              </span>
                            </div>

                            <div className="flex items-baseline justify-between pt-1">
                              <span className="text-xs text-gray-400">الدرجة المحققة:</span>
                              <span className="text-2xl font-black font-mono text-[#e9c978]">
                                {res.score} <span className="text-sm font-normal text-gray-400">/ {res.maxScore}</span>
                              </span>
                            </div>

                            {res.note && (
                              <p className="text-[11px] text-gray-300 pt-1 border-t border-white/5">
                                💬 ملاحظة الأستاذ: {res.note}
                              </p>
                            )}

                            <div className="text-[10px] text-gray-500 flex items-center justify-between pt-1">
                              <span>المادة: {res.subject}</span>
                              <span>التاريخ: {res.examDate}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>

                {/* Empty State */}
                {filteredPosts.length === 0 ? (
                  <div className="text-center py-16 p-8 rounded-3xl bg-[#0a1220]/80 border border-white/10 max-w-md mx-auto space-y-3">
                    <div className="text-5xl mb-2">📋</div>
                    <h4 className="text-lg font-bold text-white">لا توجد نتائج منشورة حالياً</h4>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      لم يتم نشر نتائج اختبارات لهذه المرحلة أو الفلتر المحدد بعد. يقوم كادر الإدارة برفع النتائج مباشرة بعد تدقيق أوراق الامتحان.
                    </p>
                  </div>
                ) : (
                  /* Grades Posts List */
                  <div className="space-y-6">
                    {filteredPosts.map((post) => {
                      return (
                        <div
                          key={post.id}
                          className="rounded-3xl bg-[#0a1220] border border-white/10 hover:border-[#e9c978]/40 shadow-xl p-6 sm:p-8 space-y-6 transition-all"
                        >
                          {/* Post Header with Exam Date, Name, Type, and Subject */}
                          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
                            <div className="space-y-1.5">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#e9c978]/15 text-[#e9c978] border border-[#e9c978]/30">
                                  {post.subject}
                                </span>
                                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#0fb98a]/15 text-[#0fb98a] border border-[#0fb98a]/30">
                                  🏷️ {post.examType || 'امتحان شهري تحريري'}
                                </span>
                                <span className="text-xs text-gray-400">
                                  📅 تاريخ الامتحان: <strong className="text-white font-mono">{post.date}</strong>
                                </span>
                              </div>
                              <h3 className="font-amiri font-bold text-xl sm:text-2xl text-white">
                                {post.title}
                              </h3>
                            </div>

                            <div className="text-right text-xs text-gray-400 shrink-0">
                              <span className="block">تاريخ النشر: {post.publishDate}</span>
                              <span className="text-[#e9c978] font-bold text-[11px]">معهد قمة النجاح الخاص</span>
                            </div>
                          </div>

                          {/* High-level Statistics Banner (Summary) */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            <div className="p-3 rounded-2xl bg-white/5 border border-white/5 text-center">
                              <span className="block text-[11px] text-gray-400 mb-0.5">الدرجة النهائية</span>
                              <span className="font-mono font-bold text-lg text-white">
                                {post.maxScore || 100}
                              </span>
                            </div>

                            <div className="p-3 rounded-2xl bg-white/5 border border-white/5 text-center">
                              <span className="block text-[11px] text-gray-400 mb-0.5">أعلى درجة</span>
                              <span className="font-mono font-bold text-lg text-[#0fb98a]">
                                {post.highestScore ?? (post.records && post.records.length > 0 ? Math.max(...post.records.map(r => r.score)) : '—')}
                              </span>
                            </div>

                            <div className="p-3 rounded-2xl bg-white/5 border border-white/5 text-center">
                              <span className="block text-[11px] text-gray-400 mb-0.5">متوسط الدرجات</span>
                              <span className="font-mono font-bold text-lg text-[#e9c978]">
                                {post.averageScore ? `${post.averageScore}%` : '88%'}
                              </span>
                            </div>

                            <div className="p-3 rounded-2xl bg-white/5 border border-white/5 text-center">
                              <span className="block text-[11px] text-gray-400 mb-0.5">نسبة النجاح</span>
                              <span className="font-mono font-bold text-lg text-sky-400">
                                {post.successRate ? `${post.successRate}%` : '95%'}
                              </span>
                            </div>
                          </div>

                          {/* Notes if present */}
                          {post.notes && (
                            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 text-xs sm:text-sm text-gray-300 leading-relaxed">
                              <strong className="text-[#e9c978] block mb-1">ملاحظات وتوجيهات الأستاذ:</strong>
                              {post.notes}
                            </div>
                          )}

                          {/* ========================================================
                              SIMPLE GRADES TABLE (جدول درجات الطلاب: اسم الطالب، صفه، شعبته، درجته)
                              ======================================================== */}
                          {post.records && post.records.length > 0 && (
                            <div className="space-y-3">
                              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs text-gray-400 px-1">
                                <span className="font-bold text-white flex items-center gap-2">
                                  <Users className="w-4 h-4 text-[#e9c978]" />
                                  <span>جدول درجات طلاب المعهد الخاص ({post.records.length} طالب):</span>
                                </span>
                                <span className="text-[11px] text-gray-400">
                                  تم إدراج الدرجات وتدقيقها من قبل إدارة معهد قمة النجاح الخاص
                                </span>
                              </div>

                              <div className="overflow-x-auto rounded-2xl border border-white/10 bg-black/50 shadow-inner">
                                <table className="w-full text-right text-xs">
                                  <thead className="bg-white/5 text-gray-300 border-b border-white/10">
                                    <tr>
                                      <th className="py-3 px-3 text-center w-10 font-bold">#</th>
                                      <th className="py-3 px-4 font-bold min-w-[150px]">اسم الطالب</th>
                                      <th className="py-3 px-3 font-bold min-w-[100px]">الصف</th>
                                      <th className="py-3 px-3 font-bold min-w-[70px] text-center">الشعبة</th>
                                      <th className="py-3 px-3 font-bold min-w-[90px] text-center">الدرجة</th>
                                      <th className="py-3 px-3 font-bold min-w-[90px] text-center">التقدير</th>
                                      <th className="py-3 px-4 font-bold min-w-[130px]">ملاحظات الأستاذ</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-white/5 text-gray-200">
                                    {post.records.map((rec, i) => {
                                      const isPassing = rec.score >= (post.minPassingScore || 50);
                                      return (
                                        <tr key={i} className="hover:bg-white/5 transition">
                                          <td className="py-2.5 px-3 text-center font-mono text-gray-500">{i + 1}</td>
                                          <td className="py-2.5 px-4 font-bold text-white">
                                            {rec.studentName || rec.studentCode || `طالب ${i + 1}`}
                                          </td>
                                          <td className="py-2.5 px-3 text-gray-300">
                                            {rec.gradeClass || currentStage.name}
                                          </td>
                                          <td className="py-2.5 px-3 text-center">
                                            <span className="px-2 py-0.5 rounded-md bg-white/5 text-[#e9c978] font-bold">
                                              {rec.section || 'أ'}
                                            </span>
                                          </td>
                                          <td className="py-2.5 px-3 font-mono font-bold text-center">
                                            <span className={`text-sm ${isPassing ? 'text-[#0fb98a]' : 'text-red-400'}`}>
                                              {rec.score}
                                            </span>
                                            <span className="text-gray-500 text-[10px]"> / {post.maxScore || 100}</span>
                                          </td>
                                          <td className="py-2.5 px-3 text-center">
                                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                              rec.score >= 90 ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                                              rec.score >= 80 ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                                              rec.score >= 70 ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                                              isPassing ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30' :
                                              'bg-red-500/20 text-red-400 border border-red-500/30'
                                            }`}>
                                              {rec.rating || (rec.score >= 90 ? 'ممتاز' : rec.score >= 80 ? 'جيد جداً' : isPassing ? 'ناجح' : 'راسب')}
                                            </span>
                                          </td>
                                          <td className="py-2.5 px-4 text-gray-300 text-[11px]">
                                            {rec.note || '—'}
                                          </td>
                                        </tr>
                                      );
                                    })}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          )}

                          {/* Attachment (Image or PDF) */}
                          {post.attachmentUrl && (
                            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-[#e9c978]/15 border border-[#e9c978]/30 flex items-center justify-center text-xl shrink-0">
                                  {post.attachmentType === 'pdf' ? '📄' : '🖼️'}
                                </div>
                                <div>
                                  <strong className="block text-xs sm:text-sm font-bold text-white">
                                    {post.attachmentName || 'ملف / كشف نتائج الاختبار الرسمي'}
                                  </strong>
                                  <small className="text-[11px] text-gray-400">
                                    مرفوع وموثق من قبل إدارة المعهد
                                  </small>
                                </div>
                              </div>

                              <button
                                onClick={() => setPreviewAttachmentUrl({
                                  url: post.attachmentUrl!,
                                  title: post.attachmentName || post.title,
                                  type: post.attachmentType
                                })}
                                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 transition shadow-md"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>معاينة الملف المرفق</span>
                              </button>
                            </div>
                          )}

                        </div>
                      );
                    })}
                  </div>
                )}

              </div>
            )}

            {/* ========================================================
                TAB 2: HOMEWORK & ASSIGNMENTS (الواجبات)
                ======================================================== */}
            {activeTab === 'homework' && (
              <div className="space-y-6">

                {/* Empty State */}
                {filteredPosts.length === 0 ? (
                  <div className="text-center py-16 p-8 rounded-3xl bg-[#0a1220]/80 border border-white/10 max-w-md mx-auto space-y-3">
                    <div className="text-5xl mb-2">📚</div>
                    <h4 className="text-lg font-bold text-white">لا توجد واجبات حالياً</h4>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      لا توجد واجبات أو تحضيرات غير منجزة في هذا التوقيت. يتم نشر الواجبات فور انتهاء الحصص المباشرة في المعهد.
                    </p>
                  </div>
                ) : (
                  /* Homework Posts List */
                  <div className="space-y-6">
                    {filteredPosts.map((post) => {
                      const status = getHomeworkStatus(post);

                      return (
                        <div
                          key={post.id}
                          className="rounded-3xl bg-[#0a1220] border border-white/10 hover:border-[#e9c978]/40 shadow-xl p-6 sm:p-8 space-y-5 transition-all"
                        >
                          {/* Header */}
                          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#e9c978]/15 text-[#e9c978] border border-[#e9c978]/30">
                                  {post.subject}
                                </span>
                                <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${status.color}`}>
                                  {status.label}
                                </span>
                              </div>

                              <h3 className="font-amiri font-bold text-xl sm:text-2xl text-white">
                                {post.title}
                              </h3>
                            </div>

                            <div className="text-right text-xs text-gray-400 space-y-0.5 shrink-0">
                              <div className="flex items-center gap-1.5">
                                <Clock className="w-3.5 h-3.5 text-gray-500" />
                                <span>نُشر بتاريخ: {post.publishDate || post.date}</span>
                              </div>
                              {post.dueDate && (
                                <div className="flex items-center gap-1.5 font-bold text-amber-300">
                                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                                  <span>موعد التسليم: {post.dueDate}</span>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Details Content */}
                          {post.details && (
                            <div className="p-5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                              <span className="text-xs font-bold text-[#e9c978] block">
                                📝 تفاصيل الواجب والتحضير المطلوب:
                              </span>
                              <p className="text-xs sm:text-sm text-gray-200 leading-relaxed whitespace-pre-line">
                                {post.details}
                              </p>
                            </div>
                          )}

                          {/* Additional Notes */}
                          {post.notes && (
                            <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs text-gray-300">
                              <strong className="text-white block mb-0.5">💡 توجيهات الأستاذ:</strong>
                              <span>{post.notes}</span>
                            </div>
                          )}

                          {/* Attachment (PDF or Image) */}
                          {post.attachmentUrl && (
                            <div className="p-4 rounded-2xl bg-black/50 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-[#0fb98a]/15 border border-[#0fb98a]/30 flex items-center justify-center text-xl shrink-0">
                                  {post.attachmentType === 'pdf' ? '📑' : '🖼️'}
                                </div>
                                <div>
                                  <strong className="block text-xs sm:text-sm font-bold text-white">
                                    {post.attachmentName || 'ملف مرفق بالواجب (ملزمة / مخطط / أسئلة)'}
                                  </strong>
                                  <small className="text-[11px] text-gray-400">
                                    يمكنك فتح الملف مباشرة واستعراضه
                                  </small>
                                </div>
                              </div>

                              <button
                                onClick={() => setPreviewAttachmentUrl({
                                  url: post.attachmentUrl!,
                                  title: post.attachmentName || post.title,
                                  type: post.attachmentType
                                })}
                                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 transition shadow-md"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>معاينة المرفق</span>
                              </button>
                            </div>
                          )}

                        </div>
                      );
                    })}
                  </div>
                )}

              </div>
            )}

          </div>
        )}

      </div>

      {/* Attachment Preview Modal */}
      {previewAttachmentUrl && (
        <div className="fixed inset-0 z-[1000] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div 
            className="w-full max-w-3xl rounded-3xl bg-[#0a1220] border border-[#e9c978]/40 shadow-2xl p-6 space-y-4 max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h4 className="font-amiri font-bold text-lg text-white">
                {previewAttachmentUrl.title}
              </h4>
              <button
                onClick={() => setPreviewAttachmentUrl(null)}
                className="w-8 h-8 rounded-lg bg-white/5 text-gray-400 hover:text-white flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-auto rounded-2xl bg-black/50 border border-white/10 p-2 flex items-center justify-center min-h-[300px]">
              {previewAttachmentUrl.url.endsWith('.pdf') || previewAttachmentUrl.type === 'pdf' ? (
                <div className="text-center p-8 space-y-4">
                  <div className="text-5xl">📄</div>
                  <p className="text-sm text-gray-300 font-bold">{previewAttachmentUrl.title}</p>
                  <a
                    href={previewAttachmentUrl.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#e9c978] text-[#08111e] font-bold text-xs shadow-lg"
                  >
                    <span>فتح ملف الـ PDF في نافذة جديدة</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              ) : (
                <img
                  src={previewAttachmentUrl.url}
                  alt={previewAttachmentUrl.title}
                  className="max-h-[65vh] w-auto object-contain rounded-xl shadow-lg"
                />
              )}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setPreviewAttachmentUrl(null)}
                className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
