import React from 'react';

export const AboutTeacher: React.FC = () => {
  return (
    <section id="about" className="py-24 relative border-t border-white/5">
      <div className="w-[min(1240px,92%)] mx-auto space-y-12">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full text-xs font-bold text-[#e9c978] bg-[#e9c978]/10 border border-[#e9c978]/25 shadow-sm">
            <span>عن الأستاذ</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold font-amiri text-white">
            خبرة تُترجم إلى درجات
          </h2>
        </div>

        {/* About Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Teacher Profile Card */}
          <div className="lg:col-span-5 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 p-8 sm:p-10 shadow-2xl text-center flex flex-col items-center">
            
            <div className="w-44 h-44 rounded-full border-4 border-[#04080f] shadow-2xl bg-gradient-to-tr from-[#e9c978] to-[#c9a24a] overflow-hidden relative mb-6 flex items-center justify-center">
              <span className="text-6xl absolute z-0">👨‍🏫</span>
              <img 
                src="https://res.cloudinary.com/zijsnksq/image/upload/f_auto,q_auto/68566" 
                alt="الأستاذ وسام سهيل العامري"
                className="w-full h-full object-cover relative z-10"
                onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
              />
            </div>

            <h3 className="font-amiri font-bold text-2xl sm:text-3xl text-white mb-1">
              الأستاذ وسام سهيل العامري
            </h3>

            <div className="text-[#e9c978] font-bold text-sm sm:text-base mb-4">
              مدرّس الأحياء — جميع المراحل
            </div>

            <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-sm">
              متخصص في تدريس علم الأحياء، معتمد على استراتيجيات التعلم النشط والوسائل التوضيحية الحديثة، مع متابعة مستمرة واختبارات دورية تقيس التقدم الفعلي.
            </p>

          </div>

          {/* Features List */}
          <div className="lg:col-span-7 space-y-5">
            
            <div className="p-6 rounded-2xl bg-[#0a1220] border border-white/10 hover:border-[#e9c978]/40 shadow-xl transition-all duration-300 flex items-start gap-5 group">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#e9c978]/20 to-[#0fb98a]/15 border border-[#e9c978]/30 text-2xl flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                🎓
              </div>
              <div>
                <h4 className="font-bold text-lg sm:text-xl text-white mb-1 group-hover:text-[#e9c978] transition">
                  شرح مبسّط
                </h4>
                <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                  كل فصل مقسّم إلى أفكار صغيرة مترابطة تسهّل الحفظ والفهم.
                </p>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-[#0a1220] border border-white/10 hover:border-[#e9c978]/40 shadow-xl transition-all duration-300 flex items-start gap-5 group">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#e9c978]/20 to-[#0fb98a]/15 border border-[#e9c978]/30 text-2xl flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                📄
              </div>
              <div>
                <h4 className="font-bold text-lg sm:text-xl text-white mb-1 group-hover:text-[#e9c978] transition">
                  ملازم وزارية
                </h4>
                <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                  ملازم محدّثة تشمل الأسئلة الوزارية مع حلول نموذجية.
                </p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
