import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Send,
  X,
  Bot,
  User,
  RotateCcw,
  Copy,
  Check,
  ExternalLink,
  Play,
  AlertCircle,
  HelpCircle,
  BookOpen,
  MessageSquare,
  LifeBuoy,
  ChevronDown,
  CheckCircle2,
  PhoneCall,
  Flame,
  ShieldCheck,
  RefreshCw,
  Info
} from 'lucide-react';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenLecture?: (lectureId: number) => void;
  onNavigateToScreen?: (screenId: string) => void;
  currentLectureTitle?: string;
  currentLectureId?: number;
  studentGrade?: string;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  status?: 'sending' | 'delivered' | 'error';
  actions?: Array<{
    type: 'open_lecture' | 'open_contact' | 'create_ticket' | 'open_url';
    title: string;
    targetId?: string | number;
    url?: string;
    icon?: string;
  }>;
  suggestedQuestions?: string[];
  diagnosis?: {
    category: string;
    severity: string;
    suggestTicket: boolean;
  };
  isRealGemini?: boolean;
  modelUsed?: string;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  isOpen,
  onClose,
  onOpenLecture,
  onNavigateToScreen,
  currentLectureTitle,
  currentLectureId,
  studentGrade = 'g6'
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('biolab_ai_student_messages');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });

  const [inputQuery, setInputQuery] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [welcomeMessage, setWelcomeMessage] = useState('مرحباً بك يا بطل! أنا المساعد الذكي لمنصة مختبر الأحياء للأستاذ وسام سهيل العامري. كيف أستطيع مساعدتك اليوم في المادة العلمية أو المحاضرات أو الاشتراك؟');

  // Support ticket popup inside assistant
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);
  const [ticketDescription, setTicketDescription] = useState('');
  const [ticketCategory, setTicketCategory] = useState<'video_playback' | 'vip_code' | 'subscription' | 'curriculum' | 'other'>('video_playback');
  const [ticketLectureName, setTicketLectureName] = useState(currentLectureTitle || '');
  const [ticketSubmitting, setTicketSubmitting] = useState(false);
  const [ticketSuccessMsg, setTicketSuccessMsg] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Quick Starter Prompts
  const starterPrompts = [
    { title: 'طريقة الاشتراك بالمحاضرات المدفوعة', query: 'كيف أشترك بالمحاضرات المدفوعة وما هي الخطوات والأسعار؟' },
    { title: 'مشكلة في تشغيل محاضرة', query: 'المحاضرة لا تفتح معي وعندي مشكلة في تشغيل الفيديو، ماذا أفعل؟' },
    { title: 'الفرق بين الخلية النباتية والحيوانية', query: 'ما هي الفروقات الوزارية المعتمدة بين الخلية النباتية والخلية الحيوانية؟' },
    { title: 'التواصل المباشر مع الأستاذ', query: 'أريد رقم وتفاصيل التواصل المباشر مع الأستاذ وسام سهيل العامري' },
    { title: 'أسعار باقات المراحل الدراسية', query: 'كم هي أسعار باقات ومحاضرات الأحياء المسجلة في المنصة؟' }
  ];

  // Fetch welcome message & assistant configuration
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const res = await fetch('/api/ai/config');
        if (res.ok) {
          const data = await res.json();
          if (data.success && data.config?.welcomeMessage) {
            setWelcomeMessage(data.config.welcomeMessage);
          }
        }
      } catch (e) {}
    };
    fetchConfig();
  }, []);

  // Sync messages to local storage
  useEffect(() => {
    try {
      localStorage.setItem('biolab_ai_student_messages', JSON.stringify(messages));
    } catch (e) {}
  }, [messages]);

  // Scroll to bottom on new message
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    }
  }, [messages, isOpen, isGenerating]);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 200);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputQuery).trim();
    if (!query || isGenerating) return;

    playClickSound();
    setInputQuery('');

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }),
      status: 'delivered'
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsGenerating(true);

    try {
      // Build conversation history for API (last 6 messages)
      const history = messages.slice(-6).map((m) => ({
        role: m.sender === 'user' ? 'user' : 'assistant',
        content: m.text
      }));

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query,
          history,
          studentGrade,
          currentLectureContext: currentLectureTitle
            ? {
                id: currentLectureId,
                title: currentLectureTitle
              }
            : undefined
        })
      });

      const data = await res.json();

      if (data.success && data.answer) {
        const mappedActions = (data.actionButtons && data.actionButtons.length > 0)
          ? data.actionButtons.map((b: any) => ({
              type: b.action === 'contact_whatsapp' ? 'open_contact' : b.action === 'create_ticket' ? 'create_ticket' : 'open_lecture',
              title: b.label,
              targetId: b.targetId,
              url: b.url
            }))
          : (data.actions || []);

        const assistantMsg: ChatMessage = {
          id: `ast-${Date.now()}`,
          sender: 'assistant',
          text: data.answer,
          timestamp: new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }),
          actions: mappedActions,
          suggestedQuestions: data.suggestedQuestions || [],
          diagnosis: data.diagnosis,
          isRealGemini: Boolean(data.diagnostic?.isRealGemini),
          modelUsed: data.diagnostic?.modelUsed
        };
        setMessages((prev) => [...prev, assistantMsg]);
        playSuccessSound();
      } else {
        const errorMsg: ChatMessage = {
          id: `ast-err-${Date.now()}`,
          sender: 'assistant',
          text: data.error || 'عذراً يا بطل، واجهت مشكلة مؤقتة في معالجة إجابتك. يرجى إعادة المحاولة أو التواصل مع إدارة المنصة.',
          timestamp: new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' })
        };
        setMessages((prev) => [...prev, errorMsg]);
      }
    } catch (err) {
      const offlineMsg: ChatMessage = {
        id: `ast-offline-${Date.now()}`,
        sender: 'assistant',
        text: 'تعذر الاتصال بخادم المنصة حالياً. يرجى التحقق من اتصالك بالإنترنت، وسأكون جاهزاً للإجابة عن أسئلتك فور عودة الاتصال.',
        timestamp: new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, offlineMsg]);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    playClickSound();
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    if (messages.length === 0) return;
    if (window.confirm('هل تود بدء محادثة جديدة ومسح السجل السابق؟')) {
      playClickSound();
      setMessages([]);
      try {
        localStorage.removeItem('biolab_ai_student_messages');
      } catch (e) {}
    }
  };

  const handleActionClick = (action: any) => {
    playClickSound();
    if (action.type === 'open_lecture' && action.targetId) {
      if (onOpenLecture) {
        onOpenLecture(Number(action.targetId));
        onClose();
      }
    } else if (action.type === 'open_contact') {
      if (action.url) {
        window.open(action.url, '_blank');
      } else if (onNavigateToScreen) {
        onNavigateToScreen('contact');
        onClose();
      }
    } else if (action.type === 'create_ticket') {
      setTicketDescription(`مشكلة واجهتني: ${action.title}`);
      setIsTicketModalOpen(true);
    } else if (action.type === 'open_url' && action.url) {
      window.open(action.url, '_blank');
    }
  };

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketDescription.trim()) return;

    setTicketSubmitting(true);
    try {
      const res = await fetch('/api/ai/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: 'طالب في المنصة',
          studentGrade: studentGrade,
          issueCategory: ticketCategory,
          lectureTitle: ticketLectureName,
          description: ticketDescription.trim()
        })
      });

      const data = await res.json();
      if (data.success) {
        setTicketSuccessMsg('تم إرسال البلاغ بنجاح إلى الأستاذ وسام سهيل العامري وفريق الدعم الفني! رقم البلاغ: ' + (data.ticket?.id || ''));
        playSuccessSound();
        setTicketDescription('');
        setTimeout(() => {
          setIsTicketModalOpen(false);
          setTicketSuccessMsg(null);
        }, 3000);
      }
    } catch (e) {
      alert('حدث خطأ أثناء إرسال البلاغ، يرجى المحاولة لاحقاً');
    } finally {
      setTicketSubmitting(false);
    }
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-[950] flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl h-[92vh] max-h-[780px] flex flex-col rounded-3xl bg-[#070e1b] border border-[#e9c978]/35 shadow-2xl overflow-hidden text-[#eaf0f8]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 bg-gradient-to-r from-[#0b172d] via-[#0d1d3a] to-[#070e1b] border-b border-[#e9c978]/25 select-none">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#c9a24a] via-[#e9c978] to-[#0fb98a] flex items-center justify-center shadow-lg shadow-[#c9a24a]/25 text-xl">
                🧬
              </div>
              <span className="absolute -bottom-1 -left-1 w-3.5 h-3.5 rounded-full bg-[#0fb98a] border-2 border-[#070e1b] animate-pulse" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-base sm:text-lg flex items-center gap-1.5 font-amiri">
                  المساعد الذكي لمنصة الأحياء
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-[#0fb98a]/20 text-[#0fb98a] border border-[#0fb98a]/30 font-bold">
                  متصل وموجّه رسمياً
                </span>
              </div>
              <p className="text-[11px] text-gray-300">
                إشراف الأستاذ وسام سهيل العامري · إجابات معتمدة وأسعار حقيقية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsTicketModalOpen(true)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-[#e9c978] transition border border-white/10 text-xs flex items-center gap-1"
              title="إرسال بلاغ دعم فني"
            >
              <LifeBuoy className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">بلاغ دعم</span>
            </button>

            <button
              onClick={handleClearChat}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-red-400 transition border border-white/10"
              title="بدء محادثة جديدة"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition border border-white/10"
              title="إغلاق النافذة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Current Lecture Context Banner (if student is browsing a lecture) */}
        {currentLectureTitle && (
          <div className="px-4 py-2 bg-[#e9c978]/10 border-b border-[#e9c978]/20 flex items-center justify-between text-xs text-[#e9c978]">
            <div className="flex items-center gap-1.5 truncate">
              <BookOpen className="w-3.5 h-3.5 shrink-0" />
              <span className="text-gray-300">أنت تشاهد حالياً:</span>
              <strong className="truncate text-white">{currentLectureTitle}</strong>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-[#e9c978]">
              سياق متصل
            </span>
          </div>
        )}

        {/* Chat Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Default Welcome Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-white/5 to-white/[0.02] border border-[#e9c978]/20 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center shrink-0 text-lg">
                ✨
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-white text-sm">
                  أهلاً بك في المساعد الذكي لمادة الأحياء!
                </h4>
                <p className="text-xs text-gray-200 leading-relaxed whitespace-pre-line">
                  {welcomeMessage}
                </p>
              </div>
            </div>

            {/* Quick Starters */}
            {messages.length === 0 && (
              <div className="pt-2 border-t border-white/10">
                <div className="text-[11px] font-bold text-[#e9c978] mb-2 flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5" />
                  أسئلة متكررة وشائعة يمكنك تجربتها بضغطة واحدة:
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {starterPrompts.map((p, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSendMessage(p.query)}
                      className="text-xs py-1.5 px-3 rounded-xl bg-white/5 hover:bg-[#e9c978]/15 border border-white/10 hover:border-[#e9c978]/40 text-gray-200 hover:text-white transition text-right flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3 h-3 text-[#e9c978] shrink-0" />
                      <span>{p.title}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Messages Flow */}
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-start' : 'items-end'} space-y-1.5`}
              >
                <div className="flex items-end gap-2 max-w-[88%] sm:max-w-[82%]">
                  {!isUser && (
                    <div className="w-8 h-8 rounded-xl bg-[#e9c978]/20 border border-[#e9c978]/40 text-[#e9c978] flex items-center justify-center text-sm shrink-0 mb-1">
                      🧬
                    </div>
                  )}

                  <div
                    className={`rounded-2xl p-3.5 sm:p-4 text-xs sm:text-sm leading-relaxed shadow-md ${
                      isUser
                        ? 'bg-gradient-to-r from-[#c9a24a] to-[#e9c978] text-[#070e1b] font-medium rounded-br-sm'
                        : 'bg-[#0f1d35] border border-white/10 text-gray-100 rounded-bl-sm'
                    }`}
                  >
                    <div className="whitespace-pre-line leading-relaxed">
                      {msg.text}
                    </div>

                    {/* Google Gemini Model Badge */}
                    {!isUser && msg.isRealGemini && (
                      <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center gap-1.5 text-[10px] sm:text-[11px] text-sky-300 font-semibold">
                        <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0 animate-pulse" />
                        <span>إجابة حقيقية مدعومة بنموذج Google Gemini ({msg.modelUsed || 'gemini-3.1-flash-lite'})</span>
                      </div>
                    )}

                    {/* Interactive Action Buttons */}
                    {msg.actions && msg.actions.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-white/10 flex flex-wrap gap-2">
                        {msg.actions.map((act, aIdx) => (
                          <button
                            key={aIdx}
                            onClick={() => handleActionClick(act)}
                            className="py-1.5 px-3 rounded-xl bg-[#e9c978] hover:bg-[#dfbe6d] text-[#070e1b] font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition"
                          >
                            {act.type === 'open_lecture' && <Play className="w-3.5 h-3.5 fill-current" />}
                            {act.type === 'open_contact' && <PhoneCall className="w-3.5 h-3.5" />}
                            {act.type === 'create_ticket' && <LifeBuoy className="w-3.5 h-3.5" />}
                            {act.type === 'open_url' && <ExternalLink className="w-3.5 h-3.5" />}
                            <span>{act.title}</span>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Suggested Follow-ups */}
                    {msg.suggestedQuestions && msg.suggestedQuestions.length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-white/5 flex flex-wrap gap-1">
                        {msg.suggestedQuestions.map((sq, sqIdx) => (
                          <button
                            key={sqIdx}
                            onClick={() => handleSendMessage(sq)}
                            className="text-[11px] py-1 px-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-emerald-300 border border-emerald-500/20 transition"
                          >
                            ↳ {sq}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {isUser && (
                    <div className="w-8 h-8 rounded-xl bg-white/10 border border-white/15 text-gray-200 flex items-center justify-center text-sm shrink-0 mb-1">
                      👤
                    </div>
                  )}
                </div>

                {/* Sub info & Copy action */}
                <div
                  className={`flex items-center gap-2 px-1 text-[10px] text-gray-400 ${
                    isUser ? 'mr-10' : 'ml-10'
                  }`}
                >
                  <span>{msg.timestamp}</span>
                  {!isUser && (
                    <button
                      onClick={() => handleCopyText(msg.text, msg.id)}
                      className="hover:text-white transition flex items-center gap-1"
                      title="نسخ الإجابة"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-[#0fb98a]" />
                          <span className="text-[#0fb98a]">تم النسخ</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>نسخ</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {/* Loading Indicator */}
          {isGenerating && (
            <div className="flex items-end gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#e9c978]/20 border border-[#e9c978]/40 text-[#e9c978] flex items-center justify-center text-sm shrink-0 animate-pulse">
                🧬
              </div>
              <div className="p-3.5 rounded-2xl bg-[#0f1d35] border border-white/10 text-xs text-gray-300 flex items-center gap-2">
                <div className="flex gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#e9c978] animate-bounce" />
                  <span className="w-2 h-2 rounded-full bg-[#0fb98a] animate-bounce [animation-delay:0.2s]" />
                  <span className="w-2 h-2 rounded-full bg-[#3fa9f5] animate-bounce [animation-delay:0.4s]" />
                </div>
                <span>المساعد يراجع المنهج وقواعد الإدارة لتوليد الإجابة الدقيقة...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-[#0a1426] border-t border-white/10">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <div className="relative flex-1">
              <textarea
                ref={inputRef}
                value={inputQuery}
                onChange={(e) => setInputQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                rows={1}
                placeholder="اكتب سؤالك هنا (عن المنهج، أسعار المحاضرات، كود التفعيل، حل مشكلة...)"
                className="w-full py-3 px-4 rounded-2xl bg-white/5 border border-white/15 focus:border-[#e9c978] focus:ring-1 focus:ring-[#e9c978] text-white text-xs sm:text-sm placeholder-gray-400 resize-none outline-none transition"
              />
            </div>

            <button
              type="submit"
              disabled={!inputQuery.trim() || isGenerating}
              className={`p-3 sm:px-5 sm:py-3 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition ${
                inputQuery.trim() && !isGenerating
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#070e1b] shadow-lg shadow-[#c9a24a]/25 hover:brightness-110 active:scale-95'
                  : 'bg-white/10 text-gray-500 cursor-not-allowed'
              }`}
            >
              <Send className="w-4 h-4 rotate-180" />
              <span className="hidden sm:inline">إرسال</span>
            </button>
          </form>

          <div className="mt-2 flex items-center justify-between text-[10px] text-gray-400 px-1">
            <span>مدعوم بقاعدة بيانات منصة الأستاذ وسام سهيل ومحرك الذكاء الاصطناعي السحابي</span>
            <span>يدعم الضغط على Enter للإرسال</span>
          </div>
        </div>
      </div>

      {/* Support Ticket Modal Inside Assistant */}
      {isTicketModalOpen && (
        <div
          className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
          onClick={() => setIsTicketModalOpen(false)}
        >
          <div
            className="relative w-full max-w-lg rounded-3xl bg-[#0a1426] border border-[#0fb98a]/40 shadow-2xl p-6 text-[#eaf0f8]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2">
                <LifeBuoy className="w-5 h-5 text-[#0fb98a]" />
                <h4 className="font-bold text-white text-base">تسجيل بلاغ مشكلة أو دعم فني</h4>
              </div>
              <button
                onClick={() => setIsTicketModalOpen(false)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {ticketSuccessMsg ? (
              <div className="p-4 rounded-2xl bg-[#0fb98a]/15 border border-[#0fb98a]/30 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-[#0fb98a] mx-auto" />
                <p className="text-sm font-bold text-[#0fb98a]">{ticketSuccessMsg}</p>
                <p className="text-xs text-gray-300">يتم إغلاق النافذة تلقائياً...</p>
              </div>
            ) : (
              <form onSubmit={handleSubmitTicket} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-gray-300 font-semibold mb-1">نوع المشكلة:</label>
                  <select
                    value={ticketCategory}
                    onChange={(e: any) => setTicketCategory(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                  >
                    <option value="video_playback">مشكلة في تشغيل الفيديو / المحاضرة</option>
                    <option value="vip_code">مشكلة في كود التفعيل والاشتراك</option>
                    <option value="subscription">استفسار عن أسعار وتفعيل الباقات</option>
                    <option value="curriculum">سؤال علمي يحتاج تدقيق الأستاذ</option>
                    <option value="other">أخرى</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-300 font-semibold mb-1">اسم المحاضرة (إن وجدت):</label>
                  <input
                    type="text"
                    value={ticketLectureName}
                    onChange={(e) => setTicketLectureName(e.target.value)}
                    placeholder="مثال: محاضرة الانقسام الخيطي - الفصل الأول"
                    className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-gray-300 font-semibold mb-1">تفاصيل المشكلة التي تواجهها:</label>
                  <textarea
                    rows={4}
                    required
                    value={ticketDescription}
                    onChange={(e) => setTicketDescription(e.target.value)}
                    placeholder="اشرح المشكلة باختصار، وما الرسالة التي تظهر لك..."
                    className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none resize-none"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsTicketModalOpen(false)}
                    className="py-2 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    disabled={ticketSubmitting || !ticketDescription.trim()}
                    className="py-2 px-5 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#2dd4bf] text-[#070e1b] font-bold shadow-md hover:brightness-110 disabled:opacity-50"
                  >
                    {ticketSubmitting ? 'جارٍ الإرسال...' : 'إرسال البلاغ للإدارة'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
