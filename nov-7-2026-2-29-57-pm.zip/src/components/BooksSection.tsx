import React, { useState, useEffect, useMemo } from 'react';
import { 
  BookOpen, 
  Search, 
  Download, 
  Eye, 
  ExternalLink, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Sparkles, 
  RefreshCw, 
  Layers, 
  GraduationCap, 
  Filter,
  ArrowRight,
  BookMarked,
  FileCheck2,
  Share2
} from 'lucide-react';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { subscribeToCurriculumBooks } from '../services/firebase';
import { downloadFileDirectly } from '../utils/fileDownloader';

export interface CurriculumBook {
  id: string;
  stage: 'primary' | 'intermediate' | 'preparatory';
  stageName?: string;
  gradeKey: string;
  grade: string;
  contentType?: 'book' | 'booklet' | 'summary' | 'exam_bank';
  contentTypeName?: string;
  subject?: string;
  icon?: string;
  title: string;
  edition?: string;
  author?: string;
  specialization?: string;
  academicLevel?: string;
  pages?: number;
  fileSize?: string;
  year?: number;
  pdfUrl?: string | null;
  fileUrl?: string | null;
  officialSource?: string;
  isAvailable?: boolean;
  verificationStatus?: 'verified' | 'pending' | 'unavailable';
  verificationNotes?: string;
  coverUrl?: string;
  description?: string;
  status?: string;
  driveUrl?: string;
  driveId?: string;
}

interface BooksSectionProps {
  onBackToHome?: () => void;
  onOpenPdfModal: (book: {
    id: string;
    title: string;
    author: string;
    pdfUrl: string;
    coverUrl?: string;
    pages?: number;
    fileSize?: string;
    edition?: string;
  }) => void;
}

const STAGE_FILTERS = [
  { key: 'all', label: 'كافة المراحل', emoji: '🌟' },
  { key: 'm1', label: 'الأول المتوسط', emoji: '📘' },
  { key: 'm2', label: 'الثاني المتوسط', emoji: '🦠' },
  { key: 'm3', label: 'الثالث المتوسط', emoji: '🧬' },
  { key: 'g4', label: 'الرابع العلمي', emoji: '🔬' },
  { key: 'g5', label: 'الخامس العلمي', emoji: '🌿' },
  { key: 'g6', label: 'السادس العلمي (الوزاري)', emoji: '👑' },
  { key: 'intermediate', label: 'المرحلة المتوسطة', emoji: '🏫' },
  { key: 'preparatory', label: 'المرحلة الإعدادية', emoji: '🏛️' },
];

const TYPE_FILTERS = [
  { key: 'all', label: 'كافة المحتويات' },
  { key: 'book', label: 'كتب منهجية وزارية' },
  { key: 'booklet', label: 'ملازم ذهبية' },
  { key: 'summary', label: 'ملخصات مركزة' },
  { key: 'exam_bank', label: 'بنك الأسئلة الوزارية' },
];

export const BooksSection: React.FC<BooksSectionProps> = ({
  onBackToHome,
  onOpenPdfModal
}) => {
  const [books, setBooks] = useState<CurriculumBook[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeStage, setActiveStage] = useState<string>('all');
  const [activeType, setActiveType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  // Helper to read deleted book blacklist from localStorage
  const getDeletedBookIds = (): string[] => {
    try {
      return JSON.parse(localStorage.getItem('biolab_deleted_book_ids') || '[]');
    } catch (e) {
      return [];
    }
  };

  // Fetch initial books from API
  const fetchBooks = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/books/curriculum');
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.books)) {
          const deletedIds = getDeletedBookIds();
          setBooks(data.books.filter((b: CurriculumBook) => !deletedIds.includes(b.id)));
        }
      }
    } catch (e) {
      console.warn('Could not load curriculum books from server API:', e);
    } finally {
      setIsLoading(false);
    }
  };

  // Real-time Firestore sync & instant deletion event listener
  useEffect(() => {
    fetchBooks();

    const unsubscribe = subscribeToCurriculumBooks((cloudBooks) => {
      const deletedIds = getDeletedBookIds();
      if (Array.isArray(cloudBooks)) {
        // Direct authoritative Firestore subscription: updates additions, edits, and deletions in real time!
        const activeBooks = cloudBooks.filter((cb) => !deletedIds.includes(cb.id));
        setBooks(activeBooks);
        setIsLoading(false);
      }
    });

    const handleBookDeleted = (e: any) => {
      const deletedId = e.detail?.id;
      if (deletedId) {
        setBooks((prev) => prev.filter((b) => b.id !== deletedId));
      }
    };
    window.addEventListener('biolab_curriculum_book_deleted', handleBookDeleted);

    return () => {
      unsubscribe();
      window.removeEventListener('biolab_curriculum_book_deleted', handleBookDeleted);
    };
  }, []);

  // Filtered and memoized books
  const filteredBooks = useMemo(() => {
    return books.filter((book) => {
      // Stage filter
      if (activeStage !== 'all') {
        if (activeStage === 'intermediate' && book.stage !== 'intermediate') return false;
        if (activeStage === 'preparatory' && book.stage !== 'preparatory') return false;
        if (['m1', 'm2', 'm3', 'g4', 'g5', 'g6'].includes(activeStage) && book.gradeKey !== activeStage) {
          return false;
        }
      }

      // Type filter
      if (activeType !== 'all') {
        const type = book.contentType || 'book';
        if (type !== activeType) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = (book.title || '').toLowerCase().includes(q);
        const matchGrade = (book.grade || '').toLowerCase().includes(q);
        const matchAuthor = (book.author || '').toLowerCase().includes(q);
        const matchDesc = (book.description || '').toLowerCase().includes(q);
        if (!matchTitle && !matchGrade && !matchAuthor && !matchDesc) return false;
      }

      return true;
    });
  }, [books, activeStage, activeType, searchQuery]);

  // Handle direct file download with native Android DownloadManager and scoped storage support
  const handleDownload = async (book: CurriculumBook) => {
    playClickSound();
    setDownloadingId(book.id);

    try {
      const pdfTarget = book.pdfUrl || book.fileUrl || `/api/download?bookId=${book.id}`;
      await downloadFileDirectly({
        url: pdfTarget,
        title: book.title,
        fileType: 'pdf',
        onSuccess: () => {
          playSuccessSound();
        },
        onError: (err) => {
          console.warn('Download notice:', err);
        }
      });
    } catch (e) {
      console.error('Download error:', e);
    } finally {
      setTimeout(() => setDownloadingId(null), 1200);
    }
  };

  // Open book in app
  const handleReadBook = (book: CurriculumBook) => {
    playClickSound();
    const pdfPath = book.pdfUrl || book.fileUrl || `/api/download?bookId=${book.id}`;
    
    onOpenPdfModal({
      id: book.id,
      title: book.title,
      author: book.author || 'وزارة التربية العراقية / إعداد أ. وسام سهيل العامري',
      pdfUrl: pdfPath,
      coverUrl: book.coverUrl,
      pages: book.pages,
      fileSize: book.fileSize,
      edition: book.edition
    });
  };

  return (
    <div className="w-[min(1280px,94%)] mx-auto py-8 sm:py-12 space-y-8 animate-fadeIn">
      
      {/* Hero Banner */}
      <div className="relative rounded-3xl overflow-hidden p-6 sm:p-10 border border-[#e9c978]/30 bg-gradient-to-br from-[#08111e] via-[#04080f] to-[#0a1829] shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#e9c978]/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#0fb98a]/10 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl text-right">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-black bg-[#e9c978]/15 text-[#e9c978] border border-[#e9c978]/30 shadow-sm">
              <Sparkles className="w-3.5 h-3.5" />
              <span>مستودع المناهج والملازم الذهبية المعتمدة</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-amiri font-bold text-white leading-tight">
              الكتب المنهجية والملازم الذهبية
            </h1>

            <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
              تصفح وقراءة وتنزيل الكتب الوزارية الرسمية والملازم الشاملة والملخصات المركزة وبنوك الأسئلة الوزارية من الأول المتوسط وحتى السادس العلمي، مع دعم القراءة المباشرة داخل التطبيق والتنزيل السريع.
            </p>

            <div className="flex items-center gap-4 pt-2 text-xs text-gray-400 flex-wrap">
              <span className="flex items-center gap-1.5 text-[#0fb98a]">
                <CheckCircle2 className="w-4 h-4" />
                <span>طبعات وزارة التربية المعتمدة 2024-2025</span>
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5 text-[#e9c978]">
                <BookMarked className="w-4 h-4" />
                <span>قراءة فورية بدون إنترنت بعد التنزيل</span>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 self-stretch md:self-auto justify-end">
            <button
              onClick={fetchBooks}
              disabled={isLoading}
              className="py-3 px-4 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-200 border border-white/10 text-xs font-bold transition flex items-center gap-2"
              title="تحديث قائمة الكتب"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-[#0fb98a]' : ''}`} />
              <span>تحديث</span>
            </button>
          </div>
        </div>
      </div>

      {/* Stage Selector Tabs */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
          {STAGE_FILTERS.map((stage) => {
            const isActive = activeStage === stage.key;
            return (
              <button
                key={stage.key}
                onClick={() => {
                  playClickSound();
                  setActiveStage(stage.key);
                }}
                className={`py-2.5 px-4 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all flex items-center gap-2 select-none ${
                  isActive
                    ? 'bg-gradient-to-r from-[#e9c978] via-[#ffd56b] to-[#c9a24a] text-[#08111e] shadow-lg shadow-[#c9a24a]/25 scale-102 font-black'
                    : 'bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10'
                }`}
              >
                <span>{stage.emoji}</span>
                <span>{stage.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Type Selector & Search Bar */}
        <div className="flex flex-col sm:flex-row items-center gap-3 p-3 rounded-2xl bg-white/5 border border-white/10">
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto no-scrollbar">
            {TYPE_FILTERS.map((type) => {
              const isActive = activeType === type.key;
              return (
                <button
                  key={type.key}
                  onClick={() => {
                    playClickSound();
                    setActiveType(type.key);
                  }}
                  className={`py-1.5 px-3 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                    isActive
                      ? 'bg-[#0fb98a] text-black shadow font-black'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {type.label}
                </button>
              );
            })}
          </div>

          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث باسم الكتاب، الملزمة، المرحلة، أو الفصل..."
              className="w-full py-2 pr-10 pl-4 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#0fb98a]"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white text-xs"
              >
                مسح
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Books Grid */}
      {isLoading ? (
        <div className="py-24 text-center space-y-4">
          <RefreshCw className="w-10 h-10 text-[#0fb98a] animate-spin mx-auto" />
          <p className="text-sm text-gray-400 font-bold">جاري تحميل مستودع الكتب والملازم المعتمدة...</p>
        </div>
      ) : filteredBooks.length === 0 ? (
        <div className="p-16 text-center rounded-3xl bg-white/5 border border-white/10 space-y-4 max-w-lg mx-auto">
          <div className="w-16 h-16 rounded-3xl bg-white/5 text-gray-400 flex items-center justify-center text-3xl mx-auto">
            📖
          </div>
          <h3 className="font-bold text-lg text-white">لا توجد كتب مطابقة لبحثك</h3>
          <p className="text-xs text-gray-400 leading-relaxed">
            لم نتمكن من العثور على أي كتب أو ملازم مطابقة للمرحلة والفلترة الحالية. جرب اختيار مرحلة أخرى أو مسح شريط البحث.
          </p>
          <button
            onClick={() => {
              setActiveStage('all');
              setActiveType('all');
              setSearchQuery('');
            }}
            className="py-2 px-4 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-black font-bold text-xs"
          >
            عرض كافة الكتب والملازم
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filteredBooks.map((book) => {
            const hasPdf = Boolean(book.pdfUrl || book.fileUrl);
            const isDownloading = downloadingId === book.id;

            let typeBadge = { label: 'كتاب منهجي', color: 'bg-blue-500/15 text-blue-300 border-blue-500/30' };
            if (book.contentType === 'booklet') {
              typeBadge = { label: 'ملزمة ذهبية', color: 'bg-[#e9c978]/15 text-[#e9c978] border-[#e9c978]/30' };
            } else if (book.contentType === 'summary') {
              typeBadge = { label: 'ملخص مركز', color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' };
            } else if (book.contentType === 'exam_bank') {
              typeBadge = { label: 'أسئلة وزارية', color: 'bg-purple-500/15 text-purple-300 border-purple-500/30' };
            }

            return (
              <div
                key={book.id}
                className="group p-4 rounded-3xl bg-gradient-to-b from-[#091220]/90 to-[#04080f]/95 hover:from-[#0c182c] hover:to-[#060c16] border border-white/10 hover:border-[#e9c978]/40 shadow-xl hover:shadow-2xl transition-all duration-300 flex flex-col justify-between gap-4 relative overflow-hidden"
              >
                {/* Book Cover + Top Badges */}
                <div className="space-y-3">
                  <div className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-black/60 border border-white/10 shadow-inner group-hover:scale-[1.02] transition-transform duration-300">
                    <img
                      src={book.coverUrl || 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=400&q=80'}
                      alt={book.title}
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=400&q=80';
                      }}
                    />

                    {/* Gradient overlay on hover */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity pointer-events-none"></div>

                    {/* Top Type Badge */}
                    <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5 flex-wrap">
                      <span className={`text-[10px] px-2.5 py-0.5 rounded-full border font-bold shadow backdrop-blur-md ${typeBadge.color}`}>
                        {typeBadge.label}
                      </span>
                    </div>

                    {/* Top Grade Badge */}
                    <div className="absolute top-2.5 left-2.5">
                      <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-black/75 text-white border border-white/20 font-bold backdrop-blur-md">
                        {book.grade}
                      </span>
                    </div>

                    {/* Quick Flip View Action on hover */}
                    {hasPdf && (
                      <button
                        onClick={() => handleReadBook(book)}
                        className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-[#0fb98a] text-black flex items-center justify-center opacity-0 group-hover:opacity-100 scale-75 group-hover:scale-100 transition-all shadow-xl hover:brightness-110 active:scale-95"
                        title="قراءة الكتاب الآن"
                      >
                        <Eye className="w-5 h-5 stroke-[2.5]" />
                      </button>
                    )}

                    {/* Bottom Metadata bar on image */}
                    <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-[11px] text-white/90 px-2 py-1 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 font-mono">
                      <span>📄 {book.pages || '—'} صفحة</span>
                      <span className="text-[#0fb98a] font-bold">{book.fileSize || 'PDF'}</span>
                    </div>
                  </div>

                  {/* Title & Author */}
                  <div className="space-y-1 text-right">
                    <h3 className="font-amiri font-bold text-base sm:text-lg text-white group-hover:text-[#e9c978] transition-colors line-clamp-2 leading-snug">
                      {book.title}
                    </h3>
                    <p className="text-xs text-gray-400 line-clamp-1 font-medium">
                      {book.author || 'إعداد الأستاذ وسام سهيل العامري'}
                    </p>
                    {book.edition && (
                      <p className="text-[11px] text-[#e9c978] font-bold">
                        {book.edition}
                      </p>
                    )}
                  </div>
                </div>

                {/* Primary & Secondary Action Buttons */}
                <div className="space-y-2 pt-2 border-t border-white/10">
                  {/* Read in app button */}
                  {hasPdf ? (
                    <button
                      type="button"
                      onClick={() => handleReadBook(book)}
                      className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#059669] text-black font-black text-xs shadow-md shadow-[#0fb98a]/20 hover:brightness-110 active:scale-98 transition flex items-center justify-center gap-2"
                    >
                      <Eye className="w-4 h-4 stroke-[2.5]" />
                      <span>قراءة الكتاب داخل التطبيق</span>
                    </button>
                  ) : (
                    <div className="py-2 px-3 rounded-xl bg-white/5 border border-white/10 text-gray-400 text-[11px] text-center font-bold italic">
                      سيتم توفير النسخة السحابية قريباً
                    </div>
                  )}

                  {/* Download button */}
                  {hasPdf && (
                    <button
                      type="button"
                      onClick={() => handleDownload(book)}
                      disabled={isDownloading}
                      className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 hover:text-white border border-white/10 text-xs font-bold transition flex items-center justify-center gap-1.5"
                    >
                      {isDownloading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#e9c978]" />
                          <span>جاري التنزيل...</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-3.5 h-3.5 text-[#e9c978]" />
                          <span>تنزيل PDF مباشر</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
