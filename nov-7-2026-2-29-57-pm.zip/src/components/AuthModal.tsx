import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Lock, 
  User, 
  GraduationCap, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  Loader2, 
  ArrowRight,
  Sparkles,
  School
} from 'lucide-react';
import { 
  loginWithEmail, 
  registerWithEmail, 
  loginWithGoogle, 
  sendPasswordReset, 
  translateAuthError, 
  syncAuthUserWithProfile,
  isUserAdmin
} from '../services/firebase';
import { UserProfile } from './StudentOnboardingModal';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { isInstalledApp, hasLinkedGoogleAccount, setGoogleAccountLinked } from '../utils/appEnvironment';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (profile: UserProfile, isAdmin: boolean) => void;
  initialTab?: 'login' | 'register' | 'forgot';
}

const SCHOOL_GRADES = [
  { id: 'g1', name: 'الأول المتوسط', stage: 'متوسطة' },
  { id: 'g2', name: 'الثاني المتوسط', stage: 'متوسطة' },
  { id: 'g3', name: 'الثالث المتوسط', stage: 'متوسطة' },
  { id: 'g4', name: 'الرابع العلمي', stage: 'إعدادية' },
  { id: 'g5', name: 'الخامس العلمي', stage: 'إعدادية' },
  { id: 'g6', name: 'السادس العلمي (وزاري)', stage: 'إعدادية' }
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAuthSuccess,
  initialTab = 'login'
}) => {
  const [tab, setTab] = useState<'login' | 'register' | 'forgot'>(initialTab);

  // Form Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [grade, setGrade] = useState('g6');
  const [showPassword, setShowPassword] = useState(false);

  // UI state
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const resetMessages = () => {
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  const handleTabChange = (newTab: 'login' | 'register' | 'forgot') => {
    playClickSound();
    resetMessages();
    setTab(newTab);
  };

  // 1. Email & Password Sign In
  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!email.trim() || !password) {
      setErrorMessage('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    setIsLoading(true);
    try {
      playClickSound();
      const cred = await loginWithEmail(email, password);
      const isAdmin = isUserAdmin(cred.user);
      const profile = await syncAuthUserWithProfile(cred.user);

      playSuccessSound();
      setSuccessMessage(isAdmin ? 'مرحباً بك يا أستاذ وسام في لوحة الإدارة ⭐' : `أهلاً بك مجدداً يا ${profile.name}! 🧬`);
      setTimeout(() => {
        onAuthSuccess(profile, isAdmin);
        onClose();
      }, 700);
    } catch (err: any) {
      console.error('Login error:', err);
      setErrorMessage(translateAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Email & Password Registration
  const handleEmailRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!displayName.trim()) {
      setErrorMessage('يرجى إدخال اسم الطالب الثلاثي');
      return;
    }
    if (!email.trim()) {
      setErrorMessage('يرجى إدخال البريد الإلكتروني');
      return;
    }
    if (password.length < 6) {
      setErrorMessage('يجب أن تتكون كلمة المرور من 6 خانات على الأقل');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('كلمتا المرور غير متطابقتين');
      return;
    }

    setIsLoading(true);
    try {
      playClickSound();
      const cred = await registerWithEmail(email, password, displayName);
      const isAdmin = isUserAdmin(cred.user);
      const profile = await syncAuthUserWithProfile(cred.user, {
        name: displayName.trim(),
        grade,
        track: 'school'
      });

      playSuccessSound();
      setSuccessMessage('تم إنشاء حساب الطالب وتوثيقه بنجاح في السحابة 🎉');
      setTimeout(() => {
        onAuthSuccess(profile, isAdmin);
        onClose();
      }, 800);
    } catch (err: any) {
      console.error('Register error:', err);
      setErrorMessage(translateAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Google Sign-In (Dedicated for students & users, never opening admin panel)
  const handleGoogleSignIn = async () => {
    resetMessages();
    setIsGoogleLoading(true);
    try {
      playClickSound();
      const cred = await loginWithGoogle();
      const profile = await syncAuthUserWithProfile(cred.user, {
        grade: 'g6',
        track: 'school'
      });

      playSuccessSound();
      setSuccessMessage(`أهلاً بك يا ${profile.name}! تم تسجيل الدخول بنجاح بحساب Google 🎉`);
      setTimeout(() => {
        onAuthSuccess(profile, false); // Always false for admin status
        onClose();
      }, 700);
    } catch (err: any) {
      console.error('Google sign in error:', err);
      setErrorMessage(translateAuthError(err));
    } finally {
      setIsGoogleLoading(false);
    }
  };

  // 4. Password Reset
  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!email.trim()) {
      setErrorMessage('يرجى إدخال بريدك الإلكتروني المسجل');
      return;
    }

    setIsLoading(true);
    try {
      playClickSound();
      await sendPasswordReset(email);
      playSuccessSound();
      setSuccessMessage('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني بنجاح! 📨');
    } catch (err: any) {
      console.error('Password reset error:', err);
      setErrorMessage(translateAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[1050] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="relative w-full max-w-md rounded-3xl bg-[#0a1220] border border-[#e9c978]/35 shadow-2xl p-6 sm:p-7 text-[#eaf0f8] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        dir="rtl"
      >
        {/* Glow ambient background accent */}
        <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full bg-[#e9c978]/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 rounded-full bg-[#0fb98a]/10 blur-3xl pointer-events-none" />

        {/* Modal Close Button */}
        <button
          onClick={() => {
            playClickSound();
            onClose();
          }}
          className="absolute top-4 left-4 w-8 h-8 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 flex items-center justify-center transition"
          title="إغلاق"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#c9a24a] to-[#e9c978] text-[#04080f] flex items-center justify-center text-xl mx-auto mb-2.5 shadow-lg shadow-[#c9a24a]/25 border border-[#e9c978]/40">
            🧬
          </div>
          <h2 className="font-amiri font-bold text-2xl text-[#e9c978]">
            {tab === 'login' && 'تسجيل الدخول'}
            {tab === 'register' && 'إنشاء حساب طالب جديد'}
            {tab === 'forgot' && 'استعادة كلمة المرور'}
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            منصة الأستاذ وسام سهيل العامري · مختبر الأحياء
          </p>
        </div>

        {/* Tab Navigation Buttons */}
        {tab !== 'forgot' && (
          <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-black/40 border border-white/10 mb-4">
            <button
              type="button"
              onClick={() => handleTabChange('login')}
              className={`py-2 text-xs font-bold rounded-xl transition-all ${
                tab === 'login'
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              تسجيل الدخول
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('register')}
              className={`py-2 text-xs font-bold rounded-xl transition-all ${
                tab === 'register'
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              حساب جديد
            </button>
          </div>
        )}

        {/* Status Alerts */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs flex items-start gap-2 text-right">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
            <span className="flex-1 leading-relaxed">{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 rounded-xl bg-[#0fb98a]/15 border border-[#0fb98a]/30 text-[#0fb98a] text-xs flex items-start gap-2 text-right">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-[#0fb98a] mt-0.5" />
            <span className="flex-1 leading-relaxed">{successMessage}</span>
          </div>
        )}

        {/* 1) Universal Google Sign-In for all users and students */}
        {tab !== 'forgot' && (
          <div className="mb-4 space-y-3">
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isGoogleLoading || isLoading}
              className="w-full py-3 px-4 rounded-2xl bg-white hover:bg-gray-100 text-gray-800 font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 transition shadow-lg hover:shadow-xl active:scale-[0.98] disabled:opacity-50 border border-gray-200"
            >
              {isGoogleLoading ? (
                <Loader2 className="w-4 h-4 animate-spin text-gray-700" />
              ) : (
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
              )}
              <span>{isGoogleLoading ? 'جاري الاتصال بحساب Google...' : 'المتابعة السريعة باستخدام حساب Google'}</span>
            </button>

            <div className="relative flex items-center justify-center my-3.5">
              <div className="border-t border-white/10 w-full" />
              <span className="bg-[#0a1220] px-3 text-[11px] text-gray-500 absolute font-medium">
                أو المتابعة بالبريد وكلمة المرور
              </span>
            </div>
          </div>
        )}

        {/* 2) Sign In Form */}
        {tab === 'login' && (
          <form onSubmit={handleEmailLogin} className="space-y-3">
            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1 text-right">
                البريد الإلكتروني
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  required
                  autoComplete="email"
                  className="w-full py-2.5 px-3.5 pl-10 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-xs sm:text-sm text-right"
                />
                <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-3 pointer-events-none" />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <button
                  type="button"
                  onClick={() => handleTabChange('forgot')}
                  className="text-[11px] text-[#e9c978] hover:underline"
                >
                  نسيت كلمة المرور؟
                </button>
                <label className="text-[11px] font-bold text-gray-400">
                  كلمة المرور
                </label>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  autoComplete="current-password"
                  className="w-full py-2.5 px-3.5 pl-10 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-xs sm:text-sm text-right"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-3 text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || isGoogleLoading}
              className="w-full mt-2 py-3 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-xs sm:text-sm shadow-lg shadow-[#c9a24a]/25 hover:brightness-110 active:scale-98 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin text-[#08111e]" />
              ) : (
                <ShieldCheck className="w-4 h-4 text-[#08111e]" />
              )}
              <span>تسجيل الدخول</span>
            </button>
          </form>
        )}

        {/* 3) Sign Up Form */}
        {tab === 'register' && (
          <form onSubmit={handleEmailRegister} className="space-y-2.5">
            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1 text-right">
                اسم الطالب الثلاثي
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="محمد أحمد علي"
                  required
                  className="w-full py-2 px-3.5 pl-10 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-xs text-right"
                />
                <User className="w-4 h-4 text-gray-400 absolute left-3 top-2.5 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1 text-right">
                الصف الدراسي
              </label>
              <div className="relative">
                <select
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  className="w-full py-2 px-3.5 rounded-xl bg-black/50 border border-white/10 text-white focus:outline-none focus:border-[#e9c978] text-xs text-right appearance-none"
                >
                  {SCHOOL_GRADES.map((g) => (
                    <option key={g.id} value={g.id} className="bg-[#0a1220] text-white">
                      {g.name}
                    </option>
                  ))}
                </select>
                <GraduationCap className="w-4 h-4 text-gray-400 absolute left-3 top-2.5 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1 text-right">
                البريد الإلكتروني
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@example.com"
                  required
                  autoComplete="email"
                  className="w-full py-2 px-3.5 pl-10 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-xs text-right"
                />
                <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-2.5 pointer-events-none" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-gray-400 mb-1 text-right">
                  كلمة المرور
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="6 أحرف+"
                  required
                  autoComplete="new-password"
                  className="w-full py-2 px-3 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-xs text-right"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-400 mb-1 text-right">
                  تأكيد الكلمة
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="تطابق الكلمة"
                  required
                  autoComplete="new-password"
                  className="w-full py-2 px-3 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-xs text-right"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || isGoogleLoading}
              className="w-full mt-3 py-2.5 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#2dd4bf] text-[#08111e] font-black text-xs sm:text-sm shadow-lg shadow-[#0fb98a]/20 hover:brightness-110 active:scale-98 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin text-[#08111e]" />
              ) : (
                <Sparkles className="w-4 h-4 text-[#08111e]" />
              )}
              <span>إنشاء الحساب وبدء الدراسة</span>
            </button>
          </form>
        )}

        {/* 4) Forgot Password Form */}
        {tab === 'forgot' && (
          <form onSubmit={handlePasswordReset} className="space-y-3.5">
            <p className="text-xs text-gray-400 leading-relaxed text-right">
              أدخل بريدك الإلكتروني المسجل في المنصة وسنرسل لك رابطاً مباشراً لتعيين كلمة مرور جديدة لحسابك.
            </p>

            <div>
              <label className="block text-[11px] font-bold text-gray-400 mb-1 text-right">
                البريد الإلكتروني
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  required
                  autoComplete="email"
                  className="w-full py-2.5 px-3.5 pl-10 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-xs sm:text-sm text-right"
                />
                <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-3 pointer-events-none" />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-xs sm:text-sm shadow-lg hover:brightness-110 active:scale-98 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin text-[#08111e]" />
              ) : (
                <Mail className="w-4 h-4 text-[#08111e]" />
              )}
              <span>إرسال رابط استعادة الحساب</span>
            </button>

            <button
              type="button"
              onClick={() => handleTabChange('login')}
              className="w-full text-center text-xs text-gray-400 hover:text-[#e9c978] transition py-1"
            >
              العودة لشاشة تسجيل الدخول
            </button>
          </form>
        )}

        {/* Web Preview Info Notice */}
        {!isInstalledApp() && tab !== 'forgot' && (
          <div className="mt-3 pt-3 border-t border-white/10 text-right space-y-2">
            <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 text-[11px] text-gray-300 flex items-start gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-[#0fb98a] shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <p className="font-bold text-gray-200">وضع الويب / المعاينة</p>
                <p className="text-gray-400 text-[10px]">
                  تسجيل الدخول بالبريد الإلكتروني متاح للجميع. ميزة ربط حساب Google التلقائي مخصصة للعمل داخل تطبيق الهاتف المثبت لتفعيل صلاحيات Google Drive دون تكرار.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isGoogleLoading || isLoading}
              className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 hover:text-white font-medium text-[11px] flex items-center justify-center gap-2 transition"
            >
              {isGoogleLoading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
              )}
              <span>تجربة المتابعة بحساب Google في الويب</span>
            </button>
          </div>
        )}

        {/* Footer info */}
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-center gap-1.5 text-[11px] text-gray-400">
          <ShieldCheck className="w-3.5 h-3.5 text-[#0fb98a]" />
          <span>جلسة مشفرة ومحمية ببروتوكولات Firebase الأمنية</span>
        </div>
      </div>
    </div>
  );
};
