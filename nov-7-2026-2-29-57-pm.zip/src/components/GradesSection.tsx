import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { gradeNames, gradeIcons, gradeSubs } from '../data/platformData';

interface GradesSectionProps {
  onSelectGrade: (gradeKey: string) => void;
}

export const GradesSection: React.FC<GradesSectionProps> = ({ onSelectGrade }) => {
  const gradesList = [
    { key: 'g1', color: '#3fa9f5', glow: 'rgba(63,169,245,0.2)' },
    { key: 'g2', color: '#0fb98a', glow: 'rgba(15,185,138,0.2)' },
    { key: 'g3', color: '#8b6cf0', glow: 'rgba(139,108,240,0.2)' },
    { key: 'g4', color: '#e9c978', glow: 'rgba(233,201,120,0.2)' },
    { key: 'g5', color: '#f05d5d', glow: 'rgba(240,93,93,0.2)' },
    { key: 'g6', color: '#00d2ff', glow: 'rgba(0,210,255,0.2)' }
  ];

  return (
    <section id="grades" className="py-24 relative border-t border-white/5 bg-gradient-to-b from-transparent via-white/[0.02] to-transparent">
      <div className="w-[min(1240px,92%)] mx-auto space-y-12">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full text-xs font-bold text-[#e9c978] bg-[#e9c978]/10 border border-[#e9c978]/25 shadow-sm">
            <span>المراحل الدراسية</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold font-amiri text-white">
            اختر مرحلتك الدراسية
          </h2>
        </div>

        {/* Grades Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {gradesList.map(({ key, color, glow }) => (
            <div
              key={key}
              onClick={() => onSelectGrade(key)}
              className="relative p-8 rounded-3xl bg-[#0a1220] border border-white/10 hover:border-[#e9c978]/40 shadow-xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl cursor-pointer text-center flex flex-col items-center justify-between group"
              style={{
                boxShadow: `0 20px 40px rgba(0,0,0,0.4)`
              }}
            >
              <div 
                className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl mb-4 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6 border"
                style={{
                  backgroundColor: glow,
                  borderColor: color
                }}
              >
                {gradeIcons[key]}
              </div>

              <h3 className="text-xl sm:text-2xl font-bold font-amiri text-white mb-2 group-hover:text-[#e9c978] transition">
                {gradeNames[key]}
              </h3>

              <p className="text-xs sm:text-sm text-gray-300 mb-6">
                {gradeSubs[key]}
              </p>

              <button
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm border transition"
                style={{
                  color: color,
                  backgroundColor: 'rgba(255,255,255,0.05)',
                  borderColor: 'rgba(255,255,255,0.1)'
                }}
              >
                <span>تصفح</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
