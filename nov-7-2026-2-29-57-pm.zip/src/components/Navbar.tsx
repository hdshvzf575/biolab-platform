import React, { useState, useEffect, useRef } from 'react';
import { 
  Menu, 
  X, 
  Sun, 
  Moon, 
  Maximize, 
  Minimize, 
  Lock,
  Home,
  Video,
  GraduationCap,
  BookOpen,
  Library,
  Building2,
  Phone,
  ChevronLeft,
  ChevronDown,
  Volume2,
  VolumeX,
  Award,
  Dna,
  User,
  School,
  Edit3,
  Sparkles,
  Bell,
  LogIn,
  LogOut,
  UserCheck,
  ShieldAlert
} from 'lucide-react';
import { playClickSound } from '../utils/audioEffects';
import { UserProfile } from './StudentOnboardingModal';

interface NavbarProps {
  currentScreen: string;
  onNavigate: (screenId: string) => void;
  onOpenLoginModal: () => void;
  onOpenAIAssistant?: () => void;
  onOpenNotificationModal?: () => void;
  isNotificationsEnabled?: boolean;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  isSoundMuted?: boolean;
  onToggleSound?: () => void;
  userProfile?: UserProfile | null;
  onOpenProfileModal?: () => void;
  currentUser?: any | null;
  onOpenAuthModal?: () => void;
  onLogout?: () => void;
  isAdmin?: boolean;
  onOpenAdminPanel?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentScreen,
  onNavigate,
  onOpenLoginModal,
  onOpenAIAssistant,
  onOpenNotificationModal,
  isNotificationsEnabled = false,
  theme,
  onToggleTheme,
  isFullscreen,
  onToggleFullscreen,
  isSoundMuted = false,
  onToggleSound,
  userProfile,
  onOpenProfileModal,
  currentUser = null,
  onOpenAuthModal,
  onLogout,
  isAdmin = false,
  onOpenAdminPanel
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    const handleClickOutside = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const navItems = [
    { label: 'الرئيسية', id: 'home', icon: Home },
    { label: 'الكتب والملازم', id: 'books', icon: BookOpen },
    { label: 'المحاضرات', id: 'lectures', icon: Video },
    { label: 'طلاب المعهد', id: 'institute-students', icon: Award },
    { label: 'المراحل', id: 'grades', icon: GraduationCap },
    { label: 'المنهج', id: 'lessons', icon: Library },
    { label: 'المعهد', id: 'institute', icon: Building2 },
    { label: 'تواصل', id: 'contact', icon: Phone },
  ];

  const handleSelectScreen = (id: string) => {
    playClickSound();
    onNavigate(id);
    setIsDrawerOpen(false);
  };

  return (
    <>
      <header 
        className={`fixed top-0 left-0 right-0 z-[800] transition-all duration-300 ${
          isScrolled 
            ? 'h-16 bg-[#04080f]/95 backdrop-blur-xl border-b border-[#e9c978]/25 shadow-xl' 
            : 'h-18 bg-[#04080f]/80 backdrop-blur-md border-b border-white/5'
        }`}
      >
        <div className="w-[min(1240px,92%)] h-full mx-auto flex items-center justify-between gap-2 sm:gap-3">
          
          {/* Brand */}
          <button 
            onClick={() => handleSelectScreen('home')}
            className="flex items-center gap-2.5 sm:gap-3 shrink-0 group text-right"
          >
            <div className="w-10 sm:w-11 h-10 sm:h-11 rounded-2xl bg-gradient-to-tr from-[#c9a24a] to-[#e9c978] text-[#04080f] flex items-center justify-center text-xl shadow-lg shadow-[#c9a24a]/30 group-hover:scale-105 transition overflow-hidden relative border border-[#e9c978]/40 shrink-0">
              <span className="absolute inset-0 flex items-center justify-center text-lg">🧬</span>
              <img 
                src="https://res.cloudinary.com/zijsnksq/image/upload/f_auto,q_auto/68566" 
                alt="شعار" 
                className="w-full h-full object-cover relative z-10"
                onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
              />
            </div>
            <div>
              <strong className="block font-amiri text-base sm:text-xl font-bold text-white group-hover:text-[#e9c978] transition leading-tight">
                وسام سهيل العامري
              </strong>
              <small className="block text-[10px] sm:text-[11px] text-gray-400 font-medium">
                علم الأحياء · مختبر الأحياء
              </small>
            </div>
          </button>

          {/* Desktop Direct Screen Navigation Switcher */}
          <nav className="hidden lg:flex items-center gap-1 bg-white/5 p-1 rounded-2xl border border-white/10 shadow-inner">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelectScreen(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 ${
                    isActive 
                      ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/25 scale-100' 
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Action Tools: User Auth Profile, Login, Admin, Theme, Fullscreen & Menu */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            
            {/* 1) Authenticated User Menu or Guest Login / Profile */}
            {currentUser ? (
              <div className="relative" ref={userMenuRef}>
                <button
                  onClick={() => {
                    playClickSound();
                    setIsUserMenuOpen(!isUserMenuOpen);
                  }}
                  className="py-1 px-2 sm:px-2.5 rounded-xl border border-[#e9c978]/40 bg-[#e9c978]/15 text-[#e9c978] hover:bg-[#e9c978]/25 flex items-center gap-1.5 text-xs font-bold transition shadow-sm"
                  title="حساب المستخدم والإعدادات"
                >
                  {currentUser.photoURL ? (
                    <img 
                      src={currentUser.photoURL} 
                      alt="avatar" 
                      className="w-5 h-5 rounded-full object-cover border border-[#e9c978]"
                    />
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-[#e9c978] text-[#08111e] flex items-center justify-center text-[10px] font-black">
                      {(currentUser.displayName || userProfile?.name || 'ط')[0]}
                    </div>
                  )}
                  <span className="max-w-[70px] sm:max-w-[100px] truncate">
                    {(currentUser.displayName || userProfile?.name || 'حسابي').split(' ')[0]}
                  </span>
                  {isAdmin && (
                    <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-normal">
                      إدارة
                    </span>
                  )}
                  <ChevronDown className="w-3 h-3 opacity-70" />
                </button>

                {/* User Dropdown Card */}
                {isUserMenuOpen && (
                  <div 
                    className="absolute left-0 sm:right-auto top-full mt-2 w-64 rounded-2xl bg-[#0a1220] border border-[#e9c978]/35 shadow-2xl p-3 z-[900] text-right space-y-2.5 animate-fadeIn"
                    dir="rtl"
                  >
                    <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white text-xs truncate max-w-[150px]">
                          {currentUser.displayName || userProfile?.name || 'مستخدم مسجل'}
                        </span>
                        {isAdmin ? (
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/30">
                            مدير المنصة ⭐
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-[#0fb98a] bg-[#0fb98a]/10 px-1.5 py-0.5 rounded border border-[#0fb98a]/30">
                            طالب موثق ✅
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-gray-400 truncate">
                        {currentUser.email || 'حساب Google متصل'}
                      </div>
                      <div className="flex items-center justify-between pt-1 border-t border-white/5 text-[10px] text-gray-400">
                        <span>المعرّف الأكاديمي:</span>
                        <span className="font-mono text-[#e9c978] bg-black/60 px-1.5 py-0.5 rounded">
                          {userProfile?.uid || 'UID-BIO-USER'}
                        </span>
                      </div>
                    </div>

                    {/* Admin Dashboard Direct Shortcut */}
                    {isAdmin && (
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          playClickSound();
                          if (onOpenAdminPanel) onOpenAdminPanel();
                          else onOpenLoginModal();
                        }}
                        className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-[#e9c978]/20 to-[#c9a24a]/20 border border-[#e9c978]/40 text-[#e9c978] hover:bg-[#e9c978]/30 font-bold text-xs flex items-center justify-between transition"
                      >
                        <span className="flex items-center gap-1.5">
                          <Lock className="w-3.5 h-3.5" />
                          <span>لوحة تحكم الإدارة السحابية</span>
                        </span>
                        <ChevronLeft className="w-3.5 h-3.5 opacity-60" />
                      </button>
                    )}

                    {/* Edit Profile Button */}
                    {onOpenProfileModal && (
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          playClickSound();
                          onOpenProfileModal();
                        }}
                        className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 font-bold text-xs flex items-center justify-between transition"
                      >
                        <span className="flex items-center gap-1.5">
                          <School className="w-3.5 h-3.5 text-[#e9c978]" />
                          <span>الصف والمسار الدراسي</span>
                        </span>
                        <Edit3 className="w-3.5 h-3.5 opacity-60" />
                      </button>
                    )}

                    {/* Logout Button */}
                    {onLogout && (
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          playClickSound();
                          onLogout();
                        }}
                        className="w-full py-2 px-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-300 font-bold text-xs flex items-center justify-between transition"
                      >
                        <span className="flex items-center gap-1.5">
                          <LogOut className="w-3.5 h-3.5 text-red-400" />
                          <span>تسجيل الخروج من الحساب</span>
                        </span>
                        <ChevronLeft className="w-3.5 h-3.5 opacity-60" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-1">
                {/* Guest Profile Badge if set */}
                {userProfile && (
                  <button
                    onClick={() => {
                      playClickSound();
                      if (onOpenProfileModal) onOpenProfileModal();
                    }}
                    className="py-1.5 px-2.5 sm:px-3 rounded-xl border border-[#e9c978]/40 bg-[#e9c978]/15 text-[#e9c978] hover:bg-[#e9c978]/25 flex items-center gap-1.5 text-xs font-bold transition shadow-sm"
                    title="الملف الشخصي والصف الدراسي (انقر للتعديل)"
                  >
                    <School className="w-3.5 h-3.5" />
                    <span className="max-w-[70px] sm:max-w-[100px] truncate">
                      {userProfile.name.split(' ')[0] || 'طالب'}
                    </span>
                    <span className="hidden md:inline text-[10px] opacity-75 font-normal">
                      ({userProfile.grade ? userProfile.grade.toUpperCase() : 'مدرسي'})
                    </span>
                    <Edit3 className="w-3 h-3 opacity-60 hover:opacity-100" />
                  </button>
                )}

                {/* Login Button */}
                <button
                  onClick={() => {
                    playClickSound();
                    if (onOpenAuthModal) onOpenAuthModal();
                    else onOpenLoginModal();
                  }}
                  className="px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-gradient-to-r from-[#0fb98a]/20 to-[#2dd4bf]/20 border border-[#0fb98a]/40 hover:bg-[#0fb98a]/30 text-[#0fb98a] font-bold text-xs sm:text-sm transition flex items-center gap-1.5 shadow-sm"
                  title="تسجيل دخول الطالب أو حساب Google"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">دخول</span>
                </button>
              </div>
            )}

            {/* AI Assistant Quick Button */}
            {onOpenAIAssistant && (
              <button
                onClick={() => {
                  playClickSound();
                  onOpenAIAssistant();
                }}
                className="px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-gradient-to-r from-[#0fb98a]/20 to-[#2dd4bf]/20 border border-[#0fb98a]/40 hover:bg-[#0fb98a]/30 text-[#0fb98a] font-bold text-xs sm:text-sm transition flex items-center gap-1.5 shadow-sm"
                title="المساعد الذكي لمنصة الأحياء"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#0fb98a] animate-pulse" />
                <span className="hidden sm:inline">المساعد الذكي</span>
              </button>
            )}

            {/* Notifications Permission & Status Toggle */}
            {onOpenNotificationModal && (
              <button
                onClick={() => {
                  playClickSound();
                  onOpenNotificationModal();
                }}
                className={`relative w-8 sm:w-9 h-8 sm:h-9 rounded-xl bg-white/5 border flex items-center justify-center transition ${
                  isNotificationsEnabled 
                    ? 'border-[#0fb98a]/40 text-[#0fb98a] hover:bg-[#0fb98a]/15 shadow-sm' 
                    : 'border-white/10 text-gray-400 hover:text-[#e9c978] hover:border-[#e9c978]/40'
                }`}
                title={isNotificationsEnabled ? 'الإشعارات مفعلة (انقر للإعدادات)' : 'تفعيل إشعارات المنصة'}
              >
                <Bell className={`w-3.5 h-3.5 ${isNotificationsEnabled ? 'fill-[#0fb98a]' : ''}`} />
                {isNotificationsEnabled && (
                  <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-[#0fb98a] ring-2 ring-black animate-pulse" />
                )}
              </button>
            )}

            {/* Admin Login Button (if not already logged in as admin) */}
            {!isAdmin && (
              <button
                onClick={onOpenLoginModal}
                className="px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-[#e9c978]/15 border border-[#e9c978]/30 hover:bg-[#e9c978]/25 text-[#e9c978] font-bold text-xs sm:text-sm transition flex items-center gap-1.5 shadow-sm"
                title="لوحة الإدارة (التطبيق، التنزيل والمحاضرات)"
              >
                <Lock className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">الإدارة</span>
              </button>
            )}

            {/* Fullscreen Toggle */}
            <button
              onClick={onToggleFullscreen}
              className="w-8 sm:w-9 h-8 sm:h-9 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 flex items-center justify-center text-gray-300 hover:text-[#e9c978] transition"
              title={isFullscreen ? 'الخروج من ملء الشاشة' : 'وضع ملء الشاشة'}
            >
              {isFullscreen ? <Minimize className="w-3.5 h-3.5" /> : <Maximize className="w-3.5 h-3.5" />}
            </button>

            {/* Sound Mute / Unmute Toggle Button */}
            <button
              onClick={() => {
                if (onToggleSound) onToggleSound();
              }}
              className={`w-8 sm:w-9 h-8 sm:h-9 rounded-xl bg-white/5 border flex items-center justify-center transition ${
                isSoundMuted
                  ? 'border-red-500/30 text-red-400 hover:bg-red-500/10'
                  : 'border-white/10 text-gray-300 hover:text-[#e9c978] hover:border-[#e9c978]/40'
              }`}
              title={isSoundMuted ? 'إلغاء كتم الصوت' : 'كتم الصوت'}
            >
              {isSoundMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-sky-400" />}
            </button>

            {/* Theme Toggle */}
            <button
              onClick={() => {
                playClickSound();
                onToggleTheme();
              }}
              className="w-8 sm:w-9 h-8 sm:h-9 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 flex items-center justify-center text-gray-300 hover:text-white transition"
              title="تبديل النمط"
            >
              {theme === 'dark' ? <Moon className="w-3.5 h-3.5 text-[#e9c978]" /> : <Sun className="w-3.5 h-3.5 text-amber-400" />}
            </button>

            {/* Mobile / Global Menu Drawer Toggle */}
            <button
              onClick={() => setIsDrawerOpen(!isDrawerOpen)}
              className="lg:hidden w-8 sm:w-9 h-8 sm:h-9 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 flex items-center justify-center text-gray-300 hover:text-white transition"
              title="قائمة الأقسام"
            >
              {isDrawerOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>

        </div>
      </header>

      {/* Cinematic Side Drawer Menu */}
      {isDrawerOpen && (
        <div className="fixed inset-0 z-[950] bg-black/80 backdrop-blur-md animate-fadeIn">
          <div 
            className="fixed top-0 right-0 w-[min(340px,88vw)] h-full bg-[#0a1220] border-l border-[#e9c978]/30 p-6 flex flex-col justify-between shadow-2xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Drawer Top */}
            <div className="space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#c9a24a] to-[#e9c978] text-[#04080f] flex items-center justify-center text-xl font-bold overflow-hidden relative shadow-md">
                    <img 
                      src="https://res.cloudinary.com/zijsnksq/image/upload/f_auto,q_auto/68566" 
                      alt="شعار" 
                      className="w-full h-full object-cover"
                      onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                    />
                  </div>
                  <div>
                    <h4 className="font-amiri font-bold text-base text-[#e9c978]">مختبر الأحياء</h4>
                    <span className="text-[11px] text-gray-400 block">الأستاذ وسام سهيل العامري</span>
                  </div>
                </div>

                <button
                  onClick={() => setIsDrawerOpen(false)}
                  className="w-8 h-8 rounded-lg bg-white/5 text-gray-400 hover:text-white flex items-center justify-center"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* User Identity Card in Drawer */}
              {currentUser ? (
                <div 
                  className="p-3.5 rounded-2xl bg-gradient-to-br from-black/60 to-black/30 border border-[#e9c978]/30 space-y-2 text-right"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-gray-400 flex items-center gap-1">
                      <UserCheck className="w-3.5 h-3.5 text-[#0fb98a]" />
                      <span>الحساب المتصل:</span>
                    </span>
                    {isAdmin ? (
                      <span className="text-[10px] text-amber-400 font-bold bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/30">
                        إدارة ⭐
                      </span>
                    ) : (
                      <span className="text-[10px] text-[#0fb98a] font-bold">
                        طالب موثق ✅
                      </span>
                    )}
                  </div>
                  <div className="font-bold text-white text-sm truncate">
                    {currentUser.displayName || userProfile?.name || 'مستخدم مسجل'}
                  </div>
                  <div className="text-[11px] text-gray-400 truncate">
                    {currentUser.email}
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-gray-300 pt-1 border-t border-white/5">
                    <span>المعرف الأكاديمي:</span>
                    <span className="font-mono text-[10px] text-[#e9c978] bg-black/50 px-2 py-0.5 rounded">
                      {userProfile?.uid || 'UID-BIO-USER'}
                    </span>
                  </div>
                </div>
              ) : userProfile ? (
                <div 
                  onClick={() => {
                    setIsDrawerOpen(false);
                    if (onOpenProfileModal) onOpenProfileModal();
                  }}
                  className="p-3.5 rounded-2xl bg-gradient-to-br from-black/60 to-black/30 border border-[#e9c978]/30 cursor-pointer hover:border-[#e9c978] transition space-y-2 text-right"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-gray-400 flex items-center gap-1">
                      <User className="w-3 h-3 text-[#e9c978]" />
                      <span>الملف الشخصي للطالب:</span>
                    </span>
                    <span className="text-[10px] text-[#e9c978] font-bold flex items-center gap-1">
                      <Edit3 className="w-3 h-3" />
                      <span>تعديل</span>
                    </span>
                  </div>
                  <div className="font-bold text-white text-sm">
                    {userProfile.name}
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-gray-300 pt-1 border-t border-white/5">
                    <span>🏫 طالب مدرسة</span>
                    <span className="font-mono text-[10px] text-[#e9c978] bg-black/50 px-2 py-0.5 rounded">
                      {userProfile.uid}
                    </span>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setIsDrawerOpen(false);
                    playClickSound();
                    if (onOpenAuthModal) onOpenAuthModal();
                    else onOpenLoginModal();
                  }}
                  className="w-full p-3 rounded-2xl bg-gradient-to-r from-[#0fb98a]/20 to-[#2dd4bf]/20 border border-[#0fb98a]/40 text-[#0fb98a] font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition hover:brightness-110"
                >
                  <LogIn className="w-4 h-4" />
                  <span>تسجيل الدخول / إنشاء حساب طالب جديد</span>
                </button>
              )}

              {/* Screens List */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-gray-400 px-3 pb-1">
                  شاشات وأقسام المنصة:
                </div>
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentScreen === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleSelectScreen(item.id)}
                      className={`w-full flex items-center justify-between p-3 rounded-2xl text-sm font-bold transition-all ${
                        isActive 
                          ? 'bg-gradient-to-r from-[#e9c978]/20 to-transparent text-[#e9c978] border-r-4 border-[#e9c978]' 
                          : 'text-gray-200 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm ${
                          isActive ? 'bg-[#e9c978] text-[#08111e]' : 'bg-white/5 text-gray-400'
                        }`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <span>{item.label}</span>
                      </div>
                      <ChevronLeft className="w-4 h-4 opacity-50" />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Bottom info & Admin Login in Drawer */}
            <div className="pt-6 border-t border-white/10 text-xs text-gray-400 space-y-2.5">
              {onOpenAIAssistant && (
                <button
                  onClick={() => {
                    setIsDrawerOpen(false);
                    playClickSound();
                    onOpenAIAssistant();
                  }}
                  className="w-full py-3 px-3 rounded-xl bg-gradient-to-r from-[#0fb98a]/20 to-[#2dd4bf]/20 border border-[#0fb98a]/40 text-[#0fb98a] font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition hover:brightness-110"
                >
                  <Sparkles className="w-4 h-4 text-[#0fb98a]" />
                  <span>فتح المساعد الذكي لمادة الأحياء</span>
                </button>
              )}

              {onOpenNotificationModal && (
                <button
                  onClick={() => {
                    setIsDrawerOpen(false);
                    playClickSound();
                    onOpenNotificationModal();
                  }}
                  className={`w-full py-3 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition ${
                    isNotificationsEnabled 
                      ? 'bg-[#0fb98a]/15 border-[#0fb98a]/40 text-[#0fb98a]' 
                      : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'
                  }`}
                >
                  <Bell className={`w-4 h-4 ${isNotificationsEnabled ? 'fill-current' : ''}`} />
                  <span>{isNotificationsEnabled ? 'إشعارات المنصة (مفعلة ✅)' : 'تفعيل إشعارات المنصة والتنبيهات 🔔'}</span>
                </button>
              )}

              {isAdmin && (
                <button
                  onClick={() => {
                    setIsDrawerOpen(false);
                    playClickSound();
                    if (onOpenAdminPanel) onOpenAdminPanel();
                    else onOpenLoginModal();
                  }}
                  className="w-full py-3 px-3 rounded-xl bg-gradient-to-r from-[#e9c978]/25 to-[#c9a24a]/25 border border-[#e9c978]/50 text-[#e9c978] hover:bg-[#e9c978] hover:text-[#08111e] text-xs font-bold flex items-center justify-center gap-2 transition"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>لوحة تحكم الإدارة السحابية ⭐</span>
                </button>
              )}

              {!isAdmin && (
                <button
                  onClick={() => {
                    setIsDrawerOpen(false);
                    playClickSound();
                    onOpenLoginModal();
                  }}
                  className="w-full py-3 px-3 rounded-xl bg-[#e9c978]/15 border border-[#e9c978]/30 text-[#e9c978] hover:bg-[#e9c978] hover:text-[#08111e] text-xs font-bold flex items-center justify-center gap-2 transition"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>دخول لوحة تحكم الإدارة والتطبيق</span>
                </button>
              )}

              {currentUser && onLogout && (
                <button
                  onClick={() => {
                    setIsDrawerOpen(false);
                    playClickSound();
                    onLogout();
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white text-xs font-bold flex items-center justify-center gap-2 transition"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>تسجيل الخروج من الحساب</span>
                </button>
              )}
              <div className="text-[11px] text-gray-500 text-center">
                منصة تعليمية متكاملة · علم الأحياء لجميع المراحل
              </div>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
