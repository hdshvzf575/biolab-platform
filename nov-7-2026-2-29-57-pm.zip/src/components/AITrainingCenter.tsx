import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  BookOpen,
  MessageSquare,
  ShieldAlert,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Plus,
  Trash2,
  Edit3,
  RefreshCw,
  Search,
  Filter,
  Check,
  X,
  ShieldCheck,
  GraduationCap,
  ExternalLink,
  ChevronDown,
  Sliders,
  Send,
  HelpCircle,
  FileText,
  Key,
  DollarSign,
  PhoneCall,
  LifeBuoy,
  Play,
  Terminal,
  Activity,
  ToggleLeft,
  ToggleRight,
  Clock,
  Eye,
  Info
} from 'lucide-react';
import {
  PreventionRule,
  AIConfig,
  AIPricingConfig,
  AIContactConfig,
  AIFewShotExample,
  AISupportTicket
} from '../services/aiKnowledgeService';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';

interface AITrainingCenterProps {
  onOpenPdfBook?: (bookId: string, page?: number) => void;
  showToast: (msg: string) => void;
}

type TabType =
  | 'instructions'
  | 'scope'
  | 'rules'
  | 'examples'
  | 'pricing'
  | 'contact'
  | 'tickets'
  | 'playground'
  | 'settings';

export const AITrainingCenter: React.FC<AITrainingCenterProps> = ({
  onOpenPdfBook,
  showToast
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('instructions');
  const [isLoading, setIsLoading] = useState(false);
  const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

  const authHeaders = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${adminToken}`
  };

  // State 1: Master AI Config & Custom Natural Language Instructions
  const [aiConfig, setAiConfig] = useState<AIConfig>({
    isEnabled: true,
    model: 'gemini-3.8-flash',
    temperature: 0.7,
    welcomeMessage: 'مرحباً بك يا بطل في منصة مختبر الأحياء!',
    customSystemInstructions: '',
    disclaimerText: '',
    updatedAt: new Date().toISOString()
  });
  const [customInstructionsText, setCustomInstructionsText] = useState('');
  const [isSavingConfig, setIsSavingConfig] = useState(false);

  // State 2: Decision Rules Engine
  const [rulesList, setRulesList] = useState<PreventionRule[]>([]);
  const [isAddRuleOpen, setIsAddRuleOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<PreventionRule | null>(null);
  const [rName, setRName] = useState('');
  const [rTriggers, setRTriggers] = useState('');
  const [rCondition, setRCondition] = useState('all');
  const [rRequiredResponse, setRRequiredResponse] = useState('');
  const [rIncludeInfo, setRIncludeInfo] = useState('');
  const [rAvoidInfo, setRAvoidInfo] = useState('');
  const [rPriority, setRPriority] = useState(10);
  const [rIsActive, setRIsActive] = useState(true);

  // State 3: Few-shot Examples & FAQs
  const [examplesList, setExamplesList] = useState<AIFewShotExample[]>([]);
  const [isAddExampleOpen, setIsAddExampleOpen] = useState(false);
  const [editingExample, setEditingExample] = useState<AIFewShotExample | null>(null);
  const [exQuestion, setExQuestion] = useState('');
  const [exAnswer, setExAnswer] = useState('');
  const [exCategory, setExCategory] = useState('general');
  const [exNotes, setExNotes] = useState('');

  // State 3.5: AI Scope Control (ما يجيب عنه وما يرفضه)
  const [strictBiologyScope, setStrictBiologyScope] = useState<boolean>(true);
  const [allowedTopicsList, setAllowedTopicsList] = useState<string[]>([]);
  const [prohibitedTopicsList, setProhibitedTopicsList] = useState<string[]>([]);
  const [rejectionResponseText, setRejectionResponseText] = useState<string>('');
  const [newAllowedTopicInput, setNewAllowedTopicInput] = useState('');
  const [newProhibitedTopicInput, setNewProhibitedTopicInput] = useState('');
  const [isSavingScope, setIsSavingScope] = useState(false);

  // Live Google Gemini Connection Test State
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<{
    tested: boolean;
    connected: boolean;
    modelUsed?: string;
    latencyMs?: number;
    sampleResponse?: string;
    message?: string;
    error?: string;
  } | null>(null);

  // State 4: Pricing & Subscriptions
  const [pricingConfig, setPricingConfig] = useState<AIPricingConfig>({
    individualLectureDefaultPrice: 5000,
    currency: 'دينار عراقي',
    packages: [
      { gradeId: 'g1', gradeName: 'الأول متوسط', fullPackagePrice: 25000, termPrice: 15000, duration: 'طيلة العام', features: ['جميع محاضرات الفصل الأول والثاني', 'ملخصات PDF الوزارية'] },
      { gradeId: 'g2', gradeName: 'الثاني متوسط', fullPackagePrice: 25000, termPrice: 15000, duration: 'طيلة العام', features: ['شرح الأحياء المتكامل', 'اختبارات إلكترونية'] },
      { gradeId: 'g3', gradeName: 'الثالث متوسط', fullPackagePrice: 35000, termPrice: 20000, duration: 'طيلة العام', features: ['المنهج الوزاري الشامل', 'بنك الأسئلة الوزارية'] },
      { gradeId: 'g4', gradeName: 'الرابع العلمي', fullPackagePrice: 40000, termPrice: 25000, duration: 'طيلة العام', features: ['علم البيئة والتصنيف', 'رسومات الأحياء التوضيحية'] },
      { gradeId: 'g5', gradeName: 'الخامس العلمي', fullPackagePrice: 45000, termPrice: 25000, duration: 'طيلة العام', features: ['الفسلجة المقارنة', 'حلول أسئلة الفصول'] },
      { gradeId: 'g6', gradeName: 'السادس العلمي', fullPackagePrice: 65000, termPrice: 35000, duration: 'طيلة العام الوزاري', features: ['الخلية، الأنسجة، التكاثر، الوراثة', 'الأكواد الشاملة والدعم المباشر'] }
    ],
    activationSteps: [
      'اختيار المحاضرة أو باقة المرحلة الدراسية من قسم المحاضرات.',
      'التواصل مع الأستاذ وسام سهيل العامري عبر واتساب لتحويل المبلغ وتأكيد الاشتراك.',
      'استلام كود التفعيل الرقمي المعتمد الخاص بالطالب.',
      'إدخال الكود في نافذة فك القفل (VIP) لتفتح جميع المحاضرات فوراً وبشكل دائم.'
    ],
    activeOffers: [
      {
        id: 'off-1',
        title: 'خصم السادس العلمي',
        discountPercentage: 20,
        description: 'خصم 20% عند الاشتراك في باقة السادس العلمي الكاملة (شاملة الوراثة)',
        expiresAt: '2026-12-31',
        isActive: true
      }
    ],
    paymentFaq: [
      { q: 'هل الكود يعمل على أكثر من جهاز؟', a: 'الكود يرتبط بجهاز الطالب الأساسي لضمان جودة الأداء وأمان الحساب.' }
    ]
  });

  // State 5: Contact Policies
  const [contactConfig, setContactConfig] = useState<AIContactConfig>({
    entityName: 'الأستاذ وسام سهيل العامري',
    whatsappNumber: '07704597073',
    whatsappLink: 'https://wa.me/9647704597073',
    telegramChannel: 'https://t.me/wissam_biology',
    instituteAddress: 'بغداد — معهد أنوار السلام الأهلي',
    guidingMessage: 'يمكنك التواصل المباشر مع الأستاذ وسام سهيل العامري عبر واتساب أو مراجعة معهد أنوار السلام الأهلي في أوقات الدوام الرسمي.',
    requiredInfoBeforeContact: 'يرجى تزويد الأستاذ باسمك الثلاثي والمرحلة الدراسية ونوع الاستفسار (اشتراك أو سؤال علمي).',
    suggestContactWhen: [
      'طلب الحصول على كود تفعيل المحاضرات المدفوعة',
      'التسجيل الحضوري في معهد أنوار السلام الأهلي',
      'استفسارات معقدة تحتاج توضيحاً صوتياً من الأستاذ مباشرة'
    ]
  });

  // State 6: Support Tickets
  const [ticketsList, setTicketsList] = useState<AISupportTicket[]>([]);
  const [ticketFilter, setTicketFilter] = useState<'all' | 'new' | 'in_progress' | 'resolved'>('all');
  const [selectedTicket, setSelectedTicket] = useState<AISupportTicket | null>(null);
  const [ticketAdminNotes, setTicketAdminNotes] = useState('');

  // State 7: Playground / Diagnostic Tester
  const [testQuery, setTestQuery] = useState('');
  const [testResult, setTestResult] = useState<any>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [showFullSystemPrompt, setShowFullSystemPrompt] = useState(false);

  // Fetch all AI data on load
  const loadAllAIData = async () => {
    setIsLoading(true);
    try {
      // 1. Config
      const confRes = await fetch('/api/ai/config');
      if (confRes.ok) {
        const cData = await confRes.json();
        if (cData.success && cData.config) {
          setAiConfig(cData.config);
          setCustomInstructionsText(cData.config.customSystemInstructions || '');
          setStrictBiologyScope(cData.config.strictBiologyScope !== false);
          setAllowedTopicsList(cData.config.allowedTopics || [
            'علم الخلية (التركيب، العضيات، الغشاء البلازمي، الانقسام الخيطي والاختزالي)',
            'علم الأنسجة (الأنسجة النباتية، الأنسجة الحيوانية، الغضروف والعظم والدم والعصب)',
            'علم التكاثر (التكاثر اللاجنسي والجنسي في النباتات والحيوانات والإنسان)',
            'علم الوراثة والتوارث (الوراثة المندلية، السيادة، الكروموسومات، الطفرات، الهندسة الوراثية)',
            'أجهزة جسم الإنسان والفسلجة (الهضم، الدوران، التنفس، الإخراج، المناعة)',
            'الأحياء المجهرية والتصنيف وعلم البيئة والتغذية في الأحياء',
            'المنهج الوزاري العراقي لمادة الأحياء (من الأول متوسط حتى السادس العلمي)',
            'منصة الأستاذ وسام سهيل العامري، معهد أنوار السلام الأهلي، أسعار الاشتراكات وأكواد VIP'
          ]);
          setProhibitedTopicsList(cData.config.prohibitedTopics || [
            'المواد الدراسية غير الأحياء (مثل الكيمياء، الفيزياء، الرياضيات، التاريخ، الجغرافيا)',
            'السياسة والأخبار الحزبية والعامة والنزاعات',
            'البرمجة وتطوير البرمجيات والذكاء الاصطناعي العام',
            'الدردشة الترفيهية العامة والرياضة والألعاب والموسيقى',
            'محاولات طلب أكواد VIP مجانية أو التحايل على نظام الدفع'
          ]);
          setRejectionResponseText(cData.config.rejectionResponse || 'عذراً يا بطل! أنا المساعد الذكي المخصص حصرياً لمنصة مختبر الأحياء للأستاذ وسام سهيل العامري. لا يمكنني الإجابة عن مواضيع خارج تخصص علم الأحياء أو خارج المنصة. يسعدني جداً مساعدتك في أي سؤال يخص مادة الأحياء، شروحات الدروس، أو اشتراكات المنصة! 🔬🧬');
        }
      }

      // 2. Rules
      const rulesRes = await fetch('/api/admin/ai/rules', { headers: authHeaders });
      if (rulesRes.ok) {
        const rData = await rulesRes.json();
        if (rData.success) setRulesList(rData.rules || []);
      }

      // 3. Examples
      const exRes = await fetch('/api/ai/examples');
      if (exRes.ok) {
        const eData = await exRes.json();
        if (eData.success) setExamplesList(eData.examples || []);
      }

      // 4. Pricing
      const priceRes = await fetch('/api/ai/pricing');
      if (priceRes.ok) {
        const pData = await priceRes.json();
        if (pData.success && pData.pricing) setPricingConfig(pData.pricing);
      }

      // 5. Contact
      const contRes = await fetch('/api/ai/contact');
      if (contRes.ok) {
        const ctData = await contRes.json();
        if (ctData.success && ctData.contact) setContactConfig(ctData.contact);
      }

      // 6. Tickets
      const tickRes = await fetch('/api/ai/tickets');
      if (tickRes.ok) {
        const tData = await tickRes.json();
        if (tData.success) setTicketsList(tData.tickets || []);
      }
    } catch (e) {
      console.warn('Failed to load some AI data:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAllAIData();
  }, []);

  // Save Natural Language Instructions (التعليمات الحرة)
  const handleSaveCustomInstructions = async () => {
    setIsSavingConfig(true);
    playClickSound();
    try {
      const res = await fetch('/api/admin/ai/config', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({
          ...aiConfig,
          customSystemInstructions: customInstructionsText
        })
      });
      const data = await res.json();
      if (data.success) {
        setAiConfig(data.config);
        showToast('تم حفظ تعليمات المدير بنجاح واعتمادها للمساعد الذكي! 🎯');
        playSuccessSound();
      } else {
        showToast('خطأ: ' + (data.error || 'تعذر الحفظ'));
      }
    } catch (e) {
      showToast('تعذر الاتصال بالسيرفر لحفظ التعليمات');
    } finally {
      setIsSavingConfig(false);
    }
  };

  // Preset snippets to quickly insert into natural language instructions
  const insertInstructionSnippet = (snippet: string) => {
    playClickSound();
    setCustomInstructionsText((prev) => {
      const trimmed = prev.trim();
      return trimmed ? `${trimmed}\n\n${snippet}` : snippet;
    });
  };

  // Rule Save / Edit Handler
  const handleSaveRule = async (e: React.FormEvent) => {
    e.preventDefault();
    const triggersArr = rTriggers.split(',').map((s) => s.trim()).filter(Boolean);
    const payload: Partial<PreventionRule> = {
      name: rName.trim(),
      triggers: triggersArr,
      triggerKeywords: triggersArr,
      conditions: rCondition,
      requiredResponse: rRequiredResponse.trim(),
      customResponse: rRequiredResponse.trim(),
      includeInfo: rIncludeInfo.trim() || undefined,
      avoidInfo: rAvoidInfo.trim() || undefined,
      priority: Number(rPriority) || 10,
      action: 'block_and_guide',
      isActive: rIsActive
    };

    try {
      if (editingRule) {
        const res = await fetch(`/api/admin/ai/rules/${editingRule.id}`, {
          method: 'PUT',
          headers: authHeaders,
          body: JSON.stringify(payload)
        });
        if (res.ok) {
          showToast('تم تحديث قاعدة الإجابة بنجاح ✅');
          playSuccessSound();
        }
      } else {
        const res = await fetch('/api/admin/ai/rules', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify(payload)
        });
        if (res.ok) {
          showToast('تمت إضافة قاعدة الإجابة وتفعيلها للمساعد بنجاح 🛡️');
          playSuccessSound();
        }
      }
      setIsAddRuleOpen(false);
      setEditingRule(null);
      resetRuleForm();
      loadAllAIData();
    } catch (e) {
      showToast('تعذر حفظ القاعدة');
    }
  };

  const resetRuleForm = () => {
    setRName('');
    setRTriggers('');
    setRCondition('all');
    setRRequiredResponse('');
    setRIncludeInfo('');
    setRAvoidInfo('');
    setRPriority(10);
    setRIsActive(true);
  };

  const handleEditRuleClick = (r: PreventionRule) => {
    setEditingRule(r);
    setRName(r.name);
    setRTriggers((r.triggers || r.triggerKeywords || []).join(', '));
    setRCondition(r.conditions || 'all');
    setRRequiredResponse(r.requiredResponse || r.customResponse || '');
    setRIncludeInfo(r.includeInfo || '');
    setRAvoidInfo(r.avoidInfo || '');
    setRPriority(r.priority || 10);
    setRIsActive(r.isActive !== false);
    setIsAddRuleOpen(true);
  };

  const handleDeleteRule = async (id: string) => {
    if (!window.confirm('هل أنت متأكد من حذف هذه القاعدة من نظام الذكاء الاصطناعي؟')) return;
    try {
      const res = await fetch(`/api/admin/ai/rules/${id}`, {
        method: 'DELETE',
        headers: authHeaders
      });
      if (res.ok) {
        showToast('تم حذف القاعدة بنجاح');
        loadAllAIData();
      }
    } catch (e) {
      showToast('تعذر حذف القاعدة');
    }
  };

  // Few-Shot Example Save Handler (إضافة أو تعديل)
  const handleSaveExample = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!exQuestion.trim() || !exAnswer.trim()) {
      showToast('يرجى ملء سؤال الطالب والجواب النموذجي');
      return;
    }

    try {
      if (editingExample) {
        const res = await fetch(`/api/admin/ai/examples/${editingExample.id}`, {
          method: 'PUT',
          headers: authHeaders,
          body: JSON.stringify({
            question: exQuestion.trim(),
            desiredAnswer: exAnswer.trim(),
            category: exCategory,
            notes: exNotes.trim()
          })
        });
        const data = await res.json();
        if (data.success) {
          showToast('تم تحديث السؤال والإجابة النموذجية بنجاح! 💡');
          playSuccessSound();
        }
      } else {
        const res = await fetch('/api/admin/ai/examples', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({
            question: exQuestion.trim(),
            desiredAnswer: exAnswer.trim(),
            category: exCategory,
            notes: exNotes.trim()
          })
        });
        const data = await res.json();
        if (data.success) {
          showToast('تمت إضافة السؤال والإجابة النموذجية بنجاح! 💡');
          playSuccessSound();
        }
      }
      setIsAddExampleOpen(false);
      setEditingExample(null);
      setExQuestion('');
      setExAnswer('');
      setExNotes('');
      loadAllAIData();
    } catch (e) {
      showToast('تعذر حفظ السؤال والإجابة');
    }
  };

  const handleEditExampleClick = (ex: AIFewShotExample) => {
    setEditingExample(ex);
    setExQuestion(ex.question);
    setExAnswer(ex.desiredAnswer);
    setExCategory(ex.category || 'general');
    setExNotes(ex.notes || '');
    setIsAddExampleOpen(true);
  };

  const handleDeleteExample = async (id: string) => {
    if (!window.confirm('هل تود حذف هذا السؤال والإجابة النموذجية؟')) return;
    try {
      const res = await fetch(`/api/admin/ai/examples/${id}`, {
        method: 'DELETE',
        headers: authHeaders
      });
      if (res.ok) {
        showToast('تم حذف السؤال النموذجي بنجاح');
        loadAllAIData();
      }
    } catch (e) {
      showToast('تعذر الحذف');
    }
  };

  // Scope Handlers (ما يجيب عنه وما يرفضه)
  const handleAddAllowedTopic = () => {
    const val = newAllowedTopicInput.trim();
    if (!val) return;
    if (allowedTopicsList.includes(val)) {
      showToast('الموضوع موجود بالفعل');
      return;
    }
    setAllowedTopicsList((prev) => [...prev, val]);
    setNewAllowedTopicInput('');
    playClickSound();
  };

  const handleRemoveAllowedTopic = (index: number) => {
    setAllowedTopicsList((prev) => prev.filter((_, i) => i !== index));
    playClickSound();
  };

  const handleAddProhibitedTopic = () => {
    const val = newProhibitedTopicInput.trim();
    if (!val) return;
    if (prohibitedTopicsList.includes(val)) {
      showToast('الموضوع المحظور موجود بالفعل');
      return;
    }
    setProhibitedTopicsList((prev) => [...prev, val]);
    setNewProhibitedTopicInput('');
    playClickSound();
  };

  const handleRemoveProhibitedTopic = (index: number) => {
    setProhibitedTopicsList((prev) => prev.filter((_, i) => i !== index));
    playClickSound();
  };

  const handleSaveScope = async () => {
    setIsSavingScope(true);
    playClickSound();
    try {
      const res = await fetch('/api/admin/ai/config', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({
          ...aiConfig,
          strictBiologyScope,
          allowedTopics: allowedTopicsList,
          prohibitedTopics: prohibitedTopicsList,
          rejectionResponse: rejectionResponseText
        })
      });
      const data = await res.json();
      if (data.success) {
        setAiConfig(data.config);
        showToast('تم حفظ نطاق الإجابة والرفض واعتماده في الذكاء الاصطناعي بنجاح! 🛡️');
        playSuccessSound();
      } else {
        showToast('خطأ: ' + (data.error || 'تعذر الحفظ'));
      }
    } catch (e) {
      showToast('تعذر حفظ نطاق الإجابة والرفض');
    } finally {
      setIsSavingScope(false);
    }
  };

  // Live Test Google Gemini Connection
  const handleTestGeminiConnection = async () => {
    setIsTestingConnection(true);
    playClickSound();
    try {
      const res = await fetch('/api/admin/ai/test-connection', {
        method: 'POST',
        headers: authHeaders
      });
      const data = await res.json();
      if (data.success && data.connected) {
        setConnectionStatus({
          tested: true,
          connected: true,
          modelUsed: data.modelUsed,
          latencyMs: data.latencyMs,
          sampleResponse: data.sampleResponse,
          message: data.message
        });
        showToast(`الاتصال بـ Google Gemini متصل وفعال! ⚡ (${data.latencyMs}ms)`);
        playSuccessSound();
      } else {
        setConnectionStatus({
          tested: true,
          connected: false,
          error: data.error || 'تعذر الاتصال بالذكاء الاصطناعي'
        });
        showToast('فشل الاتصال: ' + (data.error || ''));
      }
    } catch (e: any) {
      setConnectionStatus({
        tested: true,
        connected: false,
        error: e.message || 'خطأ أثناء الاتصال'
      });
      showToast('خطأ أثناء فحص اتصال الذكاء الاصطناعي');
    } finally {
      setIsTestingConnection(false);
    }
  };

  // Save Pricing Handler
  const handleSavePricing = async () => {
    playClickSound();
    try {
      const res = await fetch('/api/admin/ai/pricing', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify(pricingConfig)
      });
      const data = await res.json();
      if (data.success) {
        showToast('تم تحديث بيانات الأسعار والاشتراكات بنجاح! 💰');
        playSuccessSound();
      }
    } catch (e) {
      showToast('تعذر حفظ الأسعار');
    }
  };

  // Save Contact Handler
  const handleSaveContact = async () => {
    playClickSound();
    try {
      const res = await fetch('/api/admin/ai/contact', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify(contactConfig)
      });
      const data = await res.json();
      if (data.success) {
        showToast('تم تحديث قنوات وسياسات التواصل مع الأستاذ بنجاح! 📞');
        playSuccessSound();
      }
    } catch (e) {
      showToast('تعذر حفظ بيانات التواصل');
    }
  };

  // Update Ticket Status Handler
  const handleUpdateTicketStatus = async (ticketId: string, status: 'new' | 'in_progress' | 'resolved') => {
    try {
      const res = await fetch(`/api/admin/ai/tickets/${ticketId}`, {
        method: 'PATCH',
        headers: authHeaders,
        body: JSON.stringify({
          status,
          adminNotes: ticketAdminNotes
        })
      });
      const data = await res.json();
      if (data.success) {
        showToast(`تم تحديث حالة البلاغ إلى (${status === 'resolved' ? 'تم الحل' : status}) بنجاح`);
        setSelectedTicket(null);
        loadAllAIData();
      }
    } catch (e) {
      showToast('تعذر تحديث البلاغ');
    }
  };

  // Playground Test Handler
  const handleRunPlaygroundTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testQuery.trim() || isTesting) return;

    playClickSound();
    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await fetch('/api/admin/ai/test', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({
          query: testQuery.trim(),
          customInstructionsOverride: customInstructionsText
        })
      });
      const data = await res.json();
      if (data.success) {
        setTestResult(data);
        playSuccessSound();
      } else {
        showToast(data.error || 'فحص التجربة لم ينجح');
      }
    } catch (e) {
      showToast('خطأ أثناء فحص السؤال');
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div dir="rtl" className="space-y-6 text-[#eaf0f8]">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-[#0d1f3c] via-[#091528] to-[#04080f] border border-[#e9c978]/30 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#c9a24a] to-[#e9c978] text-[#04080f] flex items-center justify-center font-bold text-2xl shadow-lg shadow-[#c9a24a]/25 shrink-0">
            🤖
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-bold font-amiri text-white">
                إدارة الذكاء الاصطناعي وتعليماته
              </h2>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                aiConfig.isEnabled 
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                  : 'bg-red-500/20 text-red-400 border border-red-500/30'
              }`}>
                {aiConfig.isEnabled ? 'المساعد نشط ويعمل' : 'المساعد متوقف حالياً'}
              </span>
            </div>
            <p className="text-xs text-gray-300 mt-1">
              مركز التوجيه والتعليم الذكي للأستاذ وسام سهيل العامري · تحكم كامل في القواعد، والأسعار، وسلوك الرد.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end md:self-auto">
          <button
            onClick={() => {
              playClickSound();
              loadAllAIData();
              showToast('تم تحديث جميع بيانات المساعد الذكي 🔄');
            }}
            disabled={isLoading}
            className="py-2.5 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 text-xs font-bold flex items-center gap-1.5 border border-white/10 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>تحديث البيانات</span>
          </button>
        </div>
      </div>

      {/* Real Google Gemini AI Status & Live Test Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#0b2447]/90 via-[#0a1b35]/90 to-[#050f1d] border border-sky-400/30 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/40 text-sky-400 flex items-center justify-center font-bold text-xl shrink-0">
            ⚡
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-white text-sm sm:text-base">
                محرك الذكاء الاصطناعي الحقيقي: Google Gemini API
              </span>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                متصل فعلياً عبر Google AI Studio
              </span>
            </div>
            <p className="text-xs text-gray-300 mt-1">
              النموذج المعتمد: <code className="text-sky-300 font-mono font-bold bg-black/40 px-1.5 py-0.5 rounded">gemini-3.1-flash-lite</code> · مفتاح API محمي بالكامل على الخادم الخلفي (Server-Side Proxy)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto shrink-0">
          <button
            onClick={handleTestGeminiConnection}
            disabled={isTestingConnection}
            className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md active:scale-95 transition disabled:opacity-50"
          >
            {isTestingConnection ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>جاري فحص الاتصال...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>فحص الاتصال بـ Gemini الآن ⚡</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Connection Result Card if tested */}
      {connectionStatus && (
        <div className={`p-4 rounded-2xl border text-xs animate-fadeIn ${
          connectionStatus.connected
            ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
            : 'bg-red-950/40 border-red-500/40 text-red-200'
        }`}>
          <div className="flex items-start gap-2.5">
            {connectionStatus.connected ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            )}
            <div className="space-y-1">
              <div className="font-bold text-sm text-white flex items-center gap-2 flex-wrap">
                <span>{connectionStatus.connected ? 'نجح فحص الاتصال بـ Google Gemini!' : 'فشل فحص الاتصال'}</span>
                {connectionStatus.latencyMs !== undefined && (
                  <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-black/40 text-sky-300">
                    {connectionStatus.latencyMs}ms
                  </span>
                )}
                {connectionStatus.modelUsed && (
                  <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-black/40 text-[#e9c978]">
                    {connectionStatus.modelUsed}
                  </span>
                )}
              </div>
              <p className="text-gray-200">
                {connectionStatus.message || connectionStatus.error}
              </p>
              {connectionStatus.sampleResponse && (
                <div className="mt-2 p-2.5 rounded-xl bg-black/50 border border-white/10 text-[11px] text-gray-300">
                  <span className="text-[#e9c978] font-bold">نموذج من الرد الفعلي للذكاء الاصطناعي:</span> «{connectionStatus.sampleResponse}»
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-white/5 border border-white/10 overflow-x-auto text-xs sm:text-sm font-bold scrollbar-none">
        <button
          onClick={() => { playClickSound(); setActiveTab('instructions'); }}
          className={`py-2.5 px-3.5 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'instructions'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20 font-bold'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>التعليمات الحرة للمدير</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('scope'); }}
          className={`py-2.5 px-3.5 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'scope'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20 font-bold'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <Filter className="w-4 h-4 text-sky-400" />
          <span>ما يجيب عنه وما يرفضه (نطاق المنصة)</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('rules'); }}
          className={`py-2.5 px-3.5 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'rules'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <ShieldAlert className="w-4 h-4 text-emerald-400" />
          <span>قواعد السؤال والجواب ({rulesList.length})</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('examples'); }}
          className={`py-2.5 px-3.5 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'examples'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <GraduationCap className="w-4 h-4 text-amber-300" />
          <span>علّم المساعد بمثال ({examplesList.length})</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('pricing'); }}
          className={`py-2.5 px-3.5 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'pricing'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <DollarSign className="w-4 h-4 text-emerald-300" />
          <span>الأسعار والاشتراكات</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('contact'); }}
          className={`py-2.5 px-3.5 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'contact'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <PhoneCall className="w-4 h-4 text-blue-300" />
          <span>التواصل مع المدرس</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('tickets'); }}
          className={`py-2.5 px-3.5 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'tickets'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <LifeBuoy className="w-4 h-4 text-purple-300" />
          <span>بلاغات الطلاب ({ticketsList.filter(t => t.status === 'new').length} جديدة)</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('playground'); }}
          className={`py-2.5 px-3.5 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'playground'
              ? 'bg-gradient-to-r from-[#3fa9f5] to-[#2083cb] text-black shadow-md shadow-[#3fa9f5]/25 font-black'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <Terminal className="w-4 h-4 text-[#3fa9f5]" />
          <span>اختبار المساعد (Playground)</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('settings'); }}
          className={`py-2.5 px-3.5 rounded-xl transition flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'settings'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/20'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>إعدادات النموذج</span>
        </button>
      </div>

      {/* ======================================================== */}
      {/* TAB 1: Natural Language Instructions (التعليمات الحرة للمدير) */}
      {/* ======================================================== */}
      {activeTab === 'instructions' && (
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-5">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#e9c978]" />
              تعليمات حرة يكتبها المدير باللغة العربية الطبيعية
            </h3>
            <p className="text-xs text-gray-300 mt-1">
              اكتب هنا كأنك توجّه موظفاً في مكتبك. كل جملة تكتبها هنا تُحقن مباشرة وبأولوية عليا في عقل المساعد الذكي عند كل محادثة!
            </p>
          </div>

          {/* Quick Insert Suggestions */}
          <div className="p-4 rounded-2xl bg-black/40 border border-[#e9c978]/25 space-y-2.5">
            <div className="text-xs font-bold text-[#e9c978] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              أمثلة وقوالب توجيهية جاهزة يمكنك إدراجها بضغطة واحدة:
            </div>
            <div className="flex flex-wrap gap-2 text-xs">
              <button
                type="button"
                onClick={() =>
                  insertInstructionSnippet(
                    'إذا سأل الطالب لماذا بعض المحاضرات لا تفتح، اسأله عن اسم المحاضرة أولاً. فإذا كانت المحاضرة مدفوعة، وضّح له بلطف أنها تتطلب كود اشتراك VIP، واعرض له السعر الفعلي المسجل في المنصة وخطوات الحصول على الكود من الأستاذ وسام سهيل. إياك أن تخترع كوداً أو سعراً من عندك.'
                  )
                }
                className="py-1.5 px-3 rounded-xl bg-white/5 hover:bg-[#e9c978]/20 border border-white/10 text-gray-200 hover:text-white transition"
              >
                + قاعدة التعامل مع المحاضرات المقفلة والأسعار
              </button>

              <button
                type="button"
                onClick={() =>
                  insertInstructionSnippet(
                    'إذا سأل الطالب عن مشكلة في تشغيل الفيديو أو حدوث تقطيع، اطلب منه التحقق من سرعة الإنترنت أو تحديث الصفحة، وإذا استمرت المشكلة وجّهه لفتح بلاغ دعم فني من زر المساعد ليتابعه الفريق التقني.'
                  )
                }
                className="py-1.5 px-3 rounded-xl bg-white/5 hover:bg-[#e9c978]/20 border border-white/10 text-gray-200 hover:text-white transition"
              >
                + خطوات تشخيص مشكلات الفيديو والدعم
              </button>

              <button
                type="button"
                onClick={() =>
                  insertInstructionSnippet(
                    'عند الإجابة عن أسئلة الأحياء الوزارية للسادس العلمي، اذكر دائماً رقم الفصل، والتعريف المعتمد في دليل المعلم، ونبّه الطالب على الكلمات المفتاحية التي يحاسب عليها المصحح الوزاري.'
                  )
                }
                className="py-1.5 px-3 rounded-xl bg-white/5 hover:bg-[#e9c978]/20 border border-white/10 text-gray-200 hover:text-white transition"
              >
                + أسلوب الإجابة الوزارية المعتمدة
              </button>
            </div>
          </div>

          {/* Large Text Area */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span>محرر التعليمات الحرة (Active System Instructions):</span>
              <span className="font-mono text-emerald-400">
                {customInstructionsText.length} حرف · {customInstructionsText.trim().split(/\s+/).filter(Boolean).length} كلمة
              </span>
            </div>

            <textarea
              rows={12}
              value={customInstructionsText}
              onChange={(e) => setCustomInstructionsText(e.target.value)}
              placeholder="اكتب تعليماتك وتوجيهاتك للمساعد هنا بحرية تامة وبأي لهجة أو لغة تناسبك..."
              className="w-full p-4 rounded-2xl bg-black/50 border border-white/15 focus:border-[#e9c978] focus:ring-1 focus:ring-[#e9c978] text-white text-sm leading-relaxed placeholder-gray-500 outline-none font-sans"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="text-xs text-gray-400">
              آخر تعديل محفوظ: {aiConfig.updatedAt ? new Date(aiConfig.updatedAt).toLocaleString('ar-IQ') : 'الآن'}
            </span>

            <button
              onClick={handleSaveCustomInstructions}
              disabled={isSavingConfig}
              className="py-3 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-sm flex items-center gap-2 shadow-lg shadow-[#c9a24a]/25 hover:brightness-110 active:scale-95 transition disabled:opacity-50"
            >
              {isSavingConfig ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>جارٍ الحفظ والاعتماد...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>حفظ التعليمات وتطبيقها فوراً</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB SCOPE: Control What AI Answers and What it Rejects (ما يجيب عنه وما يرفضه) */}
      {/* ======================================================== */}
      {activeTab === 'scope' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Header Card */}
          <div className="p-5 sm:p-6 rounded-3xl bg-white/5 border border-white/10 space-y-2">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Filter className="w-5 h-5 text-sky-400" />
              التحكم في نطاق الإجابة وما يرفضه الذكاء الاصطناعي (AI Scope & Guardrails)
            </h3>
            <p className="text-xs text-gray-300 leading-relaxed">
              تحكم كامل ومباشر في حدود تخصص المساعد الذكي: حدد مواضيع الأحياء والمنصة المسموح بالحديث عنها، والمواضيع الممنوعة التي يرفضها المساعد، مع صياغة رسالة الرفض التلقائية دون الحاجة لتعديل الكود البرمجي.
            </p>
          </div>

          {/* Master Scope Toggle */}
          <div className="p-5 rounded-2xl bg-black/40 border border-[#e9c978]/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <ShieldCheck className="w-5 h-5 text-[#e9c978]" />
                <span className="font-bold text-white text-sm sm:text-base">
                  حصر الذكاء الاصطناعي حصراً في منصة الأحياء والمنهج العراقي
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                  strictBiologyScope ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-gray-500/20 text-gray-400'
                }`}>
                  {strictBiologyScope ? 'مُفعّل (حماية صارمة)' : 'غير مُفعّل (نموذج عام)'}
                </span>
              </div>
              <p className="text-xs text-gray-300">
                عند تفعيل هذا الخيار، يُمنع النموذج منعاً باتاً من الإجابة عن المواد الدراسية الأخرى (كيمياء، فيزياء، رياضيات) أو المواضيع السياسية والعامة غير المرتبطة بالأحياء.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                playClickSound();
                setStrictBiologyScope((prev) => !prev);
              }}
              className={`py-2 px-4 rounded-xl font-bold text-xs flex items-center gap-2 transition shrink-0 ${
                strictBiologyScope
                  ? 'bg-emerald-500 text-black hover:bg-emerald-400 shadow-md shadow-emerald-500/25'
                  : 'bg-white/10 text-gray-300 hover:text-white'
              }`}
            >
              {strictBiologyScope ? (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>الحصر الصارم نشط</span>
                </>
              ) : (
                <>
                  <X className="w-4 h-4" />
                  <span>تعطيل الحصر</span>
                </>
              )}
            </button>
          </div>

          {/* Allowed vs Prohibited Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* 1. Allowed Topics */}
            <div className="p-5 rounded-2xl bg-white/5 border border-emerald-500/30 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <h4 className="font-bold text-white text-sm">المواضيع المسموح بالإجابة عنها ({allowedTopicsList.length})</h4>
                </div>
                <span className="text-[11px] text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-full font-bold">نطاق معتمد</span>
              </div>

              {/* Add Allowed Topic Form */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newAllowedTopicInput}
                  onChange={(e) => setNewAllowedTopicInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddAllowedTopic(); } }}
                  placeholder="أدخل موضوعاً مسموحاً به (مثال: علم التكاثر في النباتات)..."
                  className="flex-1 p-2.5 rounded-xl bg-black/40 border border-white/15 focus:border-emerald-400 text-white text-xs outline-none"
                />
                <button
                  type="button"
                  onClick={handleAddAllowedTopic}
                  className="py-2.5 px-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs flex items-center gap-1 transition shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة</span>
                </button>
              </div>

              {/* Allowed Topics List */}
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {allowedTopicsList.map((topic, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-black/30 border border-white/5 flex items-center justify-between gap-2 text-xs text-gray-200 hover:border-emerald-500/30 transition"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="w-5 h-5 rounded-md bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px] shrink-0">
                        ✓
                      </span>
                      <span className="truncate">{topic}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveAllowedTopic(idx)}
                      className="p-1 rounded-lg text-gray-400 hover:text-red-400 hover:bg-white/5 transition shrink-0"
                      title="حذف الموضوع"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* 2. Prohibited Topics */}
            <div className="p-5 rounded-2xl bg-white/5 border border-red-500/30 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-red-400" />
                  <h4 className="font-bold text-white text-sm">المواضيع الممنوعة والمرفوضة ({prohibitedTopicsList.length})</h4>
                </div>
                <span className="text-[11px] text-red-300 bg-red-500/10 px-2 py-0.5 rounded-full font-bold">محظور قطيعاً</span>
              </div>

              {/* Add Prohibited Topic Form */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newProhibitedTopicInput}
                  onChange={(e) => setNewProhibitedTopicInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddProhibitedTopic(); } }}
                  placeholder="أدخل موضوعاً محظوراً (مثال: حل مسائل مادة الكيمياء)..."
                  className="flex-1 p-2.5 rounded-xl bg-black/40 border border-white/15 focus:border-red-400 text-white text-xs outline-none"
                />
                <button
                  type="button"
                  onClick={handleAddProhibitedTopic}
                  className="py-2.5 px-3.5 rounded-xl bg-red-500 hover:bg-red-400 text-white font-bold text-xs flex items-center gap-1 transition shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة</span>
                </button>
              </div>

              {/* Prohibited Topics List */}
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {prohibitedTopicsList.map((topic, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-black/30 border border-white/5 flex items-center justify-between gap-2 text-xs text-gray-200 hover:border-red-500/30 transition"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="w-5 h-5 rounded-md bg-red-500/20 text-red-400 flex items-center justify-center font-bold text-[10px] shrink-0">
                        ✕
                      </span>
                      <span className="truncate">{topic}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveProhibitedTopic(idx)}
                      className="p-1 rounded-lg text-gray-400 hover:text-red-400 hover:bg-white/5 transition shrink-0"
                      title="حذف من قائمة الحظر"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Custom Rejection Response Card */}
          <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-amber-300" />
                صيغة الرفض اللبقة التلقائية عند السؤال عن موضوع خارج التخصص:
              </h4>
              <button
                type="button"
                onClick={() => {
                  setRejectionResponseText('عذراً يا بطل! أنا المساعد الذكي المخصص حصرياً لمنصة مختبر الأحياء للأستاذ وسام سهيل العامري. لا يمكنني الإجابة عن مواضيع خارج تخصص علم الأحياء أو خارج المنصة. يسعدني جداً مساعدتك في أي سؤال يخص مادة الأحياء، شروحات الدروس، أو اشتراكات المنصة! 🔬🧬');
                  playClickSound();
                }}
                className="text-[11px] text-amber-300 hover:underline"
              >
                استعادة الصيغة الافتراضية
              </button>
            </div>

            <textarea
              rows={3}
              value={rejectionResponseText}
              onChange={(e) => setRejectionResponseText(e.target.value)}
              placeholder="اكتب رسالة الرفض اللبقة التي يرد بها المساعد..."
              className="w-full p-3.5 rounded-xl bg-black/50 border border-white/15 focus:border-[#e9c978] text-white text-xs leading-relaxed outline-none resize-none"
            />
          </div>

          {/* Action Save Button */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <span className="text-xs text-gray-400">
              يتم حفظ هذه القواعد وتطبيقها مباشرة على مكالمات Google Gemini API دون أي تعديل في الكود.
            </span>
            <button
              onClick={handleSaveScope}
              disabled={isSavingScope}
              className="w-full sm:w-auto py-3 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#c9a24a]/25 hover:brightness-110 active:scale-95 transition disabled:opacity-50"
            >
              {isSavingScope ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>جاري الحفظ والاعتماد...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>حفظ نطاق الإجابة والرفض واعتماده فوراً</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: Structured Decision Rules Engine (قواعد السؤال والجواب) */}
      {/* ======================================================== */}
      {activeTab === 'rules' && (
        <div className="space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3 p-5 rounded-2xl bg-white/5 border border-white/10">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-emerald-400" />
                محرك قواعد الإجابة الموجهة (Deterministic Q&A Rules)
              </h3>
              <p className="text-xs text-gray-300 mt-1">
                تطبق هذه القواعد بأعلى أولوية قبل استدعاء نموذج الذكاء الاصطناعي لضمان إجابة محددة وثابتة للأسئلة الحساسة.
              </p>
            </div>

            <button
              onClick={() => {
                resetRuleForm();
                setEditingRule(null);
                setIsAddRuleOpen(true);
              }}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#2dd4bf] text-[#08111e] font-bold text-xs flex items-center gap-1.5 shadow-md hover:brightness-110 active:scale-95 transition"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة قاعدة جديدة</span>
            </button>
          </div>

          {/* Rules List */}
          <div className="grid grid-cols-1 gap-3">
            {rulesList.map((rule) => (
              <div
                key={rule.id}
                className="p-4 sm:p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-[#e9c978]/30 transition space-y-3"
              >
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{rule.name}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        rule.isActive !== false ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {rule.isActive !== false ? 'نشطة' : 'معطلة'}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/5 text-gray-300 font-mono">
                        أولوية: {rule.priority || 10}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-gray-400 flex-wrap">
                      <span>الكلمات المفتاحية:</span>
                      <div className="flex flex-wrap gap-1">
                        {(rule.triggers || rule.triggerKeywords || []).map((t: string, idx: number) => (
                          <span key={idx} className="px-2 py-0.5 rounded-lg bg-black/40 text-amber-300 font-mono text-[11px]">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleEditRuleClick(rule)}
                      className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition"
                      title="تعديل"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteRule(rule.id)}
                      className="p-2 rounded-xl bg-white/5 hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition"
                      title="حذف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-black/40 border border-white/5 text-xs text-gray-200 leading-relaxed whitespace-pre-line">
                  <strong className="text-[#e9c978] block mb-1">الرد أو التصرف المعتمد:</strong>
                  {rule.requiredResponse || rule.customResponse}
                </div>

                {(rule.includeInfo || rule.avoidInfo) && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                    {rule.includeInfo && (
                      <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300">
                        <strong>يجب تضمين:</strong> {rule.includeInfo}
                      </div>
                    )}
                    {rule.avoidInfo && (
                      <div className="p-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-300">
                        <strong>يمنع ذكر:</strong> {rule.avoidInfo}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Add / Edit Rule Modal */}
          {isAddRuleOpen && (
            <div className="fixed inset-0 z-[1050] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
              <div
                className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-3xl bg-[#0a1426] border border-[#e9c978]/40 shadow-2xl p-6 text-[#eaf0f8]"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
                  <h4 className="font-bold text-white text-base">
                    {editingRule ? 'تعديل قاعدة السؤال والجواب' : 'إنشاء قاعدة سؤال وجواب جديدة'}
                  </h4>
                  <button onClick={() => setIsAddRuleOpen(false)} className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form onSubmit={handleSaveRule} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block text-gray-300 font-semibold mb-1">اسم القاعدة:</label>
                    <input
                      type="text"
                      required
                      value={rName}
                      onChange={(e) => setRName(e.target.value)}
                      placeholder="مثال: الاستفسار عن كود تفعيل السادس العلمي"
                      className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-300 font-semibold mb-1">
                      صيغ السؤال والأمثلة الشائعة (مفصولة بفواصل):
                    </label>
                    <input
                      type="text"
                      required
                      value={rTriggers}
                      onChange={(e) => setRTriggers(e.target.value)}
                      placeholder="مثال: ليش المحاضرة مقفولة, كيف افتح الفيديو, السعر كم, اريد كود"
                      className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-300 font-semibold mb-1">الإجابة والتصرف المطلوب:</label>
                    <textarea
                      rows={4}
                      required
                      value={rRequiredResponse}
                      onChange={(e) => setRRequiredResponse(e.target.value)}
                      placeholder="اكتب الإجابة النموذجية التي يجب أن يرد بها المساعد..."
                      className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-emerald-400 font-semibold mb-1">معلومات يجب تضمينها:</label>
                      <input
                        type="text"
                        value={rIncludeInfo}
                        onChange={(e) => setRIncludeInfo(e.target.value)}
                        placeholder="سعر المحاضرة، خطوات التفعيل، رابط الواتساب"
                        className="w-full p-2 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-red-400 font-semibold mb-1">معلومات يجب تجنبها:</label>
                      <input
                        type="text"
                        value={rAvoidInfo}
                        onChange={(e) => setRAvoidInfo(e.target.value)}
                        placeholder="تخمين كود غير حقيقي، أسعار عشوائية"
                        className="w-full p-2 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-gray-300 font-semibold mb-1">أولوية القاعدة (1-100):</label>
                      <input
                        type="number"
                        value={rPriority}
                        onChange={(e) => setRPriority(Number(e.target.value))}
                        className="w-full p-2 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-6">
                      <input
                        type="checkbox"
                        id="ruleActive"
                        checked={rIsActive}
                        onChange={(e) => setRIsActive(e.target.checked)}
                        className="w-4 h-4 accent-[#0fb98a]"
                      />
                      <label htmlFor="ruleActive" className="text-gray-200 cursor-pointer">
                        تفعيل هذه القاعدة حالياً
                      </label>
                    </div>
                  </div>

                  <div className="pt-3 flex justify-end gap-2 border-t border-white/10">
                    <button
                      type="button"
                      onClick={() => setIsAddRuleOpen(false)}
                      className="py-2 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300"
                    >
                      إلغاء
                    </button>
                    <button
                      type="submit"
                      className="py-2 px-5 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold shadow-md hover:brightness-110"
                    >
                      حفظ القاعدة
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 3: Few-Shot Prompting / Training By Examples */}
      {/* ======================================================== */}
      {activeTab === 'examples' && (
        <div className="space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3 p-5 rounded-2xl bg-white/5 border border-white/10">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-amber-300" />
                علّم المساعد بمثال (Few-Shot Training by Examples)
              </h3>
              <p className="text-xs text-gray-300 mt-1">
                تدرّب هذه الأمثلة نموذج الذكاء الاصطناعي على أسلوب وطريقة صياغة الأستاذ وسام سهيل من خلال نماذج أسئلة وأجوبة واقعية.
              </p>
            </div>

            <button
              onClick={() => setIsAddExampleOpen(true)}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs flex items-center gap-1.5 shadow-md hover:brightness-110 active:scale-95 transition"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة مثال تدريبي جديد</span>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3.5">
            {examplesList.map((ex) => (
              <div
                key={ex.id}
                className="p-4 sm:p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2.5 hover:border-[#e9c978]/30 transition"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center font-bold text-xs">
                      س
                    </span>
                    <h4 className="font-bold text-white text-sm">{ex.question}</h4>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleEditExampleClick(ex)}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-[#e9c978]/20 text-gray-400 hover:text-[#e9c978] transition"
                      title="تعديل السؤال والجواب"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteExample(ex.id)}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition"
                      title="حذف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 text-xs text-emerald-300 leading-relaxed whitespace-pre-line flex items-start gap-2">
                  <span className="w-5 h-5 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold shrink-0 mt-0.5">
                    ج
                  </span>
                  <span>{ex.desiredAnswer}</span>
                </div>

                {ex.notes && (
                  <div className="text-[11px] text-gray-400 flex items-center gap-1">
                    <Info className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>ملاحظات توجيهية: {ex.notes}</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Add / Edit Example Modal */}
          {isAddExampleOpen && (
            <div className="fixed inset-0 z-[1050] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
              <div
                className="relative w-full max-w-lg rounded-3xl bg-[#0a1426] border border-[#e9c978]/40 shadow-2xl p-6 text-[#eaf0f8]"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
                  <h4 className="font-bold text-white text-base">
                    {editingExample ? 'تعديل السؤال والجواب النموذجي' : 'إضافة سؤال وجواب تدريبي جديد للمساعد'}
                  </h4>
                  <button
                    onClick={() => {
                      setIsAddExampleOpen(false);
                      setEditingExample(null);
                      setExQuestion('');
                      setExAnswer('');
                      setExNotes('');
                    }}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form onSubmit={handleSaveExample} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block text-gray-300 font-semibold mb-1">سؤال الطالب المتوقع:</label>
                    <input
                      type="text"
                      required
                      value={exQuestion}
                      onChange={(e) => setExQuestion(e.target.value)}
                      placeholder="مثال: أستاذ ما هي ميزة الأغشية شبه المنفذة؟"
                      className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-300 font-semibold mb-1">الجواب النموذجي الذي تريده أن يجيب به:</label>
                    <textarea
                      rows={5}
                      required
                      value={exAnswer}
                      onChange={(e) => setExAnswer(e.target.value)}
                      placeholder="اكتب الجواب الكامل والمثالي بأسلوبك..."
                      className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-300 font-semibold mb-1">ملاحظات أو توجيهات إضافية:</label>
                    <input
                      type="text"
                      value={exNotes}
                      onChange={(e) => setExNotes(e.target.value)}
                      placeholder="مثال: ركّز على ذكر أمثلة الغشاء البلازمي والسيلوفان"
                      className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                    />
                  </div>

                  <div className="pt-3 flex justify-end gap-2 border-t border-white/10">
                    <button
                      type="button"
                      onClick={() => {
                        setIsAddExampleOpen(false);
                        setEditingExample(null);
                        setExQuestion('');
                        setExAnswer('');
                        setExNotes('');
                      }}
                      className="py-2 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300"
                    >
                      إلغاء
                    </button>
                    <button
                      type="submit"
                      className="py-2 px-5 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold shadow-md hover:brightness-110"
                    >
                      {editingExample ? 'حفظ التعديلات' : 'إضافة المثال'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 4: Pricing & Subscriptions (الأسعار والاشتراكات) */}
      {/* ======================================================== */}
      {activeTab === 'pricing' && (
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-6">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-400" />
                إدارة الأسعار والاشتراكات لربطها بالذكاء الاصطناعي
              </h3>
              <p className="text-xs text-gray-300 mt-1">
                عندما يسأل الطالب عن سعر أي مرحلة أو محاضرة، يلتزم المساعد بهذه الأسعار المعتمدة حصراً ولا يخترع أي رقم من عنده.
              </p>
            </div>

            <button
              onClick={handleSavePricing}
              className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#2dd4bf] text-[#08111e] font-bold text-xs flex items-center gap-1.5 shadow-md hover:brightness-110 transition"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>حفظ جميع تحديثات الأسعار</span>
            </button>
          </div>

          {/* Individual Lecture Price */}
          <div className="p-4 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h4 className="font-bold text-white text-sm">سعر المحاضرة الفردية الافتراضي:</h4>
              <p className="text-xs text-gray-400">يُطبق على أي محاضرة مدفوعة لا يحدد لها سعر خاص في جدول المحاضرات.</p>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={pricingConfig.individualLectureDefaultPrice}
                onChange={(e) =>
                  setPricingConfig({
                    ...pricingConfig,
                    individualLectureDefaultPrice: Number(e.target.value)
                  })
                }
                className="w-32 p-2.5 rounded-xl bg-white/5 border border-white/20 text-white font-bold text-center outline-none"
              />
              <span className="text-xs text-emerald-400 font-bold">{pricingConfig.currency}</span>
            </div>
          </div>

          {/* Stage Packages Grid */}
          <div className="space-y-3">
            <h4 className="font-bold text-[#e9c978] text-sm">أسعار باقات المراحل الدراسية الشاملة:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {pricingConfig.packages.map((pkg, idx) => (
                <div key={pkg.gradeId} className="p-4 rounded-2xl bg-black/30 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm">{pkg.gradeName}</span>
                    <span className="text-xs text-gray-400 font-mono">{pkg.gradeId}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <label className="text-xs text-gray-300">السعر:</label>
                    <input
                      type="number"
                      value={pkg.fullPackagePrice}
                      onChange={(e) => {
                        const newPkgs = [...pricingConfig.packages];
                        newPkgs[idx].fullPackagePrice = Number(e.target.value);
                        setPricingConfig({ ...pricingConfig, packages: newPkgs });
                      }}
                      className="w-full p-2 rounded-lg bg-white/5 border border-white/15 text-white font-mono text-center outline-none"
                    />
                    <span className="text-[11px] text-gray-400 shrink-0">د.ع</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 4 Steps Editor */}
          <div className="space-y-3">
            <h4 className="font-bold text-[#e9c978] text-sm">خطوات الاشتراك الأربعة التي يوضحها المساعد للطالب:</h4>
            <div className="space-y-2">
              {pricingConfig.activationSteps.map((step, sIdx) => (
                <div key={sIdx} className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-[#e9c978]/20 text-[#e9c978] font-bold text-xs flex items-center justify-center shrink-0">
                    {sIdx + 1}
                  </span>
                  <input
                    type="text"
                    value={step}
                    onChange={(e) => {
                      const newSteps = [...pricingConfig.activationSteps];
                      newSteps[sIdx] = e.target.value;
                      setPricingConfig({ ...pricingConfig, activationSteps: newSteps });
                    }}
                    className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs outline-none"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 5: Teacher Contact & Policies (بيانات المدرس والتواصل) */}
      {/* ======================================================== */}
      {activeTab === 'contact' && (
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <PhoneCall className="w-5 h-5 text-blue-400" />
                بيانات المدرس وقنوات التواصل وسياسات التوجيه
              </h3>
              <p className="text-xs text-gray-300 mt-1">
                تحديد القنوات الرسمية ورسالة التوجيه والحالات التي يجب فيها تحويل الطالب إلى الأستاذ وسام سهيل العامري فوراً.
              </p>
            </div>

            <button
              onClick={handleSaveContact}
              className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs flex items-center gap-1.5 shadow-md hover:brightness-110 transition"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>حفظ بيانات وسياسات التواصل</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-gray-300 font-semibold mb-1">رقم الواتساب الرسمي للأستاذ:</label>
              <input
                type="text"
                value={contactConfig.whatsappNumber}
                onChange={(e) => setContactConfig({ ...contactConfig, whatsappNumber: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none font-mono"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1">رابط قناة التلغرام الرسمية:</label>
              <input
                type="text"
                value={contactConfig.telegramChannel}
                onChange={(e) => setContactConfig({ ...contactConfig, telegramChannel: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-gray-300 font-semibold mb-1">عنوان المعهد أو مكان التدريس الحضوري:</label>
              <input
                type="text"
                value={contactConfig.instituteAddress}
                onChange={(e) => setContactConfig({ ...contactConfig, instituteAddress: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-gray-300 font-semibold mb-1">الرسالة التوجيهية عند طلب التواصل:</label>
              <textarea
                rows={3}
                value={contactConfig.guidingMessage}
                onChange={(e) => setContactConfig({ ...contactConfig, guidingMessage: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none resize-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-gray-300 font-semibold mb-1">المعلومات التي يطلبها المساعد من الطالب قبل تحويله للأستاذ:</label>
              <input
                type="text"
                value={contactConfig.requiredInfoBeforeContact}
                onChange={(e) => setContactConfig({ ...contactConfig, requiredInfoBeforeContact: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
              />
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 6: Student Support Tickets (بلاغات ومشكلات الطلاب) */}
      {/* ======================================================== */}
      {activeTab === 'tickets' && (
        <div className="space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3 p-5 rounded-2xl bg-white/5 border border-white/10">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <LifeBuoy className="w-5 h-5 text-purple-400" />
                سجل بلاغات ومشكلات الطلاب التي شخصها المساعد الذكي
              </h3>
              <p className="text-xs text-gray-300 mt-1">
                عندما يشخص المساعد مشكلة تشغيل أو عطل فني لدى الطالب، يتم تسجيل هذا البلاغ هنا لمتابعته وحله.
              </p>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-1.5 bg-black/40 p-1 rounded-xl text-xs">
              <button
                onClick={() => setTicketFilter('all')}
                className={`py-1.5 px-3 rounded-lg transition ${ticketFilter === 'all' ? 'bg-[#e9c978] text-[#08111e] font-bold' : 'text-gray-400'}`}
              >
                الكل ({ticketsList.length})
              </button>
              <button
                onClick={() => setTicketFilter('new')}
                className={`py-1.5 px-3 rounded-lg transition ${ticketFilter === 'new' ? 'bg-amber-400 text-[#08111e] font-bold' : 'text-gray-400'}`}
              >
                الجديدة ({ticketsList.filter((t) => t.status === 'new').length})
              </button>
              <button
                onClick={() => setTicketFilter('resolved')}
                className={`py-1.5 px-3 rounded-lg transition ${ticketFilter === 'resolved' ? 'bg-[#0fb98a] text-[#08111e] font-bold' : 'text-gray-400'}`}
              >
                تم الحل ({ticketsList.filter((t) => t.status === 'resolved').length})
              </button>
            </div>
          </div>

          {/* Tickets list */}
          <div className="grid grid-cols-1 gap-3">
            {ticketsList
              .filter((t) => (ticketFilter === 'all' ? true : t.status === ticketFilter))
              .map((ticket) => (
                <div
                  key={ticket.id}
                  className="p-4 sm:p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3 hover:border-purple-500/30 transition"
                >
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{ticket.studentName}</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/10 text-gray-300">
                          {ticket.studentGrade}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            ticket.status === 'resolved'
                              ? 'bg-[#0fb98a]/20 text-[#0fb98a] border border-[#0fb98a]/30'
                              : ticket.status === 'in_progress'
                              ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                          }`}
                        >
                          {ticket.status === 'resolved' ? 'تم الحل ✅' : ticket.status === 'in_progress' ? 'قيد المتابعة ⏳' : 'جديد ⚠️'}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-400">
                        {ticket.createdAt ? new Date(ticket.createdAt).toLocaleString('ar-IQ') : ''} · تصنيف المشكلة: {ticket.issueCategory}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      {ticket.status !== 'resolved' && (
                        <button
                          onClick={() => handleUpdateTicketStatus(ticket.id, 'resolved')}
                          className="py-1.5 px-3 rounded-xl bg-[#0fb98a]/20 hover:bg-[#0fb98a]/30 text-[#0fb98a] border border-[#0fb98a]/40 font-bold text-xs transition"
                        >
                          تحديد كـ "تم الحل"
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-black/40 border border-white/5 text-xs text-gray-200 leading-relaxed whitespace-pre-line">
                    {ticket.lectureTitle && (
                      <div className="text-[#e9c978] font-bold mb-1">
                        المحاضرة: {ticket.lectureTitle}
                      </div>
                    )}
                    {ticket.description}
                  </div>

                  {ticket.adminNotes && (
                    <div className="text-[11px] text-emerald-400 p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                      <strong>ملاحظة الإدارة:</strong> {ticket.adminNotes}
                    </div>
                  )}
                </div>
              ))}

            {ticketsList.length === 0 && (
              <div className="p-8 text-center text-gray-400 rounded-2xl bg-white/5 border border-white/10 text-xs">
                لا توجد بلاغات مسجلة حالياً.
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 7: AI Playground / Diagnostic Tester (اختبار المساعد) */}
      {/* ======================================================== */}
      {activeTab === 'playground' && (
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-6">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Terminal className="w-5 h-5 text-[#3fa9f5]" />
              صندوق اختبار المساعد ومعاينة التشخيص المباشر (Playground Tester)
            </h3>
            <p className="text-xs text-gray-300 mt-1">
              جرّب أي سؤال يطرحه الطالب وشاهد كيف يستجيب المساعد، مع كشف كامل للقواعد المطبقة والمصادر وزمن الاستجابة بالمللي ثانية!
            </p>
          </div>

          <form onSubmit={handleRunPlaygroundTest} className="space-y-3">
            <div className="relative">
              <textarea
                rows={3}
                value={testQuery}
                onChange={(e) => setTestQuery(e.target.value)}
                placeholder="اكتب سؤالاً تجريبياً هنا (مثال: ليش المحاضرة رقم 3 بالسادس العلمي مقفولة وما سعرها؟)"
                className="w-full p-4 rounded-2xl bg-black/50 border border-white/20 text-white text-xs sm:text-sm placeholder-gray-500 outline-none focus:border-[#3fa9f5]"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <Activity className="w-4 h-4 text-emerald-400" />
                <span>يختبر التعليمات الحرة وقواعد المنع وأحدث الأسعار المسجلة</span>
              </div>

              <button
                type="submit"
                disabled={isTesting || !testQuery.trim()}
                className="py-2.5 px-6 rounded-2xl bg-gradient-to-r from-[#3fa9f5] to-[#2083cb] text-black font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-[#3fa9f5]/25 hover:brightness-110 active:scale-95 transition disabled:opacity-50"
              >
                {isTesting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جارٍ الفحص والمعالجة...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>فحص الرد والتشخيص</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Test Result Display */}
          {testResult && (
            <div className="p-5 rounded-2xl bg-black/60 border border-[#3fa9f5]/40 space-y-4 animate-fadeIn text-xs">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span className="font-bold text-white text-sm">نتيجة الاختبار وتشخيص الاستجابة:</span>
                </div>
                <div className="flex items-center gap-2 font-mono text-[11px]">
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">
                    ⏱️ {testResult.executionTimeMs} ms
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300">
                    🧠 {testResult.trace?.modelUsed || 'gemini-3.8-flash'}
                  </span>
                </div>
              </div>

              {/* Generated Answer */}
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-gray-100 text-sm leading-relaxed whitespace-pre-line">
                <strong className="text-[#e9c978] block text-xs mb-1">الرد المولد الذي سيظهر للطالب:</strong>
                {testResult.answer}
              </div>

              {/* Diagnostic Trace Badges */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-[11px] text-gray-300 font-mono">
                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-gray-400 block">القاعدة المطبقة:</span>
                  <strong className={testResult.trace?.matchedRule ? 'text-amber-300' : 'text-gray-400'}>
                    {testResult.trace?.matchedRule ? testResult.trace.matchedRule.name : 'لا توجد (مُعالج بالنموذج)'}
                  </strong>
                </div>

                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-gray-400 block">المحاضرات المطابقة من الداتابيس:</span>
                  <strong className="text-emerald-400">
                    {testResult.trace?.matchedLectures?.length || 0} محاضرة
                  </strong>
                </div>

                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-gray-400 block">تشخيص المشكلة:</span>
                  <strong className="text-purple-300">
                    {testResult.trace?.problemDiagnosis ? testResult.trace.problemDiagnosis.category : 'استفسار عام'}
                  </strong>
                </div>
              </div>

              {/* System Prompt Peek */}
              {testResult.trace?.effectiveSystemPrompt && (
                <div className="pt-2 border-t border-white/10">
                  <button
                    onClick={() => setShowFullSystemPrompt(!showFullSystemPrompt)}
                    className="text-[11px] text-[#3fa9f5] hover:underline flex items-center gap-1 font-mono"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{showFullSystemPrompt ? 'إخفاء السياق الكامل المحقون' : 'عرض السياق الكامل (System Prompt) المحقون في المحرك'}</span>
                  </button>

                  {showFullSystemPrompt && (
                    <pre className="mt-2 p-3 rounded-xl bg-black/80 border border-white/10 text-[10px] text-gray-300 font-mono whitespace-pre-wrap max-h-60 overflow-y-auto">
                      {testResult.trace.effectiveSystemPrompt}
                    </pre>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 8: Settings & Master Controls (إعدادات النموذج والتحكم العام) */}
      {/* ======================================================== */}
      {activeTab === 'settings' && (
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-6">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sliders className="w-5 h-5 text-[#e9c978]" />
                إعدادات المساعد والتحكم العام
              </h3>
              <p className="text-xs text-gray-300 mt-1">
                تفعيل/تعطيل المساعد، اختيار نموذج الذكاء الاصطناعي، ضبط درجة الإبداع، وتعديل رسالة الترحيب الأولى.
              </p>
            </div>

            <button
              onClick={handleSaveCustomInstructions}
              className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs flex items-center gap-1.5 shadow-md hover:brightness-110 transition"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>حفظ الإعدادات</span>
            </button>
          </div>

          <div className="space-y-4 text-xs">
            {/* Master Toggle */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-black/40 border border-white/10">
              <div>
                <h4 className="font-bold text-white text-sm">حالة المساعد الذكي في المنصة:</h4>
                <p className="text-xs text-gray-400">عند التعطيل، تختفي أيقونة المحادثة من شاشات الطلاب.</p>
              </div>

              <button
                type="button"
                onClick={() => setAiConfig({ ...aiConfig, isEnabled: !aiConfig.isEnabled })}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition ${
                  aiConfig.isEnabled ? 'bg-emerald-500 text-black' : 'bg-red-500/20 text-red-300 border border-red-500/30'
                }`}
              >
                {aiConfig.isEnabled ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
                <span>{aiConfig.isEnabled ? 'المساعد مفعل' : 'المساعد معطل'}</span>
              </button>
            </div>

            {/* Model Selector */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-300 font-semibold mb-1">نموذج الذكاء الاصطناعي المعتمد:</label>
                <select
                  value={aiConfig.model}
                  onChange={(e) => setAiConfig({ ...aiConfig, model: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-white/5 border border-white/15 text-white outline-none"
                >
                  <option value="gemini-3.8-flash">Gemini 3.8 Flash (سريع، دقيق، موصى به للمناهج)</option>
                  <option value="gemini-flash-latest">Gemini Flash Latest</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">
                  درجة الإبداع والالتزام (Temperature: {aiConfig.temperature ?? 0.7}):
                </label>
                <input
                  type="range"
                  min="0.1"
                  max="1.0"
                  step="0.05"
                  value={aiConfig.temperature ?? 0.7}
                  onChange={(e) => setAiConfig({ ...aiConfig, temperature: parseFloat(e.target.value) })}
                  className="w-full accent-[#e9c978] mt-2 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-gray-400 mt-1">
                  <span>0.1 (التزام حرفي تام بالقواعد والأسعار)</span>
                  <span>1.0 (إجابات إبداعية موسعة)</span>
                </div>
              </div>
            </div>

            {/* Welcome Message */}
            <div>
              <label className="block text-gray-300 font-semibold mb-1">رسالة الترحيب الافتتاحية للمحادثة:</label>
              <textarea
                rows={3}
                value={aiConfig.welcomeMessage}
                onChange={(e) => setAiConfig({ ...aiConfig, welcomeMessage: e.target.value })}
                className="w-full p-3 rounded-xl bg-white/5 border border-white/15 text-white outline-none resize-none leading-relaxed"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
