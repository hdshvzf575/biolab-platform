import React from 'react';
import { 
  Home, 
  Video, 
  GraduationCap, 
  BookOpen, 
  Library, 
  Building2, 
  Phone,
  Award,
  Dna
} from 'lucide-react';
import { motion } from 'motion/react';
import { playClickSound } from '../utils/audioEffects';

interface NavigationDockProps {
  currentScreen: string;
  onNavigate: (screenId: string) => void;
}

export const NavigationDock: React.FC<NavigationDockProps> = ({
  currentScreen,
  onNavigate
}) => {
  const dockItems = [
    { id: 'home', label: 'الرئيسية', icon: Home, emoji: '🏠' },
    { id: 'books', label: 'الكتب والملازم', icon: BookOpen, emoji: '📚' },
    { id: 'lectures', label: 'المحاضرات', icon: Video, emoji: '📺' },
    { id: 'institute-students', label: 'طلاب المعهد', icon: Award, emoji: '🎯' },
    { id: 'grades', label: 'المراحل', icon: GraduationCap, emoji: '🎓' },
    { id: 'lessons', label: 'المنهج', icon: Library, emoji: '📖' },
    { id: 'institute', label: 'المعهد', icon: Building2, emoji: '🏫' },
    { id: 'contact', label: 'تواصل', icon: Phone, emoji: '💬' },
  ];

  return (
    <nav 
      aria-label="التنقل السريع"
      className="fixed bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 z-[700] w-[min(94%,680px)] pointer-events-none"
    >
      <div className="pointer-events-auto p-1.5 rounded-full bg-[#08111e]/90 backdrop-blur-2xl border border-[#e9c978]/30 shadow-[0_12px_36px_rgba(0,0,0,0.65)] flex items-center justify-between gap-1 overflow-x-auto no-scrollbar">
        {dockItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.id;

          return (
            <button
              key={item.id}
              onClick={() => {
                playClickSound();
                onNavigate(item.id);
              }}
              className={`relative flex-1 py-2 sm:py-2.5 px-2 rounded-full flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 transition-colors duration-200 text-[11px] sm:text-xs font-bold outline-none select-none ${
                isActive 
                  ? 'text-[#08111e]' 
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {/* Active animated floating pill */}
              {isActive && (
                <motion.div
                  layoutId="activeDockPill"
                  className="absolute inset-0 rounded-full bg-gradient-to-r from-[#e9c978] via-[#f3dc98] to-[#c9a24a] shadow-lg shadow-[#c9a24a]/30"
                  transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                />
              )}

              <span className="relative z-10 flex items-center justify-center">
                <Icon className={`w-4 h-4 sm:w-4 sm:h-4 transition-transform ${isActive ? 'scale-110 stroke-[2.5]' : 'stroke-2'}`} />
              </span>

              <span className={`relative z-10 transition-all truncate leading-none ${isActive ? 'font-black' : 'font-medium'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
