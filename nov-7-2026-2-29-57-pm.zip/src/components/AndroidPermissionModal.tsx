import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Download, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Settings, 
  X, 
  Sparkles,
  ArrowRight,
  BookOpen,
  Lock,
  Smartphone,
  Info
} from 'lucide-react';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { 
  requestNotificationPermission, 
  requestStorageAccess, 
  checkNotificationPermission, 
  checkStorageAccess, 
  androidPermissionBridge, 
  PermissionState, 
  PermissionType 
} from '../services/androidPermissionBridge';

interface AndroidPermissionModalProps {
  isOpen: boolean;
  permissionType: PermissionType;
  targetTitle?: string;
  onClose: () => void;
  onPermissionGranted?: () => void;
  onPermissionDenied?: () => void;
}

export const AndroidPermissionModal: React.FC<AndroidPermissionModalProps> = ({
  isOpen,
  permissionType,
  targetTitle,
  onClose,
  onPermissionGranted,
  onPermissionDenied
}) => {
  const [permissionState, setPermissionState] = useState<PermissionState>('prompt');
  const [isRequesting, setIsRequesting] = useState<boolean>(false);
  const [showSuccessToast, setShowSuccessToast] = useState<boolean>(false);
  const [denialNotice, setDenialNotice] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setDenialNotice(false);
      checkCurrentStatus();
    }
  }, [isOpen, permissionType]);

  const checkCurrentStatus = async () => {
    try {
      if (permissionType === 'notifications') {
        const state = await checkNotificationPermission();
        setPermissionState(state);
      } else {
        const state = await checkStorageAccess();
        setPermissionState(state);
      }
    } catch (e) {
      setPermissionState('prompt');
    }
  };

  if (!isOpen) return null;

  const isAndroid = androidPermissionBridge.isAndroidNative();
  const androidSdk = androidPermissionBridge.getAndroidSdkVersion();

  const handleTriggerNativePermission = async () => {
    playClickSound();
    setIsRequesting(true);
    setDenialNotice(false);

    try {
      let isGranted = false;

      // Call the corresponding bridge function that triggers official OS dialog
      if (permissionType === 'notifications') {
        isGranted = await requestNotificationPermission();
      } else {
        isGranted = await requestStorageAccess();
      }

      if (isGranted) {
        playSuccessSound();
        setShowSuccessToast(true);
        setPermissionState('granted');
        setTimeout(() => {
          setShowSuccessToast(false);
          if (onPermissionGranted) onPermissionGranted();
          onClose();
        }, 1200);
      } else {
        setPermissionState('denied');
        setDenialNotice(true);
        if (onPermissionDenied) onPermissionDenied();
      }
    } catch (err) {
      console.warn('Permission request execution error:', err);
      setDenialNotice(true);
    } finally {
      setIsRequesting(false);
    }
  };

  const handleOpenSettings = () => {
    playClickSound();
    if (permissionType === 'notifications') {
      androidPermissionBridge.openNotificationSettings();
    } else {
      androidPermissionBridge.openAppSettings();
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn select-none">
      <div 
        className="relative w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#0a1424] via-[#060c18] to-[#04080f] border border-[#e9c978]/40 shadow-2xl p-5 sm:p-7 text-right text-white space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow Ambient Lights */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#e9c978]/10 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#0fb98a]/10 rounded-full blur-3xl pointer-events-none -ml-16 -mb-16" />

        {/* Top Bar: OS Badge & Close Button */}
        <div className="flex items-center justify-between gap-3 relative z-10 border-b border-white/10 pb-3">
          <button
            onClick={() => { playClickSound(); onClose(); }}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition"
            title="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2">
            <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-[#e9c978]/15 border border-[#e9c978]/30 text-[#e9c978] font-bold flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5" />
              <span>{isAndroid ? `نظام Android ${androidSdk > 0 ? `(API ${androidSdk})` : ''}` : 'إذن المتصفح / Web'}</span>
            </span>
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-[#c9a24a] to-[#e9c978] text-[#04080f] flex items-center justify-center shadow-lg shadow-[#c9a24a]/25">
              {permissionType === 'notifications' ? (
                <Bell className="w-4 h-4 fill-current" />
              ) : (
                <Download className="w-4 h-4 stroke-[2.5]" />
              )}
            </div>
          </div>
        </div>

        {/* Header & Academic Subtitle */}
        <div className="space-y-1.5 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#0fb98a]/15 text-[#0fb98a] border border-[#0fb98a]/30">
            <Sparkles className="w-3 h-3" />
            <span>طلب إذن نظام رسمي · منصة الكائنات</span>
          </div>

          <h3 className="font-amiri font-bold text-xl sm:text-2xl text-white leading-snug">
            {permissionType === 'notifications' 
              ? 'تفعيل إشعارات وتنبيهات الأحياء'
              : 'إذن حفظ وتنزيل الكتب على جهازك'}
          </h3>

          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
            {permissionType === 'notifications' ? (
              'نطلب هذا الإذن لنوفر لك إشعارات فورية بكل ما يخص دراستك وامتحاناتك الوزارية مباشرة من الأستاذ وسام سهيل العامري.'
            ) : (
              <>
                نطلب هذا الإذن لحفظ ملف <strong className="text-[#e9c978]">{targetTitle || 'الكتاب المنهجي أو الملزمة'}</strong> في مجلد التنزيلات (Downloads) بجهازك لتتمكن من القراءة بدون إنترنت.
              </>
            )}
          </p>
        </div>

        {/* Detailed Rationale Section (لماذا نطلب الإذن؟) */}
        <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3 relative z-10 text-xs">
          <div className="font-bold text-[#e9c978] flex items-center gap-1.5 pb-1 border-b border-white/5">
            <Info className="w-4 h-4" />
            <span>لماذا يحتاج التطبيق إلى هذا الإذن؟</span>
          </div>

          {permissionType === 'notifications' ? (
            <div className="space-y-2.5 text-gray-200">
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-lg bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <span><strong>محاضرات جديدة:</strong> تنبيه فوري بالاسم فور رفع محاضرة أو مراجعة مركزة لصفك الدراسي.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-lg bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center shrink-0 mt-0.5">
                  <Sparkles className="w-3.5 h-3.5" />
                </div>
                <span><strong>تنبيهات الامتحانات:</strong> جداول مواعيد الامتحانات الوزارية وبنوك الأسئلة الشاملة.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0 mt-0.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                </div>
                <span><strong>خصوصية وتحكم تام:</strong> بدون إعلانات مزعجة، مع إمكانية إيقاف الإشعارات في أي وقت من إعدادات الهاتف.</span>
              </div>
            </div>
          ) : (
            <div className="space-y-2.5 text-gray-200">
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-lg bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <span><strong>تنزيل مباشر:</strong> حفظ نسخة PDF الأصلية في مجلد التنزيلات (Downloads) بهاتفك لتسهيل طباعتها أو مشاركتها.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-lg bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center shrink-0 mt-0.5">
                  <BookOpen className="w-3.5 h-3.5" />
                </div>
                <span><strong>دراسة أوفلاين:</strong> قراءة وتصفح الكتاب والملزمة في أي وقت وبدون الحاجة لأي اتصال بالإنترنت.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Lock className="w-3.5 h-3.5" />
                </div>
                <span><strong>أمان الملفات (Scoped Storage):</strong> التطبيق لا يطلب ولا يملك حق الوصول لأي من صورك أو ملفاتك الخاصة نهائياً.</span>
              </div>
            </div>
          )}
        </div>

        {/* Two-Step Guidance Banner */}
        <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2.5 text-[11px] text-gray-300">
          <span className="text-base">💡</span>
          <span>
            عند الضغط على الزر أدناه، ستظهر لك <strong>نافذة نظام أندرويد الرسمية</strong>، يرجى اختيار <strong>«السماح» (Allow)</strong> لتفعيل الميزة.
          </span>
        </div>

        {/* Success Confirmation Banner */}
        {showSuccessToast && (
          <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>تم منح الإذن وتفعيل الميزة بنجاح! شكراً لك 🎉</span>
          </div>
        )}

        {/* Rejection / Denied State with settings link */}
        {(denialNotice || permissionState === 'denied') && !showSuccessToast && (
          <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-200 text-xs space-y-2">
            <div className="flex items-center gap-2 font-bold text-amber-300">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>تم رفض الإذن أو تم تقييده مسبقاً في إعدادات جهازك</span>
            </div>
            <p className="text-[11px] leading-relaxed text-gray-300">
              لن يتم تعطيل أي ميزة أساسية بالمنصة، ولكن للاستفادة الكاملة من هذه الخاصية يمكنك تفعيلها يدوياً بالنقر على &quot;فتح إعدادات الهاتف&quot;.
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-2 relative z-10">
          {(denialNotice || permissionState === 'denied') ? (
            <button
              type="button"
              onClick={handleOpenSettings}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-xs sm:text-sm shadow-lg hover:brightness-110 active:scale-98 transition flex items-center justify-center gap-2"
            >
              <Settings className="w-4 h-4" />
              <span>فتح إعدادات الهاتف لتفعيل الإذن ⚙️</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleTriggerNativePermission}
              disabled={isRequesting}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#059669] text-black font-black text-xs sm:text-sm shadow-lg shadow-[#0fb98a]/25 hover:brightness-110 active:scale-98 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {permissionType === 'notifications' ? (
                <>
                  <Bell className="w-4 h-4 fill-black" />
                  <span>{isRequesting ? 'جاري فتح نافذة النظام...' : 'الموافقة ومتابعة الإذن بالنظام 🔔'}</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 stroke-[2.5]" />
                  <span>{isRequesting ? 'جاري فتح نافذة النظام...' : 'السماح بالحفظ وبدء التنزيل 📥'}</span>
                </>
              )}
            </button>
          )}

          <button
            type="button"
            onClick={() => { playClickSound(); onClose(); }}
            className="w-full sm:w-auto py-3.5 px-5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 text-xs font-bold transition shrink-0"
          >
            لاحقاً
          </button>
        </div>

      </div>
    </div>
  );
};
