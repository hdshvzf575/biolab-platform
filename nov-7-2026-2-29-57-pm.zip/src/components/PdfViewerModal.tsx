import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Download,
  X,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  Bookmark,
  Search,
  RotateCw,
  ExternalLink,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  Moon,
  Sun,
  FileText
} from 'lucide-react';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { downloadFileDirectly } from '../utils/fileDownloader';

export interface ViewerBookData {
  id?: string;
  title: string;
  grade?: string;
  author?: string;
  pdfUrl?: string | null;
  fileUrl?: string | null;
  fileId?: string;
  driveUrl?: string;
  driveId?: string;
  driveAccessStatus?: string;
  pages?: number | string;
  icon?: string;
  sourceType?: 'direct-pdf' | 'school-repo' | 'open-access' | 'external-source';
  fileSize?: string;
  isAvailable?: boolean;
  verificationStatus?: 'verified' | 'pending' | 'unavailable';
  officialSource?: string;
}

interface PdfViewerModalProps {
  book: ViewerBookData | null;
  onClose: () => void;
}

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({ book, onClose }) => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const totalPages = typeof book?.pages === 'number' ? book.pages : (book?.pages ? parseInt(String(book.pages), 10) || 150 : 150);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [fitMode, setFitMode] = useState<'normal' | 'fit-width'>('normal');
  const [readingFilter, setReadingFilter] = useState<'normal' | 'sepia' | 'night' | 'dark' | 'none'>('normal');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadToast, setDownloadToast] = useState<string | null>(null);
  const [hasSavedProgress, setHasSavedProgress] = useState(false);
  const [savedPageNumber, setSavedPageNumber] = useState(1);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  if (!book) return null;

  // Determine actual target URL for the PDF
  const rawUrl = (book.pdfUrl || book.fileUrl || book.driveUrl || '').trim();
  let effectivePdfUrl = '';

  const extractDriveFileId = (str: string): string | null => {
    if (!str) return null;
    const match = str.match(/\/file\/d\/([a-zA-Z0-9_-]+)/i) || str.match(/[?&]id=([a-zA-Z0-9_-]+)/i);
    return match ? match[1] : null;
  };

  const detectedDriveId = book.driveId || extractDriveFileId(rawUrl);

  if (rawUrl && rawUrl.startsWith('/uploads/')) {
    effectivePdfUrl = rawUrl;
  } else if (book.id && (book.id.startsWith('b') || book.id.startsWith('curriculum_'))) {
    effectivePdfUrl = `/api/books/drive-proxy/${book.id}`;
  } else if (detectedDriveId) {
    effectivePdfUrl = `/api/stream-drive/${detectedDriveId}`;
  } else if (rawUrl && (rawUrl.startsWith('http://') || rawUrl.startsWith('https://'))) {
    if (rawUrl.includes('drive.google.com') || rawUrl.includes('docs.google.com')) {
      const dId = extractDriveFileId(rawUrl);
      effectivePdfUrl = dId ? `/api/stream-drive/${dId}` : `/api/books/stream?url=${encodeURIComponent(rawUrl)}`;
    } else {
      effectivePdfUrl = `/api/books/stream?url=${encodeURIComponent(rawUrl)}`;
    }
  } else if (book.id) {
    effectivePdfUrl = `/api/books/drive-proxy/${book.id}`;
  }

  const isBookUnavailable = book.isAvailable === false || (!rawUrl && !book.id && !detectedDriveId);

  // If book is marked unavailable, show polite academic notice instead of wrong/blank PDF
  if (isBookUnavailable) {
    return (
      <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
        <div
          className="relative w-full max-w-md rounded-3xl bg-[#0a1220] border border-[#e9c978]/40 shadow-2xl p-6 text-center text-[#eaf0f8] space-y-4"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center text-3xl mx-auto shadow-inner">
            ⚠️
          </div>
          <div>
            <h3 className="font-amiri font-bold text-xl text-[#e9c978] mb-1">
              النسخة الأصلية غير متوفرة حالياً
            </h3>
            <span className="text-xs text-gray-400 font-bold">
              {book.title}
            </span>
          </div>
          <p className="text-xs text-gray-300 leading-relaxed bg-black/40 p-3.5 rounded-2xl border border-white/5">
            النسخة الإلكترونية الأصلية المعتمدة لهذا الكتاب غير متوفرة حالياً في مستودع الوزارة أو جاري التحقق من طبعتها الرسمية لعام 2024. التزاماً بالأمانة العلمية للمنصة، لا يتم عرض كتاب وهمي بديل.
          </p>
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-2">
            <button
              onClick={onClose}
              className="w-full sm:w-auto py-2.5 px-6 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-xs shadow-md hover:brightness-110 transition"
            >
              العودة للمكتبة
            </button>
            {book.officialSource && (
              <a
                href={book.officialSource}
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-gray-200 font-bold text-xs flex items-center justify-center gap-1.5 transition"
              >
                <span>موقع وزارة التربية</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Book identifier for bookmarking
  const bookKey = `biolab_pdf_bookmark_${book.id || book.title.replace(/\s+/g, '_')}`;

  // Check saved bookmark from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(bookKey);
      if (saved) {
        const pageNum = parseInt(saved, 10);
        if (!isNaN(pageNum) && pageNum > 1) {
          setHasSavedProgress(true);
          setSavedPageNumber(pageNum);
        }
      }
    } catch (e) {}
  }, [bookKey]);

  // Save current page to localStorage whenever it changes
  const saveBookmark = useCallback((page: number) => {
    try {
      localStorage.setItem(bookKey, page.toString());
      setSavedPageNumber(page);
      setHasSavedProgress(true);
    } catch (e) {}
  }, [bookKey]);

  const handlePageChange = (newPage: number) => {
    const valid = Math.max(1, Math.min(totalPages, newPage));
    setCurrentPage(valid);
    saveBookmark(valid);
    playClickSound();
  };

  const handleResumeReading = () => {
    playSuccessSound();
    setCurrentPage(savedPageNumber);
    setHasSavedProgress(false);
  };

  // Zoom controls
  const zoomIn = () => {
    playClickSound();
    setZoomLevel(prev => Math.min(prev + 25, 250));
    setFitMode('normal');
  };

  const zoomOut = () => {
    playClickSound();
    setZoomLevel(prev => Math.max(prev - 25, 50));
    setFitMode('normal');
  };

  const resetZoom = () => {
    playClickSound();
    setZoomLevel(100);
    setFitMode('normal');
  };

  const toggleFitWidth = () => {
    playClickSound();
    if (fitMode === 'fit-width') {
      setFitMode('normal');
      setZoomLevel(100);
    } else {
      setFitMode('fit-width');
      setZoomLevel(120);
    }
  };

  // Fullscreen toggle
  const toggleFullscreen = () => {
    playClickSound();
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().then(() => {
        setIsFullscreen(true);
      }).catch(() => {});
    } else {
      document.exitFullscreen?.().then(() => {
        setIsFullscreen(false);
      }).catch(() => {});
    }
  };

  // Direct Download Trigger
  const handleDirectDownload = async () => {
    playClickSound();
    setIsDownloading(true);
    setDownloadToast('جاري بدء التنزيل المباشر إلى جهازك...');

    await downloadFileDirectly({
      url: effectivePdfUrl,
      file: effectivePdfUrl.startsWith('/uploads/') ? effectivePdfUrl : undefined,
      title: book.title,
      fileType: 'pdf',
      onProgress: (msg) => setDownloadToast(msg),
      onSuccess: (msg) => {
        playSuccessSound();
        setDownloadToast(msg);
        setIsDownloading(false);
        setTimeout(() => setDownloadToast(null), 4000);
      },
      onError: (err) => {
        setDownloadToast(err);
        setIsDownloading(false);
        setTimeout(() => setDownloadToast(null), 5000);
      }
    });
  };

  // Construct iframe embed src with PDF.js query params
  const iframeSrc = `${effectivePdfUrl}#page=${currentPage}&zoom=${zoomLevel}&toolbar=1&navpanes=1`;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div 
        ref={containerRef}
        className={`relative w-full max-w-6xl h-[94vh] rounded-3xl bg-[#0a1220] border border-[#e9c978]/40 shadow-2xl flex flex-col overflow-hidden text-[#eaf0f8] select-none ${
          isFullscreen ? 'fixed inset-0 max-w-none h-screen rounded-none z-[1100]' : ''
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* ========================================================
            TOP TOOLBAR: TITLE, PAGE CONTROLS, ZOOM & DIRECT DOWNLOAD
            ======================================================== */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between px-4 py-2.5 bg-black/70 border-b border-white/10 gap-2 shrink-0">
          
          {/* Book Info */}
          <div className="flex items-center gap-2.5 truncate">
            <span className="text-xl shrink-0">{book.icon || '📖'}</span>
            <div className="truncate">
              <h3 className="font-amiri font-bold text-sm sm:text-base text-white truncate max-w-sm sm:max-w-md">
                {book.title}
              </h3>
              <p className="text-[11px] text-gray-400 truncate flex items-center gap-2">
                <span>{book.author ? `✍️ ${book.author}` : book.grade || 'كتاب مادة الأحياء'}</span>
                {book.fileSize && <span className="font-mono text-[#e9c978]">({book.fileSize})</span>}
              </p>
            </div>
          </div>

          {/* Controls: Page Navigator, Zoom, Search, Direct Download, Close */}
          <div className="flex items-center justify-between sm:justify-end gap-1.5 flex-wrap">
            
            {/* Page Jump / Controls */}
            <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-xl px-2 py-1 text-xs">
              <button
                type="button"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage <= 1}
                className="p-1 hover:bg-white/10 rounded disabled:opacity-30 text-gray-300"
                title="الصفحة السابقة"
              >
                <ChevronRight className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-1 font-mono text-[11px] px-1">
                <input
                  type="number"
                  min={1}
                  max={totalPages}
                  value={currentPage}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    if (!isNaN(val)) handlePageChange(val);
                  }}
                  className="w-10 text-center bg-black/60 border border-white/10 rounded py-0.5 text-white font-bold focus:outline-none focus:border-[#e9c978]"
                />
                <span className="text-gray-400">/</span>
                <span className="text-gray-400">{totalPages}</span>
              </div>

              <button
                type="button"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage >= totalPages}
                className="p-1 hover:bg-white/10 rounded disabled:opacity-30 text-gray-300"
                title="الصفحة التالية"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>

            {/* Zoom Controls */}
            <div className="hidden sm:flex items-center gap-1 bg-white/5 border border-white/10 rounded-xl px-1.5 py-1 text-xs">
              <button
                type="button"
                onClick={zoomOut}
                className="p-1 hover:bg-white/10 rounded text-gray-300 hover:text-white"
                title="تصغير (-)"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={resetZoom}
                className="px-1.5 py-0.5 text-[10px] font-mono font-bold text-gray-300 hover:text-white"
                title="إعادة التعيين لـ 100%"
              >
                {zoomLevel}%
              </button>
              <button
                type="button"
                onClick={zoomIn}
                className="p-1 hover:bg-white/10 rounded text-gray-300 hover:text-white"
                title="تكبير (+)"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={toggleFitWidth}
                className={`p-1 rounded text-xs ${fitMode === 'fit-width' ? 'bg-[#e9c978] text-black font-bold' : 'text-gray-300 hover:bg-white/10'}`}
                title="ملاءمة عرض الشاشة"
              >
                ↔️
              </button>
            </div>

            {/* Reading Mode Filters (Night / Sepia / Normal) */}
            <div className="hidden md:flex items-center gap-0.5 bg-white/5 border border-white/10 rounded-xl p-0.5">
              <button
                type="button"
                onClick={() => setReadingFilter('normal')}
                className={`p-1 rounded text-[10px] font-bold ${readingFilter === 'normal' ? 'bg-white/20 text-white' : 'text-gray-400'}`}
                title="نمط نهاري طبيعي"
              >
                <Sun className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setReadingFilter('night')}
                className={`p-1 rounded text-[10px] font-bold ${readingFilter === 'night' ? 'bg-purple-500/30 text-purple-300' : 'text-gray-400'}`}
                title="نمط قراءة ليلي عالي التباين"
              >
                <Moon className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setReadingFilter('sepia')}
                className={`p-1 rounded text-[10px] font-bold ${readingFilter === 'sepia' ? 'bg-amber-600/30 text-amber-300' : 'text-gray-400'}`}
                title="نمط حماية العين (سيبيا دافئ)"
              >
                📖
              </button>
            </div>

            {/* Search Assistant in PDF */}
            <button
              type="button"
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className={`p-2 rounded-xl border transition ${
                isSearchOpen 
                  ? 'bg-[#e9c978] text-black border-[#e9c978]' 
                  : 'bg-white/5 border-white/10 text-gray-300 hover:text-white hover:bg-white/10'
              }`}
              title="البحث داخل نص الكتاب"
            >
              <Search className="w-3.5 h-3.5" />
            </button>

            {/* Direct Download Button (لا وسيط ولا Google Drive) */}
            <button
              type="button"
              onClick={handleDirectDownload}
              disabled={isDownloading}
              className="inline-flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-emerald-500 to-teal-600 text-black shadow-md shadow-emerald-500/20 hover:brightness-110 active:scale-95 transition disabled:opacity-50"
              title="تنزيل ملف PDF الأصلي مباشرة إلى مجلد التنزيلات على جهازك"
            >
              <Download className="w-4 h-4 text-black" />
              <span className="hidden sm:inline">تنزيل PDF للجهاز</span>
              <span className="sm:hidden">تنزيل</span>
            </button>

            {/* Fullscreen Toggle */}
            <button
              type="button"
              onClick={toggleFullscreen}
              className="p-2 rounded-xl bg-white/5 border border-white/10 text-gray-300 hover:text-white hover:bg-white/10 transition"
              title={isFullscreen ? 'تصغير الشاشة' : 'ملء الشاشة'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={() => { playClickSound(); onClose(); }}
              className="p-2 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white transition"
              title="إغلاق القارئ"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ========================================================
            SUB-BAR: BOOKMARK RESUME NOTIFICATION (IF SAVED PROGRESS FOUND)
            ======================================================== */}
        {hasSavedProgress && savedPageNumber !== currentPage && (
          <div className="px-4 py-2 bg-gradient-to-r from-amber-500/20 via-yellow-500/15 to-transparent border-b border-amber-500/30 flex items-center justify-between text-xs text-amber-200 animate-fadeIn">
            <div className="flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-amber-400 animate-bounce" />
              <span>
                توقفت سابقاً عند <strong>الصفحة {savedPageNumber}</strong> من هذا الكتاب.
              </span>
            </div>
            <button
              type="button"
              onClick={handleResumeReading}
              className="px-3 py-1 rounded-lg bg-amber-400 text-black font-bold text-xs hover:brightness-110 transition shadow-sm"
            >
              استئناف القراءة الآن ➡️
            </button>
          </div>
        )}

        {/* In-App Text Search Assistant Bar */}
        {isSearchOpen && (
          <div className="px-4 py-2.5 bg-black/80 border-b border-white/10 flex items-center gap-2 text-xs animate-fadeIn">
            <Search className="w-4 h-4 text-[#e9c978] shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="اكتب كلمة للبحث عنها في محتويات الكتاب (مثال: الخلية، الميتوكوندريا، DNA)..."
              className="flex-1 py-1.5 px-3 rounded-lg bg-white/10 border border-white/10 text-white text-xs placeholder:text-gray-400 focus:outline-none focus:border-[#e9c978]"
            />
            <span className="text-[11px] text-gray-400 shrink-0">
              💡 يمكنك أيضاً الضغط على <kbd className="px-1.5 py-0.5 bg-white/10 rounded font-mono">Ctrl + F</kbd> للبحث المباشر في نص الـ PDF
            </span>
          </div>
        )}

        {/* Download Toast Message */}
        {downloadToast && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-[1050] px-5 py-2.5 rounded-2xl bg-black/90 border border-[#0fb98a] text-white text-xs font-bold shadow-2xl flex items-center gap-2 animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-[#0fb98a]" />
            <span>{downloadToast}</span>
          </div>
        )}

        {/* ========================================================
            MAIN VIEWER CANVAS & IFRAME WITH READING FILTERS
            ======================================================== */}
        <div className="flex-1 w-full bg-[#1e2227] relative overflow-hidden flex items-center justify-center">
          
          {/* Loading Indicator */}
          {isLoading && (
            <div className="absolute inset-0 z-10 bg-[#0a1220] flex flex-col items-center justify-center p-6 space-y-3">
              <div className="w-12 h-12 rounded-2xl border-2 border-[#e9c978] border-t-transparent animate-spin" />
              <p className="text-xs text-[#e9c978] font-bold">جاري فتح وتجهيز صفحات الكتاب بجودة عالية...</p>
              <span className="text-[11px] text-gray-400">حفظ التقدم التلقائي مفعل</span>
            </div>
          )}

          {/* Fallback / Error State */}
          {hasError ? (
            <div className="p-8 text-center max-w-md space-y-4 bg-black/60 rounded-3xl border border-white/10 m-4">
              <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto" />
              <h4 className="font-bold text-base text-white">تعذر العرض المباشر داخل الإطار</h4>
              <p className="text-xs text-gray-300 leading-relaxed">
                هذا المرجع قد يفرض قيود أمان تمنع تضمينه في نافذة داخلية، لكن يمكنك تنزيله مباشرة إلى جهازك أو فتحه في تبويب مستقل.
              </p>
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleDirectDownload}
                  className="px-4 py-2 rounded-xl bg-[#0fb98a] text-black font-bold text-xs"
                >
                  تنزيل مباشر PDF
                </button>
                <a
                  href={effectivePdfUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-xl bg-white/10 text-white font-bold text-xs"
                >
                  فتح المصدر الأصلي 🌐
                </a>
              </div>
            </div>
          ) : (
            <iframe
              ref={iframeRef}
              src={iframeSrc}
              title={book.title}
              onLoad={() => setIsLoading(false)}
              onError={() => {
                setIsLoading(false);
                setHasError(true);
              }}
              className={`w-full h-full border-0 absolute inset-0 transition-all duration-300 ${
                readingFilter === 'night' 
                  ? 'invert contrast-125 hue-rotate-180 brightness-90 bg-black' 
                  : readingFilter === 'sepia' 
                  ? 'sepia-[0.35] brightness-95' 
                  : ''
              }`}
              allow="autoplay; fullscreen"
            />
          )}
        </div>

        {/* ========================================================
            BOTTOM STATUS BAR: READING PROGRESS & QUICK TIPS
            ======================================================== */}
        <div className="px-4 py-2 bg-black/80 border-t border-white/10 flex items-center justify-between text-[11px] text-gray-400 shrink-0">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-[#e9c978]">
              <Bookmark className="w-3.5 h-3.5" />
              <span>يتم حفظ تقدمك تلقائياً في ذاكرة جهازك</span>
            </span>
            <span className="hidden sm:inline">·</span>
            <span className="hidden sm:inline">
              الصفحة الحالية: <strong className="text-white font-mono">{currentPage}</strong> من {totalPages}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleDirectDownload}
              className="text-[#0fb98a] hover:underline font-bold flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تنزيل نسخة PDF للجهاز</span>
            </button>
            <span className="text-gray-500">|</span>
            <button
              type="button"
              onClick={onClose}
              className="text-gray-400 hover:text-white"
            >
              إغلاق
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
