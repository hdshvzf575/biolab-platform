import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Award, 
  ChevronDown, 
  ChevronUp, 
  Filter, 
  HelpCircle,
  Copy,
  Check
} from 'lucide-react';
import { BIOLOGY_CHAPTERS, MinisterialQuestion } from '../data/biologyCurriculum';

export const MinisterialBank: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedChapter, setSelectedChapter] = useState<number | 'all'>('all');
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Flatten all questions with chapter info
  const allQuestions = useMemo(() => {
    const list: (MinisterialQuestion & { chapterTitle: string; chapterId: number })[] = [];
    BIOLOGY_CHAPTERS.forEach(ch => {
      ch.ministerialQuestions.forEach(q => {
        list.push({
          ...q,
          chapterTitle: ch.title,
          chapterId: ch.id
        });
      });
    });
    return list;
  }, []);

  // Filtered list
  const filteredQuestions = useMemo(() => {
    return allQuestions.filter(q => {
      const matchSearch = 
        q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.years.some(y => y.includes(searchQuery));
      const matchType = selectedType === 'all' || q.type === selectedType;
      const matchChapter = selectedChapter === 'all' || q.chapterId === selectedChapter;
      return matchSearch && matchType && matchChapter;
    });
  }, [allQuestions, searchQuery, selectedType, selectedChapter]);

  const toggleExpand = (id: string) => {
    setExpandedIds(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const copyQuestion = (q: MinisterialQuestion) => {
    const text = `سؤال وزاري (${q.years.join('، ')}):\n${q.question}\n\nالجواب:\n${q.answer}`;
    navigator.clipboard.writeText(text);
    setCopiedId(q.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 text-[#eaf0f8]">
      {/* Search and Filters Bar */}
      <div className="p-5 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-xl space-y-4">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-5 h-5 absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="ابحث عن سؤال وزاري، تعريف، تعليل، سنة (مثال: 2023، السبيروجيرا، الخشب)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-3.5 pr-12 pl-4 text-sm text-gray-100 placeholder-gray-400 focus:outline-none focus:border-[#e9c978] transition"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-semibold">
            <button
              onClick={() => setSelectedType('all')}
              className={`px-3 py-1.5 rounded-xl transition ${
                selectedType === 'all' 
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] font-bold' 
                  : 'bg-white/5 text-gray-300 hover:text-white'
              }`}
            >
              الكل ({allQuestions.length})
            </button>
            <button
              onClick={() => setSelectedType('definition')}
              className={`px-3 py-1.5 rounded-xl transition ${
                selectedType === 'definition' 
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] font-bold' 
                  : 'bg-white/5 text-gray-300 hover:text-white'
              }`}
            >
              التعاريف
            </button>
            <button
              onClick={() => setSelectedType('reason')}
              className={`px-3 py-1.5 rounded-xl transition ${
                selectedType === 'reason' 
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] font-bold' 
                  : 'bg-white/5 text-gray-300 hover:text-white'
              }`}
            >
              التعاليل
            </button>
            <button
              onClick={() => setSelectedType('comparison')}
              className={`px-3 py-1.5 rounded-xl transition ${
                selectedType === 'comparison' 
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] font-bold' 
                  : 'bg-white/5 text-gray-300 hover:text-white'
              }`}
            >
              المقارنات
            </button>
            <button
              onClick={() => setSelectedType('function')}
              className={`px-3 py-1.5 rounded-xl transition ${
                selectedType === 'function' 
                  ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] font-bold' 
                  : 'bg-white/5 text-gray-300 hover:text-white'
              }`}
            >
              الموقع والوظيفة
            </button>
          </div>

          {/* Chapter Filter */}
          <select
            value={selectedChapter}
            onChange={(e) => setSelectedChapter(e.target.value === 'all' ? 'all' : Number(e.target.value))}
            className="bg-white/5 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-gray-200 focus:outline-none"
          >
            <option value="all" className="bg-[#0a1220]">كل الفصول الثمانية</option>
            {BIOLOGY_CHAPTERS.map(c => (
              <option key={c.id} value={c.id} className="bg-[#0a1220]">
                الفصل {c.id}: {c.title.substring(0, 20)}...
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Questions List */}
      <div className="space-y-3">
        {filteredQuestions.length > 0 ? (
          filteredQuestions.map((q) => {
            const isExpanded = !!expandedIds[q.id];
            return (
              <div
                key={q.id}
                className="rounded-2xl border border-white/10 bg-[#0a1220]/80 hover:border-[#e9c978]/30 transition overflow-hidden"
              >
                <div
                  onClick={() => toggleExpand(q.id)}
                  className="p-4 sm:p-5 flex items-start justify-between gap-3 cursor-pointer select-none"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                        q.type === 'definition' ? 'bg-[#3fa9f5]/20 text-[#3fa9f5]' :
                        q.type === 'reason' ? 'bg-[#e9c978]/20 text-[#e9c978]' :
                        q.type === 'comparison' ? 'bg-[#8b6cf0]/20 text-[#8b6cf0]' :
                        'bg-[#0fb98a]/20 text-[#0fb98a]'
                      }`}>
                        {q.type === 'definition' ? 'تعريف وزاري' :
                         q.type === 'reason' ? 'تعليل وزاري' :
                         q.type === 'comparison' ? 'مقارنة هامة' : 'موقع ووظيفة'}
                      </span>

                      <span className="text-[11px] text-gray-400 bg-white/5 px-2 py-0.5 rounded">
                        الفصل {q.chapterId}
                      </span>

                      <div className="flex gap-1 text-[11px] text-gray-400">
                        {q.years.map((y, idx) => (
                          <span key={idx} className="bg-black/40 px-1.5 py-0.5 rounded text-[#e9c978] font-mono font-medium">
                            {y}
                          </span>
                        ))}
                      </div>
                    </div>

                    <h4 className="text-sm sm:text-base font-bold text-white leading-relaxed pt-1">
                      {q.question}
                    </h4>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 mt-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        copyQuestion(q);
                      }}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition"
                      title="نسخ السؤال والجواب"
                    >
                      {copiedId === q.id ? <Check className="w-4 h-4 text-[#0fb98a]" /> : <Copy className="w-4 h-4" />}
                    </button>
                    <div className="p-1.5 rounded-lg bg-white/5 text-gray-400">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </div>
                </div>

                {isExpanded && (
                  <div className="p-5 pt-1 border-t border-white/10 bg-black/40 text-sm text-gray-200 leading-relaxed space-y-1.5 animate-fadeIn">
                    <span className="text-xs font-bold text-[#0fb98a] block">الجواب الوزاري النموذجي:</span>
                    <p>{q.answer}</p>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="p-12 text-center text-gray-400 bg-white/5 rounded-3xl">
            لم يتم العثور على أي سؤال يطابق البحث «{searchQuery}».
          </div>
        )}
      </div>
    </div>
  );
};
