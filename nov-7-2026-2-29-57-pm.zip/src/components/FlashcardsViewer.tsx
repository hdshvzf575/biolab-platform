import React, { useState } from 'react';
import { 
  Sparkles, 
  RotateCw, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle, 
  BookMarked,
  Layers,
  Shuffle
} from 'lucide-react';
import { FLASHCARDS_LIST, Flashcard } from '../data/biologyCurriculum';

export const FlashcardsViewer: React.FC = () => {
  const [cards, setCards] = useState<Flashcard[]>(FLASHCARDS_LIST);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [masteredIds, setMasteredIds] = useState<Set<string>>(new Set());
  const [filterChapter, setFilterChapter] = useState<number | 'all'>('all');

  const filteredCards = cards.filter(c => filterChapter === 'all' || c.chapterId === filterChapter);
  const currentCard = filteredCards[currentIndex % (filteredCards.length || 1)];

  const handleNext = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex(prev => (prev + 1) % filteredCards.length);
    }, 150);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex(prev => (prev - 1 + filteredCards.length) % filteredCards.length);
    }, 150);
  };

  const toggleMastered = (id: string) => {
    setMasteredIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const shuffleCards = () => {
    setIsFlipped(false);
    setCards([...cards].sort(() => Math.random() - 0.5));
    setCurrentIndex(0);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 text-[#eaf0f8]">
      {/* Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#e9c978]" />
          <span className="text-xs sm:text-sm font-bold text-white">بطاقات المراجعة الذكية للتعاريف والتعاليل</span>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={filterChapter}
            onChange={(e) => {
              setFilterChapter(e.target.value === 'all' ? 'all' : Number(e.target.value));
              setCurrentIndex(0);
              setIsFlipped(false);
            }}
            className="bg-black/40 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-gray-200 focus:outline-none"
          >
            <option value="all">كل الفصول ({FLASHCARDS_LIST.length})</option>
            {[1, 2, 3, 4, 5, 6, 7, 8].map(ch => (
              <option key={ch} value={ch}>الفصل {ch}</option>
            ))}
          </select>

          <button
            onClick={shuffleCards}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 transition"
            title="خلط البطاقات عشوائياً"
          >
            <Shuffle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Flashcard */}
      {filteredCards.length > 0 && currentCard ? (
        <div className="space-y-4">
          <div 
            onClick={() => setIsFlipped(!isFlipped)}
            className="relative min-h-[260px] sm:min-h-[280px] p-6 sm:p-8 rounded-3xl cursor-pointer select-none transition-all duration-500 perspective-1000 border border-[#e9c978]/30 shadow-2xl flex flex-col justify-between"
            style={{
              background: isFlipped 
                ? 'linear-gradient(145deg, #0f1d30, #0a1422)' 
                : 'linear-gradient(145deg, #0d1726, #060b13)',
            }}
          >
            {/* Card Top badge */}
            <div className="flex items-center justify-between gap-2">
              <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                currentCard.category === 'تعريف' ? 'bg-[#3fa9f5]/20 text-[#3fa9f5]' :
                currentCard.category === 'تعليل' ? 'bg-[#e9c978]/20 text-[#e9c978]' :
                currentCard.category === 'مقارنة' ? 'bg-[#8b6cf0]/20 text-[#8b6cf0]' :
                'bg-[#0fb98a]/20 text-[#0fb98a]'
              }`}>
                {currentCard.category} · {currentCard.tag}
              </span>

              <div className="flex items-center gap-1.5 text-xs text-gray-400">
                <RotateCw className="w-3.5 h-3.5 text-[#e9c978]" />
                <span>انقر للقلب</span>
              </div>
            </div>

            {/* Content Front / Back */}
            <div className="py-6 text-center">
              {!isFlipped ? (
                <div className="space-y-3">
                  <span className="text-xs text-gray-400 uppercase tracking-widest block">السؤال / المفهوم</span>
                  <h3 className="text-lg sm:text-2xl font-bold font-amiri text-white leading-relaxed">
                    {currentCard.front}
                  </h3>
                </div>
              ) : (
                <div className="space-y-3 animate-fadeIn">
                  <span className="text-xs text-[#0fb98a] font-bold uppercase tracking-widest block">الجواب النموذجي</span>
                  <p className="text-sm sm:text-base text-gray-100 leading-relaxed font-medium">
                    {currentCard.back}
                  </p>
                </div>
              )}
            </div>

            {/* Card Bottom status */}
            <div className="flex items-center justify-between text-xs pt-4 border-t border-white/10 text-gray-400">
              <span>البطاقة {(currentIndex % filteredCards.length) + 1} من {filteredCards.length}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleMastered(currentCard.id);
                }}
                className={`flex items-center gap-1.5 font-bold transition ${
                  masteredIds.has(currentCard.id) ? 'text-[#0fb98a]' : 'text-gray-400 hover:text-white'
                }`}
              >
                <CheckCircle className="w-4 h-4" />
                <span>{masteredIds.has(currentCard.id) ? 'تم الحفظ بنجاح ✓' : 'حفظتها'}</span>
              </button>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between gap-4">
            <button
              onClick={handlePrev}
              className="flex-1 py-3 px-4 rounded-2xl bg-white/5 border border-white/10 text-gray-200 font-bold text-sm hover:bg-white/10 transition flex items-center justify-center gap-2"
            >
              <ChevronRight className="w-4 h-4" />
              <span>السابق</span>
            </button>
            <div className="text-xs text-gray-400 font-medium text-center">
              المحفوظة: <strong className="text-[#0fb98a]">{masteredIds.size}</strong> من {filteredCards.length}
            </div>
            <button
              onClick={handleNext}
              className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] font-bold text-sm hover:brightness-110 transition flex items-center justify-center gap-2 shadow-lg"
            >
              <span>التالي</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center text-gray-400 bg-white/5 rounded-3xl">
          لا توجد بطاقات لهذا الفصل.
        </div>
      )}
    </div>
  );
};
