import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowDownToLine, 
  CheckCircle, 
  RotateCw, 
  X, 
  ShieldCheck, 
  AlertCircle 
} from 'lucide-react';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { 
  AppUpdatePayload, 
  dismissUpdateVersion, 
  applyAppUpdateSafely 
} from '../utils/versionManager';

export type AppUpdateData = AppUpdatePayload;

interface AppUpdateModalProps {
  isOpen: boolean;
  updateData: AppUpdateData | null;
  onClose: () => void;
  onRefreshBundle?: () => void;
}

export const AppUpdateModal: React.FC<AppUpdateModalProps> = ({
  isOpen,
  updateData,
  onClose,
  onRefreshBundle
}) => {
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [updateError, setUpdateError] = useState<string | null>(null);

  if (!isOpen || !updateData) return null;

  const handleDismissLater = () => {
    playClickSound();
    dismissUpdateVersion(updateData.version);
    onClose();
  };

  const handleUpdateNow = async () => {
    setIsUpdating(true);
    setUpdateError(null);
    playClickSound();

    try {
      const ok = await applyAppUpdateSafely(updateData);
      if (ok) {
        setUpdateSuccess(true);
        playSuccessSound();

        // Brief delay for visual satisfaction, then apply bundle refresh
        setTimeout(() => {
          if (typeof onRefreshBundle === 'function') {
            onRefreshBundle();
          } else {
            window.location.reload();
          }
        }, 800);
      } else {
        setUpdateError('تعذر تطبيق التحديث بسبب بطء الشبكة، تم الحفاظ على بياناتك المحلية بأمان.');
        setIsUpdating(false);
      }
    } catch (err: any) {
      console.warn('Update apply notice:', err);
      setUpdateError('حدث خطأ أثناء فحص ملفات التحديث. يمكنك المحاولة لاحقاً دون فقدان أي بيانات.');
      setIsUpdating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[1150] flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div 
        className="relative w-full max-w-md rounded-3xl bg-[#0a1220] border border-[#0fb98a]/40 shadow-[0_20px_60px_rgba(0,0,0,0.85)] p-6 sm:p-8 text-[#eaf0f8] text-right overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow */}
        <div className="absolute -top-16 -right-16 w-36 h-36 rounded-full bg-[#0fb98a]/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 rounded-full bg-[#e9c978]/15 blur-3xl pointer-events-none" />

        {/* Dismiss Button if not forced */}
        {!updateData.forceUpdate && (
          <button
            onClick={handleDismissLater}
            className="absolute top-5 left-5 w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white flex items-center justify-center transition border border-white/10"
            title="تأجيل التحديث"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Header */}
        <div className="text-center space-y-2 mb-5">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#0fb98a] to-[#2dd4bf] text-[#08111e] flex items-center justify-center text-2xl mx-auto shadow-lg shadow-[#0fb98a]/25 animate-bounce">
            🚀
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0fb98a]/15 border border-[#0fb98a]/30 text-[#0fb98a] text-xs font-mono font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>إصدار جديد متاح v{updateData.version}</span>
          </div>

          <h3 className="font-amiri font-bold text-xl sm:text-2xl text-white">
            {updateData.title || 'تحديث جديد لمنصة وسام للأحياء'}
          </h3>
          <p className="text-xs text-gray-400">
            تاريخ التحديث: {updateData.releaseDate || new Date().toISOString().split('T')[0]}
          </p>
        </div>

        {/* Release Notes */}
        <div className="space-y-2.5 my-5">
          <h4 className="text-xs font-bold text-[#e9c978] flex items-center gap-1.5">
            <span>أبرز الإضافات والتحسينات في هذا التحديث:</span>
          </h4>

          <div className="space-y-2 max-h-48 overflow-y-auto p-3 rounded-2xl bg-black/40 border border-white/10 text-xs">
            {updateData.releaseNotes && updateData.releaseNotes.length > 0 ? (
              updateData.releaseNotes.map((note, idx) => (
                <div key={idx} className="flex items-start gap-2 text-gray-200 leading-relaxed">
                  <span className="text-[#0fb98a] font-bold shrink-0">✓</span>
                  <span>{note}</span>
                </div>
              ))
            ) : (
              <p className="text-gray-400 text-center py-2">تحسينات شاملة للأداء وسرعة تحميل الكتب والمحاضرات.</p>
            )}
          </div>
        </div>

        {/* Safety Note */}
        <div className="text-[11px] text-gray-400 bg-white/5 p-2.5 rounded-xl border border-white/5 mb-4 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#0fb98a] shrink-0" />
          <span>التحديث يتم بسلاسة داخل التطبيق دون فقدان ملفك الشخصي أو تقدمك الدراسي.</span>
        </div>

        {/* Error notification if update fails */}
        {updateError && (
          <div className="text-xs text-red-300 bg-red-950/60 p-3 rounded-xl border border-red-500/40 mb-4 flex items-center gap-2 animate-fadeIn">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{updateError}</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-2">
          <button
            type="button"
            onClick={handleUpdateNow}
            disabled={isUpdating || updateSuccess}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#0fb98a] to-[#2dd4bf] text-[#08111e] font-black text-sm shadow-xl hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {updateSuccess ? (
              <>
                <CheckCircle className="w-4 h-4 text-[#08111e]" />
                <span>تم تثبيت الإصدار بنجاح! جاري التفعيل...</span>
              </>
            ) : isUpdating ? (
              <>
                <RotateCw className="w-4 h-4 animate-spin text-[#08111e]" />
                <span>جاري تحميل التحديث وتطبيق الإضافات...</span>
              </>
            ) : (
              <>
                <RotateCw className="w-4 h-4 text-[#08111e]" />
                <span>تحديث الآن وتطبيق الإضافات</span>
              </>
            )}
          </button>

          {/* Download APK fallback if user is on android or prefers APK */}
          {updateData.apkUrl && (
            <a
              href={updateData.apkUrl}
              download="biolab.apk"
              onClick={() => playClickSound()}
              className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-bold transition flex items-center justify-center gap-1.5 border border-white/10"
            >
              <ArrowDownToLine className="w-3.5 h-3.5 text-[#e9c978]" />
              <span>تنزيل ملف التحديث بصيغة APK للهاتف</span>
            </a>
          )}

          {!updateData.forceUpdate && !updateSuccess && (
            <button
              type="button"
              onClick={handleDismissLater}
              className="w-full py-2 text-center text-xs text-gray-400 hover:text-gray-200 transition"
            >
              تذكيري لاحقاً
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
