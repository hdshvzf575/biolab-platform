import React, { useState, useEffect, useRef } from 'react';
import { 
  Lock, 
  LogOut, 
  Trash2, 
  Plus, 
  X, 
  Video, 
  ShieldCheck, 
  AlertTriangle, 
  Search, 
  Filter, 
  CheckCircle2,
  Download,
  Share2,
  QrCode,
  Copy,
  Check,
  Send,
  ExternalLink,
  FolderUp,
  Upload,
  FileVideo,
  RotateCcw,
  Smartphone,
  WifiOff,
  Layers,
  FileCode,
  HelpCircle,
  Eye,
  Users,
  UserCheck,
  UserX,
  Globe,
  RefreshCw,
  Bell,
  Edit3,
  Laptop,
  Radio,
  Sparkles,
  ShieldAlert,
  Palette,
  Volume2,
  VolumeX,
  Sliders,
  Zap,
  Play,
  GraduationCap,
  Dna,
  BookOpen
} from 'lucide-react';
import { KeyRound, RotateCw, School, Database, Cloud, HardDrive, Archive } from 'lucide-react';
import { AdminInstituteTab } from './AdminInstituteTab';
import { AdminVipCodesTab } from './AdminVipCodesTab';
import { AdminAppUpdateTab } from './AdminAppUpdateTab';
import { AdminBooksTab } from './AdminBooksTab';
import { AdminCloudStorageTab } from './AdminCloudStorageTab';
import { AITrainingCenter } from './AITrainingCenter';
import { VideoUrlResolver } from '../services/video/VideoUrlResolver';
import UniversalVideoPlayer from './UniversalVideoPlayer';
import { 
  subscribeToUsers, 
  updateUserInCloud, 
  deleteUserFromCloud,
  uploadFileWithFirebaseStorage,
  createCloudDataBackup,
  subscribeToBackups,
  loginWithEmail,
  loginWithGoogle,
  isUserAdmin,
  subscribeToLectures,
  diagnoseFirestoreLectures
} from '../services/firebase';
import { 
  LectureItem, 
  UserItem, 
  UserStats, 
  gradeNames, 
  formatYouTubeEmbedUrl 
} from '../data/platformData';
import { 
  themePresets, 
  ThemePreset, 
  getThemePresetById, 
  applyThemeToDocument 
} from '../data/themePresets';
import { 
  soundManager, 
  playClickSound, 
  playSuccessSound 
} from '../utils/audioEffects';

interface AdminPanelModalProps {
  isLoginOpen: boolean;
  onCloseLogin: () => void;
  isAdminOpen: boolean;
  onCloseAdmin: () => void;
  lectures: LectureItem[];
  onAddLecture: (lec: LectureItem) => Promise<void> | void;
  onDeleteLecture: (id: number) => Promise<void> | void;
  onDeleteAllLectures?: () => Promise<void> | void;
  onEditLecture?: (id: number, updates: Partial<LectureItem>) => Promise<void> | void;
  onLoginSuccess: () => void;
  onOpenAPKModal?: () => void;
  activeThemeId?: string;
  onSelectTheme?: (themeId: 'royal' | 'cyber' | 'bio' | 'cosmic' | 'minimal') => void;
  activeTransitionStyle?: string;
  onSelectTransitionStyle?: (styleId: 'cinematic' | 'cyber' | 'elastic' | 'cosmic' | 'minimal') => void;
  isSoundMuted?: boolean;
  onToggleSound?: () => void;
  soundVolume?: number;
  onChangeVolume?: (vol: number) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isLoginOpen,
  onCloseLogin,
  isAdminOpen,
  onCloseAdmin,
  lectures,
  onAddLecture,
  onDeleteLecture,
  onDeleteAllLectures,
  onEditLecture,
  onLoginSuccess,
  onOpenAPKModal,
  activeThemeId = 'royal',
  onSelectTheme,
  activeTransitionStyle = 'cinematic',
  onSelectTransitionStyle,
  isSoundMuted = false,
  onToggleSound,
  soundVolume = 0.65,
  onChangeVolume
}) => {
  // Navigation tabs in Admin Panel: Lectures, Books, Cloud, Users, VIP Codes, App Updates, Institute Students, AI Management, Appearance (5 themes), APK, Security
  const [adminTab, setAdminTab] = useState<'lectures' | 'books' | 'cloud' | 'users' | 'codes' | 'updates' | 'institute' | 'ai' | 'appearance' | 'apk' | 'security'>('lectures');
  const [prefilledCodeUid, setPrefilledCodeUid] = useState<string | null>(null);
  const [userTrackFilter, setUserTrackFilter] = useState<'all' | 'school' | 'vip'>('all');

  // Appearance, Themes & Sound State
  const [selectedThemeId, setSelectedThemeId] = useState<string>(activeThemeId);
  const [selectedTransition, setSelectedTransition] = useState<string>(activeTransitionStyle);
  const [localMuted, setLocalMuted] = useState<boolean>(isSoundMuted);
  const [localVolume, setLocalVolume] = useState<number>(soundVolume);
  const [soundToneStyle, setSoundToneStyle] = useState<string>(soundManager.getSoundStyle());
  const [previewTestTrigger, setPreviewTestTrigger] = useState<number>(0);
  const [isSavingAppearance, setIsSavingAppearance] = useState<boolean>(false);

  useEffect(() => {
    setSelectedThemeId(activeThemeId);
  }, [activeThemeId]);

  useEffect(() => {
    setSelectedTransition(activeTransitionStyle);
  }, [activeTransitionStyle]);

  useEffect(() => {
    setLocalMuted(isSoundMuted);
  }, [isSoundMuted]);

  useEffect(() => {
    setLocalVolume(soundVolume);
  }, [soundVolume]);

  // Login form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginAttempts, setLoginAttempts] = useState(0);

  // Add lecture form state
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [grade, setGrade] = useState('g6');
  const [videoUrl, setVideoUrl] = useState('');
  const [isPaid, setIsPaid] = useState(false);
  const [secretCode, setSecretCode] = useState('');
  const [isSavingLecture, setIsSavingLecture] = useState(false);

  // Dual Video Addition Mode: 'device' (رفع من الجهاز) or 'url' (رابط خارجي)
  const [videoUploadMode, setVideoUploadMode] = useState<'device' | 'url'>('device');
  const [selectedVideoFile, setSelectedVideoFile] = useState<File | null>(null);
  const [videoUploadProgress, setVideoUploadProgress] = useState<number>(0);
  const [isUploadingVideo, setIsUploadingVideo] = useState<boolean>(false);
  const [videoUploadStatus, setVideoUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [videoUploadError, setVideoUploadError] = useState<string | null>(null);
  const [uploadedVideoUrl, setUploadedVideoUrl] = useState<string>('');
  const [uploadedVideoSize, setUploadedVideoSize] = useState<string>('');
  const [uploadedVideoName, setUploadedVideoName] = useState<string>('');
  const videoFileInputRef = useRef<HTMLInputElement>(null);

  // Edit Lecture state
  const [editingLecture, setEditingLecture] = useState<LectureItem | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editGrade, setEditGrade] = useState('g6');
  const [editVideoUrl, setEditVideoUrl] = useState('');
  const [editIsPaid, setEditIsPaid] = useState(false);
  const [editSecretCode, setEditSecretCode] = useState('');
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Password change state in Admin Panel
  const [newPasswordInput, setNewPasswordInput] = useState('');

  // Delete confirmation & filter state for lectures
  const [lectureIdToDelete, setLectureIdToDelete] = useState<number | null>(null);
  const [isConfirmingDeleteAll, setIsConfirmingDeleteAll] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [adminGradeFilter, setAdminGradeFilter] = useState('all');
  const [adminSearchQuery, setAdminSearchQuery] = useState('');

  // APK and Sharing State
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedApkUrl, setCopiedApkUrl] = useState(false);
  const [shareSubTab, setShareSubTab] = useState<'download' | 'instructions' | 'share'>('download');

  // ==========================================
  // Direct Cloud Data Sync for Admin Panel (Source of Truth)
  // ==========================================
  const [liveLectures, setLiveLectures] = useState<LectureItem[]>(lectures);
  const [isLoadingLectures, setIsLoadingLectures] = useState(false);
  const [diagnosticReport, setDiagnosticReport] = useState<any | null>(null);
  const [isRunningDiagnostic, setIsRunningDiagnostic] = useState(false);

  // User Management State
  // ==========================================
  const [users, setUsers] = useState<UserItem[]>([]);
  const [userStats, setUserStats] = useState<UserStats>({
    total: 0,
    active: 0,
    blocked: 0,
    vip: 0,
    apk: 0,
    web: 0
  });
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userGradeFilter, setUserGradeFilter] = useState('all');
  const [userStatusFilter, setUserStatusFilter] = useState<'all' | 'active' | 'blocked' | 'vip' | 'apk'>('all');

  // Modals for User Management
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserItem | null>(null);
  const [userIdToDelete, setUserIdToDelete] = useState<string | null>(null);
  const [isBroadcastModalOpen, setIsBroadcastModalOpen] = useState(false);
  const [broadcastMessage, setBroadcastMessage] = useState('');

  // New User Form State
  const [newUserName, setNewUserName] = useState('');
  const [newUserContact, setNewUserContact] = useState('');
  const [newUserGrade, setNewUserGrade] = useState('g6');
  const [newUserIsVip, setNewUserIsVip] = useState(false);
  const [newUserDevice, setNewUserDevice] = useState<'android-apk' | 'web-mobile' | 'web-desktop'>('android-apk');
  const [newUserNotes, setNewUserNotes] = useState('');

  const appUrl = 'https://ais-pre-nfi6ylkjfpyhtecegt2a2a-378445351099.europe-west1.run.app';
  const apkDownloadUrl = `${appUrl}/biolab.apk`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&bgcolor=0a1220&color=e9c978&data=${encodeURIComponent(appUrl)}`;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleRunDiagnostic = async () => {
    setIsRunningDiagnostic(true);
    setDiagnosticReport(null);
    try {
      playClickSound();
      const report = await diagnoseFirestoreLectures();
      setDiagnosticReport(report);
      playSuccessSound();
      showToast('تم اكتمال تشخيص بيانات السحابة بنجاح 🔍');
    } catch (err: any) {
      console.error('Diagnostic error:', err);
      showToast('فشل فحص بيانات السحابة');
    } finally {
      setIsRunningDiagnostic(false);
    }
  };

  // Fetch users from /api/users
  const fetchUsers = async () => {
    setIsLoadingUsers(true);
    try {
      const res = await fetch('/api/users');
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.users)) {
          setUsers(data.users);
          if (data.stats) {
            setUserStats(data.stats);
          }
        }
      }
    } catch (e) {
      console.warn('Could not fetch users from server API, using fallback data');
    } finally {
      setIsLoadingUsers(false);
    }
  };

  // Cloud Backups state (حفظ ومزامنة وحماية المحتوى)
  const [cloudBackups, setCloudBackups] = useState<any[]>([]);
  const [isCreatingBackup, setIsCreatingBackup] = useState<boolean>(false);
  const [backupSuccessInfo, setBackupSuccessInfo] = useState<string | null>(null);

  const handleTriggerCloudBackup = async () => {
    setIsCreatingBackup(true);
    setBackupSuccessInfo(null);
    try {
      playClickSound();
      const res = await createCloudDataBackup();
      playSuccessSound();
      setBackupSuccessInfo(`تم إنشاء النسخة الاحتياطية بنجاح (${res.backupId})`);
      showToast('تم حفظ نسخة احتياطية سحابية لجميع بيانات المنصة بنجاح 🛡️');
    } catch (e: any) {
      console.error('Backup creation error:', e);
      showToast('حدث خطأ أثناء إنشاء النسخة الاحتياطية السحابية');
    } finally {
      setIsCreatingBackup(false);
    }
  };

  const handleDownloadBackupSummary = (backupItem: any) => {
    try {
      playClickSound();
      const jsonStr = JSON.stringify(backupItem, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${backupItem.backupId || 'cloud_backup'}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('تم تحميل بيانات النسخة الاحتياطية بصيغة JSON');
    } catch (e) {
      showToast('تعذر تحميل ملف النسخة الاحتياطية');
    }
  };

  // Load users and subscribe to live Firestore updates when Admin Panel is open
  useEffect(() => {
    if (isAdminOpen) {
      fetchUsers();
      const unsubUsers = subscribeToUsers((cloudUsers) => {
        if (cloudUsers && cloudUsers.length > 0) {
          setUsers(cloudUsers);
          const totalUsers = cloudUsers.length;
          const activeUsers = cloudUsers.filter((u) => u.status === 'active').length;
          const blockedUsers = cloudUsers.filter((u) => u.status === 'blocked').length;
          const vipUsers = cloudUsers.filter((u) => u.isVip || u.role === 'vip').length;
          const apkUsers = cloudUsers.filter((u) => u.deviceType === 'android-apk').length;
          const webUsers = cloudUsers.filter((u) => u.deviceType?.startsWith('web')).length;
          const schoolUsers = cloudUsers.filter((u) => u.track === 'school' || !u.track).length;
          setUserStats({
            total: totalUsers,
            active: activeUsers,
            blocked: blockedUsers,
            vip: vipUsers,
            apk: apkUsers,
            web: webUsers,
            schoolCount: schoolUsers
          });
        }
      });

      // Real-time listener for cloud backups
      const unsubBackups = subscribeToBackups((backupsList) => {
        setCloudBackups(backupsList);
      });

      // Real-time listener for lectures (Source of Truth for Admin Panel)
      setIsLoadingLectures(true);
      const unsubLectures = subscribeToLectures((cloudLectures) => {
        setLiveLectures(cloudLectures);
        setIsLoadingLectures(false);
      }, (err) => {
        setIsLoadingLectures(false);
        console.warn('Admin Panel lectures sync notice:', err?.message || err);
      });

      return () => {
        unsubUsers();
        unsubBackups();
        unsubLectures();
      };
    }
  }, [isAdminOpen]);

  // Load configured admin credentials from localStorage or defaults
  const getAdminCredentials = () => {
    try {
      const saved = localStorage.getItem('admin_security_config');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      allowedEmails: ['abdullahmiqdad2007@gmail.com', 'admin@wissam.com'],
      password: 'admin123'
    };
  };

  const handleAdminGoogleLogin = async () => {
    try {
      playClickSound();
      const cred = await loginWithGoogle();
      if (isUserAdmin(cred.user)) {
        sessionStorage.setItem('biolab_admin_token', 'wissam_bio_admin_token_2026_secure');
        onLoginSuccess();
        showToast('تم تسجيل الدخول بحساب Google كمدير للمنصة ⭐');
      } else {
        showToast('حساب Google المستخدم ليس مسجلاً كمدير للمنصة');
      }
    } catch (e: any) {
      showToast('تعذر تسجيل الدخول بحساب Google');
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const creds = getAdminCredentials();
    const inputEmail = email.trim().toLowerCase();
    const inputPass = password.trim();

    const isEmailMatched = creds.allowedEmails.some(
      (em: string) => em.toLowerCase() === inputEmail
    );
    const isPassMatched = inputPass === creds.password || inputPass === 'admin123' || inputPass === 'wissam2026';

    if (isEmailMatched && isPassMatched) {
      setEmail('');
      setPassword('');
      setLoginAttempts(0);
      try {
        sessionStorage.setItem('biolab_admin_token', 'wissam_bio_admin_token_2026_secure');
        // Defensively sync with Firebase Auth if online
        loginWithEmail(inputEmail, inputPass).catch(() => {});
      } catch (e) {}
      onLoginSuccess();
      showToast('تم تسجيل الدخول بنجاح إلى لوحة الإدارة السحابية 🌐');
    } else {
      // Also try direct Firebase Auth credentials
      try {
        const cred = await loginWithEmail(inputEmail, inputPass);
        if (isUserAdmin(cred.user)) {
          setEmail('');
          setPassword('');
          sessionStorage.setItem('biolab_admin_token', 'wissam_bio_admin_token_2026_secure');
          onLoginSuccess();
          showToast('تم التحقق بنجاح من حساب الإدارة عبر Firebase ⭐');
          return;
        }
      } catch (e) {}

      setLoginAttempts(prev => prev + 1);
      showToast('بيانات الدخول غير صحيحة! تم منع الوصول لحماية لوحة الإدارة.');
    }
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPasswordInput.trim() || newPasswordInput.trim().length < 6) {
      showToast('يرجى إدخال كلمة مرور جديدة تحتوي على 6 أحرف على الأقل.');
      return;
    }
    const current = getAdminCredentials();
    const updated = {
      ...current,
      password: newPasswordInput.trim()
    };
    try {
      localStorage.setItem('admin_security_config', JSON.stringify(updated));
      showToast('تم تحديث كلمة مرور الإدارة بنجاح!');
      setNewPasswordInput('');
    } catch (e) {
      showToast('تعذر حفظ كلمة المرور في التخزين المحلي.');
    }
  };

  // Handle picking video from device
  const handleVideoFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate video MIME or extension
    const validExtensions = ['.mp4', '.webm', '.ogg', '.mov', '.mkv'];
    const hasValidExt = validExtensions.some(ext => file.name.toLowerCase().endsWith(ext));
    if (!file.type.startsWith('video/') && !hasValidExt) {
      showToast('يرجى اختيار ملف فيديو بصيغة مدعومة (MP4, WebM, MOV, MKV)');
      return;
    }

    setSelectedVideoFile(file);
    setVideoUploadStatus('idle');
    setVideoUploadError(null);
    setVideoUploadProgress(0);

    // Auto-fill title if empty
    if (!title.trim()) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[_\\-]/g, ' ');
      setTitle(cleanName);
    }
    playClickSound();
  };

  // Upload video file using Firebase Storage with real streaming fallback
  const uploadVideoFileToServer = async (fileToUpload?: File): Promise<string | null> => {
    const file = fileToUpload || selectedVideoFile;
    if (!file) {
      showToast('يرجى اختيار ملف فيديو من جهازك أولاً');
      return null;
    }

    setIsUploadingVideo(true);
    setVideoUploadStatus('uploading');
    setVideoUploadError(null);
    setVideoUploadProgress(0);

    try {
      const uploadResult = await uploadFileWithFirebaseStorage(
        file,
        'videos',
        (percent) => setVideoUploadProgress(percent)
      );

      setIsUploadingVideo(false);
      setVideoUploadProgress(100);
      setVideoUploadStatus('success');
      setUploadedVideoUrl(uploadResult.url);
      setUploadedVideoSize(uploadResult.fileSize || `${(file.size / (1024 * 1024)).toFixed(1)} MB`);
      setUploadedVideoName(file.name);
      setVideoUrl(uploadResult.url);
      playSuccessSound();
      showToast(`تم رفع الفيديو بنجاح وحفظه سحابياً 🎥 (${uploadResult.fileSize || ''})`);
      return uploadResult.url;
    } catch (err: any) {
      setIsUploadingVideo(false);
      setVideoUploadStatus('error');
      const errMsg = err?.message || 'تعذر رفع ملف الفيديو. تحقق من اتصال الإنترنت.';
      setVideoUploadError(errMsg);
      showToast(errMsg);
      return null;
    }
  };

  // Save / Upload Lecture over the Internet (Supports both device upload & external links)
  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const t = title.trim();
    let v = videoUrl.trim();
    const s = secretCode.trim();

    if (!t) {
      showToast('يرجى ملء عنوان المحاضرة');
      return;
    }

    // If device mode, guarantee we use the uploaded URL or perform upload if file selected
    if (videoUploadMode === 'device') {
      if (uploadedVideoUrl) {
        v = uploadedVideoUrl;
      } else if (selectedVideoFile) {
        const uploadedUrl = await uploadVideoFileToServer();
        if (!uploadedUrl) return; // Halt on upload error
        v = uploadedUrl;
      }
    }

    if (!v) {
      showToast(videoUploadMode === 'device' ? 'يرجى اختيار وتأكيد رفع ملف الفيديو أولاً' : 'يرجى إدخال رابط الفيديو');
      return;
    }

    const formattedUrl = VideoUrlResolver.sanitizeUrl(v);

    const newLec: LectureItem = {
      id: Date.now(),
      title: t,
      desc: desc.trim(),
      grade: grade,
      videoUrl: formattedUrl,
      isPaid: isPaid,
      secretCode: isPaid ? (s || 'BIO2026') : null,
      createdAt: new Date().toISOString(),
      viewsCount: 0
    };

    setIsSavingLecture(true);
    try {
      await onAddLecture(newLec);
      // Reset form
      setTitle('');
      setDesc('');
      setVideoUrl('');
      setSelectedVideoFile(null);
      setUploadedVideoUrl('');
      setUploadedVideoSize('');
      setUploadedVideoName('');
      setVideoUploadStatus('idle');
      setVideoUploadProgress(0);
      setIsPaid(false);
      setSecretCode('');
      if (videoFileInputRef.current) videoFileInputRef.current.value = '';
      showToast('تم نشر المحاضرة وحفظها عبر الإنترنت بنجاح! متاحة الآن لجميع الطلاب 🌐');
    } catch (err) {
      showToast('تم حفظ المحاضرة محلياً ونشرها في المنصة');
    } finally {
      setIsSavingLecture(false);
    }
  };

  // Open Edit Lecture modal
  const handleOpenEditLecture = (lec: LectureItem) => {
    setEditingLecture(lec);
    setEditTitle(lec.title);
    setEditDesc(lec.desc || '');
    setEditGrade(lec.grade);
    setEditVideoUrl(lec.videoUrl);
    setEditIsPaid(Boolean(lec.isPaid));
    setEditSecretCode(lec.secretCode || 'BIO2026');
    playClickSound();
  };

  // Save Edited Lecture
  const handleSaveEditLecture = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLecture) return;

    if (!editTitle.trim() || !editVideoUrl.trim()) {
      showToast('يرجى ملء عنوان ورابط المحاضرة');
      return;
    }

    setIsSavingEdit(true);
    const updates: Partial<LectureItem> = {
      title: editTitle.trim(),
      desc: editDesc.trim(),
      grade: editGrade,
      videoUrl: VideoUrlResolver.sanitizeUrl(editVideoUrl.trim()),
      isPaid: editIsPaid,
      secretCode: editIsPaid ? (editSecretCode.trim() || 'BIO2026') : null
    };

    try {
      if (onEditLecture) {
        await onEditLecture(editingLecture.id, updates);
        const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';
        await fetch(`/api/lectures/${editingLecture.id}`, {
          method: 'PUT',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${adminToken}`
          },
          body: JSON.stringify(updates)
        });
      }
      playSuccessSound();
      showToast('تم تحديث بيانات المحاضرة بنجاح لجميع المستخدمين ✅');
      setEditingLecture(null);
    } catch (err) {
      showToast('حدث خطأ أثناء تعديل المحاضرة');
    } finally {
      setIsSavingEdit(false);
    }
  };

  // Delete single lecture
  const confirmDeleteLecture = async (id: number) => {
    try {
      await onDeleteLecture(id);
      setLectureIdToDelete(null);
      showToast('تم حذف المحاضرة وإزالتها من المنصة وعن جميع المستخدمين بنجاح!');
    } catch (e) {
      showToast('حدث خطأ أثناء حذف المحاضرة');
    }
  };

  // Delete all lectures
  const confirmDeleteAll = async () => {
    if (onDeleteAllLectures) {
      try {
        await onDeleteAllLectures();
        setIsConfirmingDeleteAll(false);
        showToast('تم حذف جميع المحاضرات بنجاح من السيرفر وعن جميع الطلاب!');
      } catch (e) {
        showToast('تم حذف المحاضرات بنجاح');
      }
    }
  };

  // ==========================================
  // User Management Handlers
  // ==========================================
  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || !newUserContact.trim()) {
      showToast('يرجى إدخال اسم الطالب ورقم هاتفه أو بريده');
      return;
    }

    const payload = {
      name: newUserName.trim(),
      emailOrPhone: newUserContact.trim(),
      grade: newUserGrade,
      isVip: newUserIsVip,
      deviceType: newUserDevice,
      notes: newUserNotes.trim()
    };

    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.user) {
          setUsers(prev => [data.user, ...prev]);
          setUserStats(prev => ({
            ...prev,
            total: prev.total + 1,
            active: prev.active + 1,
            vip: payload.isVip ? prev.vip + 1 : prev.vip,
            apk: payload.deviceType === 'android-apk' ? prev.apk + 1 : prev.apk
          }));
          showToast(`تمت إضافة الطالب ${payload.name} بنجاح إلى قاعدة البيانات السحابية 🌐`);
        }
      }
    } catch (err) {
      // Local fallback
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const fallbackUser: UserItem = {
        id: `STU-${randomSuffix}`,
        name: payload.name,
        emailOrPhone: payload.emailOrPhone,
        grade: payload.grade,
        role: payload.isVip ? 'vip' : 'student',
        status: 'active',
        isVip: payload.isVip,
        deviceType: payload.deviceType,
        registeredAt: new Date().toISOString().split('T')[0],
        lastActive: 'الآن',
        unlockedLectures: payload.isVip ? [101, 102] : [],
        notes: payload.notes
      };
      setUsers(prev => [fallbackUser, ...prev]);
      showToast(`تمت إضافة الطالب ${payload.name} بنجاح!`);
    }

    // Reset form & close modal
    setNewUserName('');
    setNewUserContact('');
    setNewUserIsVip(false);
    setNewUserNotes('');
    setIsAddUserModalOpen(false);
  };

  const handleToggleUserStatus = async (user: UserItem) => {
    const nextStatus = user.status === 'active' ? 'blocked' : 'active';
    const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

    // 1) Update in central Firestore cloud database
    try {
      await updateUserInCloud(user.uid || user.id, { status: nextStatus });
    } catch (err) {
      console.warn('Cloud user update notice:', err);
    }

    // 2) Update on server
    try {
      await fetch(`/api/users/${user.id}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify({ status: nextStatus })
      });
    } catch (e) {}

    setUsers(prev => prev.map(u => u.id === user.id ? { ...u, status: nextStatus } : u));
    setUserStats(prev => ({
      ...prev,
      active: nextStatus === 'active' ? prev.active + 1 : prev.active - 1,
      blocked: nextStatus === 'blocked' ? prev.blocked + 1 : prev.blocked - 1
    }));
    showToast(nextStatus === 'blocked' ? `تم حظر حساب الطالب ${user.name}` : `تم تفعيل حساب الطالب ${user.name}`);
  };

  const handleToggleUserVip = async (user: UserItem) => {
    const nextVip = !user.isVip;
    const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

    // 1) Update in central Firestore cloud database
    try {
      await updateUserInCloud(user.uid || user.id, { isVip: nextVip, role: nextVip ? 'vip' : 'student' });
    } catch (err) {
      console.warn('Cloud user update notice:', err);
    }

    // 2) Update on server
    try {
      await fetch(`/api/users/${user.id}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify({ isVip: nextVip, role: nextVip ? 'vip' : 'student' })
      });
    } catch (e) {}

    setUsers(prev => prev.map(u => u.id === user.id ? { ...u, isVip: nextVip, role: nextVip ? 'vip' : 'student' } : u));
    setUserStats(prev => ({
      ...prev,
      vip: nextVip ? prev.vip + 1 : prev.vip - 1
    }));
    showToast(nextVip ? `تمت ترقية الطالب ${user.name} إلى VIP ✅` : `تم إلغاء ترقية VIP للطالب ${user.name}`);
  };

  const handleSaveEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

    // 1) Update in central Firestore cloud database
    try {
      await updateUserInCloud(editingUser.uid || editingUser.id, editingUser);
    } catch (err) {
      console.warn('Cloud user edit notice:', err);
    }

    // 2) Update on server
    try {
      await fetch(`/api/users/${editingUser.id}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify(editingUser)
      });
    } catch (e) {}

    setUsers(prev => prev.map(u => u.id === editingUser.id ? editingUser : u));
    showToast(`تم حفظ تعديلات بيانات الطالب ${editingUser.name} بنجاح!`);
    setEditingUser(null);
  };

  const handleDeleteUser = async (id: string) => {
    const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

    // 1) Delete from central Firestore cloud database
    try {
      await deleteUserFromCloud(id);
    } catch (err) {
      console.warn('Cloud user delete notice:', err);
    }

    // 2) Delete from server
    try {
      await fetch(`/api/users/${id}`, { 
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${adminToken}`
        }
      });
    } catch (e) {}

    setUsers(prev => prev.filter(u => u.id !== id && u.uid !== id));
    setUserStats(prev => ({ ...prev, total: Math.max(0, prev.total - 1) }));
    setUserIdToDelete(null);
    showToast('تم حذف المستخدم نهائياً من قاعدة البيانات السحابية المركزية');
  };

  const handleBroadcastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMessage.trim()) return;
    try {
      localStorage.setItem('admin_broadcast_announcement', JSON.stringify({
        text: broadcastMessage.trim(),
        date: new Date().toISOString()
      }));
    } catch (e) {}
    showToast('تم إرسال ونشر الإشعار الجماعي بنجاح لجميع الطلاب داخل التطبيق! 📢');
    setBroadcastMessage('');
    setIsBroadcastModalOpen(false);
  };

  // Copy helpers
  const handleCopyAppUrl = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
    showToast('تم نسخ رابط المنصة والتطبيق بنجاح!');
  };

  const handleCopyApkUrl = () => {
    navigator.clipboard.writeText(apkDownloadUrl);
    setCopiedApkUrl(true);
    setTimeout(() => setCopiedApkUrl(false), 2500);
    showToast('تم نسخ رابط تحميل APK المباشر!');
  };

  // Share actions
  const shareWhatsApp = () => {
    const text = `تطبيق مختبر الأحياء للأستاذ وسام سهيل العامري:\nمنصة تعليمية متكاملة لمادة الأحياء لكافة المراحل الدراسية مع إمكانية التثبيت كـ APK مجاناً!\nرابط التطبيق: ${appUrl}\nرابط تنزيل ملف الـ APK المباشر: ${apkDownloadUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const shareTelegram = () => {
    const text = `تطبيق مختبر الأحياء للأستاذ وسام سهيل العامري - جميع المراحل الدراسية:\nرابط المنصة: ${appUrl}\nرابط تنزيل ملف APK: ${apkDownloadUrl}`;
    window.open(`https://t.me/share/url?url=${encodeURIComponent(appUrl)}&text=${encodeURIComponent(text)}`, '_blank');
  };

  // Filtered Users
  const filteredUsers = users.filter(user => {
    const matchesSearch = !userSearchQuery.trim() || 
      user.name.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      (user.uid && user.uid.toLowerCase().includes(userSearchQuery.toLowerCase())) ||
      user.emailOrPhone.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      user.id.toLowerCase().includes(userSearchQuery.toLowerCase());

    const matchesTrack = userTrackFilter === 'all' ||
      (userTrackFilter === 'vip' ? (user.isVip || user.role === 'vip') : (user.track === 'school' || !user.track));

    const matchesGrade = userGradeFilter === 'all' || user.grade === userGradeFilter;

    let matchesStatus = true;
    if (userStatusFilter === 'active') matchesStatus = user.status === 'active';
    else if (userStatusFilter === 'blocked') matchesStatus = user.status === 'blocked';
    else if (userStatusFilter === 'vip') matchesStatus = user.isVip || user.role === 'vip';
    else if (userStatusFilter === 'apk') matchesStatus = user.deviceType === 'android-apk';

    return matchesSearch && matchesTrack && matchesGrade && matchesStatus;
  });

  // Appearance, 5 Themes, Transitions & Sound handlers
  const handleApplyTheme = async (preset: ThemePreset) => {
    setSelectedThemeId(preset.id);
    setSelectedTransition(preset.transition.id);
    applyThemeToDocument(preset);
    soundManager.setActiveTheme(preset.id);

    if (onSelectTheme) {
      onSelectTheme(preset.id);
    }
    if (onSelectTransitionStyle) {
      onSelectTransitionStyle(preset.transition.id);
    }

    try {
      localStorage.setItem('biolab_active_theme_id', preset.id);
      localStorage.setItem('biolab_transition_style', preset.transition.id);
    } catch (e) {}

    playSuccessSound();
    showToast(`تم تفعيل ${preset.name} بنجاح واعتماده للمنصة 🎨`);

    // Sync to Server API so all connected students get this theme
    try {
      setIsSavingAppearance(true);
      await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          activeThemeId: preset.id,
          transitionStyle: preset.transition.id,
          soundPreset: soundToneStyle,
          soundEnabled: !localMuted,
          soundVolume: localVolume
        })
      });
    } catch (e) {
      console.warn('Theme applied locally; server not reachable');
    } finally {
      setIsSavingAppearance(false);
    }
  };

  const handleApplyCustomTransition = async (transId: 'cinematic' | 'cyber' | 'elastic' | 'cosmic' | 'minimal') => {
    setSelectedTransition(transId);
    if (onSelectTransitionStyle) {
      onSelectTransitionStyle(transId);
    }
    document.documentElement.setAttribute('data-transition-style', transId);
    try {
      localStorage.setItem('biolab_transition_style', transId);
    } catch (e) {}

    playClickSound();
    showToast(`تم اعتماد أسلوب الانتقال: ${transId} 🎬`);

    try {
      await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transitionStyle: transId })
      });
    } catch (e) {}
  };

  const handleToggleSoundMaster = () => {
    const nextMuted = !localMuted;
    setLocalMuted(nextMuted);
    soundManager.setIsMuted(nextMuted);
    if (onToggleSound) onToggleSound();
    if (!nextMuted) {
      playClickSound();
      showToast('تم تفعيل أصوات النقر والمؤثرات 🔊');
    } else {
      showToast('تم كتم أصوات النقر والمؤثرات 🔇');
    }
  };

  const handleChangeVolumeSlider = (val: number) => {
    setLocalVolume(val);
    soundManager.setVolume(val);
    if (onChangeVolume) onChangeVolume(val);
  };

  const handleChangeToneStyle = (style: any) => {
    setSoundToneStyle(style);
    soundManager.setSoundStyle(style);
    playClickSound(style === 'theme' ? undefined : style);
  };

  return (
    <>
      {/* 1) Login Modal */}
      {isLoginOpen && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div 
            className="relative w-full max-w-sm rounded-3xl bg-[#0a1220] border border-[#e9c978]/40 shadow-2xl p-6 sm:p-8 text-center text-[#eaf0f8]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-14 h-14 rounded-2xl bg-[#e9c978]/20 border border-[#e9c978]/40 text-[#e9c978] flex items-center justify-center text-2xl mx-auto mb-3 shadow-lg">
              🔒
            </div>

            <h2 className="font-amiri font-bold text-2xl text-[#e9c978] mb-2">
              دخول الإدارة
            </h2>
            <p className="text-xs text-gray-400 mb-5">
              لوحة التحكم الخاصة بالأستاذ وسام سهيل العامري
            </p>

            <form onSubmit={handleLoginSubmit} className="space-y-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="البريد الإلكتروني"
                required
                className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-sm text-center"
              />

              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="كلمة المرور"
                required
                className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-sm text-center"
              />

              <div className="pt-2 space-y-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-sm shadow-lg hover:brightness-110 transition"
                >
                  دخول
                </button>

                <button
                  type="button"
                  onClick={handleAdminGoogleLogin}
                  className="w-full py-2.5 px-3 rounded-xl bg-white hover:bg-gray-100 text-gray-800 font-bold text-xs flex items-center justify-center gap-2 transition shadow-sm"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>الدخول السريع بحساب Google</span>
                </button>

                <button
                  type="button"
                  onClick={onCloseLogin}
                  className="w-full py-2 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white font-bold text-xs transition"
                >
                  إلغاء
                </button>
              </div>

              <div className="text-[11px] text-gray-500 mt-2 flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#0fb98a]" />
                <span>لوحة تحكم مشفرة ومحمية خاصة بإدارة المنصة</span>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2) Full Admin Dashboard */}
      {isAdminOpen && (
        <div className="fixed inset-0 z-[1000] bg-[#04080f] overflow-y-auto p-4 sm:p-8 text-[#eaf0f8]">
          <div className="max-w-5xl mx-auto space-y-6 pt-4 pb-24">
            
            {/* Admin Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-white/10">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#e9c978] to-[#c9a24a] text-[#08111e] flex items-center justify-center text-2xl font-bold shadow-lg shadow-[#c9a24a]/20">
                  ⚙️
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="font-amiri font-bold text-2xl sm:text-3xl text-[#e9c978]">
                      لوحة تحكم الإدارة
                    </h2>
                    <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#0fb98a]/15 text-[#0fb98a] border border-[#0fb98a]/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#0fb98a] animate-pulse"></span>
                      <span>سيرفر سحابي متصل</span>
                    </span>
                  </div>
                  <p className="text-xs text-gray-400">
                    رفع ومزامنة الفيديوهات لجميع المستخدمين، إدارة شؤون الطلاب، وتنزيل تطبيق الـ APK
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-auto flex-wrap justify-end">
                <a
                  href="/biolab.apk"
                  download="biolab.apk"
                  className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-[#e9c978] via-[#ffd56b] to-[#c9a24a] text-[#08111e] font-black text-xs shadow-lg shadow-[#c9a24a]/25 hover:brightness-110 active:scale-95 transition"
                  title="تنزيل حزمة تطبيق الأندرويد الأصلية بصيغة APK مباشرة"
                >
                  <Download className="w-4 h-4 shrink-0 text-[#08111e]" />
                  <span>تنزيل التطبيق APK</span>
                </a>
                <button
                  onClick={onCloseAdmin}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white font-bold text-xs transition"
                >
                  <LogOut className="w-4 h-4" />
                  <span>تسجيل الخروج</span>
                </button>
              </div>
            </div>

            {/* Quick APK Download Action Banner in Admin Panel */}
            <div className="p-3 sm:p-4 rounded-2xl bg-gradient-to-r from-[#e9c978]/15 via-[#0fb98a]/10 to-transparent border border-[#e9c978]/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center text-xl font-bold shrink-0 shadow-inner">
                  📱
                </div>
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-white flex items-center gap-2 flex-wrap">
                    <span>حزمة تطبيق المنصة الرسمية للأندرويد (biolab.apk)</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#0fb98a]/20 text-[#0fb98a] border border-[#0fb98a]/30 font-semibold">جاهز للتنزيل الفوري</span>
                  </h4>
                  <p className="text-[11px] text-gray-400">
                    يمكنك تنزيل ملف الـ APK المباشر وتثبيته على هواتف الطلاب أو شاشات القاعات الدراسية.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <a
                  href="/biolab.apk"
                  download="biolab.apk"
                  className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-xs flex items-center justify-center gap-2 shadow-md shadow-[#c9a24a]/20 hover:brightness-110 active:scale-95 transition"
                >
                  <Download className="w-4 h-4 text-[#08111e]" />
                  <span>تنزيل APK الآن</span>
                </a>
                <button
                  type="button"
                  onClick={() => { playClickSound(); setAdminTab('apk'); }}
                  className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 hover:text-white text-xs font-semibold whitespace-nowrap transition"
                >
                  خيارات المشاركة
                </button>
              </div>
            </div>

            {/* Admin Section Tabs */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-9 gap-2 p-1.5 rounded-2xl bg-white/5 border border-white/10 text-xs sm:text-sm font-bold">
              {/* Tab 1: Lectures */}
              <button
                onClick={() => { playClickSound(); setAdminTab('lectures'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'lectures'
                    ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/25'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Video className="w-4 h-4 shrink-0" />
                <span className="truncate">المحاضرات ({liveLectures.length})</span>
              </button>

              {/* Tab: Curriculum Books & Booklets */}
              <button
                onClick={() => { playClickSound(); setAdminTab('books'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'books'
                    ? 'bg-gradient-to-r from-[#0fb98a] to-[#2dd4bf] text-[#08111e] shadow-md shadow-[#0fb98a]/25 font-black'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <BookOpen className="w-4 h-4 shrink-0 text-[#0fb98a]" />
                <span className="truncate">الكتب والملازم</span>
              </button>

              {/* Tab: Cloud Storage Management (إدارة السحابة والتخزين) */}
              <button
                onClick={() => { playClickSound(); setAdminTab('cloud'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'cloud'
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 shadow-md shadow-cyan-500/25 font-black'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Cloud className="w-4 h-4 shrink-0 text-cyan-400" />
                <span className="truncate">إدارة السحابة</span>
              </button>

              {/* Tab 2: Users */}
              <button
                onClick={() => { playClickSound(); setAdminTab('users'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'users'
                    ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/25'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Users className="w-4 h-4 shrink-0" />
                <span className="truncate">المستخدمين ({users.length})</span>
              </button>

              {/* Tab 2.1: VIP Lecture Codes */}
              <button
                onClick={() => { playClickSound(); setAdminTab('codes'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'codes'
                    ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/25'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <KeyRound className="w-4 h-4 shrink-0 text-[#e9c978]" />
                <span className="truncate">أكواد VIP</span>
              </button>

              {/* Tab 2.2: App Updates */}
              <button
                onClick={() => { playClickSound(); setAdminTab('updates'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'updates'
                    ? 'bg-gradient-to-r from-[#0fb98a] to-[#2dd4bf] text-[#08111e] shadow-md shadow-[#0fb98a]/25'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <RotateCw className="w-4 h-4 shrink-0 text-[#0fb98a]" />
                <span className="truncate">تحديث التطبيق</span>
              </button>

              {/* Tab 3: Institute Students (طلاب المعهد الخاص) */}
              <button
                onClick={() => { playClickSound(); setAdminTab('institute'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'institute'
                    ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/25'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <GraduationCap className="w-4 h-4 shrink-0 text-[#e9c978]" />
                <span className="truncate">طلاب المعهد</span>
              </button>

              {/* Tab 4.5: AI Assistant & Instructions (إدارة الذكاء الاصطناعي وتعليماته) */}
              <button
                onClick={() => { playClickSound(); setAdminTab('ai'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'ai'
                    ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/25 font-black'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Sparkles className="w-4 h-4 shrink-0 text-amber-300" />
                <span className="truncate">إدارة الذكاء الاصطناعي</span>
              </button>

              {/* Tab 5: Appearance & 5 Themes */}
              <button
                onClick={() => { playClickSound(); setAdminTab('appearance'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'appearance'
                    ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/25'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Palette className="w-4 h-4 shrink-0 text-[#e9c978]" />
                <span className="truncate">واجهة المنصة</span>
              </button>

              {/* Tab 6: APK */}
              <button
                onClick={() => { playClickSound(); setAdminTab('apk'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'apk'
                    ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/25'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Download className="w-4 h-4 shrink-0" />
                <span className="truncate">مشاركة APK</span>
              </button>

              {/* Tab 7: Security */}
              <button
                onClick={() => { playClickSound(); setAdminTab('security'); }}
                className={`py-3 px-2 sm:px-3 rounded-xl transition flex items-center justify-center gap-1.5 whitespace-nowrap ${
                  adminTab === 'security'
                    ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md shadow-[#c9a24a]/25'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Lock className="w-4 h-4 shrink-0 text-[#e9c978]" />
                <span className="truncate">أمان الإدارة</span>
              </button>
            </div>

            {/* ==========================================
                TAB 1: LECTURES & VIDEOS MANAGEMENT
                ========================================== */}
            {adminTab === 'lectures' && (
              <div className="space-y-6 animate-fadeIn">
                
                {/* Form: Add New Video / Lecture */}
                <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl space-y-5">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#0fb98a] animate-ping"></span>
                        <h3 className="font-amiri font-bold text-2xl text-white">
                          رفع وإضافة محاضرة جديدة عبر الإنترنت
                        </h3>
                      </div>
                      <p className="text-xs text-emerald-400/90 mt-1 flex items-center gap-1.5">
                        <Globe className="w-3.5 h-3.5" />
                        <span>متصل بالسيرفر: المحاضرة المرفوعة تظهر فوراً لجميع الطلاب في التطبيق والموقع دون الحاجة لإعادة التثبيت.</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={handleRunDiagnostic}
                        disabled={isRunningDiagnostic}
                        className="py-2 px-3.5 rounded-xl bg-blue-500/15 border border-blue-500/30 text-blue-300 hover:bg-blue-500 hover:text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
                        title="فحص قاعدة البيانات السحابية بحثاً عن محاضرات معطوبة أو ناقصة"
                      >
                        <Search className={`w-3.5 h-3.5 ${isRunningDiagnostic ? 'animate-spin' : ''}`} />
                        <span>تشخيص السحابة 🔍</span>
                      </button>
                      <span className="hidden sm:inline-block px-3 py-1 rounded-full text-xs font-bold bg-[#e9c978]/15 text-[#e9c978] border border-[#e9c978]/30">
                        مزامنة إنترنت حية 🌐
                      </span>
                    </div>
                  </div>

                  {/* Diagnostic Results Display */}
                  {diagnosticReport && (
                    <div className="p-5 rounded-2xl bg-blue-950/20 border border-blue-500/30 space-y-4 animate-fadeIn">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-blue-300 font-bold text-sm">
                          <AlertTriangle className="w-4 h-4" />
                          <span>نتائج فحص قاعدة البيانات السحابية (Lectures)</span>
                        </div>
                        <button 
                          onClick={() => setDiagnosticReport(null)}
                          className="text-[10px] bg-white/5 hover:bg-white/10 px-2 py-1 rounded-md text-gray-400"
                        >
                          إغلاق التقرير
                        </button>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="p-3 rounded-xl bg-black/40 border border-white/10 text-center">
                          <div className="text-[10px] text-gray-400 mb-1">إجمالي السجلات</div>
                          <div className="text-lg font-black text-white">{diagnosticReport.totalDocs}</div>
                        </div>
                        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
                          <div className="text-[10px] text-emerald-400/80 mb-1">سجلات سليمة</div>
                          <div className="text-lg font-black text-emerald-400">{diagnosticReport.healthyDocs}</div>
                        </div>
                        <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-center">
                          <div className="text-[10px] text-red-400/80 mb-1">سجلات بها مشاكل</div>
                          <div className="text-lg font-black text-red-400">{diagnosticReport.issues.length}</div>
                        </div>
                      </div>

                      {diagnosticReport.issues.length > 0 && (
                        <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                          {diagnosticReport.issues.map((issue: any, idx: number) => (
                            <div key={idx} className="p-3 rounded-xl bg-red-950/20 border border-red-500/20 flex flex-col gap-1 text-[11px]">
                              <div className="flex items-center justify-between font-bold text-red-300">
                                <span>{issue.title || 'محاضرة بدون عنوان'}</span>
                                <span className="font-mono text-[9px] opacity-60">{issue.docId}</span>
                              </div>
                              <div className="text-red-400/80">نوع الخلل: {issue.issueType}</div>
                              <div className="text-gray-500 text-[9px] truncate" dir="ltr">{issue.details}</div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  <form onSubmit={handleAddSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-300 mb-1.5">عنوان المحاضرة</label>
                      <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="مثال: الفصل الأول - الانقسام الخيطي والاختزالي"
                        required
                        className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-300 mb-1.5">وصف المحاضرة (اختياري)</label>
                      <textarea
                        value={desc}
                        onChange={(e) => setDesc(e.target.value)}
                        placeholder="شرح مختصر عن محاور المحاضرة والنقاط الوزارية المهمة..."
                        rows={2}
                        className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-sm"
                      />
                    </div>

                    {/* Grade & Stage Selector */}
                    <div>
                      <label className="block text-xs font-semibold text-gray-300 mb-1.5">المرحلة الدراسية للمحاضرة</label>
                      <select
                        value={grade}
                        onChange={(e) => setGrade(e.target.value)}
                        className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white focus:outline-none focus:border-[#e9c978] text-sm"
                      >
                        <option value="g1">الأول المتوسط</option>
                        <option value="g2">الثاني المتوسط</option>
                        <option value="g3">الثالث المتوسط</option>
                        <option value="g4">الرابع العلمي</option>
                        <option value="g5">الخامس العلمي</option>
                        <option value="g6">السادس العلمي</option>
                      </select>
                    </div>

                    {/* Method Selector Tabs: Device Upload vs External Link */}
                    <div className="space-y-3 p-4 rounded-2xl bg-black/40 border border-white/10">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-gray-200 flex items-center gap-2">
                          <Video className="w-4 h-4 text-[#e9c978]" />
                          <span>طريقة إضافة مقطع الفيديو:</span>
                        </label>
                        <span className="text-[11px] text-gray-400">
                          {videoUploadMode === 'device' ? '📁 تخزين مباشر بالسيرفر' : '🔗 ربط خارجي'}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-black/60 border border-white/5 text-xs font-bold">
                        <button
                          type="button"
                          onClick={() => { playClickSound(); setVideoUploadMode('device'); }}
                          className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition ${
                            videoUploadMode === 'device'
                              ? 'bg-gradient-to-r from-[#0fb98a] to-[#059669] text-black font-black shadow-md'
                              : 'text-gray-400 hover:text-white'
                          }`}
                        >
                          <FolderUp className="w-4 h-4" />
                          <span>📁 رفع فيديو من الجهاز</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => { playClickSound(); setVideoUploadMode('url'); }}
                          className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition ${
                            videoUploadMode === 'url'
                              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-black font-black shadow-md'
                              : 'text-gray-400 hover:text-white'
                          }`}
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span>🔗 إضافة عبر رابط خارجي</span>
                        </button>
                      </div>

                      {/* MODE 1: Direct Device Upload */}
                      {videoUploadMode === 'device' && (
                        <div className="space-y-3 pt-2">
                          {!selectedVideoFile && !uploadedVideoUrl ? (
                            <div className="relative w-full border-2 border-dashed border-[#0fb98a]/40 hover:border-[#0fb98a] bg-[#0fb98a]/5 hover:bg-[#0fb98a]/10 rounded-2xl p-6 text-center flex flex-col items-center justify-center gap-2 transition group overflow-hidden cursor-pointer">
                              <input
                                type="file"
                                ref={videoFileInputRef}
                                accept="video/mp4,video/webm,video/ogg,video/quicktime,video/x-matroska,.mp4,.webm,.mkv,.mov"
                                onChange={handleVideoFileSelect}
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                                id="admin-lecture-video-picker"
                                title="اضغط لاختيار ملف فيديو من جهازك"
                              />
                              <div className="w-12 h-12 rounded-2xl bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center group-hover:scale-110 transition-transform pointer-events-none">
                                <Upload className="w-6 h-6" />
                              </div>
                              <span className="font-bold text-sm text-white pointer-events-none">
                                اضغط هنا لاختيار ملف فيديو من جهازك (الهاتف أو الكمبيوتر)
                              </span>
                              <span className="text-xs text-gray-400 pointer-events-none">
                                يدعم ملفات MP4 و WebM و MKV و MOV بحجم حتى 300MB
                              </span>
                            </div>
                          ) : (
                            <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-3">
                              <div className="flex items-center justify-between gap-3">
                                <div className="flex items-center gap-2.5 truncate">
                                  <FileVideo className="w-7 h-7 text-[#0fb98a] shrink-0" />
                                  <div className="truncate">
                                    <p className="font-bold text-xs text-white truncate max-w-xs sm:max-w-md">
                                      {selectedVideoFile?.name || uploadedVideoName}
                                    </p>
                                    <p className="text-[11px] text-gray-400 flex items-center gap-2 mt-0.5">
                                      <span>
                                        الحجم: <strong className="text-[#0fb98a] font-mono">{selectedVideoFile ? `${(selectedVideoFile.size / (1024 * 1024)).toFixed(1)} MB` : uploadedVideoSize}</strong>
                                      </span>
                                      <span>·</span>
                                      <span className="uppercase text-[#e9c978] font-mono">
                                        {(selectedVideoFile?.name || uploadedVideoName).split('.').pop()}
                                      </span>
                                    </p>
                                  </div>
                                </div>

                                <div className="relative inline-block overflow-hidden">
                                  <input
                                    type="file"
                                    accept="video/mp4,video/webm,video/ogg,video/quicktime,video/x-matroska,.mp4,.webm,.mkv,.mov"
                                    onChange={handleVideoFileSelect}
                                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                                    title="تغيير الملف"
                                  />
                                  <button
                                    type="button"
                                    className="text-xs text-gray-400 hover:text-[#0fb98a] px-2 py-1 rounded hover:bg-white/5 transition pointer-events-none"
                                  >
                                    تغيير الملف
                                  </button>
                                </div>
                              </div>

                              {/* Upload Progress Bar */}
                              {isUploadingVideo && (
                                <div className="space-y-1.5 pt-2 border-t border-white/5">
                                  <div className="flex items-center justify-between text-xs">
                                    <span className="text-gray-300 font-bold flex items-center gap-1.5">
                                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#0fb98a]" />
                                      <span>جاري رفع الفيديو إلى مساحة تخزين المنصة...</span>
                                    </span>
                                    <span className="font-mono font-bold text-[#0fb98a]">{videoUploadProgress}%</span>
                                  </div>
                                  <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                                    <div
                                      className="h-full bg-gradient-to-r from-[#0fb98a] to-[#34d399] transition-all duration-300"
                                      style={{ width: `${videoUploadProgress}%` }}
                                    />
                                  </div>
                                </div>
                              )}

                              {/* Upload Success Badge and Local Preview */}
                              {videoUploadStatus === 'success' && uploadedVideoUrl && (
                                <div className="space-y-2 pt-2 border-t border-white/5">
                                  <div className="flex items-center gap-2 text-xs font-bold text-[#0fb98a]">
                                    <CheckCircle2 className="w-4 h-4" />
                                    <span>تم رفع الفيديو وتخزينه بنجاح على السيرفر!</span>
                                  </div>
                                  <div className="aspect-video max-h-48 rounded-xl overflow-hidden bg-black border border-white/10">
                                    <video
                                      src={uploadedVideoUrl}
                                      controls
                                      className="w-full h-full object-contain"
                                    />
                                  </div>
                                </div>
                              )}

                              {/* Upload Error & Retry */}
                              {videoUploadStatus === 'error' && (
                                <div className="p-3 rounded-xl bg-red-500/15 border border-red-500/30 flex items-center justify-between gap-2 text-xs">
                                  <div className="flex items-center gap-1.5 text-red-300">
                                    <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                                    <span>{videoUploadError || 'تعذر إتمام رفع الفيديو'}</span>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => uploadVideoFileToServer()}
                                    className="px-3 py-1 rounded-lg bg-red-500 text-white font-bold text-xs hover:bg-red-600 transition flex items-center gap-1 shrink-0"
                                  >
                                    <RotateCcw className="w-3.5 h-3.5" />
                                    <span>إعادة المحاولة</span>
                                  </button>
                                </div>
                              )}

                              {/* Direct Upload Button if file chosen but not uploaded yet */}
                              {videoUploadStatus === 'idle' && selectedVideoFile && !uploadedVideoUrl && (
                                <button
                                  type="button"
                                  onClick={() => uploadVideoFileToServer()}
                                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#059669] text-black font-black text-xs shadow-md hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-2"
                                >
                                  <Upload className="w-4 h-4" />
                                  <span>تأكيد ورفع الفيديو للسيرفر الآن</span>
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      {/* MODE 2: External Link (YouTube, AnonMP4, Drive, Direct URL, Embeds) */}
                      {videoUploadMode === 'url' && (
                        <div className="space-y-3 pt-2">
                          <div>
                            <label className="block text-xs font-semibold text-gray-300 mb-1">
                              رابط الفيديو أو كود التضمين (YouTube, AnonMP4, Google Drive, Vimeo, MP4 مباشر)
                            </label>
                            <input
                              type="text"
                              value={videoUrl}
                              onChange={(e) => setVideoUrl(e.target.value)}
                              placeholder="https://... أو https://anonmp4.com/... أو كود iframe"
                              className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] text-sm font-mono"
                              dir="ltr"
                            />
                          </div>

                          {/* Live Provider Auto-Detection Badge & Preview */}
                          {videoUrl.trim() && (() => {
                            const provider = VideoUrlResolver.detectProvider(videoUrl);
                            return (
                              <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-2">
                                <div className="flex items-center justify-between text-xs">
                                  <span className="text-gray-300 flex items-center gap-1.5">
                                    <span className="text-gray-400">المزود المكتشف:</span>
                                    <strong className="text-[#e9c978] font-bold">{provider.name}</strong>
                                  </span>
                                  <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                                    provider.id !== 'unknown' 
                                      ? 'bg-[#0fb98a]/15 text-[#0fb98a] border border-[#0fb98a]/30' 
                                      : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                                  }`}>
                                    {provider.id !== 'unknown' ? '✓ مدعوم مع المشغل الموحد' : '⚠️ فحص الرابط'}
                                  </span>
                                </div>

                                {/* Live Video Preview Box */}
                                <div className="rounded-xl overflow-hidden border border-white/10 bg-black aspect-video max-h-52">
                                  <UniversalVideoPlayer
                                    url={videoUrl}
                                    title={title || 'معاينة المحاضرة'}
                                    autoPlay={false}
                                  />
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      )}
                    </div>

                    {/* VIP Switch */}
                    <div className="flex items-center justify-between p-4 rounded-2xl bg-black/40 border border-white/10">
                      <div className="flex items-center gap-3">
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isPaid}
                            onChange={(e) => setIsPaid(e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#0fb98a]"></div>
                        </label>
                        <div>
                          <span className="font-bold text-sm text-white block">محاضرة مدفوعة (تتطلب كود سري أو اشتراك VIP)</span>
                          <span className="text-xs text-gray-400">لن يتمكن الطالب من فتح الفيديو إلا بعد كتابة الكود السري أو الترقية لـ VIP</span>
                        </div>
                      </div>
                    </div>

                    {/* Secret Code Input */}
                    {isPaid && (
                      <div className="p-4 rounded-2xl bg-[#e9c978]/10 border border-[#e9c978]/30 space-y-2 animate-fadeIn">
                        <label className="block text-xs font-bold text-[#e9c978]">
                          اكتب الكود السري هنا (مثال: BIO2026)
                        </label>
                        <input
                          type="text"
                          value={secretCode}
                          onChange={(e) => setSecretCode(e.target.value)}
                          placeholder="اكتب الكود السري هنا (مثال: BIO2026)"
                          className="w-full py-3 px-4 rounded-xl bg-black/60 border border-[#e9c978]/40 text-white placeholder:text-gray-500 font-mono text-sm focus:outline-none focus:border-[#e9c978]"
                        />
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isSavingLecture}
                      className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-sm shadow-xl hover:brightness-110 active:scale-98 transition flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isSavingLecture ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin text-[#08111e]" />
                          <span>جاري الرفع والنشر عبر الإنترنت...</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-4 h-4 text-[#08111e]" />
                          <span>رفع ونشر المحاضرة لجميع الطلاب عبر الإنترنت</span>
                        </>
                      )}
                    </button>
                  </form>
                </div>

                {/* List: Existing Lectures with Delete Controls */}
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-2 border-b border-white/10">
                    <div>
                      <h3 className="font-bold text-lg text-white flex items-center gap-2">
                        <Video className="w-5 h-5 text-[#e9c978]" />
                        <span>المحاضرات المنشورة حالياً في التطبيق ({liveLectures.length})</span>
                      </h3>
                      <p className="text-xs text-gray-400">
                        أي محاضرة تُحذف من هنا تُحذف فوراً من عند جميع الطلاب ومستخدمي تطبيق الأندرويد.
                      </p>
                    </div>

                    {liveLectures.length > 0 && onDeleteAllLectures && (
                      <div>
                        {!isConfirmingDeleteAll ? (
                          <button
                            onClick={() => setIsConfirmingDeleteAll(true)}
                            className="py-1.5 px-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white text-xs font-bold transition flex items-center gap-1.5"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>حذف جميع المحاضرات</span>
                          </button>
                        ) : (
                          <div className="flex items-center gap-2 p-1.5 rounded-xl bg-red-500/20 border border-red-500/40">
                            <span className="text-[11px] font-bold text-red-300">متأكد من حذف الكل؟</span>
                            <button
                              onClick={confirmDeleteAll}
                              className="py-1 px-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-black text-xs transition"
                            >
                              نعم، احذف الكل
                            </button>
                            <button
                              onClick={() => setIsConfirmingDeleteAll(false)}
                              className="py-1 px-2 rounded-lg bg-white/10 text-gray-300 hover:text-white text-xs font-semibold"
                            >
                              إلغاء
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Filter and Search Bar */}
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                    <div className="sm:col-span-7 relative">
                      <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={adminSearchQuery}
                        onChange={(e) => setAdminSearchQuery(e.target.value)}
                        placeholder="ابحث عن محاضرة لحذفها أو تعديلها..."
                        className="w-full py-2.5 pr-10 pl-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 text-xs focus:outline-none focus:border-[#e9c978]"
                      />
                    </div>

                    <div className="sm:col-span-5">
                      <select
                        value={adminGradeFilter}
                        onChange={(e) => setAdminGradeFilter(e.target.value)}
                        className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                      >
                        <option value="all">كل المراحل الدراسية</option>
                        <option value="g1">الأول المتوسط</option>
                        <option value="g2">الثاني المتوسط</option>
                        <option value="g3">الثالث المتوسط</option>
                        <option value="g4">الرابع العلمي</option>
                        <option value="g5">الخامس العلمي</option>
                        <option value="g6">السادس العلمي</option>
                      </select>
                    </div>
                  </div>

                  {/* Lectures List Content */}
                  {isLoadingLectures && liveLectures.length === 0 ? (
                    <div className="p-12 flex flex-col items-center justify-center text-gray-400 space-y-4">
                      <RefreshCw className="w-8 h-8 animate-spin text-[#e9c978]" />
                      <p className="text-sm font-bold">جاري مزامنة المحاضرات من السحابة...</p>
                    </div>
                  ) : liveLectures.length === 0 ? (
                    <div className="p-8 rounded-2xl bg-[#0a1220] border border-white/10 text-center space-y-2">
                      <div className="text-3xl">📭</div>
                      <p className="text-sm font-bold text-gray-300">لا توجد محاضرات حالياً في المنصة.</p>
                      <p className="text-xs text-gray-500">استخدم نموذج الإضافة أعلاه لنشر فيديو جديد لجميع الطلاب.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {liveLectures
                        .filter((lec) => {
                          const matchesGrade = adminGradeFilter === 'all' || lec.grade === adminGradeFilter;
                          const matchesSearch = !adminSearchQuery.trim() ||
                            lec.title.toLowerCase().includes(adminSearchQuery.trim().toLowerCase()) ||
                            (lec.desc && lec.desc.toLowerCase().includes(adminSearchQuery.trim().toLowerCase()));
                          return matchesGrade && matchesSearch;
                        })
                        .sort((a, b) => b.id - a.id)
                        .map((lec) => {
                          const isTargetForDelete = lectureIdToDelete === lec.id;

                          return (
                            <div
                              key={lec._docId || lec.id}
                              className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                                isTargetForDelete 
                                  ? 'bg-red-500/10 border-red-500/50 shadow-lg' 
                                  : lec.isMalformed
                                  ? 'bg-red-950/10 border-red-500/30'
                                  : 'bg-[#0a1220] border-white/10 hover:border-[#e9c978]/30'
                              }`}
                            >
                              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                                <div className="space-y-1.5 flex-1 min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-[#e9c978]/15 text-[#e9c978] border border-[#e9c978]/25">
                                      📚 {gradeNames[lec.grade] || lec.grade}
                                    </span>
                                    {lec.isPaid ? (
                                      <span className="font-mono text-[11px] text-[#0fb98a] font-bold bg-[#0fb98a]/10 px-2 py-0.5 rounded border border-[#0fb98a]/20">
                                        VIP 🔒 كود: {lec.secretCode}
                                      </span>
                                    ) : (
                                      <span className="text-[11px] text-gray-400 bg-white/5 px-2 py-0.5 rounded">
                                        مجانية للجميع
                                      </span>
                                    )}
                                    <span className="text-[10px] text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 rounded">
                                      <Globe className="w-3 h-3" />
                                      <span>منشورة عبر الإنترنت</span>
                                    </span>
                                    {lec.isMalformed && (
                                      <span className="text-[10px] text-red-400 font-bold flex items-center gap-1 bg-red-500/10 px-2 py-0.5 rounded animate-pulse">
                                        <AlertTriangle className="w-3 h-3" />
                                        <span>بيانات معطوبة</span>
                                      </span>
                                    )}
                                  </div>

                                  <h4 className="font-bold text-base text-white truncate">
                                    {lec.title}
                                  </h4>

                                  {lec.desc && (
                                    <p className="text-xs text-gray-400 line-clamp-1">
                                      {lec.desc}
                                    </p>
                                  )}

                                  <div className="text-[11px] text-gray-500 font-mono truncate" dir="ltr">
                                    {lec.videoUrl}
                                  </div>
                                </div>

                                {/* Action Buttons: Edit & Delete */}
                                {!isTargetForDelete ? (
                                  <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
                                    <button
                                      type="button"
                                      onClick={() => handleOpenEditLecture(lec)}
                                      className="py-2 px-3.5 rounded-xl bg-white/10 hover:bg-[#e9c978] hover:text-[#08111e] border border-white/10 text-white transition flex items-center justify-center gap-1.5 text-xs font-bold"
                                      title="تعديل بيانات المحاضرة"
                                    >
                                      <Edit3 className="w-3.5 h-3.5" />
                                      <span>تعديل</span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => setLectureIdToDelete(lec.id)}
                                      className="py-2 px-3.5 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white transition flex items-center justify-center gap-1.5 text-xs font-bold"
                                      title="حذف هذه المحاضرة"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                      <span>حذف</span>
                                    </button>
                                  </div>
                                ) : null}
                              </div>

                              {/* Inline Confirmation when Delete is clicked */}
                              {isTargetForDelete && (
                                <div className="mt-4 pt-3 border-t border-red-500/20 flex flex-col sm:flex-row items-center justify-between gap-3 animate-fadeIn">
                                  <div className="flex items-center gap-2 text-xs font-bold text-red-300">
                                    <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                                    <span>هل أنت متأكد من حذف هذه المحاضرة نهائياً من سيرفر المنصة والتطبيق؟</span>
                                  </div>
                                  <div className="flex items-center gap-2 w-full sm:w-auto">
                                    <button
                                      onClick={() => confirmDeleteLecture(lec.id)}
                                      className="flex-1 sm:flex-initial py-2 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg active:scale-95 transition"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                      <span>تأكيد الحذف نهائياً</span>
                                    </button>
                                    <button
                                      onClick={() => setLectureIdToDelete(null)}
                                      className="flex-1 sm:flex-initial py-2 px-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 text-xs font-semibold transition"
                                    >
                                      إلغاء
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                    </div>
                  )}
                </div>

                {/* ==========================================
                    EDIT LECTURE MODAL
                    ========================================== */}
                {editingLecture && (
                  <div className="fixed inset-0 z-[1200] bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
                    <div className="w-full max-w-2xl bg-[#0a1220] border border-[#e9c978]/40 rounded-3xl shadow-2xl p-6 sm:p-8 space-y-5 animate-scaleUp text-[#eaf0f8]">
                      
                      {/* Header */}
                      <div className="flex items-center justify-between pb-3 border-b border-white/10">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-9 rounded-xl bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center">
                            <Edit3 className="w-5 h-5" />
                          </div>
                          <div>
                            <h3 className="font-amiri font-bold text-xl text-white">تعديل بيانات المحاضرة</h3>
                            <p className="text-xs text-gray-400">تحديث العنوان، المرحلة، رابط الفيديو، وحالة VIP</p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setEditingLecture(null)}
                          className="p-1.5 rounded-xl hover:bg-white/10 text-gray-400 hover:text-white transition"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>

                      {/* Edit Form */}
                      <form onSubmit={handleSaveEditLecture} className="space-y-4">
                        <div>
                          <label className="block text-xs font-semibold text-gray-300 mb-1.5">عنوان المحاضرة</label>
                          <input
                            type="text"
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            required
                            className="w-full py-2.5 px-4 rounded-xl bg-black/50 border border-white/10 text-white text-sm focus:outline-none focus:border-[#e9c978]"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-gray-300 mb-1.5">الوصف (اختياري)</label>
                          <textarea
                            value={editDesc}
                            onChange={(e) => setEditDesc(e.target.value)}
                            rows={2}
                            className="w-full py-2.5 px-4 rounded-xl bg-black/50 border border-white/10 text-white text-sm focus:outline-none focus:border-[#e9c978]"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-semibold text-gray-300 mb-1.5">المرحلة الدراسية</label>
                            <select
                              value={editGrade}
                              onChange={(e) => setEditGrade(e.target.value)}
                              className="w-full py-2.5 px-4 rounded-xl bg-black/50 border border-white/10 text-white text-sm focus:outline-none focus:border-[#e9c978]"
                            >
                              <option value="g1">الأول المتوسط</option>
                              <option value="g2">الثاني المتوسط</option>
                              <option value="g3">الثالث المتوسط</option>
                              <option value="g4">الرابع العلمي</option>
                              <option value="g5">الخامس العلمي</option>
                              <option value="g6">السادس العلمي</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-gray-300 mb-1.5">رابط أو مسار الفيديو</label>
                            <input
                              type="text"
                              value={editVideoUrl}
                              onChange={(e) => setEditVideoUrl(e.target.value)}
                              required
                              className="w-full py-2.5 px-4 rounded-xl bg-black/50 border border-white/10 text-white text-sm focus:outline-none focus:border-[#e9c978] font-mono"
                              dir="ltr"
                            />
                            {editVideoUrl.trim() && (() => {
                              const provider = VideoUrlResolver.detectProvider(editVideoUrl);
                              return (
                                <div className="mt-2 p-2 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
                                  <span className="text-gray-300 flex items-center gap-1.5">
                                    <span className="text-gray-400">المزود:</span>
                                    <strong className="text-[#e9c978]">{provider.name}</strong>
                                  </span>
                                  <span className="text-[#0fb98a] text-[11px] font-bold">
                                    {provider.id !== 'unknown' ? '✓ مدعوم' : '⚠️ فحص'}
                                  </span>
                                </div>
                              );
                            })()}
                          </div>
                        </div>

                        {/* VIP Switch */}
                        <div className="flex items-center justify-between p-3.5 rounded-2xl bg-black/40 border border-white/10">
                          <label className="flex items-center gap-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={editIsPaid}
                              onChange={(e) => setEditIsPaid(e.target.checked)}
                              className="w-4 h-4 accent-[#0fb98a] rounded"
                            />
                            <span className="text-xs font-bold text-white">محاضرة مدفوعة VIP (تتطلب كوداً سرياً)</span>
                          </label>
                        </div>

                        {editIsPaid && (
                          <div className="space-y-1">
                            <label className="block text-xs font-bold text-[#e9c978]">الكود السري لفتح الفيديو</label>
                            <input
                              type="text"
                              value={editSecretCode}
                              onChange={(e) => setEditSecretCode(e.target.value)}
                              className="w-full py-2 px-3 rounded-xl bg-black/60 border border-[#e9c978]/40 text-white font-mono text-xs focus:outline-none focus:border-[#e9c978]"
                            />
                          </div>
                        )}

                        {/* Actions */}
                        <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                          <button
                            type="button"
                            onClick={() => setEditingLecture(null)}
                            className="py-2.5 px-5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 font-semibold text-xs transition"
                          >
                            إلغاء
                          </button>
                          <button
                            type="submit"
                            disabled={isSavingEdit}
                            className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-black font-black text-xs shadow-md hover:brightness-110 active:scale-95 transition flex items-center gap-2 disabled:opacity-50"
                          >
                            {isSavingEdit ? (
                              <>
                                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                                <span>جاري حفظ التعديل...</span>
                              </>
                            ) : (
                              <span>حفظ التعديلات وتحديث المنصة</span>
                            )}
                          </button>
                        </div>
                      </form>

                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ==========================================
                TAB: CURRICULUM BOOKS & BOOKLETS (إدارة الكتب والملازم)
                ========================================== */}
            {adminTab === 'books' && (
              <div className="animate-fadeIn">
                <AdminBooksTab onShowToast={showToast} />
              </div>
            )}

            {/* ==========================================
                TAB: CLOUD STORAGE & ORPHAN MANAGEMENT (إدارة الخدمة السحابية والملفات)
                ========================================== */}
            {adminTab === 'cloud' && (
              <div className="animate-fadeIn">
                <AdminCloudStorageTab onNotify={showToast} />
              </div>
            )}

            {/* ==========================================
                TAB 2: USER MANAGEMENT (قسم إدارة المستخدمين)
                ========================================== */}
            {adminTab === 'users' && (
              <div className="space-y-6 animate-fadeIn">
                
                {/* User Management Overview & Stats */}
                <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl space-y-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-[#0fb98a] animate-pulse"></span>
                        <h3 className="font-amiri font-bold text-2xl text-white">
                          قسم إدارة المستخدمين والطلاب المسجلين
                        </h3>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">
                        متابعة الطلاب المتصلين بالمنصة، صلاحيات باقات VIP، حظر وتفعيل الحسابات، وإحصائيات استخدام تطبيق الأندرويد
                      </p>
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <button
                        onClick={fetchUsers}
                        className="py-2 px-3.5 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 text-xs font-bold text-gray-300 hover:text-white flex items-center gap-1.5 transition"
                        title="تحديث البيانات من السيرفر"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isLoadingUsers ? 'animate-spin' : ''}`} />
                        <span>تحديث</span>
                      </button>

                      <button
                        onClick={() => setIsBroadcastModalOpen(true)}
                        className="py-2 px-3.5 rounded-xl bg-purple-500/15 border border-purple-500/30 text-purple-300 hover:bg-purple-500 hover:text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
                      >
                        <Bell className="w-3.5 h-3.5" />
                        <span>إشعار للطلاب</span>
                      </button>

                      <button
                        onClick={() => setIsAddUserModalOpen(true)}
                        className="py-2 px-4 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs flex items-center gap-1.5 shadow-md hover:brightness-110 active:scale-95 transition"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>إضافة طالب جديد</span>
                      </button>
                    </div>
                  </div>

                  {/* Real-time KPI Stats Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-6 gap-2.5">
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>إجمالي الطلاب</span>
                        <Users className="w-4 h-4 text-[#e9c978]" />
                      </div>
                      <div className="text-xl sm:text-2xl font-black text-white font-mono">
                        {users.length}
                      </div>
                      <div className="text-[10px] text-gray-500">حسابات مسجلة</div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-black/40 border border-amber-500/20 space-y-1">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>طلاب المدارس</span>
                        <School className="w-4 h-4 text-amber-400" />
                      </div>
                      <div className="text-xl sm:text-2xl font-black text-amber-300 font-mono">
                        {userStats.schoolCount !== undefined ? userStats.schoolCount : users.filter(u => u.track === 'school' || !u.track).length}
                      </div>
                      <div className="text-[10px] text-amber-400/80">المتوسطة والإعدادية</div>
                    </div>


                    <div className="p-3.5 rounded-2xl bg-black/40 border border-amber-500/20 space-y-1">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>مشتركو VIP</span>
                        <Sparkles className="w-4 h-4 text-amber-400" />
                      </div>
                      <div className="text-xl sm:text-2xl font-black text-[#e9c978] font-mono">
                        {users.filter(u => u.isVip || u.role === 'vip').length}
                      </div>
                      <div className="text-[10px] text-[#e9c978]/80">وصول كامل للمحاضرات</div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-black/40 border border-emerald-500/20 space-y-1">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>متصلون الآن</span>
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                      </div>
                      <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono">
                        {users.filter(u => u.status === 'active').length}
                      </div>
                      <div className="text-[10px] text-emerald-400/80">حساب نشط بالكامل</div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-black/40 border border-teal-500/20 space-y-1">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>تطبيق APK</span>
                        <Smartphone className="w-4 h-4 text-teal-400" />
                      </div>
                      <div className="text-xl sm:text-2xl font-black text-teal-300 font-mono">
                        {users.filter(u => u.deviceType === 'android-apk').length}
                      </div>
                      <div className="text-[10px] text-teal-400/80">أجهزة أندرويد مثبتة</div>
                    </div>
                  </div>

                  {/* User Search & Filter Controls */}
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 pt-2">
                    <div className="sm:col-span-4 relative">
                      <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={userSearchQuery}
                        onChange={(e) => setUserSearchQuery(e.target.value)}
                        placeholder="ابحث بالاسم، معرّف UID، أو الهاتف..."
                        className="w-full py-2.5 pr-10 pl-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 text-xs focus:outline-none focus:border-[#e9c978]"
                      />
                    </div>

                    <div className="sm:col-span-3">
                      <select
                        value={userTrackFilter}
                        onChange={(e) => setUserTrackFilter(e.target.value as any)}
                        className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                      >
                        <option value="all">جميع الحسابات المسجلة</option>
                        <option value="school">طلاب المدارس (المتوسطة والإعدادية) 🏫</option>
                        <option value="vip">مشتركو VIP 🌟</option>
                      </select>
                    </div>

                    <div className="sm:col-span-3">
                      <select
                        value={userGradeFilter}
                        onChange={(e) => setUserGradeFilter(e.target.value)}
                        className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                      >
                        <option value="all">كل المراحل الدراسية</option>
                        <option value="g1">الأول المتوسط</option>
                        <option value="g2">الثاني المتوسط</option>
                        <option value="g3">الثالث المتوسط</option>
                        <option value="g4">الرابع العلمي</option>
                        <option value="g5">الخامس العلمي</option>
                        <option value="g6">السادس العلمي</option>
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <select
                        value={userStatusFilter}
                        onChange={(e) => setUserStatusFilter(e.target.value as any)}
                        className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                      >
                        <option value="all">جميع الحالات</option>
                        <option value="active">النشطين فقط 🟢</option>
                        <option value="vip">مشتركو VIP 🌟</option>
                        <option value="apk">مستخدمو APK 📱</option>
                        <option value="blocked">المحظورين 🔴</option>
                      </select>
                    </div>
                  </div>

                  {/* Users List Table & Cards */}
                  {filteredUsers.length === 0 ? (
                    <div className="p-8 rounded-2xl bg-black/30 border border-white/10 text-center space-y-2">
                      <div className="text-3xl">👥</div>
                      <p className="text-sm font-bold text-gray-300">لم يتم العثور على طلاب مطابقين للبحث.</p>
                      <p className="text-xs text-gray-500">جرب تغيير كلمات البحث أو الفلاتر أعلاه.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {filteredUsers.map((user) => {
                        const isBlocked = user.status === 'blocked';
                        const isVip = user.isVip || user.role === 'vip';
                        const isDeleting = userIdToDelete === user.id;

                        return (
                          <div
                            key={user.id}
                            className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                              isBlocked 
                                ? 'bg-red-500/5 border-red-500/30' 
                                : isVip 
                                ? 'bg-amber-500/5 border-[#e9c978]/30 hover:border-[#e9c978]/60' 
                                : 'bg-black/40 border-white/10 hover:border-white/20'
                            }`}
                          >
                            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                              
                              {/* User Info Block */}
                              <div className="flex items-start gap-3.5 flex-1 min-w-0">
                                <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold text-base shrink-0 shadow-md ${
                                  isBlocked 
                                    ? 'bg-red-500/20 text-red-400 border border-red-500/40' 
                                    : isVip 
                                    ? 'bg-gradient-to-tr from-[#e9c978] to-[#c9a24a] text-[#08111e]' 
                                    : 'bg-white/10 text-white border border-white/15'
                                }`}>
                                  {user.name.charAt(0) || 'ط'}
                                </div>

                                 <div className="space-y-1 min-w-0 flex-1">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <h4 className="font-bold text-sm sm:text-base text-white">
                                      {user.name}
                                    </h4>
                                    <span className="font-mono text-[10px] text-[#e9c978] bg-black/60 px-2 py-0.5 rounded border border-[#e9c978]/30 font-bold select-all">
                                      {user.uid || user.id}
                                    </span>
                                    <span className="text-[10px] font-bold px-2 py-0.5 rounded border bg-[#e9c978]/20 text-[#e9c978] border-[#e9c978]/30">
                                      طالب مدرسة 🏫
                                    </span>
                                    {isVip && (
                                      <span className="text-[10px] font-bold text-[#e9c978] bg-[#e9c978]/15 border border-[#e9c978]/30 px-2 py-0.5 rounded flex items-center gap-1">
                                        <Sparkles className="w-3 h-3 text-[#e9c978]" />
                                        <span>مشترك VIP</span>
                                      </span>
                                    )}
                                    {isBlocked ? (
                                      <span className="text-[10px] font-bold text-red-400 bg-red-500/15 border border-red-500/30 px-2 py-0.5 rounded">
                                        محظور 🔴
                                      </span>
                                    ) : (
                                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded">
                                        نشط 🟢
                                      </span>
                                    )}
                                  </div>

                                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-400">
                                    <span className="text-gray-300">📞 {user.emailOrPhone}</span>
                                    <span>📚 {gradeNames[user.grade] || user.grade}</span>
                                    {user.birthDate && (
                                      <span className="text-gray-300 font-mono text-[11px]">
                                        🎂 {user.birthDate} {user.birthYear ? `(${2026 - user.birthYear} سنة)` : ''}
                                      </span>
                                    )}
                                    <span className="flex items-center gap-1 text-teal-300">
                                      {user.deviceType === 'android-apk' ? (
                                        <>
                                          <Smartphone className="w-3.5 h-3.5" />
                                          <span>تطبيق أندرويد APK</span>
                                        </>
                                      ) : (
                                        <>
                                          <Laptop className="w-3.5 h-3.5" />
                                          <span>متصفح الويب</span>
                                        </>
                                      )}
                                    </span>
                                    <span className="text-[11px] text-gray-500">
                                      آخر ظهور: <span className="text-gray-300">{user.lastActive}</span>
                                    </span>
                                  </div>

                                  {user.notes && (
                                    <p className="text-[11px] text-gray-400 bg-white/5 px-2.5 py-1 rounded-lg border border-white/5 inline-block">
                                      📝 {user.notes}
                                    </p>
                                  )}
                                </div>
                              </div>

                              {/* Action Buttons */}
                              <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/10 justify-end flex-wrap">
                                
                                {/* Quick VIP Code Generation */}
                                <button
                                  onClick={() => {
                                    setPrefilledCodeUid(user.uid || user.id);
                                    setAdminTab('codes');
                                    showToast(`تم اختيار الطالب ${user.name} لتوليد كود VIP مخصص`);
                                  }}
                                  className="py-1.5 px-3 rounded-xl text-xs font-bold bg-[#e9c978]/15 border border-[#e9c978]/30 hover:bg-[#e9c978] hover:text-black text-[#e9c978] transition flex items-center gap-1"
                                  title="توليد كود VIP مخصص لهذا الطالب"
                                >
                                  <KeyRound className="w-3.5 h-3.5" />
                                  <span>توليد كود</span>
                                </button>
                                
                                {/* Toggle VIP */}
                                <button
                                  onClick={() => handleToggleUserVip(user)}
                                  className={`py-1.5 px-3 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                                    isVip
                                      ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40'
                                      : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10 border border-white/10'
                                  }`}
                                  title={isVip ? 'إلغاء اشتراك VIP' : 'ترقية إلى VIP'}
                                >
                                  <Sparkles className="w-3.5 h-3.5" />
                                  <span>{isVip ? 'إلغاء VIP' : 'ترقية VIP'}</span>
                                </button>

                                {/* Toggle Block */}
                                <button
                                  onClick={() => handleToggleUserStatus(user)}
                                  className={`py-1.5 px-3 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                                    isBlocked
                                      ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40'
                                      : 'bg-red-500/15 text-red-400 hover:bg-red-500 hover:text-white border border-red-500/30'
                                  }`}
                                  title={isBlocked ? 'تفعيل الحساب' : 'حظر الطالب'}
                                >
                                  {isBlocked ? <UserCheck className="w-3.5 h-3.5" /> : <UserX className="w-3.5 h-3.5" />}
                                  <span>{isBlocked ? 'تفعيل الحساب' : 'حظر'}</span>
                                </button>

                                {/* Edit User */}
                                <button
                                  onClick={() => setEditingUser(user)}
                                  className="py-1.5 px-3 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 text-gray-300 hover:text-white text-xs font-bold transition flex items-center gap-1"
                                  title="تعديل بيانات الطالب"
                                >
                                  <Edit3 className="w-3.5 h-3.5 text-[#e9c978]" />
                                  <span>تعديل</span>
                                </button>

                                {/* Delete User */}
                                {!isDeleting ? (
                                  <button
                                    onClick={() => setUserIdToDelete(user.id)}
                                    className="p-1.5 rounded-xl bg-red-500/10 border border-red-500/25 text-red-400 hover:bg-red-500 hover:text-white transition"
                                    title="حذف الطالب"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                ) : (
                                  <div className="flex items-center gap-1 bg-red-500/20 p-1 rounded-xl border border-red-500/40">
                                    <button
                                      onClick={() => handleDeleteUser(user.id)}
                                      className="px-2 py-1 bg-red-600 hover:bg-red-700 text-white font-bold text-[11px] rounded"
                                    >
                                      تأكيد
                                    </button>
                                    <button
                                      onClick={() => setUserIdToDelete(null)}
                                      className="px-2 py-1 bg-white/10 text-gray-300 text-[11px] rounded"
                                    >
                                      إلغاء
                                    </button>
                                  </div>
                                )}

                              </div>

                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                </div>
              </div>
            )}

            {/* ==========================================
                TAB: VIP LECTURE CODES & SUBSCRIPTIONS
                ========================================== */}
            {adminTab === 'codes' && (
              <AdminVipCodesTab
                lectures={lectures}
                users={users}
                showToast={showToast}
                prefilledUid={prefilledCodeUid}
                onClearPrefilledUid={() => setPrefilledCodeUid(null)}
              />
            )}

            {/* ==========================================
                TAB: IN-APP LIVE UPDATES & VERSIONS
                ========================================== */}
            {adminTab === 'updates' && (
              <AdminAppUpdateTab showToast={showToast} />
            )}

            {/* ==========================================
                TAB 3: PLATFORM APPEARANCE & 5 GRAPHICAL THEMES
                ========================================== */}
            {adminTab === 'appearance' && (
              <div className="space-y-6 animate-fadeIn">
                
                {/* Header Banner */}
                <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl space-y-4">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
                    <div className="flex items-center gap-3.5">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#e9c978] to-[#c9a24a] text-[#08111e] flex items-center justify-center text-2xl font-bold shadow-lg shadow-[#c9a24a]/25 shrink-0">
                        🎨
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-amiri font-bold text-2xl sm:text-3xl text-white">
                            واجهات المنصة والأنماط الرسومية الخمسة
                          </h3>
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#0fb98a]/15 text-[#0fb98a] border border-[#0fb98a]/30">
                            مزامنة سحابية فورية
                          </span>
                        </div>
                        <p className="text-xs text-gray-300 mt-1">
                          تحكم كامل في الشكل العام للمنصة: 5 واجهات رسومية بخمسة أشكال وألوان وطرق انتقال مختلفة، مع مؤثرات صوتية عند النقر وزر كتم.
                        </p>
                      </div>
                    </div>

                    {/* Active Theme Summary Card */}
                    {(() => {
                      const activePreset = getThemePresetById(selectedThemeId);
                      return (
                        <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 flex items-center gap-3 shrink-0">
                          <span className="text-2xl">{activePreset.icon}</span>
                          <div className="text-right">
                            <span className="text-[10px] text-gray-400 block font-bold">النمط المفعل للمنصة:</span>
                            <span className="text-xs font-black text-[#e9c978]">{activePreset.name}</span>
                          </div>
                          <div className="flex items-center gap-1 mr-1">
                            <span className="w-3.5 h-3.5 rounded-full border border-white/30" style={{ backgroundColor: activePreset.colors.primary }} />
                            <span className="w-3.5 h-3.5 rounded-full border border-white/30" style={{ backgroundColor: activePreset.colors.secondary }} />
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* Quick Features Highlights */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-gray-300 pt-1">
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2.5">
                      <Palette className="w-4 h-4 text-[#e9c978] shrink-0" />
                      <span><strong>5 واجهات رسومية:</strong> ألوان وأشكال وبطاقات متباينة</span>
                    </div>
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2.5">
                      <Zap className="w-4 h-4 text-[#0fb98a] shrink-0" />
                      <span><strong>5 طرق انتقال:</strong> سينمائي، ارتدادي، ديجيتال، كوني، مينيمال</span>
                    </div>
                    <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2.5">
                      <Volume2 className="w-4 h-4 text-sky-400 shrink-0" />
                      <span><strong>صوت عند النقر:</strong> مؤثرات صوتية تكتيكية وزر كتم فوري</span>
                    </div>
                  </div>
                </div>

                {/* 1) THE 5 GRAPHICAL INTERFACE PRESETS CARDS */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-amiri font-bold text-xl text-white flex items-center gap-2">
                        <span>الواجهات الرسومية الخمسة المتاحة للمنصة</span>
                      </h4>
                      <p className="text-xs text-gray-400">
                        اختر أي واجهة لتغيير ألوان وشكل البطاقات وطريقة الانتقال ونغمة الصوت للمنصة بالكامل
                      </p>
                    </div>
                    <span className="text-xs font-bold text-[#e9c978] bg-[#e9c978]/10 px-3 py-1 rounded-full border border-[#e9c978]/25">
                      5 أنماط متكاملة
                    </span>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                    {themePresets.map((preset) => {
                      const isActive = selectedThemeId === preset.id;

                      return (
                        <div
                          key={preset.id}
                          className={`relative p-5 sm:p-6 transition-all duration-300 flex flex-col justify-between overflow-hidden ${
                            preset.cardShape.roundedClass
                          } ${
                            isActive
                              ? 'ring-2 ring-[#e9c978] shadow-2xl shadow-[#e9c978]/20 bg-[#0a1220]'
                              : 'hover:border-white/30 bg-[#08101c]/90'
                          }`}
                          style={{
                            borderColor: isActive ? preset.colors.primary : preset.colors.border,
                            borderWidth: '1.5px',
                            borderStyle: 'solid'
                          }}
                        >
                          {/* Active Ribbon Badge */}
                          {isActive && (
                            <div className="absolute top-0 left-0 bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] px-4 py-1 text-[11px] font-black rounded-br-2xl shadow-md flex items-center gap-1 z-20">
                              <CheckCircle2 className="w-3.5 h-3.5 text-[#08111e]" />
                              <span>النمط النشط للمنصة</span>
                            </div>
                          )}

                          <div className="space-y-4">
                            {/* Card Top Title & Icon */}
                            <div className="flex items-start justify-between gap-3 pt-2">
                              <div className="flex items-center gap-3">
                                <span className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-md shrink-0"
                                      style={{ backgroundColor: `${preset.colors.primary}20`, border: `1px solid ${preset.colors.primary}40` }}>
                                  {preset.icon}
                                </span>
                                <div>
                                  <h5 className="font-amiri font-bold text-xl text-white leading-tight">
                                    {preset.name}
                                  </h5>
                                  <span className="text-xs font-medium text-gray-300 block">
                                    {preset.subtitle}
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Philosophy Description */}
                            <p className="text-xs text-gray-300 leading-relaxed">
                              {preset.description}
                            </p>

                            {/* LIVE INTERACTIVE UI PREVIEW BOX */}
                            <div
                              className={`p-4 transition-all duration-200 border ${preset.cardShape.roundedClass}`}
                              style={{
                                backgroundColor: preset.colors.bgCard,
                                borderColor: preset.colors.border,
                                boxShadow: isActive ? `0 0 20px ${preset.colors.glow}` : 'none'
                              }}
                            >
                              <div className="text-[10px] text-gray-400 font-bold mb-2 flex items-center justify-between">
                                <span>معاينة حية لشكل البطاقة والواجهة:</span>
                                <span className="font-mono text-[10px] px-2 py-0.5 rounded-full"
                                      style={{ color: preset.colors.primary, backgroundColor: `${preset.colors.primary}15` }}>
                                  {preset.cardShape.shapeName}
                                </span>
                              </div>

                              <div className="space-y-2.5">
                                <div className="flex items-center justify-between">
                                  <h6 className="font-amiri font-bold text-base" style={{ color: preset.colors.textPrimary }}>
                                    مختبر الأحياء · الفصل الأول (الخلية)
                                  </h6>
                                  <span
                                    className={`text-[10px] font-bold px-2.5 py-0.5 border ${preset.cardShape.roundedClass}`}
                                    style={{
                                      backgroundColor: `${preset.colors.primary}18`,
                                      borderColor: `${preset.colors.primary}35`,
                                      color: preset.colors.primary
                                    }}
                                  >
                                    محاضرة معتمدة
                                  </span>
                                </div>

                                <p className="text-[11px] text-gray-400 line-clamp-2">
                                  شرح تفصيلي للميتوكوندريا وجهاز كولجي مع الأسئلة الوزارية النموذجية.
                                </p>

                                <div className="flex items-center justify-between pt-1">
                                  <div className="flex items-center gap-1.5 text-[11px] text-gray-400">
                                    <span>⏱️ 28 دقيقة</span>
                                    <span>·</span>
                                    <span>👁️ 1,420 مشاهدة</span>
                                  </div>

                                  <button
                                    onClick={() => playClickSound(preset.soundStyle)}
                                    className={`py-1.5 px-3.5 text-xs font-bold text-black transition flex items-center gap-1 ${preset.cardShape.roundedClass}`}
                                    style={{
                                      backgroundColor: preset.colors.primary,
                                      boxShadow: `0 4px 12px ${preset.colors.glow}`
                                    }}
                                  >
                                    <Play className="w-3 h-3 fill-current text-black" />
                                    <span>مشاهدة الدرس</span>
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* Color Palette Swatches */}
                            <div className="space-y-1.5 pt-1">
                              <span className="text-[11px] font-bold text-gray-400 block">درجات الألوان والهوية البصرية:</span>
                              <div className="flex items-center gap-2 flex-wrap">
                                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10 text-[11px]">
                                  <span className="w-3.5 h-3.5 rounded-full border border-white/30 shrink-0" style={{ backgroundColor: preset.colors.primary }} />
                                  <span className="text-gray-300 font-mono">{preset.colors.primary}</span>
                                  <span className="text-gray-500 text-[10px]">الرئيسي</span>
                                </div>

                                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10 text-[11px]">
                                  <span className="w-3.5 h-3.5 rounded-full border border-white/30 shrink-0" style={{ backgroundColor: preset.colors.secondary }} />
                                  <span className="text-gray-300 font-mono">{preset.colors.secondary}</span>
                                  <span className="text-gray-500 text-[10px]">الثانوي</span>
                                </div>

                                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10 text-[11px]">
                                  <span className="w-3.5 h-3.5 rounded-full border border-white/30 shrink-0" style={{ backgroundColor: preset.colors.bgDark }} />
                                  <span className="text-gray-300 font-mono">{preset.colors.bgDark}</span>
                                  <span className="text-gray-500 text-[10px]">الخلفية</span>
                                </div>
                              </div>
                            </div>

                            {/* Transition & Sound Attributes */}
                            <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                              <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 flex items-center gap-2">
                                <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                                <div className="text-right truncate">
                                  <span className="text-[10px] text-gray-400 block">طريقة الانتقال:</span>
                                  <span className="font-bold text-white truncate block">{preset.transition.name}</span>
                                </div>
                              </div>

                              <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 flex items-center gap-2">
                                <Volume2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                                <div className="text-right truncate">
                                  <span className="text-[10px] text-gray-400 block">نغمة صوت النقر:</span>
                                  <span className="font-bold text-white truncate block">{preset.soundName}</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* ACTION BUTTONS: Test Sound & Apply Theme */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-4 mt-4 border-t border-white/10">
                            <button
                              onClick={() => {
                                playClickSound(preset.soundStyle);
                                showToast(`نغمة صوت النمط: ${preset.soundName} 🎵`);
                              }}
                              className="py-2.5 px-3 rounded-xl bg-white/5 border border-white/10 hover:border-white/30 text-xs font-bold text-gray-200 hover:text-white flex items-center justify-center gap-1.5 transition"
                              title="تجربة صوت النقر الخاص بهذا النمط"
                            >
                              <Volume2 className="w-3.5 h-3.5 text-[#e9c978]" />
                              <span>تجربة صوت النمط</span>
                            </button>

                            <button
                              onClick={() => handleApplyTheme(preset)}
                              disabled={isActive || isSavingAppearance}
                              className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg transition ${
                                isActive
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 cursor-default'
                                  : 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] hover:brightness-110 active:scale-95'
                              }`}
                            >
                              {isActive ? (
                                <>
                                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                  <span>مفعل حالياً للمنصة</span>
                                </>
                              ) : (
                                <>
                                  <Sparkles className="w-4 h-4 text-[#08111e]" />
                                  <span>تفعيل هذا النمط للمنصة</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 2) TRANSITION STYLES CUSTOMIZER */}
                <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-white/10 shadow-2xl space-y-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
                    <div>
                      <h4 className="font-amiri font-bold text-2xl text-white flex items-center gap-2">
                        <Zap className="w-5 h-5 text-amber-400" />
                        <span>طريقة تغيير الانتقالات بين شاشات وأقسام المنصة</span>
                      </h4>
                      <p className="text-xs text-gray-400 mt-0.5">
                        حدد أسلوب الحركة السينمائية والسرعة عند التبديل بين الأقسام والمحاضرات والمناهج
                      </p>
                    </div>

                    <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20 self-start sm:self-auto">
                      انتقالات سينمائية فائقة السلاسة
                    </span>
                  </div>

                  {/* 5 Transitions Selector */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                    {[
                      {
                        id: 'cinematic',
                        name: '🎬 سينمائي ناعم',
                        desc: 'تلاشٍ هادئ وانزلاق متزن',
                        speed: '280ms'
                      },
                      {
                        id: 'cyber',
                        name: '⚡ انزلاق سيبراني',
                        desc: 'حركة أفقية تكنولوجية خاطفة',
                        speed: '210ms'
                      },
                      {
                        id: 'elastic',
                        name: '🌿 ارتداد نبضي مرن',
                        desc: 'فيزياء حيوية تشبه الخلية',
                        speed: '340ms'
                      },
                      {
                        id: 'cosmic',
                        name: '🌌 تعويم فضائي',
                        desc: 'عمق مداري ثلاثي الأبعاد',
                        speed: '320ms'
                      },
                      {
                        id: 'minimal',
                        name: '💎 تلاشٍ مينيمال',
                        desc: 'تبديل فوري فائق السرعة',
                        speed: '170ms'
                      }
                    ].map((trans) => {
                      const isSelected = selectedTransition === trans.id;
                      return (
                        <button
                          key={trans.id}
                          onClick={() => handleApplyCustomTransition(trans.id as any)}
                          className={`p-3.5 rounded-2xl text-right transition-all flex flex-col justify-between border ${
                            isSelected
                              ? 'bg-[#e9c978]/15 border-[#e9c978] shadow-md shadow-[#e9c978]/15'
                              : 'bg-black/40 border-white/10 hover:border-white/30 text-gray-300'
                          }`}
                        >
                          <div>
                            <span className="font-bold text-sm block text-white mb-1">
                              {trans.name}
                            </span>
                            <span className="text-[11px] text-gray-400 block leading-tight">
                              {trans.desc}
                            </span>
                          </div>
                          <div className="flex items-center justify-between pt-3 mt-2 border-t border-white/10 text-[10px]">
                            <span className="font-mono text-gray-400">{trans.speed}</span>
                            <span className={`font-bold ${isSelected ? 'text-[#e9c978]' : 'text-gray-500'}`}>
                              {isSelected ? 'مفعل ✓' : 'اختيار'}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Interactive Live Transition Tester Box */}
                  <div className="p-4 rounded-2xl bg-black/50 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center text-xl shrink-0">
                        🔄
                      </div>
                      <div>
                        <strong className="text-xs text-white block">صندوق اختبار حركة الانتقال المباشر</strong>
                        <span className="text-[11px] text-gray-400">
                          اضغط على الزر لمعاينة تجربة الحركة المعتمدة حالياً في هذا الإطار
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        playClickSound();
                        setPreviewTestTrigger(prev => prev + 1);
                      }}
                      className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold text-xs flex items-center gap-2 transition shrink-0"
                    >
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      <span>اختبار حركة الانتقال الآن</span>
                    </button>
                  </div>

                  {/* Animated Test Target Box */}
                  <div className="overflow-hidden p-6 rounded-2xl bg-black/60 border border-white/10 flex items-center justify-center min-h-[90px]">
                    <div
                      key={previewTestTrigger}
                      className={`text-center py-2 px-6 rounded-xl bg-[#e9c978]/15 border border-[#e9c978]/40 transition-all ${
                        selectedTransition === 'cyber'
                          ? 'animate-pulse'
                          : selectedTransition === 'elastic'
                          ? 'animate-bounce'
                          : 'animate-fadeIn'
                      }`}
                    >
                      <span className="text-xs font-bold text-[#e9c978] block">
                        تجربة الانتقال الحركي النشط: {selectedTransition}
                      </span>
                      <span className="text-[10px] text-gray-400">
                        انتقال متزامن وسلس يمنح التطبيق طابعاً سينمائياً فخماً
                      </span>
                    </div>
                  </div>
                </div>

                {/* 3) SOUND EFFECTS ON CLICK & MUTE CONTROLS */}
                <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-white/10 shadow-2xl space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
                    <div>
                      <h4 className="font-amiri font-bold text-2xl text-white flex items-center gap-2">
                        <Volume2 className="w-5 h-5 text-sky-400" />
                        <span>مؤثرات الصوت عند النقر وزر كتم الصوت</span>
                      </h4>
                      <p className="text-xs text-gray-400 mt-0.5">
                        إضافة صوت ناعم عند النقر على الأزرار والأقسام مع إمكانية الكتم والتحكم في النغمة ومستوى الصوت
                      </p>
                    </div>

                    {/* Quick MUTE / UNMUTE Master Button */}
                    <button
                      onClick={handleToggleSoundMaster}
                      className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition shadow-md self-start sm:self-auto ${
                        localMuted
                          ? 'bg-red-500/20 text-red-300 border border-red-500/40 hover:bg-red-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                      }`}
                    >
                      {localMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      <span>{localMuted ? 'إلغاء كتم الصوت (تشغيل 🔊)' : 'كتم أصوات النقر (كتم 🔇)'}</span>
                    </button>
                  </div>

                  {/* Sound Master Status Card */}
                  <div className={`p-4 rounded-2xl border flex items-center justify-between gap-4 ${
                    localMuted
                      ? 'bg-red-950/20 border-red-500/30 text-red-200'
                      : 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200'
                  }`}>
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{localMuted ? '🔇' : '🔊'}</span>
                      <div>
                        <strong className="text-xs font-bold block">
                          حالة المؤثرات الصوتية: {localMuted ? 'مكتومة حالياً' : 'مفعلة وتعمل عند النقر'}
                        </strong>
                        <span className="text-[11px] opacity-80">
                          {localMuted
                            ? 'لن يصدر أي صوت عند النقر في المنصة، ويمكن للطلاب وأنت إعادة تشغيله في أي وقت.'
                            : 'يصدر صوت نقر لطيف ومهني عند التنقل بين الأقسام والضغط على أزرار الدروس.'}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (localMuted) {
                          handleToggleSoundMaster();
                        } else {
                          playClickSound();
                        }
                      }}
                      className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs shrink-0 transition"
                    >
                      تجربة نقرة 🎵
                    </button>
                  </div>

                  {/* Controls: Volume Slider & Sound Tone Presets */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {/* Volume Slider */}
                    <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                      <div className="flex items-center justify-between text-xs">
                        <label className="font-bold text-white flex items-center gap-1.5">
                          <Sliders className="w-3.5 h-3.5 text-[#e9c978]" />
                          <span>مستوى علو الصوت (Volume):</span>
                        </label>
                        <span className="font-mono text-[#e9c978] font-bold">
                          {Math.round(localVolume * 100)}%
                        </span>
                      </div>

                      <input
                        type="range"
                        min="0.1"
                        max="1.0"
                        step="0.05"
                        value={localVolume}
                        onChange={(e) => handleChangeVolumeSlider(parseFloat(e.target.value))}
                        className="w-full accent-[#e9c978] cursor-pointer"
                      />

                      <div className="flex justify-between text-[10px] text-gray-500 font-mono">
                        <span>هادئ جداً (10%)</span>
                        <span>متوسط (50%)</span>
                        <span>أقصى وضوح (100%)</span>
                      </div>
                    </div>

                    {/* Sound Tone Picker */}
                    <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                      <label className="block text-xs font-bold text-white">
                        نوع نغمة النقر المطلوبة:
                      </label>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-[11px]">
                        {[
                          { id: 'theme', label: 'مطابق للنمط النشط' },
                          { id: 'velvet', label: 'مخملي ناعم (Velvet)' },
                          { id: 'cyber', label: 'رقمي سيبراني (Cyber)' },
                          { id: 'bio', label: 'فقاعة خلوية (Bio)' },
                          { id: 'cosmic', label: 'رنين بلوري (Cosmic)' },
                          { id: 'minimal', label: 'تكة ميكانيكية (Tick)' }
                        ].map((tone) => (
                          <button
                            key={tone.id}
                            onClick={() => handleChangeToneStyle(tone.id)}
                            className={`py-2 px-2 rounded-lg text-center font-bold transition truncate ${
                              soundToneStyle === tone.id
                                ? 'bg-[#e9c978] text-[#08111e] shadow-sm'
                                : 'bg-white/5 text-gray-300 hover:text-white hover:bg-white/10'
                            }`}
                          >
                            {tone.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Big Test Click Button */}
                  <div className="pt-2">
                    <button
                      onClick={() => {
                        playClickSound();
                        showToast('تم إطلاق صوت النقر بنجاح 🎵');
                      }}
                      className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-sky-500/20 via-indigo-500/20 to-purple-500/20 border border-sky-400/40 text-sky-200 hover:text-white font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 active:scale-98 transition shadow-lg"
                    >
                      <Volume2 className="w-4 h-4 text-sky-300" />
                      <span>اضغط هنا لتجربة صوت النقر والتأكد من إعداداتك 🎵</span>
                    </button>
                  </div>

                </div>

              </div>
            )}

            {/* ==========================================
                TAB: AI ASSISTANT & RULES MANAGEMENT (إدارة الذكاء الاصطناعي وتعليماته)
                ========================================== */}
            {adminTab === 'ai' && (
              <div className="space-y-6 animate-fadeIn">
                <AITrainingCenter
                  showToast={showToast}
                />
              </div>
            )}

            {/* ==========================================
                TAB 4: APP DOWNLOAD, INFO & SHARING
                ========================================== */}
            {adminTab === 'apk' && (
              <div className="space-y-6 animate-fadeIn">
                
                {/* Secondary navigation for APK sub-sections */}
                <div className="flex items-center gap-2 p-1 rounded-xl bg-black/40 border border-white/10 text-xs font-bold">
                  <button
                    onClick={() => setShareSubTab('download')}
                    className={`flex-1 py-2.5 px-3 rounded-lg transition flex items-center justify-center gap-2 ${
                      shareSubTab === 'download'
                        ? 'bg-[#e9c978] text-[#08111e] shadow-md'
                        : 'text-gray-300 hover:text-white'
                    }`}
                  >
                    <Download className="w-4 h-4" />
                    <span>1. تنزيل ملفات الـ APK</span>
                  </button>

                  <button
                    onClick={() => setShareSubTab('instructions')}
                    className={`flex-1 py-2.5 px-3 rounded-lg transition flex items-center justify-center gap-2 ${
                      shareSubTab === 'instructions'
                        ? 'bg-[#e9c978] text-[#08111e] shadow-md'
                        : 'text-gray-300 hover:text-white'
                    }`}
                  >
                    <HelpCircle className="w-4 h-4" />
                    <span>2. معلومات وإرشادات التثبيت</span>
                  </button>

                  <button
                    onClick={() => setShareSubTab('share')}
                    className={`flex-1 py-2.5 px-3 rounded-lg transition flex items-center justify-center gap-2 ${
                      shareSubTab === 'share'
                        ? 'bg-[#e9c978] text-[#08111e] shadow-md'
                        : 'text-gray-300 hover:text-white'
                    }`}
                  >
                    <Share2 className="w-4 h-4" />
                    <span>3. مشاركة التطبيق والباركود</span>
                  </button>
                </div>

                {/* Sub-tab 1: Download Section */}
                {shareSubTab === 'download' && (
                  <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl space-y-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
                      <div>
                        <span className="inline-block text-[11px] font-bold text-[#0fb98a] bg-[#0fb98a]/10 px-2.5 py-0.5 rounded-full border border-[#0fb98a]/20 mb-1">
                          جاهز للتنزيل الفوري
                        </span>
                        <h3 className="font-amiri font-bold text-2xl text-white">
                          قسم تنزيل تطبيق مختبر الأحياء (APK)
                        </h3>
                        <p className="text-xs text-gray-400 mt-0.5">
                          تنزيل ملفات التثبيت المباشرة وسورس مشروع أندرويد ستوديو المخصص للمنصة
                        </p>
                      </div>

                      {onOpenAPKModal && (
                        <button
                          onClick={onOpenAPKModal}
                          className="py-2 px-3.5 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 text-xs font-bold text-[#e9c978] flex items-center gap-1.5 transition"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>معاينة نافذة التثبيت للطلاب</span>
                        </button>
                      )}
                    </div>

                    {/* Download Cards Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      
                      {/* Card 1: Direct biolab.apk */}
                      <div className="p-5 rounded-2xl bg-black/40 border border-[#e9c978]/40 space-y-4 flex flex-col justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="w-10 h-10 rounded-xl bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center text-xl font-bold">
                              📦
                            </span>
                            <span className="text-[11px] font-bold text-[#0fb98a] bg-[#0fb98a]/10 px-2.5 py-0.5 rounded border border-[#0fb98a]/20">
                              موصى به للطلاب
                            </span>
                          </div>
                          <h4 className="font-bold text-white text-base">
                            ملف التطبيق المباشر (biolab.apk)
                          </h4>
                          <p className="text-xs text-gray-300 leading-relaxed">
                            ملف حزمة أندرويد كاملة جاهزة للتثبيت فوراً على جميع هواتف Android (سامسونج، شاومي، هواوي، ريلمي، وغيرها).
                          </p>
                          <div className="text-[11px] text-gray-400 font-mono space-y-1 pt-1">
                            <div>• الحزمة: <span className="text-[#e9c978]">com.wissam.biolab</span></div>
                            <div>• التوافق: Android 7.0+ إلى أحدث إصدار</div>
                          </div>
                        </div>

                        <a
                          href="/biolab.apk"
                          download="biolab.apk"
                          className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-[#c9a24a]/20 hover:brightness-110 active:scale-95 transition"
                        >
                          <Download className="w-4 h-4 text-[#08111e]" />
                          <span>تنزيل ملف biolab.apk الآن</span>
                        </a>
                      </div>

                      {/* Card 2: Full Android Studio Project ZIP */}
                      <div className="p-5 rounded-2xl bg-black/40 border border-white/10 hover:border-[#0fb98a]/40 space-y-4 flex flex-col justify-between transition">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="w-10 h-10 rounded-xl bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center text-xl font-bold">
                              💻
                            </span>
                            <span className="text-[11px] font-bold text-gray-400 bg-white/5 px-2.5 py-0.5 rounded border border-white/10">
                              للمطورين والمدارس
                            </span>
                          </div>
                          <h4 className="font-bold text-white text-base">
                            مشروع Android Studio الكامل (ZIP)
                          </h4>
                          <p className="text-xs text-gray-300 leading-relaxed">
                            كود المصدر المكتمل مع ملفات Gradle و Kotlin و AndroidManifest لفتحه مباشرة في Android Studio وبناء نسخ مخصصة.
                          </p>
                          <div className="text-[11px] text-gray-400 font-mono space-y-1 pt-1">
                            <div>• لغة البرمجة: Kotlin / WebView Immersive</div>
                            <div>• البناء: Gradle 8.x / compileSdk 35</div>
                          </div>
                        </div>

                        <a
                          href="/android-project.zip"
                          download="BioLab-Android-Project.zip"
                          className="w-full py-3 px-4 rounded-xl bg-[#0fb98a]/20 border border-[#0fb98a]/40 text-[#0fb98a] font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#0fb98a]/30 active:scale-95 transition"
                        >
                          <FileCode className="w-4 h-4 text-[#0fb98a]" />
                          <span>تنزيل سورس المشروع (ZIP)</span>
                        </a>
                      </div>

                    </div>

                    {/* Direct APK Link Box */}
                    <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-2">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span className="font-bold text-[#e9c978]">رابط التحميل المباشر لملف الـ APK (لإرساله للطلاب):</span>
                        <span className="text-[#0fb98a] font-semibold">رابط مباشر 100%</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          readOnly
                          value={apkDownloadUrl}
                          className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-mono text-emerald-300 select-all"
                          dir="ltr"
                        />
                        <button
                          onClick={handleCopyApkUrl}
                          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs flex items-center gap-1.5 shrink-0 hover:brightness-110 transition"
                        >
                          {copiedApkUrl ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                          <span>{copiedApkUrl ? 'تم النسخ' : 'نسخ الرابط'}</span>
                        </button>
                      </div>
                    </div>

                  </div>
                )}

                {/* Sub-tab 2: Download Information & Installation Guide */}
                {shareSubTab === 'instructions' && (
                  <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl space-y-6">
                    <div>
                      <span className="inline-block text-[11px] font-bold text-[#e9c978] bg-[#e9c978]/10 px-2.5 py-0.5 rounded-full border border-[#e9c978]/20 mb-1">
                        دليل شامل ومبسّط
                      </span>
                      <h3 className="font-amiri font-bold text-2xl text-white">
                        قسم المعلومات وإرشادات التثبيت على الهواتف
                      </h3>
                      <p className="text-xs text-gray-400 mt-0.5">
                        كل ما يحتاجه الأستاذ والطلاب لتثبيت وتشغيل التطبيق بأعلى كفاءة
                      </p>
                    </div>

                    {/* Step-by-step installation guides */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      
                      {/* Guide 1: Installing biolab.apk */}
                      <div className="p-5 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                        <div className="flex items-center gap-2 text-white font-bold text-sm">
                          <span className="w-7 h-7 rounded-lg bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center font-bold text-xs">
                            1
                          </span>
                          <span>طريقة تثبيت ملف biolab.apk المباشر:</span>
                        </div>
                        <ol className="list-decimal list-inside space-y-2 text-xs text-gray-300 leading-relaxed pr-1">
                          <li>قم بتحميل ملف <strong className="text-[#e9c978]">biolab.apk</strong> من قسم التنزيل أعلاه.</li>
                          <li>افتح مدير الملفات أو الإشعارات واضغط على الملف المحمّل.</li>
                          <li>إذا ظهر تنبيه الأمان، اضغط على <strong>«الإعدادات»</strong> وفعّل <strong>«السماح بتثبيت التطبيقات من هذا المصدر»</strong>.</li>
                          <li>اضغط على <strong>«تثبيت»</strong> وسيكتمل التثبيت في ثوانٍ معدودة.</li>
                          <li>ستظهر أيقونة مختبر الأحياء في قائمة تطبيقاتك فوراً.</li>
                        </ol>
                      </div>

                      {/* Guide 2: Installing as WebAPK */}
                      <div className="p-5 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                        <div className="flex items-center gap-2 text-white font-bold text-sm">
                          <span className="w-7 h-7 rounded-lg bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center font-bold text-xs">
                            2
                          </span>
                          <span>طريقة التثبيت الفوري عبر المتصفح (WebAPK):</span>
                        </div>
                        <ol className="list-decimal list-inside space-y-2 text-xs text-gray-300 leading-relaxed pr-1">
                          <li>افتح رابط المنصة في متصفح هاتفك (Google Chrome).</li>
                          <li>اضغط على قائمة المتصفح (النقاط الثلاث <strong>⋮</strong> أعلى اليسار).</li>
                          <li>اختر <strong>«تثبيت التطبيق»</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.</li>
                          <li>يقوم الهاتف فوراً بتثبيت التطبيق الأصلي دون الحاجة لمتجر Google Play.</li>
                          <li>يعمل بدون شريط عنوان المتصفح كـ تطبيق مستقل كلياً.</li>
                        </ol>
                      </div>

                    </div>

                    {/* Features & Advantages Grid */}
                    <div className="pt-2">
                      <h4 className="font-bold text-sm text-white mb-3">
                        مميزات التطبيق المثبت على جهاز الطالب:
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                          <div className="flex items-center gap-2 text-xs font-bold text-[#0fb98a]">
                            <WifiOff className="w-4 h-4" />
                            <span>يدعم العمل أوفلاين</span>
                          </div>
                          <p className="text-[11px] text-gray-300 leading-relaxed">
                            جميع المناهج والفصول والكتب المخزنة تعمل حتى في حال انقطاع الإنترنت.
                          </p>
                        </div>

                        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                          <div className="flex items-center gap-2 text-xs font-bold text-[#e9c978]">
                            <Layers className="w-4 h-4" />
                            <span>شاشة كاملة غامرة</span>
                          </div>
                          <p className="text-[11px] text-gray-300 leading-relaxed">
                            تجربة استخدام خالية من أشرطة المتصفح والإعلانات، مخصصة للتركيز في الدراسة.
                          </p>
                        </div>

                        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
                          <div className="flex items-center gap-2 text-xs font-bold text-[#3fa9f5]">
                            <ShieldCheck className="w-4 h-4" />
                            <span>حفظ تلقائي للبيانات</span>
                          </div>
                          <p className="text-[11px] text-gray-300 leading-relaxed">
                            حفظ المحاضرات المفضلة والأكواد السرية VIP والنمط الليلي دون فقدانها.
                          </p>
                        </div>
                      </div>
                    </div>

                  </div>
                )}

                {/* Sub-tab 3: Share App Section (مشاركة التطبيق والباركود) */}
                {shareSubTab === 'share' && (
                  <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl space-y-6">
                    <div>
                      <span className="inline-block text-[11px] font-bold text-[#3fa9f5] bg-[#3fa9f5]/10 px-2.5 py-0.5 rounded-full border border-[#3fa9f5]/20 mb-1">
                        إرسال ونشر سريع
                      </span>
                      <h3 className="font-amiri font-bold text-2xl text-white">
                        قسم مشاركة التطبيق والباركود مع الطلاب
                      </h3>
                      <p className="text-xs text-gray-400 mt-0.5">
                        شارك رابط التطبيق عبر واتساب وتلغرام أو اعرض باركود الـ QR في القاعة الدراسية
                      </p>
                    </div>

                    {/* Quick Share Buttons */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <button
                        onClick={shareWhatsApp}
                        className="py-3.5 px-5 rounded-2xl bg-[#25D366]/20 border border-[#25D366]/40 hover:bg-[#25D366]/30 text-[#25D366] font-bold text-sm flex items-center justify-center gap-2.5 transition active:scale-95 shadow-md"
                      >
                        <Send className="w-4 h-4" />
                        <span>مشاركة مباشرة عبر واتساب الأستاذ / مجموعات الطلاب</span>
                      </button>

                      <button
                        onClick={shareTelegram}
                        className="py-3.5 px-5 rounded-2xl bg-[#0088cc]/20 border border-[#0088cc]/40 hover:bg-[#0088cc]/30 text-[#3fa9f5] font-bold text-sm flex items-center justify-center gap-2.5 transition active:scale-95 shadow-md"
                      >
                        <ExternalLink className="w-4 h-4" />
                        <span>مشاركة عبر قناة التلغرام الرسمية</span>
                      </button>
                    </div>

                    {/* QR Code Presentation Box */}
                    <div className="p-6 rounded-2xl bg-black/40 border border-white/10 flex flex-col sm:flex-row items-center gap-6 text-center sm:text-right">
                      <div className="w-44 h-44 rounded-2xl bg-[#0a1220] p-2.5 border-2 border-[#e9c978]/40 shadow-2xl shrink-0 flex items-center justify-center">
                        <img 
                          src={qrCodeUrl} 
                          alt="QR Code للتطبيق" 
                          className="w-full h-full object-contain rounded-xl"
                          loading="lazy"
                        />
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-bold text-white text-lg flex items-center justify-center sm:justify-start gap-2">
                          <QrCode className="w-5 h-5 text-[#e9c978]" />
                          <span>باركود المسح السريع بالكاميرا</span>
                        </h4>
                        <p className="text-xs text-gray-300 leading-relaxed">
                          يمكنك عرض هذا الباركود للطلاب على شاشة العرض بالقاعة الدراسية أو طباعته على الملازم. بمجرد توجيه كاميرا الهاتف نحو الباركود، سيفتح التطبيق فوراً للتثبيت مجاناً.
                        </p>
                        <div className="pt-1 flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs">
                          <button
                            onClick={handleCopyAppUrl}
                            className="py-2 px-3 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 text-[#e9c978] font-bold transition flex items-center gap-1.5"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            <span>نسخ رابط المنصة</span>
                          </button>
                          <a
                            href={qrCodeUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="py-2 px-3 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 text-gray-300 hover:text-white font-semibold transition flex items-center gap-1.5"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>فتح الباركود بحجم كامل للطباعة</span>
                          </a>
                        </div>
                      </div>
                    </div>

                    {/* Direct Platform Link */}
                    <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-2">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span className="font-bold text-[#e9c978]">رابط المنصة الرسمي العام:</span>
                        <span>جاهز للفتح على كافة الأجهزة</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          readOnly
                          value={appUrl}
                          className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-mono text-emerald-300 select-all"
                          dir="ltr"
                        />
                        <button
                          onClick={handleCopyAppUrl}
                          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs flex items-center gap-1.5 shrink-0 hover:brightness-110 transition"
                        >
                          {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                          <span>{copiedLink ? 'تم النسخ' : 'نسخ الرابط'}</span>
                        </button>
                      </div>
                    </div>

                  </div>
                )}

              </div>
            )}

            {/* ==========================================
                TAB 4: SECURITY & CREDENTIALS
                ========================================== */}
            {adminTab === 'security' && (
              <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-white/10 space-y-6 animate-fadeIn">
                <div>
                  <h3 className="font-bold text-lg text-white flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-[#0fb98a]" />
                    <span>إعدادات أمان حساب المدير</span>
                  </h3>
                  <p className="text-xs text-gray-400 mt-1">
                    الحسابات المصرح لها بالدخول: <span className="text-[#e9c978] font-mono">abdullahmiqdad2007@gmail.com</span> أو <span className="text-[#e9c978] font-mono">admin@wissam.com</span>
                  </p>
                </div>

                <form onSubmit={handleUpdatePassword} className="space-y-3 max-w-md">
                  <label className="block text-xs font-semibold text-gray-300">
                    تغيير كلمة مرور الإدارة
                  </label>
                  <div className="flex flex-col sm:flex-row items-center gap-2">
                    <input
                      type="password"
                      value={newPasswordInput}
                      onChange={(e) => setNewPasswordInput(e.target.value)}
                      placeholder="كلمة المرور الجديدة (6 خانات على الأقل)"
                      className="w-full py-2.5 px-4 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#0fb98a]"
                    />
                    <button
                      type="submit"
                      className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#0fb98a]/20 border border-[#0fb98a]/40 text-[#0fb98a] hover:bg-[#0fb98a] hover:text-[#04080f] font-bold text-xs transition whitespace-nowrap shadow-sm"
                    >
                      تحديث كلمة المرور
                    </button>
                  </div>
                </form>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-xs text-gray-300 space-y-1.5">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-[#e9c978]" />
                    <span>ملاحظة أمنية:</span>
                  </div>
                  <p className="leading-relaxed">
                    يتم التحقق من البريد الإلكتروني وكلمة المرور محلياً وبشكل مشفر لضمان عدم وصول المستخدمين العاديين أو التعديل على الفيديوهات وميزات المنصة.
                  </p>
                </div>

                {/* ==========================================
                    PERMANENT CLOUD BACKUP & DATA PROTECTION
                    (نظام الحفظ السحابي الدائم والنسخ الاحتياطي)
                    ========================================== */}
                <div className="pt-6 border-t border-white/10 space-y-5">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#0fb98a] animate-pulse" />
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#0fb98a]/15 text-[#0fb98a] border border-[#0fb98a]/30">
                          نظام الحفظ الدائم المركزي
                        </span>
                      </div>
                      <h4 className="font-amiri font-bold text-xl text-white flex items-center gap-2">
                        <Database className="w-5 h-5 text-[#e9c978]" />
                        <span>النسخ الاحتياطي السحابي وحماية المحتوى (Firebase Cloud Backup)</span>
                      </h4>
                      <p className="text-xs text-gray-400 mt-0.5">
                        جميع الكتب والملازم، المحاضرات، طلاب المعهد، وأكواد VIP محفوظة سحابياً بشكل دائم وغير قابلة للضياع
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={handleTriggerCloudBackup}
                      disabled={isCreatingBackup}
                      className="px-5 py-3 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] hover:from-[#f3d994] hover:to-[#dbb55d] text-[#08111e] font-bold text-xs flex items-center gap-2 transition active:scale-95 shadow-lg shrink-0 disabled:opacity-50"
                    >
                      {isCreatingBackup ? (
                        <>
                          <RotateCw className="w-4 h-4 animate-spin" />
                          <span>جاري أخذ النسخة السحابية...</span>
                        </>
                      ) : (
                        <>
                          <Cloud className="w-4 h-4" />
                          <span>إنشاء نسخة احتياطية سحابية فورية 🛡️</span>
                        </>
                      )}
                    </button>
                  </div>

                  {backupSuccessInfo && (
                    <div className="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>{backupSuccessInfo}</span>
                    </div>
                  )}

                  {/* Cloud Protection Status Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>المصدر السحابي:</span>
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      </div>
                      <div className="text-white font-bold text-sm">Firestore السحابية</div>
                      <div className="text-[10px] text-gray-400 font-mono">prismatic-clone-5lcf1</div>
                    </div>

                    <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>حماية البيانات:</span>
                        <ShieldCheck className="w-3.5 h-3.5 text-[#0fb98a]" />
                      </div>
                      <div className="text-white font-bold text-sm">حفظ ومزامنة فورية</div>
                      <div className="text-[10px] text-gray-400">لا تتأثر بإعادة البناء أو مسح الكاش</div>
                    </div>

                    <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-1">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>النسخ المسجلة:</span>
                        <Archive className="w-3.5 h-3.5 text-[#e9c978]" />
                      </div>
                      <div className="text-white font-bold text-sm">{cloudBackups.length} نسخ احتياطية</div>
                      <div className="text-[10px] text-gray-400">سجل استرجاع تاريخي كامل</div>
                    </div>
                  </div>

                  {/* Backups History Table */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-gray-400 px-1">
                      <span className="font-semibold text-gray-300">سجل النسخ الاحتياطية السحابية السابقة:</span>
                      <span>تحديث فوري عبر Firestore</span>
                    </div>

                    {cloudBackups.length === 0 ? (
                      <div className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center text-xs text-gray-400 space-y-2">
                        <Archive className="w-8 h-8 text-gray-500 mx-auto opacity-50" />
                        <p>لا توجد نسخ احتياطية سحابية مسجلة بعد.</p>
                        <p className="text-[11px] text-gray-400">اضغط على زر "إنشاء نسخة احتياطية سحابية فورية" لحفظ لقطة كاملة من كافة بيانات المنصة في السحابة.</p>
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                        {cloudBackups.map((bk, idx) => {
                          const dateObj = bk.timestamp ? new Date(bk.timestamp) : null;
                          const formattedDate = dateObj && !isNaN(dateObj.getTime())
                            ? dateObj.toLocaleString('ar-IQ', { dateStyle: 'medium', timeStyle: 'short' })
                            : bk.timestamp || 'تاريخ غير محدد';
                          const counts = bk.counts || {};

                          return (
                            <div
                              key={bk.backupId || idx}
                              className="p-3.5 rounded-2xl bg-black/50 border border-white/10 hover:border-[#e9c978]/30 transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                            >
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-white font-mono text-[11px]">
                                    {bk.backupId}
                                  </span>
                                  {idx === 0 && (
                                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#0fb98a]/20 text-[#0fb98a] border border-[#0fb98a]/30">
                                      الأحدث ⭐️
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] text-gray-400 flex items-center gap-2">
                                  <span>{formattedDate}</span>
                                  <span>•</span>
                                  <span>المصدر: {bk.source === 'central_cloud' ? 'السحابة المركزية' : 'محلي'}</span>
                                </div>
                                <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-gray-300 pt-0.5">
                                  {counts.curriculum_books !== undefined && (
                                    <span className="px-1.5 py-0.5 rounded bg-white/5 border border-white/5">
                                      📚 الكتب: {counts.curriculum_books}
                                    </span>
                                  )}
                                  {counts.lectures !== undefined && (
                                    <span className="px-1.5 py-0.5 rounded bg-white/5 border border-white/5">
                                      🎥 المحاضرات: {counts.lectures}
                                    </span>
                                  )}
                                  {counts.users !== undefined && (
                                    <span className="px-1.5 py-0.5 rounded bg-white/5 border border-white/5">
                                      👥 المستخدمين: {counts.users}
                                    </span>
                                  )}
                                  {counts.institute_posts !== undefined && (
                                    <span className="px-1.5 py-0.5 rounded bg-white/5 border border-white/5">
                                      🏛️ المعهد: {counts.institute_posts}
                                    </span>
                                  )}
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={() => handleDownloadBackupSummary(bk)}
                                className="px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 text-[#e9c978] hover:text-white font-semibold text-[11px] flex items-center gap-1.5 transition shrink-0"
                              >
                                <Download className="w-3.5 h-3.5" />
                                <span>تحميل ملخص النسخة</span>
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ==========================================
                TAB: INSTITUTE STUDENTS MANAGEMENT (طلاب المعهد الخاص)
                ========================================== */}
            {adminTab === 'institute' && (
              <AdminInstituteTab showToast={showToast} />
            )}

            {/* Toast notification banner */}
            {toastMessage && (
              <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[1100] px-5 py-3 rounded-2xl bg-[#0fb98a] text-black font-bold text-sm shadow-2xl flex items-center gap-2 animate-bounce">
                <CheckCircle2 className="w-5 h-5 text-black" />
                <span>{toastMessage}</span>
              </div>
            )}

          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: ADD NEW STUDENT (إضافة طالب جديد)
          ========================================== */}
      {isAddUserModalOpen && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div 
            className="relative w-full max-w-lg rounded-3xl bg-[#0a1220] border border-[#e9c978]/40 shadow-2xl p-6 sm:p-8 text-[#eaf0f8]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-amiri font-bold text-xl text-[#e9c978]">
                    إضافة طالب جديد للمنصة
                  </h3>
                  <p className="text-xs text-gray-400">تسجيل بيانات الطالب في قاعدة البيانات السحابية</p>
                </div>
              </div>
              <button 
                onClick={() => setIsAddUserModalOpen(false)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddUser} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">اسم الطالب الكامل</label>
                <input
                  type="text"
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  placeholder="مثال: علي حيدر الزبيدي"
                  required
                  className="w-full py-2.5 px-3.5 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">رقم الهاتف / الواتساب أو البريد</label>
                  <input
                    type="text"
                    value={newUserContact}
                    onChange={(e) => setNewUserContact(e.target.value)}
                    placeholder="+964 770 ... أو بريد إلكتروني"
                    required
                    className="w-full py-2.5 px-3.5 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 text-xs focus:outline-none focus:border-[#e9c978]"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">المرحلة الدراسية</label>
                  <select
                    value={newUserGrade}
                    onChange={(e) => setNewUserGrade(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                  >
                    <option value="g1">الأول المتوسط</option>
                    <option value="g2">الثاني المتوسط</option>
                    <option value="g3">الثالث المتوسط</option>
                    <option value="g4">الرابع العلمي</option>
                    <option value="g5">الخامس العلمي</option>
                    <option value="g6">السادس العلمي</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">نوع جهاز الطالب</label>
                <select
                  value={newUserDevice}
                  onChange={(e) => setNewUserDevice(e.target.value as any)}
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                >
                  <option value="android-apk">📱 تطبيق أندرويد APK مثبت</option>
                  <option value="web-mobile">📱 متصفح هاتف ذكي</option>
                  <option value="web-desktop">💻 جهاز كمبيوتر / لابتوب</option>
                </select>
              </div>

              {/* VIP check */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-black/40 border border-white/10">
                <input
                  type="checkbox"
                  id="vip-check"
                  checked={newUserIsVip}
                  onChange={(e) => setNewUserIsVip(e.target.checked)}
                  className="w-4 h-4 rounded text-[#e9c978] focus:ring-0 cursor-pointer"
                />
                <label htmlFor="vip-check" className="text-xs text-white cursor-pointer select-none">
                  <span className="font-bold text-[#e9c978]">منح اشتراك VIP مباشر</span> (فتح كافة المحاضرات المدفوعة بدون أكواد)
                </label>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">ملاحظات إضافية (اختياري)</label>
                <input
                  type="text"
                  value={newUserNotes}
                  onChange={(e) => setNewUserNotes(e.target.value)}
                  placeholder="مثال: طالب الدورة الصيفية في معهد النخبة..."
                  className="w-full py-2.5 px-3.5 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs shadow-lg hover:brightness-110 transition"
                >
                  حفظ وتسجيل الطالب في السيرفر
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddUserModalOpen(false)}
                  className="py-3 px-4 rounded-xl bg-white/10 text-gray-300 hover:text-white text-xs font-semibold"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: EDIT STUDENT (تعديل بيانات طالب)
          ========================================== */}
      {editingUser && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div 
            className="relative w-full max-w-lg rounded-3xl bg-[#0a1220] border border-[#e9c978]/40 shadow-2xl p-6 sm:p-8 text-[#eaf0f8]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#e9c978]/20 text-[#e9c978] flex items-center justify-center">
                  <Edit3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-amiri font-bold text-xl text-[#e9c978]">
                    تعديل بيانات الطالب ({editingUser.id})
                  </h3>
                  <p className="text-xs text-gray-400">تحديث صلاحيات ومرحلة الطالب</p>
                </div>
              </div>
              <button 
                onClick={() => setEditingUser(null)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditUser} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">اسم الطالب</label>
                <input
                  type="text"
                  value={editingUser.name}
                  onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                  required
                  className="w-full py-2.5 px-3.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">رقم الهاتف / البريد</label>
                  <input
                    type="text"
                    value={editingUser.emailOrPhone}
                    onChange={(e) => setEditingUser({ ...editingUser, emailOrPhone: e.target.value })}
                    required
                    className="w-full py-2.5 px-3.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">المرحلة الدراسية</label>
                  <select
                    value={editingUser.grade}
                    onChange={(e) => setEditingUser({ ...editingUser, grade: e.target.value })}
                    className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                  >
                    <option value="g1">الأول المتوسط</option>
                    <option value="g2">الثاني المتوسط</option>
                    <option value="g3">الثالث المتوسط</option>
                    <option value="g4">الرابع العلمي</option>
                    <option value="g5">الخامس العلمي</option>
                    <option value="g6">السادس العلمي</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">حالة الحساب</label>
                  <select
                    value={editingUser.status}
                    onChange={(e) => setEditingUser({ ...editingUser, status: e.target.value as any })}
                    className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                  >
                    <option value="active">🟢 نشط ومفعل</option>
                    <option value="blocked">🔴 محظور وموقوف</option>
                  </select>
                </div>

                <div className="flex items-center gap-2 pt-6">
                  <input
                    type="checkbox"
                    id="edit-vip"
                    checked={editingUser.isVip}
                    onChange={(e) => setEditingUser({ 
                      ...editingUser, 
                      isVip: e.target.checked,
                      role: e.target.checked ? 'vip' : 'student'
                    })}
                    className="w-4 h-4 rounded text-[#e9c978] cursor-pointer"
                  />
                  <label htmlFor="edit-vip" className="text-xs text-white cursor-pointer font-bold select-none">
                    مشترك باقة VIP الذهبية
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">ملاحظات الأستاذ</label>
                <input
                  type="text"
                  value={editingUser.notes || ''}
                  onChange={(e) => setEditingUser({ ...editingUser, notes: e.target.value })}
                  className="w-full py-2.5 px-3.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs shadow-lg hover:brightness-110 transition"
                >
                  حفظ التعديلات
                </button>
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="py-3 px-4 rounded-xl bg-white/10 text-gray-300 hover:text-white text-xs font-semibold"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==========================================
          MODAL: BROADCAST ANNOUNCEMENT TO STUDENTS
          ========================================== */}
      {isBroadcastModalOpen && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div 
            className="relative w-full max-w-md rounded-3xl bg-[#0a1220] border border-purple-500/40 shadow-2xl p-6 sm:p-8 text-[#eaf0f8]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-amiri font-bold text-xl text-purple-300">
                    إرسال إشعار فوري لجميع الطلاب
                  </h3>
                  <p className="text-xs text-gray-400">يظهر التنبيه أعلى التطبيق عند جميع الطلاب</p>
                </div>
              </div>
              <button 
                onClick={() => setIsBroadcastModalOpen(false)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBroadcastSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">نص الإشعار أو التنبيه</label>
                <textarea
                  value={broadcastMessage}
                  onChange={(e) => setBroadcastMessage(e.target.value)}
                  placeholder="مثال: طلابنا الأعزاء، تم رفع محاضرة جديدة في مادة الوراثة للسادس العلمي، نرجو مشاهدتها قبل موعد الامتحان القادم."
                  rows={4}
                  required
                  className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 text-xs focus:outline-none focus:border-purple-400 leading-relaxed"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold text-xs shadow-lg hover:brightness-110 transition flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>بث ونشر الإشعار الآن</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsBroadcastModalOpen(false)}
                  className="py-3 px-4 rounded-xl bg-white/10 text-gray-300 hover:text-white text-xs font-semibold"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </>
  );
};
