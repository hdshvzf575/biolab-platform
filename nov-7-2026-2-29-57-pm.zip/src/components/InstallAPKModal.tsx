import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  CheckCircle2, 
  X, 
  Sparkles, 
  WifiOff, 
  ExternalLink, 
  Copy, 
  Check, 
  ShieldCheck, 
  Layers,
  ArrowRight,
  Share2,
  QrCode,
  Send,
  Apple,
  Info,
  HelpCircle,
  FileCheck2,
  RotateCw
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { CURRENT_APP_VERSION, applyAppUpdateSafely } from '../utils/versionManager';

interface InstallAPKModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAPKModal: React.FC<InstallAPKModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'share'>('android');

  if (!isOpen) return null;

  // Prefer shared public URL if available, else current origin
  const appUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ais-pre-nfi6ylkjfpyhtecegt2a2a-378445351099.europe-west1.run.app';
  const apkDownloadUrl = '/biolab.apk';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&bgcolor=0a1220&color=e9c978&data=${encodeURIComponent(appUrl)}`;

  const copyAppUrl = () => {
    playClickSound();
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleNativeShare = async () => {
    playClickSound();
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'منصة مختبر الأحياء - الأستاذ وسام سهيل العامري',
          text: 'منصة تعليمية متكاملة لمادة الأحياء لكافة المراحل الدراسية مع إمكانية التثبيت المباشر على الهاتف مجاناً!',
          url: appUrl,
        });
        return;
      } catch (e) {}
    }
    copyAppUrl();
  };

  const shareWhatsApp = () => {
    playClickSound();
    const text = `تطبيق مختبر الأحياء للأستاذ وسام سهيل العامري:\nمنصة تعليمية متكاملة لمادة الأحياء لكافة المراحل الدراسية مع إمكانية التثبيت كـ APK للأندرويد وتطبيق Safari للآيفون مجاناً!\nرابط المنصة: ${appUrl}\nرابط تنزيل APK المباشر: ${appUrl}${apkDownloadUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const shareTelegram = () => {
    playClickSound();
    const text = `تطبيق مختبر الأحياء للأستاذ وسام سهيل العامري - جميع المراحل الدراسية:\nرابط المنصة: ${appUrl}\nتحميل ملف APK: ${appUrl}${apkDownloadUrl}`;
    window.open(`https://t.me/share/url?url=${encodeURIComponent(appUrl)}&text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleQuickInstall = async () => {
    playClickSound();
    if (isInstallable) {
      const res = await install();
      if (res) {
        playSuccessSound();
        onClose();
      }
    } else {
      setActiveTab('android');
    }
  };

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-[0_20px_60px_rgba(0,0,0,0.85)] p-5 sm:p-7 text-[#eaf0f8]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={() => { playClickSound(); onClose(); }}
          className="absolute top-5 left-5 p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition text-gray-400 hover:text-white"
          title="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-5">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#c9a24a] to-[#e9c978] shadow-lg shadow-[#c9a24a]/30 mb-2.5 text-2xl">
            📲
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#0fb98a]/15 text-[#0fb98a] border border-[#0fb98a]/30 mb-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            تثبيت المنصة على الهاتف · Android & iOS
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-amiri text-white">
            تثبيت وتحميل تطبيق مختبر الأحياء
          </h2>
          <p className="text-xs text-gray-300 mt-1 max-w-md mx-auto">
            الأستاذ وسام سهيل العامري — علم الأحياء لكافة المراحل الدراسية
          </p>
        </div>

        {/* Status Box if already installed */}
        {isInstalled && (
          <div className="mb-4 p-3.5 rounded-2xl bg-[#0fb98a]/10 border border-[#0fb98a]/30 flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#0fb98a] shrink-0" />
            <div className="text-xs">
              <span className="font-bold text-[#0fb98a] block">التطبيق مثبت بالفعل على هذا الجهاز!</span>
              يعمل الآن كـ تطبيق مستقل بدون أشرطة متصفح ويدعم العمل التام أوفلاين.
            </div>
          </div>
        )}

        {/* Navigation Tabs (Android vs iOS vs Share) */}
        <div className="grid grid-cols-3 rounded-2xl bg-black/40 p-1 mb-5 border border-white/10 text-xs font-bold text-center">
          <button
            type="button"
            onClick={() => { playClickSound(); setActiveTab('android'); }}
            className={`py-2.5 px-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
              activeTab === 'android' 
                ? 'bg-gradient-to-r from-[#0fb98a] to-[#059669] text-black shadow-md' 
                : 'text-gray-300 hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>أندرويد (APK)</span>
          </button>

          <button
            type="button"
            onClick={() => { playClickSound(); setActiveTab('ios'); }}
            className={`py-2.5 px-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
              activeTab === 'ios' 
                ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md' 
                : 'text-gray-300 hover:text-white'
            }`}
          >
            <Apple className="w-4 h-4" />
            <span>آيفون وآيباد</span>
          </button>

          <button
            type="button"
            onClick={() => { playClickSound(); setActiveTab('share'); }}
            className={`py-2.5 px-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
              activeTab === 'share' 
                ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] shadow-md' 
                : 'text-gray-300 hover:text-white'
            }`}
          >
            <Share2 className="w-4 h-4" />
            <span>المشاركة والباركود</span>
          </button>
        </div>

        {/* ========================================================= */}
        {/* TAB 1: ANDROID (ملف APK الحقيقي وخطوات التثبيت) */}
        {/* ========================================================= */}
        {activeTab === 'android' && (
          <div className="space-y-4 text-xs sm:text-sm">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3.5">
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <h4 className="font-bold text-white text-sm flex items-center gap-1.5">
                    <span>ملف APK أصلي وموقّع وجاهز للتثبيت</span>
                  </h4>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono bg-[#0fb98a]/20 text-[#0fb98a] border border-[#0fb98a]/30">
                  v{CURRENT_APP_VERSION} · 120.8 KB
                </span>
              </div>

              {/* Verified APK Details Card */}
              <div className="p-3.5 rounded-xl bg-black/40 border border-[#0fb98a]/30 space-y-1.5 text-xs text-gray-300">
                <div className="flex justify-between border-b border-white/10 pb-1">
                  <span className="text-gray-400">اسم الحزمة (Package):</span>
                  <span className="text-[#0fb98a] font-mono font-bold">com.wissam.biolab</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-1">
                  <span className="text-gray-400">التوقيع الرقمي:</span>
                  <span className="text-emerald-300 font-bold">موقّع رسمي v1 + v2 + v3</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-1">
                  <span className="text-gray-400">الأجهزة المتوافقة:</span>
                  <span className="text-white">Android 7.0 (API 24) إلى Android 15 و16 (API 35+)</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-1">
                  <span className="text-gray-400">الأذونات الذكية:</span>
                  <span className="text-[#0fb98a] font-bold">إشعارات رسمية (POST_NOTIFICATIONS) + تنزيل مباشر</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">حالة الفحص:</span>
                  <span className="text-[#e9c978] font-bold">خالٍ تماماً من خطأ تحليل الحزمة (Parse Error)</span>
                </div>
              </div>

              {/* Main Download Button */}
              <a
                href={apkDownloadUrl}
                download="biolab.apk"
                onClick={() => playSuccessSound()}
                className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-[#0fb98a] via-[#10b981] to-[#059669] text-black font-black text-center flex items-center justify-center gap-2 shadow-lg shadow-[#0fb98a]/25 hover:brightness-110 active:scale-[0.98] transition"
              >
                <Download className="w-5 h-5 text-black stroke-[2.5]" />
                <span className="text-sm">تنزيل ملف الـ APK المباشر للهاتف (.apk)</span>
              </a>

              {/* Force In-App Refresh / Cache Buster Button for Installed Users */}
              <button
                type="button"
                onClick={async () => {
                  playClickSound();
                  await applyAppUpdateSafely({
                    version: CURRENT_APP_VERSION,
                    title: 'تحديث منصة وسام للأحياء',
                    releaseNotes: [],
                    releaseDate: new Date().toISOString(),
                    forceUpdate: true
                  });
                  window.location.reload();
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-[#0fb98a]/30 text-xs font-bold text-[#0fb98a] flex items-center justify-center gap-2 transition"
              >
                <RotateCw className="w-3.5 h-3.5 text-[#0fb98a]" />
                <span>إعادة تحميل وتحديث التطبيق المثبت (مسح الكاش والتحديث الفوري)</span>
              </button>

              {/* Step-by-Step Installation Instructions for Android */}
              <div className="space-y-2 pt-2 text-xs">
                <h5 className="font-bold text-[#e9c978] flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-[#e9c978]" />
                  <span>خطوات التثبيت السلس على هواتف Android:</span>
                </h5>
                <ol className="space-y-1.5 pr-2 text-gray-300">
                  <li className="flex items-start gap-2">
                    <span className="w-4 h-4 rounded-full bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center font-bold shrink-0 text-[10px] mt-0.5">1</span>
                    <span>اضغط زر <strong>«تنزيل ملف الـ APK»</strong> أعلاه.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-4 h-4 rounded-full bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center font-bold shrink-0 text-[10px] mt-0.5">2</span>
                    <span>بعد اكتمال التنزيل، اضغط على الإشعار أو افتح الملف من تطبيق «ملفاتي» أو مجلد «Downloads».</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-4 h-4 rounded-full bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center font-bold shrink-0 text-[10px] mt-0.5">3</span>
                    <span>إذا ظهر تنبيه الأمان، اضغط <strong>«الإعدادات»</strong> ثم فعّل خيار <strong>«السماح بالتثبيت من هذا المصدر»</strong>.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-4 h-4 rounded-full bg-[#0fb98a]/20 text-[#0fb98a] flex items-center justify-center font-bold shrink-0 text-[10px] mt-0.5">4</span>
                    <span>اضغط <strong>«تثبيت» (Install)</strong>، وستظهر أيقونة مختبر الأحياء فوراً على شاشة هاتفك الرئيسية.</span>
                  </li>
                </ol>
              </div>

              {/* WebAPK Chrome Quick Option */}
              {isInstallable && (
                <div className="pt-2 border-t border-white/10">
                  <button
                    type="button"
                    onClick={handleQuickInstall}
                    className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-200 font-bold text-xs flex items-center justify-center gap-2 transition"
                  >
                    <Smartphone className="w-4 h-4 text-[#0fb98a]" />
                    <span>أو تثبيت فوري بنقرة واحدة عبر المتصفح (WebAPK)</span>
                  </button>
                </div>
              )}
            </div>

            {/* Android Highlights */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2">
                <WifiOff className="w-4 h-4 text-[#0fb98a] shrink-0" />
                <span>حفظ المناهج والمحاضرات أوفلاين</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#e9c978] shrink-0" />
                <span>خفيف وسريع جداً على الهاتف</span>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 2: iOS (iPhone & iPad آلية التثبيت والتوزيع الرسمية) */}
        {/* ========================================================= */}
        {activeTab === 'ios' && (
          <div className="space-y-4 text-xs sm:text-sm">
            
            {/* Engineering Honesty Notice */}
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-amber-300">
                <Info className="w-4 h-4 shrink-0 text-amber-300" />
                <span>تنبيه تقني هام لمستخدمي iPhone و iPad:</span>
              </div>
              <p className="text-xs leading-relaxed text-amber-100">
                نظام <strong>iOS</strong> لا يدعم ملفات <strong>APK</strong> إطلاقاً (لأنها مخصصة لأندرويد فقط). وبدلاً من ذلك، توفر منصة مختبر الأحياء الدعم الكامل لمعيار Apple الرسمي للتطبيقات المستقلة <strong>(Standalone Web App / PWA)</strong>، والذي يمنحك تجربة تطبيق أصلي بشاشة كاملة وبدون إطار المتصفح!
              </p>
            </div>

            {/* Official Apple Install Steps via Safari */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <div className="flex items-center gap-2">
                <Apple className="w-5 h-5 text-white" />
                <h4 className="font-bold text-white text-sm">
                  طريقة التثبيت الرسمية على أجهزة Apple (خلال 10 ثوانٍ):
                </h4>
              </div>

              <div className="space-y-3 pt-1 text-xs text-gray-200">
                <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold shrink-0 text-xs mt-0.5">1</span>
                  <div>
                    <strong className="text-white block">افتح الرابط في متصفح Safari:</strong>
                    <span>تأكد من فتح رابط المنصة في متصفح Safari الرسمي المدمج بنظام iOS.</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold shrink-0 text-xs mt-0.5">2</span>
                  <div>
                    <strong className="text-white block">اضغط على زر المشاركة (Share ⎋):</strong>
                    <span>الموجود في أسفل شاشة سفاري (مربع يخرج منه سهم للأعلى).</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold shrink-0 text-xs mt-0.5">3</span>
                  <div>
                    <strong className="text-white block">اختر «إضافة إلى الصفحة الرئيسية» (Add to Home Screen ➕):</strong>
                    <span>مرر قائمة الخيارات للأسفل واضغط على خيار الإضافة إلى الصفحة الرئيسية.</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold shrink-0 text-xs mt-0.5">4</span>
                  <div>
                    <strong className="text-white block">اضغط «إضافة» (Add) في الزاوية:</strong>
                    <span>ستظهر أيقونة منصة مختبر الأحياء فوراً على شاشة هاتفك مثل أي تطبيق مثبت من App Store!</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Native TestFlight / App Store Requirements Transparency */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-2 text-xs text-gray-300">
              <h5 className="font-bold text-[#e9c978] flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-[#e9c978]" />
                <span>حول نشر نسخة IPA على TestFlight أو App Store:</span>
              </h5>
              <p className="leading-relaxed">
                توزيع ملفات التثبيت المباشرة (IPA) وتفعيل TestFlight يتطلب قانونياً حساب <strong>Apple Developer Program</strong> رسمي مدفوع (99 دولاراً/سنوياً) واعتماد توقيع مطور من شركة Apple عبر بيئة Xcode. التطبيق المهيأ حالياً عبر Safari PWA يمنحك 100% من المميزات (شاشة كاملة، سرعة فائقة، أيقونة مخصصة، حفظ البيانات أوفلاين) بشكل مجاني وفوري.
              </p>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 3: SHARE & QR CODE (مشاركة الرابط والباركود) */}
        {/* ========================================================= */}
        {activeTab === 'share' && (
          <div className="space-y-4 text-xs sm:text-sm">
            
            {/* Direct Link box */}
            <div className="p-4 rounded-2xl bg-white/5 border border-[#e9c978]/30 space-y-3">
              <div className="flex items-center justify-between text-xs text-gray-300">
                <span className="font-bold text-[#e9c978]">رابط المنصة المباشر:</span>
                <span>يعمل على جميع الأجهزة</span>
              </div>
              
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={appUrl}
                  className="w-full bg-black/50 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-mono text-emerald-300 select-all"
                />
                <button
                  type="button"
                  onClick={copyAppUrl}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] font-bold text-xs flex items-center gap-1.5 shrink-0 hover:brightness-110 transition shadow-md"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'تم النسخ' : 'نسخ'}</span>
                </button>
              </div>

              {/* Social Share Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={shareWhatsApp}
                  className="py-2.5 px-4 rounded-xl bg-[#25D366]/20 border border-[#25D366]/40 hover:bg-[#25D366]/30 text-[#25D366] font-bold text-xs flex items-center justify-center gap-2 transition"
                >
                  <Send className="w-4 h-4" />
                  <span>إرسال عبر واتساب</span>
                </button>

                <button
                  type="button"
                  onClick={shareTelegram}
                  className="py-2.5 px-4 rounded-xl bg-[#0088cc]/20 border border-[#0088cc]/40 hover:bg-[#0088cc]/30 text-[#0088cc] font-bold text-xs flex items-center justify-center gap-2 transition"
                >
                  <Send className="w-4 h-4" />
                  <span>مشاركة عبر تلغرام</span>
                </button>
              </div>

              {/* Native Web Share API button */}
              <button
                type="button"
                onClick={handleNativeShare}
                className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-200 font-bold text-xs flex items-center justify-center gap-2 transition"
              >
                <Share2 className="w-4 h-4 text-[#e9c978]" />
                <span>مشاركة الرابط عبر تطبيقات الهاتف الأخرى</span>
              </button>
            </div>

            {/* QR Code Card */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col sm:flex-row items-center gap-4 text-center sm:text-right">
              <div className="w-36 h-36 rounded-2xl p-2 bg-[#0a1220] border-2 border-[#e9c978]/40 shadow-xl flex items-center justify-center shrink-0">
                <img 
                  src={qrCodeUrl} 
                  alt="QR Code للتطبيق" 
                  className="w-full h-full object-contain rounded-xl"
                  loading="lazy"
                />
              </div>
              <div className="space-y-1.5">
                <h5 className="font-bold text-white text-sm flex items-center justify-center sm:justify-start gap-1.5">
                  <QrCode className="w-4 h-4 text-[#e9c978]" />
                  <span>امسح الباركود بكاميرا الهاتف</span>
                </h5>
                <p className="text-xs text-gray-300 leading-relaxed">
                  وجّه كاميرا أي هاتف (iPhone أو Android) نحو الرمز لفتح المنصة مباشرة وتثبيتها دون الحاجة لكتابة الرابط يدوياً.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Footer info */}
        <div className="mt-5 pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-gray-400">
          <div>الأستاذ وسام سهيل العامري · مختبر الأحياء لكافة المراحل</div>
          <button
            type="button"
            onClick={() => { playClickSound(); onClose(); }}
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-medium transition"
          >
            إغلاق النافذة
          </button>
        </div>
      </div>
    </div>
  );
};
