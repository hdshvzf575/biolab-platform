import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Play, 
  Pause,
  Volume2,
  Volume1,
  VolumeX,
  RotateCcw, 
  RotateCw,
  Maximize2, 
  Minimize2,
  Lock, 
  KeyRound, 
  CheckCircle, 
  RefreshCw,
  ExternalLink,
  AlertTriangle,
  Settings,
  Check
} from 'lucide-react';
import { VideoUrlResolver, ResolvedVideoInfo } from '../services/video/VideoUrlResolver';
import { playClickSound } from '../utils/audioEffects';

export interface UniversalVideoPlayerProps {
  url: string;
  title?: string;
  poster?: string;
  autoPlay?: boolean;
  isPaid?: boolean;
  isUnlocked?: boolean;
  onOpenVipModal?: () => void;
  className?: string;
}

function formatVideoTime(seconds: number): string {
  if (isNaN(seconds) || seconds <= 0) return '00:00';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const paddedSecs = secs < 10 ? `0${secs}` : `${secs}`;
  const paddedMins = mins < 10 ? `0${mins}` : `${mins}`;
  if (hrs > 0) {
    return `${hrs}:${paddedMins}:${paddedSecs}`;
  }
  return `${paddedMins}:${paddedSecs}`;
}

const PLAYBACK_SPEEDS = [0.75, 1, 1.25, 1.5, 2];

export const UniversalVideoPlayer: React.FC<UniversalVideoPlayerProps> = ({
  url,
  title = 'المحاضرة التعليمية',
  poster,
  autoPlay = false,
  isPaid = false,
  isUnlocked = false,
  onOpenVipModal,
  className = ''
}) => {
  const [videoInfo, setVideoInfo] = useState<ResolvedVideoInfo | null>(null);
  const [hasStarted, setHasStarted] = useState<boolean>(autoPlay);
  const [isPlaying, setIsPlaying] = useState<boolean>(autoPlay);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [playbackError, setPlaybackError] = useState<string | null>(null);
  const [iframeLoaded, setIframeLoaded] = useState<boolean>(false);

  // Custom Video Player States
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [bufferedPercent, setBufferedPercent] = useState<number>(0);
  const [volume, setVolume] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState<boolean>(false);
  const [showControls, setShowControls] = useState<boolean>(true);
  const [isBuffering, setIsBuffering] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [seekHoverTime, setSeekHoverTime] = useState<number | null>(null);
  const [seekHoverPos, setSeekHoverPos] = useState<number>(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoElementRef = useRef<HTMLVideoElement>(null);
  const controlsTimeoutRef = useRef<any>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);
  const lastTapRef = useRef<number>(0);

  // 1. Resolve video info whenever URL changes
  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);
    setPlaybackError(null);
    setIframeLoaded(false);

    VideoUrlResolver.resolve(url)
      .then((info) => {
        if (!isMounted) return;
        setVideoInfo(info);
        setIsLoading(false);
        if (info.errorMessage) {
          setPlaybackError(info.errorMessage);
        }
      })
      .catch((err) => {
        if (!isMounted) return;
        setIsLoading(false);
        setPlaybackError(err?.message || 'تعذر تحليل ومعالجة رابط الفيديو');
      });

    return () => {
      isMounted = false;
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    };
  }, [url]);

  // 2. Fullscreen change listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // 3. Auto-hide controls timer during playback
  const triggerShowControls = useCallback(() => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
        setShowSpeedMenu(false);
      }, 3000);
    }
  }, [isPlaying]);

  // 4. Video Element Event Listeners
  useEffect(() => {
    const video = videoElementRef.current;
    if (!video) return;

    const onTimeUpdate = () => {
      setCurrentTime(video.currentTime);
      if (video.buffered.length > 0 && video.duration > 0) {
        const bufferedEnd = video.buffered.end(video.buffered.length - 1);
        setBufferedPercent(Math.min(100, (bufferedEnd / video.duration) * 100));
      }
    };

    const onLoadedMetadata = () => {
      setDuration(video.duration || 0);
      setIsBuffering(false);
    };

    const onWaiting = () => setIsBuffering(true);
    const onPlaying = () => {
      setIsBuffering(false);
      setIsPlaying(true);
    };
    const onPause = () => {
      setIsPlaying(false);
      setShowControls(true);
    };
    const onEnded = () => {
      setIsPlaying(false);
      setShowControls(true);
    };

    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('loadedmetadata', onLoadedMetadata);
    video.addEventListener('waiting', onWaiting);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('pause', onPause);
    video.addEventListener('ended', onEnded);

    return () => {
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('loadedmetadata', onLoadedMetadata);
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('ended', onEnded);
    };
  }, [hasStarted, videoInfo]);

  // Controls Handlers
  const handleTogglePlay = useCallback(() => {
    playClickSound();
    const video = videoElementRef.current;
    if (!video) return;

    if (video.paused) {
      video.play().then(() => {
        setIsPlaying(true);
        triggerShowControls();
      }).catch((e) => {
        console.warn('Video play attempt notice:', e);
      });
    } else {
      video.pause();
      setIsPlaying(false);
      setShowControls(true);
    }
  }, [triggerShowControls]);

  const handleStartPlay = useCallback(() => {
    playClickSound();
    setHasStarted(true);
    setIsPlaying(true);
    setPlaybackError(null);
  }, []);

  const handleSkip = useCallback((seconds: number) => {
    playClickSound();
    const video = videoElementRef.current;
    if (!video) return;
    const newTime = Math.max(0, Math.min(duration, video.currentTime + seconds));
    video.currentTime = newTime;
    setCurrentTime(newTime);
    triggerShowControls();
  }, [duration, triggerShowControls]);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current || !duration) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const targetTime = pos * duration;
    if (videoElementRef.current) {
      videoElementRef.current.currentTime = targetTime;
      setCurrentTime(targetTime);
    }
    triggerShowControls();
  };

  const handleProgressHover = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current || !duration) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    setSeekHoverPos(pos * 100);
    setSeekHoverTime(pos * duration);
  };

  const handleToggleMute = useCallback(() => {
    playClickSound();
    const video = videoElementRef.current;
    if (!video) return;
    const nextMuted = !isMuted;
    video.muted = nextMuted;
    setIsMuted(nextMuted);
  }, [isMuted]);

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    const video = videoElementRef.current;
    if (video) {
      video.volume = val;
      video.muted = val === 0;
      setIsMuted(val === 0);
    }
  };

  const handleSetSpeed = (speed: number) => {
    playClickSound();
    setPlaybackRate(speed);
    if (videoElementRef.current) {
      videoElementRef.current.playbackRate = speed;
    }
    setShowSpeedMenu(false);
    triggerShowControls();
  };

  const handleToggleFullscreen = useCallback(() => {
    playClickSound();
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  }, []);

  const handleOpenExternal = useCallback(() => {
    playClickSound();
    if (!url) return;
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {
      window.location.href = url;
    }
  }, [url]);

  const handleRetry = useCallback(() => {
    playClickSound();
    setPlaybackError(null);
    setIsLoading(true);
    setIframeLoaded(false);
    VideoUrlResolver.resolve(url).then((info) => {
      setVideoInfo(info);
      setIsLoading(false);
      setHasStarted(true);
      setIsPlaying(true);
    });
  }, [url]);

  // Double tap to seek ±10s on mobile
  const handleTouchContainer = (e: React.TouchEvent) => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      const touchX = e.changedTouches[0].clientX;
      const rect = containerRef.current?.getBoundingClientRect();
      if (rect) {
        if (touchX - rect.left < rect.width / 2) {
          handleSkip(-10);
        } else {
          handleSkip(10);
        }
      }
    } else {
      triggerShowControls();
    }
    lastTapRef.current = now;
  };

  const isLocked = isPaid && !isUnlocked;
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;
  const thumbnailUrl = poster || (videoInfo ? VideoUrlResolver.getThumbnail(videoInfo.originalUrl) : 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80');

  return (
    <div 
      ref={containerRef}
      onMouseMove={triggerShowControls}
      onTouchStart={handleTouchContainer}
      className={`relative w-full aspect-video bg-black overflow-hidden rounded-3xl border border-white/10 group select-none ${
        isFullscreen ? 'rounded-none border-0' : ''
      } ${className}`}
    >
      {/* 1. VIP Locked Overlay */}
      {isLocked ? (
        <div className="w-full h-full bg-gradient-to-br from-[#e9c978]/15 via-black/85 to-black flex flex-col items-center justify-center p-6 text-center select-none">
          <div className="absolute top-3 right-3 z-20 px-2.5 py-1 rounded-lg text-xs font-black bg-[#e9c978] text-[#08111e] shadow-md flex items-center gap-1">
            <Lock className="w-3.5 h-3.5" />
            <span>VIP 🔒 مغلقة</span>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-[#e9c978]/20 border border-[#e9c978]/40 text-[#e9c978] flex items-center justify-center text-2xl mb-3 shadow-lg animate-pulse">
            <Lock className="w-7 h-7" />
          </div>
          <h4 className="font-amiri font-bold text-lg text-[#e9c978] mb-1">
            محاضرة خاصة مدفوعة
          </h4>
          <p className="text-xs text-gray-300 mb-4 max-w-xs">
            تتطلب كود سري من الأستاذ وسام سهيل العامري لمشاهدة الفيديو
          </p>
          {onOpenVipModal && (
            <button
              onClick={() => { playClickSound(); onOpenVipModal(); }}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-xs shadow-md hover:scale-105 active:scale-95 transition flex items-center gap-1.5"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>أدخل الكود السري لفتح الفيديو</span>
            </button>
          )}
        </div>
      ) : !hasStarted ? (
        /* 2. Cover / Poster Thumbnail with Play Button */
        <div 
          onClick={handleStartPlay}
          className="w-full h-full relative cursor-pointer overflow-hidden select-none"
        >
          <img
            src={thumbnailUrl}
            alt={title}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80';
            }}
          />

          {/* Dark Overlay */}
          <div className="absolute inset-0 bg-black/45 group-hover:bg-black/25 transition-colors flex items-center justify-center">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-[#0fb98a] via-[#10b981] to-[#34d399] text-[#08111e] flex items-center justify-center shadow-2xl transition-all duration-300 group-hover:scale-110 group-active:scale-95">
              <Play className="w-7 h-7 fill-current mr-0.5" />
            </div>
          </div>

          {/* Top Badges */}
          <div className="absolute top-3 right-3 z-10 flex items-center gap-2">
            {isPaid && isUnlocked && (
              <span className="px-2.5 py-1 rounded-lg text-xs font-black bg-[#0fb98a] text-black shadow flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>VIP مفتوحة</span>
              </span>
            )}
            <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-black/75 backdrop-blur-md text-[#e9c978] border border-white/10 shadow">
              مختبر الأحياء · وسام سهيل العامري
            </span>
          </div>

          <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-lg bg-black/80 backdrop-blur-md text-[11px] text-white font-mono font-bold flex items-center gap-1.5 border border-white/10">
            <Play className="w-3 h-3 fill-white" />
            <span>انقر للمشاهدة الآن</span>
          </div>
        </div>
      ) : playbackError ? (
        /* 3. Error Fallback State */
        <div className="w-full h-full p-6 bg-[#0a1220] flex flex-col items-center justify-center text-center space-y-3 text-white">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center text-2xl">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div className="space-y-1 max-w-sm">
            <h4 className="font-bold text-sm text-white">تعذر تشغيل هذا الفيديو داخل الإطار</h4>
            <p className="text-xs text-gray-300 leading-relaxed">
              {playbackError || 'الموقع المزود للفيديو قد يمنع التضمين المباشر أو يحتاج لتشغيله في المتصفح الخارجي.'}
            </p>
          </div>
          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={handleRetry}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center gap-1.5 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إعادة المحاولة</span>
            </button>
            <button
              type="button"
              onClick={handleOpenExternal}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-xs flex items-center gap-1.5 shadow-md hover:brightness-110 transition"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>مشاهدة في المتصفح الخارجي 🌐</span>
            </button>
          </div>
        </div>
      ) : videoInfo?.playbackMode === 'html5_video' ? (
        /* 4. Professional Custom HTML5 Video Player */
        <div 
          onClick={handleTogglePlay}
          className="w-full h-full relative bg-black flex items-center justify-center cursor-pointer overflow-hidden"
        >
          <video
            ref={videoElementRef}
            src={videoInfo.playbackUrl}
            autoPlay
            playsInline
            preload="metadata"
            className="w-full h-full object-contain"
            onError={() => {
              setPlaybackError('تعذر فك ترميز ملف الفيديو أو تعذر الوصول إلى مسار التخزين.');
            }}
          >
            {videoInfo.mimeType && (
              <source src={videoInfo.playbackUrl} type={videoInfo.mimeType} />
            )}
            متصفحك لا يدعم تشغيل هذا النوع من الفيديوهات.
          </video>

          {/* Buffering Indicator */}
          {isBuffering && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-none z-20">
              <div className="p-3.5 rounded-2xl bg-black/80 border border-[#0fb98a]/40 shadow-2xl flex items-center gap-2.5 text-xs text-[#0fb98a] font-bold">
                <RefreshCw className="w-5 h-5 animate-spin text-[#0fb98a]" />
                <span>جاري البث...</span>
              </div>
            </div>
          )}

          {/* Big Center Play Indicator when Paused */}
          {!isPlaying && !isBuffering && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/35 pointer-events-none z-10">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-[#0fb98a] to-[#34d399] text-[#08111e] flex items-center justify-center shadow-2xl scale-100 transition-transform">
                <Play className="w-7 h-7 fill-current mr-0.5" />
              </div>
            </div>
          )}

          {/* Platform Top Branding Bar */}
          <div 
            className={`absolute top-0 inset-x-0 p-3 bg-gradient-to-b from-black/80 via-black/40 to-transparent flex items-center justify-between z-30 transition-opacity duration-300 pointer-events-auto ${
              showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-[#0fb98a] text-black shadow">
                🧬 مختبر الأحياء
              </span>
              <span className="text-xs font-bold text-white truncate max-w-xs sm:max-w-md">
                {title}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleToggleFullscreen}
                className="p-1.5 text-gray-300 hover:text-white rounded-lg hover:bg-white/10 transition"
                title="ملء الشاشة"
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Custom Bottom Controls Bar */}
          <div 
            className={`absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/95 via-black/80 to-transparent p-3 pt-6 flex flex-col gap-2 z-30 transition-opacity duration-300 pointer-events-auto ${
              showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
            onClick={(e) => e.stopPropagation()}
            dir="ltr"
          >
            {/* Seek / Progress Timeline Bar */}
            <div 
              ref={progressBarRef}
              onClick={handleSeek}
              onMouseMove={handleProgressHover}
              onMouseLeave={() => setSeekHoverTime(null)}
              className="relative w-full h-2 hover:h-3 bg-white/20 hover:bg-white/30 rounded-full cursor-pointer transition-all flex items-center"
            >
              {/* Buffered Progress */}
              <div 
                className="absolute left-0 top-0 bottom-0 bg-white/30 rounded-full"
                style={{ width: `${bufferedPercent}%` }}
              />

              {/* Played Progress */}
              <div 
                className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-[#0fb98a] via-[#10b981] to-[#e9c978] rounded-full shadow-md"
                style={{ width: `${progressPercent}%` }}
              />

              {/* Scrubber Thumb */}
              <div 
                className="absolute w-3.5 h-3.5 rounded-full bg-white shadow-lg border-2 border-[#0fb98a] -ml-1.5 transition-transform group-hover:scale-125"
                style={{ left: `${progressPercent}%` }}
              />

              {/* Hover Tooltip */}
              {seekHoverTime !== null && (
                <div 
                  className="absolute bottom-5 -translate-x-1/2 px-2 py-0.5 rounded bg-black/90 text-[10px] font-mono text-[#e9c978] border border-white/10 pointer-events-none"
                  style={{ left: `${seekHoverPos}%` }}
                >
                  {formatVideoTime(seekHoverTime)}
                </div>
              )}
            </div>

            {/* Controls Button Row */}
            <div className="flex items-center justify-between text-white text-xs pt-1">
              {/* Left Group: Play, Skip, Volume, Time */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleTogglePlay}
                  className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition flex items-center justify-center"
                  title={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
                >
                  {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => handleSkip(-10)}
                  className="p-1 text-gray-300 hover:text-white transition flex items-center gap-0.5"
                  title="رجوع 10 ثوانٍ"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span className="text-[10px] font-mono font-bold">10</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSkip(10)}
                  className="p-1 text-gray-300 hover:text-white transition flex items-center gap-0.5"
                  title="تقديم 10 ثوانٍ"
                >
                  <RotateCw className="w-4 h-4" />
                  <span className="text-[10px] font-mono font-bold">10</span>
                </button>

                {/* Volume slider */}
                <div className="flex items-center gap-1.5 group/vol">
                  <button
                    type="button"
                    onClick={handleToggleMute}
                    className="p-1 text-gray-300 hover:text-white transition"
                    title={isMuted ? 'إلغاء الكتم' : 'كتم الصوت'}
                  >
                    {isMuted || volume === 0 ? (
                      <VolumeX className="w-4 h-4 text-red-400" />
                    ) : volume < 0.5 ? (
                      <Volume1 className="w-4 h-4" />
                    ) : (
                      <Volume2 className="w-4 h-4 text-[#0fb98a]" />
                    )}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={isMuted ? 0 : volume}
                    onChange={handleVolumeChange}
                    className="w-14 sm:w-18 h-1 accent-[#0fb98a] bg-white/20 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Time Display */}
                <div className="font-mono text-[11px] text-gray-300 tracking-wider">
                  <span className="text-[#e9c978]">{formatVideoTime(currentTime)}</span>
                  <span className="mx-1 text-gray-500">/</span>
                  <span>{formatVideoTime(duration)}</span>
                </div>
              </div>

              {/* Right Group: Speed Menu & Fullscreen */}
              <div className="flex items-center gap-2">
                {/* Playback Speed Dropdown */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                    className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-[11px] font-bold text-gray-200 hover:text-white flex items-center gap-1 transition"
                    title="سرعة التشغيل"
                  >
                    <Settings className="w-3 h-3 text-[#e9c978]" />
                    <span>{playbackRate}x</span>
                  </button>

                  {showSpeedMenu && (
                    <div className="absolute bottom-9 right-0 bg-[#0a1220] border border-[#e9c978]/30 rounded-xl p-1 shadow-2xl flex flex-col gap-0.5 z-40 min-w-[70px]">
                      {PLAYBACK_SPEEDS.map((speed) => (
                        <button
                          key={speed}
                          type="button"
                          onClick={() => handleSetSpeed(speed)}
                          className={`px-2.5 py-1 text-right text-[11px] font-bold rounded-lg transition flex items-center justify-between ${
                            playbackRate === speed
                              ? 'bg-[#0fb98a] text-black'
                              : 'text-gray-300 hover:bg-white/10'
                          }`}
                        >
                          <span>{speed}x</span>
                          {playbackRate === speed && <Check className="w-3 h-3" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Fullscreen Button */}
                <button
                  type="button"
                  onClick={handleToggleFullscreen}
                  className="p-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-white/10 transition"
                  title="ملء الشاشة"
                >
                  {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* 5. Official / Provider Iframe Player (YouTube, Vimeo, etc.) */
        <div className="w-full h-full relative bg-black">
          {isLoading && (
            <div className="absolute inset-0 z-10 bg-black/80 flex items-center justify-center text-xs text-[#0fb98a] gap-2 font-bold">
              <RefreshCw className="w-4 h-4 animate-spin text-[#0fb98a]" />
              <span>جاري تجهيز مشغل الفيديو...</span>
            </div>
          )}

          <iframe
            src={videoInfo?.playbackUrl}
            title={title}
            loading="lazy"
            onLoad={() => {
              setIsLoading(false);
              setIframeLoaded(true);
            }}
            onError={() => {
              setIsLoading(false);
              setPlaybackError('تعذر تحميل مشغل الفيديو عبر الإنترنت.');
            }}
            className="w-full h-full border-0 absolute inset-0"
            allowFullScreen
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          />

          {/* Quick Floating Actions Bar */}
          <div className="absolute top-2.5 left-2.5 z-20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1.5 bg-black/70 backdrop-blur-md p-1 rounded-xl border border-white/10">
            <button
              type="button"
              onClick={handleOpenExternal}
              className="p-1.5 text-gray-300 hover:text-white rounded-lg hover:bg-white/10 flex items-center gap-1 text-[10px] font-bold"
              title="فتح الفيديو في تبويب مستقل"
            >
              <ExternalLink className="w-3 h-3 text-[#e9c978]" />
              <span className="hidden sm:inline">فتح خارجي</span>
            </button>
            <button
              type="button"
              onClick={handleToggleFullscreen}
              className="p-1.5 text-gray-300 hover:text-white rounded-lg hover:bg-white/10"
              title="ملء الشاشة"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UniversalVideoPlayer;
