import React, { useState, useEffect, useMemo, useCallback, memo } from 'react';
import { Globe, RefreshCw } from 'lucide-react';
import { LectureItem, gradeNames } from '../data/platformData';
import { playClickSound } from '../utils/audioEffects';
import { subscribeToLectures } from '../services/firebase';
import UniversalVideoPlayer from './UniversalVideoPlayer';

interface LectureCardProps {
  lec: LectureItem;
  isUnlocked: boolean;
  onOpenVipModal: (id: number) => void;
}

// Memoized individual lecture card to prevent re-renders when other lectures change
const LectureCard = memo<LectureCardProps>(({ lec, isUnlocked, onOpenVipModal }) => {
  return (
    <div className="rounded-3xl bg-[#0a1220] border border-white/10 hover:border-[#e9c978]/40 overflow-hidden shadow-xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between group">
      {/* Universal Video Player Area */}
      <UniversalVideoPlayer
        url={lec.videoUrl}
        title={lec.title}
        isPaid={lec.isPaid}
        isUnlocked={isUnlocked}
        onOpenVipModal={() => onOpenVipModal(lec.id)}
      />

      {/* Info Area */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <h3 className="font-bold text-base sm:text-lg text-white mb-2 leading-snug group-hover:text-[#e9c978] transition">
            {lec.title}
          </h3>
          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed mb-4">
            {lec.desc || 'بدون وصف'}
          </p>
        </div>

        <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs font-bold text-[#e9c978]">
          <span>📚 {gradeNames[lec.grade] || lec.grade}</span>
          {lec.isPaid ? (
            <span className="text-[11px] text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
              محاضرة VIP
            </span>
          ) : (
            <span className="text-[11px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20 flex items-center gap-1">
              <Globe className="w-3 h-3" />
              <span>مجانية ومباشرة</span>
            </span>
          )}
        </div>
      </div>
    </div>
  );
});

LectureCard.displayName = 'LectureCard';

interface LecturesSectionProps {
  lectures: LectureItem[];
  unlockedVip: number[];
  onOpenVipModal: (lectureId: number) => void;
  selectedGradeFilter: string;
  onFilterChange: (grade: string) => void;
  onRefreshLectures?: () => void;
  isRefreshing?: boolean;
}

export const LecturesSection: React.FC<LecturesSectionProps> = memo(({
  lectures,
  unlockedVip,
  onOpenVipModal,
  selectedGradeFilter,
  onFilterChange,
  onRefreshLectures,
  isRefreshing = false
}) => {
  // Direct real-time Firestore subscription state
  const [liveLectures, setLiveLectures] = useState<LectureItem[]>(lectures);

  // Sync with prop when passed
  useEffect(() => {
    if (Array.isArray(lectures)) {
      setLiveLectures(lectures);
    }
  }, [lectures]);

  // Subscribe directly to Firestore collection 'lectures' for real-time additions, edits & deletions
  useEffect(() => {
    const unsubscribe = subscribeToLectures(
      (cloudLectures) => {
        if (Array.isArray(cloudLectures)) {
          setLiveLectures(cloudLectures);
        }
      },
      (err) => {
        console.warn('LecturesSection direct Firestore subscription notice:', err?.message || err);
      }
    );
    return () => unsubscribe();
  }, []);

  // Memoize counts per grade to avoid recalculating on each render
  const gradeCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const lec of liveLectures) {
      counts[lec.grade] = (counts[lec.grade] || 0) + 1;
    }
    return counts;
  }, [liveLectures]);

  // Memoize filtered and sorted list
  const filteredAndSortedLectures = useMemo(() => {
    let result = liveLectures;
    if (selectedGradeFilter !== 'all') {
      result = liveLectures.filter(lec => lec.grade === selectedGradeFilter);
    }
    return [...result].sort((a, b) => b.id - a.id);
  }, [liveLectures, selectedGradeFilter]);

  const handleFilterClick = useCallback((gradeKey: string) => {
    playClickSound();
    onFilterChange(gradeKey);
  }, [onFilterChange]);

  return (
    <section id="lectures" className="py-24 relative border-t border-white/5 bg-gradient-to-b from-transparent via-[#0fb98a]/5 to-transparent">
      <div className="w-[min(1240px,92%)] mx-auto space-y-10">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full text-xs font-bold text-[#e9c978] bg-[#e9c978]/10 border border-[#e9c978]/25 shadow-sm">
            <Globe className="w-3.5 h-3.5 text-[#0fb98a]" />
            <span>المحاضرات المرئية السحابية</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#0fb98a] animate-pulse"></span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold font-amiri text-white">
            أحدث المحاضرات
          </h2>
          <p className="text-sm sm:text-base text-gray-300 max-w-xl mx-auto">
            المحاضرات المضافة حديثاً من قبل الأستاذ عبر الإنترنت - تعمل وتتحدث تلقائياً على جميع الأجهزة وتطبيق الأندرويد.
          </p>

          {/* Online Sync Badge & Refresh */}
          <div className="flex items-center justify-center gap-3 pt-2">
            <span className="inline-flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>متصل بالإنترنت ومحدث لحظياً</span>
            </span>

            {onRefreshLectures && (
              <button
                onClick={onRefreshLectures}
                disabled={isRefreshing}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs text-gray-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition active:scale-95 disabled:opacity-50"
                title="تحديث المحاضرات من السيرفر"
              >
                <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin text-[#e9c978]' : ''}`} />
                <span>تحديث الفيديوهات</span>
              </button>
            )}
          </div>
        </div>

        {/* Grade Filters for Lectures */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          <button
            onClick={() => handleFilterClick('all')}
            className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition ${
              selectedGradeFilter === 'all'
                ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md'
                : 'bg-white/5 text-gray-300 hover:text-white border border-white/10'
            }`}
          >
            جميع المحاضرات ({lectures.length})
          </button>
          {Object.entries(gradeNames).map(([key, name]) => {
            const countInGrade = gradeCounts[key] || 0;
            return (
              <button
                key={key}
                onClick={() => handleFilterClick(key)}
                className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition ${
                  selectedGradeFilter === key
                    ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md'
                    : 'bg-white/5 text-gray-300 hover:text-white border border-white/10'
                }`}
              >
                <span>{name}</span>
                {countInGrade > 0 && (
                  <span className="mr-1.5 opacity-75 font-mono text-[11px]">({countInGrade})</span>
                )}
              </button>
            );
          })}
        </div>

        {/* Lectures Grid */}
        {filteredAndSortedLectures.length === 0 ? (
          <div className="text-center py-16 p-8 rounded-3xl bg-[#0a1220]/80 border border-white/10 max-w-md mx-auto space-y-2">
            <div className="text-4xl mb-2">📺</div>
            <p className="text-gray-200 text-sm font-semibold">لا توجد محاضرات في هذه المرحلة حالياً.</p>
            <p className="text-xs text-gray-400">يقوم الأستاذ برفع المحاضرات بانتظام من قسم الإدارة لتظهر لجميع الطلاب مباشرة.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedLectures.map((lec) => (
              <LectureCard
                key={lec.id}
                lec={lec}
                isUnlocked={unlockedVip.includes(lec.id)}
                onOpenVipModal={onOpenVipModal}
              />
            ))}
          </div>
        )}

      </div>
    </section>
  );
});

LecturesSection.displayName = 'LecturesSection';
