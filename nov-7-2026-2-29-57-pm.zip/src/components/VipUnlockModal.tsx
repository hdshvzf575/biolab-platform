import React, { useState, useEffect } from 'react';
import { KeyRound, X, Lock, CheckCircle2, AlertCircle, Copy, Check, Sparkles } from 'lucide-react';
import { LectureItem } from '../data/platformData';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';

interface VipUnlockModalProps {
  lectureId: number | null;
  lectures: LectureItem[];
  userUid?: string;
  onUnlockSuccess: (lectureId: number) => void;
  onClose: () => void;
}

export const VipUnlockModal: React.FC<VipUnlockModalProps> = ({
  lectureId,
  lectures,
  userUid,
  onUnlockSuccess,
  onClose
}) => {
  const [code, setCode] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [copiedUid, setCopiedUid] = useState(false);

  // Active user UID from props or localStorage
  const activeUid = userUid || (() => {
    try {
      const saved = localStorage.getItem('biolab_user_profile');
      if (saved) return JSON.parse(saved).uid;
      return localStorage.getItem('biolab_session_id') || 'UID-BIO-GUEST';
    } catch (e) {
      return 'UID-BIO-GUEST';
    }
  })();

  if (lectureId === null) return null;

  const targetLecture = lectures.find(l => l.id === lectureId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    const entered = code.trim().toUpperCase();

    if (!entered) {
      setErrorMsg('يرجى إدخال رمز الكود أولاً.');
      return;
    }

    setIsVerifying(true);
    playClickSound();

    try {
      // 1. Primary: Server-side validation linking code to UID
      const res = await fetch('/api/codes/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: entered,
          uid: activeUid
        })
      });

      const data = await res.json();

      if (res.ok && data.success) {
        playSuccessSound();
        setSuccessMsg(data.message || 'تم تفعيل الكود بنجاح!');
        setTimeout(() => {
          if (targetLecture) onUnlockSuccess(targetLecture.id);
          onClose();
        }, 1100);
        return;
      }

      // If server returned specific error (e.g. UID mismatch)
      if (data && data.error) {
        // Check if legacy fallback matches
        if (targetLecture && targetLecture.secretCode && entered === targetLecture.secretCode.toUpperCase()) {
          playSuccessSound();
          setSuccessMsg('تم التحقق من الكود المباشر بنجاح!');
          setTimeout(() => {
            onUnlockSuccess(targetLecture.id);
            onClose();
          }, 900);
          return;
        }

        setErrorMsg(data.error);
        setIsVerifying(false);
        return;
      }
    } catch (networkErr) {
      // Offline fallback: check targetLecture.secretCode
      if (targetLecture && targetLecture.secretCode && entered === targetLecture.secretCode.toUpperCase()) {
        playSuccessSound();
        setSuccessMsg('تم التحقق بنجاح (وضع غير متصل)');
        setTimeout(() => {
          onUnlockSuccess(targetLecture.id);
          onClose();
        }, 900);
        return;
      }
      setErrorMsg('تعذر الاتصال بالخادم للتحقق من الكود، تأكد من الاتصال بالإنترنت.');
    } finally {
      setIsVerifying(false);
    }
  };

  const copyUid = () => {
    playClickSound();
    try {
      navigator.clipboard.writeText(activeUid);
      setCopiedUid(true);
      setTimeout(() => setCopiedUid(false), 2000);
    } catch (e) {}
  };

  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div 
        className="relative w-full max-w-md rounded-3xl bg-[#0a1220] border border-[#e9c978]/40 shadow-[0_20px_60px_rgba(0,0,0,0.85)] p-6 sm:p-8 text-center text-[#eaf0f8] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="absolute -top-16 -right-16 w-36 h-36 rounded-full bg-[#e9c978]/15 blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={() => {
            playClickSound();
            onClose();
          }}
          className="absolute top-5 left-5 w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white flex items-center justify-center transition border border-white/10"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-16 h-16 rounded-2xl bg-[#e9c978]/15 border border-[#e9c978]/40 text-[#e9c978] flex items-center justify-center text-3xl mx-auto mb-3 shadow-lg">
          🔒
        </div>

        <h2 className="font-amiri font-bold text-2xl text-[#e9c978] mb-1">
          فتح المحاضرة المدفوعة
        </h2>

        {targetLecture && (
          <p className="text-xs text-[#0fb98a] font-bold mb-3 px-2 line-clamp-2">
            «{targetLecture.title}»
          </p>
        )}

        {/* User UID Badge for Teacher Reference */}
        <div className="mb-5 p-3 rounded-2xl bg-black/50 border border-white/10 text-right space-y-1">
          <div className="flex items-center justify-between text-[11px] text-gray-400">
            <span>معرّف حسابك الخاص (UID):</span>
            <button
              type="button"
              onClick={copyUid}
              className="flex items-center gap-1 text-[#e9c978] hover:underline"
            >
              {copiedUid ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedUid ? 'تم النسخ' : 'نسخ المعرّف'}</span>
            </button>
          </div>
          <div className="font-mono text-sm font-black text-white text-center py-1 tracking-wider bg-white/5 rounded-xl border border-white/5 select-all">
            {activeUid}
          </div>
          <span className="text-[10px] text-gray-400 block text-center">
            أعطِ هذا المعرّف للأستاذ وسام للحصول على كود مخصص لحسابك حصراً.
          </span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1 text-right">
            <label className="block text-xs font-bold text-gray-300">
              أدخل كود التفعيل:
            </label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="مثال: VIP-BIO-2026-..."
              autoFocus
              className="w-full py-3.5 px-4 rounded-xl bg-black/70 border border-[#e9c978]/40 text-center font-mono text-base font-black text-[#e9c978] placeholder:text-gray-500 focus:outline-none focus:border-[#e9c978] tracking-wider uppercase"
            />
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs font-bold text-right flex items-start gap-2 animate-fadeIn">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-xl bg-[#0fb98a]/15 border border-[#0fb98a]/30 text-[#0fb98a] text-xs font-bold text-center flex items-center justify-center gap-2 animate-fadeIn">
              <CheckCircle2 className="w-4 h-4 text-[#0fb98a]" />
              <span>{successMsg}</span>
            </div>
          )}

          <div className="space-y-2 pt-2">
            <button
              type="submit"
              disabled={isVerifying}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-sm shadow-xl hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <KeyRound className="w-4 h-4 text-[#08111e]" />
              <span>{isVerifying ? 'جاري التحقق من الصلاحية...' : 'تفعيل وفتح المحاضرة'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white text-xs font-bold transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
