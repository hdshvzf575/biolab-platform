import React, { useState, useEffect } from 'react';
import { 
  Award, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  ArrowLeft, 
  Clock, 
  Sparkles, 
  Check, 
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { BIOLOGY_CHAPTERS, QuizQuestion } from '../data/biologyCurriculum';

interface InteractiveQuizProps {
  initialChapterId?: number | null;
  onClose?: () => void;
}

export const InteractiveQuiz: React.FC<InteractiveQuizProps> = ({ 
  initialChapterId = null,
  onClose 
}) => {
  const [selectedChapterId, setSelectedChapterId] = useState<number | 'all'>(
    initialChapterId || 'all'
  );
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(25);
  const [enableTimer, setEnableTimer] = useState(false);

  // Initialize questions
  const loadQuestions = () => {
    let pool: QuizQuestion[] = [];
    if (selectedChapterId === 'all') {
      BIOLOGY_CHAPTERS.forEach(c => {
        pool = [...pool, ...c.quiz];
      });
    } else {
      const chapter = BIOLOGY_CHAPTERS.find(c => c.id === selectedChapterId);
      if (chapter) pool = [...chapter.quiz];
    }
    // Shuffle slightly
    setQuestions(pool.sort(() => Math.random() - 0.5));
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setIsAnswerSubmitted(false);
    setScore(0);
    setQuizFinished(false);
    setTimerSeconds(25);
  };

  useEffect(() => {
    loadQuestions();
  }, [selectedChapterId]);

  // Timer countdown
  useEffect(() => {
    if (!enableTimer || quizFinished || isAnswerSubmitted || questions.length === 0) return;

    if (timerSeconds <= 0) {
      // Time is up, auto submit as missed
      setIsAnswerSubmitted(true);
      return;
    }

    const interval = setInterval(() => {
      setTimerSeconds(prev => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [timerSeconds, enableTimer, quizFinished, isAnswerSubmitted, questions.length]);

  const currentQuestion = questions[currentIndex];

  const handleSelectOption = (idx: number) => {
    if (isAnswerSubmitted) return;
    setSelectedAnswer(idx);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;
    setIsAnswerSubmitted(true);
    if (selectedAnswer === currentQuestion.correctIndex) {
      setScore(prev => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setIsAnswerSubmitted(false);
      setTimerSeconds(25);
    } else {
      setQuizFinished(true);
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl p-6 sm:p-8 text-[#eaf0f8]">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-white/10">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#e9c978]/15 text-[#e9c978] border border-[#e9c978]/30 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            اختبارات الأحياء التفاعلية
          </div>
          <h3 className="text-xl sm:text-2xl font-bold font-amiri text-white">
            بنك الاختبارات الإلكترونية والوزارية
          </h3>
        </div>

        {/* Filter dropdown */}
        <div className="flex items-center gap-2">
          <select
            value={selectedChapterId}
            onChange={(e) => {
              const val = e.target.value === 'all' ? 'all' : Number(e.target.value);
              setSelectedChapterId(val);
            }}
            className="bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs font-semibold text-gray-200 focus:outline-none focus:border-[#e9c978]"
          >
            <option value="all" className="bg-[#0a1220] text-white">اختبار شامل (جميع الفصول)</option>
            {BIOLOGY_CHAPTERS.map(c => (
              <option key={c.id} value={c.id} className="bg-[#0a1220] text-white">
                الفصل {c.id}: {c.title.substring(0, 24)}...
              </option>
            ))}
          </select>

          <button
            onClick={() => setEnableTimer(!enableTimer)}
            className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1 transition ${
              enableTimer 
                ? 'bg-[#e9c978]/20 border-[#e9c978] text-[#e9c978]' 
                : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
            }`}
            title="تفعيل مؤقت السؤال لمحاكاة الاختبار الوزاري"
          >
            <Clock className="w-4 h-4" />
            <span className="hidden sm:inline">مؤقت</span>
          </button>
        </div>
      </div>

      {/* Quiz Body */}
      {!quizFinished && currentQuestion ? (
        <div className="py-6 space-y-6">
          {/* Progress & timer status */}
          <div className="flex items-center justify-between text-xs text-gray-400">
            <div>
              السؤال <span className="text-[#e9c978] font-bold text-sm">{currentIndex + 1}</span> من {questions.length}
            </div>

            {enableTimer && (
              <div className={`flex items-center gap-1.5 font-mono font-bold ${
                timerSeconds <= 5 ? 'text-red-400 animate-pulse' : 'text-gray-300'
              }`}>
                <Clock className="w-3.5 h-3.5" />
                <span>{timerSeconds} ثانية</span>
              </div>
            )}

            <div>
              الدرجة الحالية: <span className="text-[#0fb98a] font-bold text-sm">{score}</span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-[#c9a24a] to-[#0fb98a] transition-all duration-300 rounded-full"
              style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
            />
          </div>

          {/* Question Text */}
          <div className="p-5 rounded-2xl bg-white/5 border border-white/10">
            <h4 className="text-base sm:text-lg font-bold text-white leading-relaxed">
              {currentQuestion.question}
            </h4>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentQuestion.options.map((opt, oIdx) => {
              let btnClass = "bg-white/5 border-white/10 text-gray-200 hover:bg-white/10";
              
              if (isAnswerSubmitted) {
                if (oIdx === currentQuestion.correctIndex) {
                  btnClass = "bg-[#0fb98a]/20 border-[#0fb98a] text-white font-bold ring-2 ring-[#0fb98a]/40";
                } else if (oIdx === selectedAnswer) {
                  btnClass = "bg-rose-500/20 border-rose-500 text-rose-300";
                } else {
                  btnClass = "opacity-40 bg-white/5 border-white/5 text-gray-400";
                }
              } else if (selectedAnswer === oIdx) {
                btnClass = "bg-[#e9c978]/20 border-[#e9c978] text-white font-bold ring-2 ring-[#e9c978]/40";
              }

              return (
                <button
                  key={oIdx}
                  onClick={() => handleSelectOption(oIdx)}
                  disabled={isAnswerSubmitted}
                  className={`w-full p-4 rounded-xl border text-right transition flex items-center justify-between gap-3 text-sm font-medium ${btnClass}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-black/30 flex items-center justify-center text-xs font-mono font-bold shrink-0 text-gray-300">
                      {String.fromCharCode(65 + oIdx)}
                    </span>
                    <span>{opt}</span>
                  </div>

                  {isAnswerSubmitted && oIdx === currentQuestion.correctIndex && (
                    <CheckCircle2 className="w-5 h-5 text-[#0fb98a] shrink-0" />
                  )}
                  {isAnswerSubmitted && oIdx === selectedAnswer && oIdx !== currentQuestion.correctIndex && (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Box */}
          {isAnswerSubmitted && (
            <div className={`p-4 rounded-2xl border text-xs sm:text-sm space-y-1.5 animate-fadeIn ${
              selectedAnswer === currentQuestion.correctIndex 
                ? 'bg-[#0fb98a]/10 border-[#0fb98a]/30 text-emerald-200' 
                : 'bg-amber-500/10 border-amber-500/30 text-amber-200'
            }`}>
              <div className="font-bold flex items-center gap-2">
                {selectedAnswer === currentQuestion.correctIndex ? (
                  <Check className="w-4 h-4 text-[#0fb98a]" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                )}
                <span>توضيح وتفسير الإجابة:</span>
              </div>
              <p className="text-gray-200 leading-relaxed">
                {currentQuestion.explanation}
              </p>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-2">
            {!isAnswerSubmitted ? (
              <button
                onClick={handleSubmitAnswer}
                disabled={selectedAnswer === null}
                className={`py-3 px-8 rounded-xl font-bold text-sm transition mr-auto ${
                  selectedAnswer === null 
                    ? 'bg-white/10 text-gray-500 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] hover:brightness-110 shadow-lg'
                }`}
              >
                تأكيد الإجابة
              </button>
            ) : (
              <button
                onClick={handleNextQuestion}
                className="py-3 px-8 rounded-xl bg-gradient-to-r from-[#0fb98a] to-[#0d9488] text-white font-bold text-sm hover:brightness-110 shadow-lg transition mr-auto flex items-center gap-2"
              >
                <span>{currentIndex + 1 < questions.length ? 'السؤال التالي ←' : 'عرض النتيجة النهائية 🏆'}</span>
              </button>
            )}
          </div>
        </div>
      ) : quizFinished ? (
        /* Results Screen */
        <div className="py-8 text-center space-y-6">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-tr from-[#c9a24a] to-[#e9c978] text-[#04080f] shadow-2xl mx-auto">
            <Award className="w-10 h-10" />
          </div>

          <div>
            <h4 className="text-2xl sm:text-3xl font-bold font-amiri text-white">
              اكتمل الاختبار بنجاح!
            </h4>
            <p className="text-sm text-gray-300 mt-1">
              إليك نتيجتك التقديرية في مادة الأحياء للسادس العلمي
            </p>
          </div>

          {/* Score Badge */}
          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 max-w-sm mx-auto space-y-2">
            <div className="text-4xl font-black font-amiri text-[#e9c978]">
              {score} / {questions.length}
            </div>
            <div className="text-sm font-semibold text-gray-300">
              النسبة المئوية:{' '}
              <span className="text-[#0fb98a] font-bold">
                {Math.round((score / (questions.length || 1)) * 100)}%
              </span>
            </div>
            <div className="text-xs text-gray-400 pt-2">
              {score / questions.length >= 0.85 
                ? '🌟 مستوى ممتاز جداً! أنت على الطريق الصحيح للدرجة الكاملة (100) بالوزاري.' 
                : score / questions.length >= 0.6 
                ? '👍 مستوى جيد، راجع التعاريف والتعاليل لتعزيز درجتك.' 
                : '⚠️ تحتاج لمراجعة مكثفة للفصول والمفاهيم الأساسية.'}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={loadQuestions}
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#04080f] font-bold text-sm flex items-center gap-2 hover:brightness-110 transition shadow-lg"
            >
              <RotateCcw className="w-4 h-4" />
              إعادة الاختبار
            </button>
            {onClose && (
              <button
                onClick={onClose}
                className="py-3 px-6 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-sm transition"
              >
                إغلاق النافذة
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="py-12 text-center text-gray-400">
          لا توجد أسئلة متوفرة حالياً في هذا القسم.
        </div>
      )}
    </div>
  );
};
