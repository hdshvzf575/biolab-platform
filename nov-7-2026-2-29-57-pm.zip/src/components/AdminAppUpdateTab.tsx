import React, { useState, useEffect } from 'react';
import { 
  RotateCw, 
  Sparkles, 
  CheckCircle2, 
  ArrowDownToLine, 
  Smartphone, 
  FileText, 
  RefreshCw,
  AlertTriangle,
  Globe
} from 'lucide-react';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { publishAppUpdateToCloud } from '../services/firebase';

import { CURRENT_APP_VERSION } from '../utils/versionManager';

interface AdminAppUpdateTabProps {
  showToast: (msg: string) => void;
}

export const AdminAppUpdateTab: React.FC<AdminAppUpdateTabProps> = ({ showToast }) => {
  const [version, setVersion] = useState(CURRENT_APP_VERSION);
  const [title, setTitle] = useState(`تحديث المنصة الأكاديمي الشامل v${CURRENT_APP_VERSION}`);
  const [releaseNotesText, setReleaseNotesText] = useState(
    'نظام المصادقة الرسمي المتكامل (البريد الإلكتروني + تسجيل الدخول بحساب Google)\nمركز إدارة وتحكم سحابي مركزي (Cloud Management Center) متصل مباشرة بـ Firebase وStorage\nنظام موحد لتشغيل الفيديوهات الخارجية ومعالجة الروابط لجميع المزودين\nتحديث جذري لآلية التخزين المؤقت وحل مشكلة عدم ظهور التعديلات في النسخة المثبتة\nتحديث Service Worker التلقائي وإلغاء التخزين القديم لملفات APK\nدعم كامل وسلس لجميع إصدارات أندرويد (Android 7 حتى Android 16)'
  );
  const [forceUpdate, setForceUpdate] = useState(false);
  const [apkUrl, setApkUrl] = useState('/biolab.apk');
  const [isLoading, setIsLoading] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [lastPublishedDate, setLastPublishedDate] = useState<string>('');

  const fetchCurrentUpdate = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/app-update', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.update) {
          setVersion(data.update.version || CURRENT_APP_VERSION);
          setTitle(data.update.title || '');
          if (Array.isArray(data.update.releaseNotes)) {
            setReleaseNotesText(data.update.releaseNotes.join('\n'));
          }
          setForceUpdate(Boolean(data.update.forceUpdate));
          setApkUrl(data.update.apkUrl || '/biolab.apk');
          setLastPublishedDate(data.update.releaseDate || '');
        }
      }
    } catch (e) {
      console.warn('Could not fetch app update info:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCurrentUpdate();
  }, []);

  const handlePublishUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!version.trim() || !title.trim()) {
      showToast('يرجى كتابة رقم الإصدار وعنوان التحديث');
      return;
    }

    setIsPublishing(true);
    playClickSound();

    const notesList = releaseNotesText
      .split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0);

    const updatePayload = {
      version: version.trim(),
      title: title.trim(),
      releaseNotes: notesList,
      forceUpdate,
      apkUrl: apkUrl.trim(),
      releaseDate: new Date().toISOString().split('T')[0]
    };

    const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

    // 1) Write to central Firestore cloud database
    try {
      await publishAppUpdateToCloud(updatePayload);
    } catch (cloudErr) {
      console.warn('Cloud update publish notice:', cloudErr);
    }

    // 2) Write to server API
    try {
      const res = await fetch('/api/app-update', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify(updatePayload)
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playSuccessSound();
        showToast('تم نشر التحديث الجديد بنجاح في قاعدة البيانات المركزية والسيرفر 🚀');
        setLastPublishedDate(new Date().toISOString().split('T')[0]);
      } else {
        showToast(data.error || 'تم حفظ التحديث في قاعدة البيانات السحابية');
      }
    } catch (err) {
      showToast('تم حفظ التحديث في قاعدة البيانات السحابية المركزية');
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn text-right">
      
      {/* Form: Publish App Update */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#0fb98a]/30 shadow-2xl space-y-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2">
              <RotateCw className="w-5 h-5 text-[#0fb98a]" />
              <h3 className="font-amiri font-bold text-2xl text-white">
                إدارة التحديث التلقائي للإضافات من داخل التطبيق
              </h3>
            </div>
            <p className="text-xs text-gray-300 mt-1">
              عند نشر إصدار جديد، يظهر إشعار فوري لجميع الطلاب ومستخدمي APK يدعوهم للتحديث دون فقدان أي بيانات.
            </p>
          </div>

          <button
            onClick={fetchCurrentUpdate}
            className="py-1.5 px-3 rounded-xl bg-white/5 border border-white/10 hover:border-[#0fb98a]/40 text-xs font-bold text-gray-300 hover:text-white flex items-center gap-1.5 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>فحص الحالة</span>
          </button>
        </div>

        {lastPublishedDate && (
          <div className="p-3 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
            <span className="text-gray-400">آخر تحديث منشور لجميع الأجهزة:</span>
            <span className="text-[#0fb98a] font-bold font-mono">
              v{version} · {lastPublishedDate}
            </span>
          </div>
        )}

        <form onSubmit={handlePublishUpdate} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            
            {/* Version Number */}
            <div className="sm:col-span-4 space-y-1.5">
              <label className="block text-xs font-bold text-gray-200">
                رقم الإصدار الجديد (Version)
              </label>
              <input
                type="text"
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                placeholder="مثال: 2.5.0"
                required
                className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#0fb98a] text-[#0fb98a] font-mono font-bold text-sm focus:outline-none"
              />
            </div>

            {/* Release Title */}
            <div className="sm:col-span-8 space-y-1.5">
              <label className="block text-xs font-bold text-gray-200">
                عنوان التحديث الرئيسي
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثال: تحديث المنصة الأكاديمي الشامل"
                required
                className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#0fb98a] text-white text-xs font-bold focus:outline-none"
              />
            </div>

            {/* APK Download URL */}
            <div className="sm:col-span-12 space-y-1.5">
              <label className="block text-xs font-bold text-gray-200">
                رابط ملف APK المباشر للتنزيل الخارجي
              </label>
              <input
                type="text"
                value={apkUrl}
                onChange={(e) => setApkUrl(e.target.value)}
                placeholder="/biolab.apk"
                className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#0fb98a] text-gray-200 font-mono text-xs focus:outline-none"
              />
            </div>

            {/* Release Notes */}
            <div className="sm:col-span-12 space-y-1.5">
              <label className="block text-xs font-bold text-gray-200 flex items-center justify-between">
                <span>ملاحظات الإصدار والإضافات الجديدة (سطر لكل ميزة)</span>
                <span className="text-[10px] text-gray-400">ستظهر كنقاط للمستخدم</span>
              </label>
              <textarea
                value={releaseNotesText}
                onChange={(e) => setReleaseNotesText(e.target.value)}
                rows={5}
                className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#0fb98a] text-gray-200 text-xs leading-relaxed focus:outline-none"
              />
            </div>

            {/* Force Update Checkbox */}
            <div className="sm:col-span-12 pt-1">
              <label className="flex items-center gap-3 p-3 rounded-xl bg-black/40 border border-white/10 cursor-pointer">
                <input
                  type="checkbox"
                  checked={forceUpdate}
                  onChange={(e) => setForceUpdate(e.target.checked)}
                  className="w-4 h-4 rounded text-[#0fb98a] focus:ring-0"
                />
                <div className="text-xs">
                  <span className="font-bold text-white block">إلزام الطلاب بالتحديث الفوري (Force Update)</span>
                  <span className="text-[11px] text-gray-400">عند تفعيله، لن يتمكن الطالب من تخطي التحديث حتى يضغط على زر التحديث.</span>
                </div>
              </label>
            </div>
          </div>

          <button
            type="submit"
            disabled={isPublishing}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#0fb98a] to-[#2dd4bf] text-[#08111e] font-black text-sm shadow-xl hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4 text-[#08111e]" />
            <span>{isPublishing ? 'جاري نشر التحديث عبر السيرفر...' : 'نشر التحديث الجديد لجميع الطلاب 🚀'}</span>
          </button>
        </form>
      </div>

    </div>
  );
};
