import React from 'react';
import { ArrowRight, Home, ChevronLeft, ChevronRight } from 'lucide-react';

interface ScreenHeaderProps {
  title: string;
  subtitle?: string;
  tag?: string;
  currentScreenId?: string;
  onBack: () => void;
  onNavigate?: (screenId: string) => void;
  actionButton?: React.ReactNode;
}

export const ScreenHeader: React.FC<ScreenHeaderProps> = ({
  title,
  subtitle,
  tag,
  currentScreenId,
  onBack,
  onNavigate,
  actionButton
}) => {
  const screensOrder = [
    { id: 'home', label: 'الرئيسية' },
    { id: 'books', label: 'الكتب والملازم' },
    { id: 'lectures', label: 'المحاضرات' },
    { id: 'institute-students', label: 'طلاب المعهد' },
    { id: 'grades', label: 'المراحل' },
    { id: 'lessons', label: 'المنهج' },
    { id: 'institute', label: 'المعهد' },
    { id: 'about', label: 'عن الأستاذ' },
    { id: 'contact', label: 'تواصل' },
  ];

  const currentIndex = screensOrder.findIndex(s => s.id === currentScreenId);
  const prevScreen = currentIndex > 0 ? screensOrder[currentIndex - 1] : null;
  const nextScreen = currentIndex >= 0 && currentIndex < screensOrder.length - 1 ? screensOrder[currentIndex + 1] : null;

  return (
    <div className="w-full pt-20 pb-5 mb-4 border-b border-white/10 bg-gradient-to-b from-white/[0.03] to-transparent">
      <div className="w-[min(1240px,92%)] mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Back Button and Title */}
        <div className="flex items-center gap-3.5">
          <button
            onClick={onBack}
            className="group flex items-center gap-2 py-2 px-3.5 sm:px-4 rounded-2xl bg-white/5 border border-white/10 hover:border-[#e9c978]/50 hover:bg-[#e9c978]/10 text-gray-300 hover:text-[#e9c978] transition-all duration-200 active:scale-95 shadow-sm shrink-0"
            title="الرجوع للرئيسية"
          >
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            <span className="text-xs sm:text-sm font-bold">الرئيسية</span>
          </button>

          <div className="h-6 w-px bg-white/10 shrink-0 hidden sm:block" />

          <div>
            {tag && (
              <span className="inline-block text-[11px] font-bold text-[#e9c978] bg-[#e9c978]/10 px-2.5 py-0.5 rounded-full mb-1 border border-[#e9c978]/20">
                {tag}
              </span>
            )}
            <h1 className="font-amiri font-bold text-2xl sm:text-3xl text-white leading-tight">
              {title}
            </h1>
            {subtitle && (
              <p className="text-xs sm:text-sm text-gray-400 mt-0.5">
                {subtitle}
              </p>
            )}
          </div>
        </div>

        {/* Quick Screen Navigation Controls on Desktop/Tablet */}
        <div className="flex items-center gap-2 self-start md:self-auto flex-wrap">
          {onNavigate && prevScreen && (
            <button
              onClick={() => onNavigate(prevScreen.id)}
              className="py-1.5 px-3 rounded-xl bg-white/5 border border-white/10 hover:border-white/20 text-xs text-gray-300 hover:text-white transition flex items-center gap-1.5"
              title={`الانتقال إلى ${prevScreen.label}`}
            >
              <ChevronRight className="w-3.5 h-3.5" />
              <span>{prevScreen.label}</span>
            </button>
          )}

          {onNavigate && nextScreen && (
            <button
              onClick={() => onNavigate(nextScreen.id)}
              className="py-1.5 px-3 rounded-xl bg-[#e9c978]/15 border border-[#e9c978]/30 hover:bg-[#e9c978]/25 text-xs text-[#e9c978] font-bold transition flex items-center gap-1.5"
              title={`الانتقال إلى ${nextScreen.label}`}
            >
              <span>{nextScreen.label}</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          )}

          {actionButton}
        </div>

      </div>
    </div>
  );
};
