import React from 'react';
import { MapPin, Phone, MessageSquare, ExternalLink } from 'lucide-react';

export const InstituteSection: React.FC = () => {
  return (
    <section id="institute" className="py-24 relative border-t border-white/5 bg-gradient-to-b from-transparent via-[#0fb98a]/5 to-transparent">
      <div className="w-[min(1240px,92%)] mx-auto space-y-12">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full text-xs font-bold text-[#e9c978] bg-[#e9c978]/10 border border-[#e9c978]/25 shadow-sm">
            <span>التقديم والالتحاق</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold font-amiri text-white">
            معهد أنوار السلام
          </h2>
        </div>

        {/* Institute Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Card Info */}
          <div className="lg:col-span-6 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 p-8 sm:p-10 shadow-2xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold bg-[#0fb98a]/20 text-[#0fb98a] border border-[#0fb98a]/35">
                <span>🟢 التسجيل مفتوح الآن</span>
              </div>

              <h3 className="font-amiri font-bold text-3xl sm:text-4xl text-[#e9c978]">
                معهد أنوار السلام
              </h3>

              <p className="text-sm sm:text-base text-gray-300 pb-4 border-b border-dashed border-white/10">
                معهد تعليمي متخصص بإشراف الأستاذ وسام سهيل العامري
              </p>

              <div className="space-y-3 pt-2">
                
                {/* Location */}
                <div className="flex items-start gap-4 p-4 rounded-2xl bg-black/30 border border-white/10">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#e9c978] to-[#c9a24a] text-[#08111e] flex items-center justify-center text-xl shrink-0 shadow-md">
                    📍
                  </div>
                  <div>
                    <strong className="block text-xs text-gray-400 font-semibold mb-0.5">العنوان</strong>
                    <span className="block text-sm sm:text-base font-bold text-white">
                      الحسينية - شارع الشريفي - مقابل أفران أبو شهد
                    </span>
                  </div>
                </div>

                {/* Institute Phone */}
                <div className="flex items-start gap-4 p-4 rounded-2xl bg-black/30 border border-white/10">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#e9c978] to-[#c9a24a] text-[#08111e] flex items-center justify-center text-xl shrink-0 shadow-md">
                    🏫
                  </div>
                  <div>
                    <strong className="block text-xs text-gray-400 font-semibold mb-1">رقم المعهد</strong>
                    <a 
                      href="tel:077037474703" 
                      className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-[#e9c978]/15 border border-[#e9c978]/30 text-[#e9c978] font-black text-base sm:text-lg tracking-wider"
                      dir="ltr"
                    >
                      📞 077037474703
                    </a>
                  </div>
                </div>

                {/* Teacher Phone */}
                <div className="flex items-start gap-4 p-4 rounded-2xl bg-black/30 border border-white/10">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#e9c978] to-[#c9a24a] text-[#08111e] flex items-center justify-center text-xl shrink-0 shadow-md">
                    👨‍🏫
                  </div>
                  <div>
                    <strong className="block text-xs text-gray-400 font-semibold mb-1">رقم الأستاذ</strong>
                    <a 
                      href="tel:07746933500" 
                      className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-[#e9c978]/15 border border-[#e9c978]/30 text-[#e9c978] font-black text-base sm:text-lg tracking-wider"
                      dir="ltr"
                    >
                      📞 07746933500
                    </a>
                  </div>
                </div>

              </div>
            </div>

            {/* Actions */}
            <div className="pt-6">
              <a 
                href="https://wa.me/96477037474703" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-sm sm:text-base shadow-xl hover:brightness-110 transition flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-5 h-5 text-[#08111e]" />
                <span>💬 تواصل عبر واتساب</span>
              </a>
            </div>

          </div>

          {/* Map */}
          <div className="lg:col-span-6 rounded-3xl overflow-hidden border border-[#e9c978]/30 shadow-2xl relative min-h-[420px] bg-[#0a1220] flex flex-col">
            <iframe 
              src="https://maps.google.com/maps?q=33.546204,44.403943&t=&z=16&ie=UTF8&iwloc=&output=embed" 
              allowFullScreen
              loading="lazy"
              className="w-full h-full flex-1 border-0 min-h-[380px]"
              title="موقع معهد أنوار السلام - الأستاذ وسام سهيل العامري"
            />
            
            <div className="p-4 bg-[#04080f]/90 backdrop-blur-md border-t border-white/10 flex items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-200">
                <MapPin className="w-4 h-4 text-[#e9c978]" />
                <span>📍 موقع المعهد على الخريطة الحية</span>
              </div>
              <a 
                href="https://www.google.com/maps?q=33.546204,44.403943" 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs sm:text-sm hover:brightness-110 transition flex items-center gap-1.5 shadow-md"
              >
                <span>الخرائط</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
