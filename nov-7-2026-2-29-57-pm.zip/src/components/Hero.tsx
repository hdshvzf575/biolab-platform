import React from 'react';
import { 
  Video, 
  GraduationCap, 
  BookOpen, 
  Library, 
  Building2, 
  Phone, 
  UserCheck, 
  ArrowLeft,
  Sparkles
} from 'lucide-react';

interface HeroProps {
  onNavigate: (screenId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onNavigate
}) => {
  const hubCards = [
    {
      id: 'institute-students',
      title: 'طلاب المعهد الخاص',
      desc: 'جدول درجات الامتحانات والاختبارات الدورية، والواجبات اليومية لكافة المراحل الدراسية',
      icon: '🎯',
      badge: 'جدول درجات وواجبات',
      color: 'from-[#e9c978]/20 to-[#e9c978]/5',
      borderColor: 'border-[#e9c978]/40 group-hover:border-[#e9c978]',
      btnText: 'دخول قسم طلاب المعهد الخاص'
    },
    {
      id: 'books',
      title: 'الكتب المنهجية والملازم',
      desc: 'الكتب الوزارية الرسمية، الملازم الذهبية، الملخصات وبنوك الأسئلة لجميع المراحل المدرسية',
      icon: '📚',
      badge: 'قراءة وتنزيل مباشر',
      color: 'from-[#0fb98a]/25 to-[#e9c978]/15',
      borderColor: 'border-[#0fb98a]/40 group-hover:border-[#0fb98a]',
      btnText: 'تصفح الكتب والملازم'
    },
    {
      id: 'lectures',
      title: 'المحاضرات المرئية',
      desc: 'المحاضرات المضافة حديثاً من قبل الأستاذ مع ميزة الأكواد السرية VIP',
      icon: '📺',
      badge: 'فيديوهات وشروحات',
      color: 'from-[#0fb98a]/20 to-[#0fb98a]/5',
      borderColor: 'border-[#0fb98a]/30 group-hover:border-[#0fb98a]',
      btnText: 'شاهد المحاضرات'
    },
    {
      id: 'grades',
      title: 'المراحل الدراسية',
      desc: 'اختر مرحلتك الدراسية من الأول المتوسط إلى السادس العلمي',
      icon: '🎓',
      badge: '6 مراحل دراسية',
      color: 'from-[#e9c978]/20 to-[#e9c978]/5',
      borderColor: 'border-[#e9c978]/30 group-hover:border-[#e9c978]',
      btnText: 'اختر مرحلتك'
    },
    {
      id: 'lessons',
      title: 'المنهج الدراسي',
      desc: 'فصول مادة الأحياء لجميع المراحل بالتفصيل مع شروحات مبسّطة',
      icon: '📖',
      badge: '24 فصلاً دراسياً',
      color: 'from-[#3fa9f5]/20 to-[#3fa9f5]/5',
      borderColor: 'border-[#3fa9f5]/30 group-hover:border-[#3fa9f5]',
      btnText: 'تصفح الفصول'
    },
    {
      id: 'institute',
      title: 'معهد أنوار السلام',
      desc: 'العنوان وأرقام الهواتف والتسجيل وخريطة حية للموقع',
      icon: '🏫',
      badge: 'التسجيل مفتوح',
      color: 'from-[#0fb98a]/20 to-[#0fb98a]/5',
      borderColor: 'border-[#0fb98a]/30 group-hover:border-[#0fb98a]',
      btnText: 'تفاصيل المعهد'
    },
    {
      id: 'about',
      title: 'عن الأستاذ',
      desc: 'خبرة تُترجم إلى درجات وشرح مبسّط وملازم وزارية شاملة',
      icon: '👨‍🏫',
      badge: 'المسيرة والخبرة',
      color: 'from-[#e9c978]/20 to-[#e9c978]/5',
      borderColor: 'border-[#e9c978]/30 group-hover:border-[#e9c978]',
      btnText: 'نبذة عن الأستاذ'
    },
    {
      id: 'contact',
      title: 'تواصل معنا',
      desc: 'للاستفسارات والأسئلة عبر واتساب الأستاذ وقناة التلغرام',
      icon: '💬',
      badge: 'دعم وتواصل',
      color: 'from-[#25D366]/20 to-[#25D366]/5',
      borderColor: 'border-[#25D366]/30 group-hover:border-[#25D366]',
      btnText: 'طرق التواصل'
    }
  ];

  return (
    <div className="pt-24 pb-28 space-y-16">
      
      {/* 1) Hero Intro & Cinematic Orbit */}
      <div className="w-[min(1240px,92%)] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Text Content */}
          <div className="lg:col-span-7 text-center lg:text-right space-y-6">
            
            <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full text-xs sm:text-sm font-bold bg-gradient-to-r from-[#0fb98a]/15 to-[#e9c978]/15 border border-[#e9c978]/30 text-[#e9c978] shadow-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-[#0fb98a] shadow-[0_0_12px_#0fb98a] animate-ping" />
              <span>منصة تعليمية إلكترونية · العام الدراسي 2025 - 2026</span>
            </div>

            <h1 className="font-amiri font-bold text-4xl sm:text-6xl lg:text-7xl leading-tight text-white">
              الأستاذ<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#e9c978] via-[#fff3d1] to-[#c9a24a] drop-shadow-sm">
                وسام سهيل العامري
              </span>
            </h1>

            <p className="text-lg sm:text-2xl font-semibold text-white/95">
              مدرّس مادة <b className="text-[#0fb98a]">الأحياء</b> — لجميع المراحل الدراسية
            </p>

            <p className="text-sm sm:text-base text-gray-300 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              منصة متكاملة تجمع المحاضرات، الملازم، والمراجعات المركزة لجميع المراحل. تعلّم الأحياء بأسلوب مبسّط وعميق يوصلك إلى أعلى الدرجات.
            </p>

            {/* Quick Action Navigation Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-2">
              <button
                onClick={() => onNavigate('grades')}
                className="inline-flex items-center gap-2 px-6 sm:px-8 py-3.5 rounded-2xl font-bold text-sm sm:text-base bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-lg shadow-[#c9a24a]/30 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#c9a24a]/40 transition active:scale-95"
              >
                <span>🎓 اختر مرحلتك</span>
              </button>

              <button
                onClick={() => onNavigate('institute-students')}
                className="inline-flex items-center gap-2 px-6 sm:px-7 py-3.5 rounded-2xl font-bold text-sm sm:text-base bg-[#0fb98a]/15 border border-[#0fb98a]/40 text-[#0fb98a] hover:bg-[#0fb98a]/25 hover:-translate-y-1 transition active:scale-95 shadow-md"
              >
                <span>🎯 طلاب المعهد (الدرجات والواجبات)</span>
              </button>

              <button
                onClick={() => onNavigate('lectures')}
                className="inline-flex items-center gap-2 px-6 sm:px-7 py-3.5 rounded-2xl font-bold text-xs sm:text-sm bg-white/5 border border-[#e9c978]/30 text-white hover:border-[#e9c978] hover:bg-white/10 hover:-translate-y-1 transition active:scale-95 shadow-md"
              >
                <span>📺 المحاضرات المرئية</span>
              </button>
            </div>

          </div>

          {/* Visual Biology Orbit */}
          <div className="lg:col-span-5 flex items-center justify-center relative order-first lg:order-last">
            <div className="relative w-64 sm:w-80 aspect-square flex items-center justify-center">
              
              {/* Outer Orbit 1 */}
              <div className="absolute inset-0 rounded-full border border-dashed border-[#e9c978]/25 animate-spin-slow">
                <div className="absolute -top-4 left-1/2 -ml-5 w-10 sm:w-11 h-10 sm:h-11 rounded-2xl bg-[#0a1220]/90 border border-[#e9c978]/40 shadow-xl flex items-center justify-center text-xl animate-spin-reverse">
                  🔬
                </div>
                <div className="absolute -bottom-4 left-1/2 -ml-5 w-10 sm:w-11 h-10 sm:h-11 rounded-2xl bg-[#0a1220]/90 border border-[#e9c978]/40 shadow-xl flex items-center justify-center text-xl animate-spin-reverse">
                  🌿
                </div>
              </div>

              {/* Orbit 2 */}
              <div className="absolute inset-[15%] rounded-full border border-solid border-white/10 animate-spin-reverse">
                <div className="absolute top-1/2 -right-4 -mt-5 w-10 sm:w-11 h-10 sm:h-11 rounded-2xl bg-[#0a1220]/90 border border-[#0fb98a]/40 shadow-xl flex items-center justify-center text-xl animate-spin-slow">
                  🧪
                </div>
                <div className="absolute top-1/2 -left-4 -mt-5 w-10 sm:w-11 h-10 sm:h-11 rounded-2xl bg-[#0a1220]/90 border border-[#0fb98a]/40 shadow-xl flex items-center justify-center text-xl animate-spin-slow">
                  🦠
                </div>
              </div>

              {/* Orbit 3 */}
              <div className="absolute inset-[30%] rounded-full border border-dashed border-[#8b6cf0]/30 animate-spin-slow">
                <div className="absolute -top-4 left-1/2 -ml-4 w-9 h-9 rounded-xl bg-[#0a1220]/90 border border-[#8b6cf0]/40 shadow-xl flex items-center justify-center text-base animate-spin-reverse">
                  🧫
                </div>
                <div className="absolute -bottom-4 left-1/2 -ml-4 w-9 h-9 rounded-xl bg-[#0a1220]/90 border border-[#8b6cf0]/40 shadow-xl flex items-center justify-center text-base animate-spin-reverse">
                  🌱
                </div>
              </div>

              {/* Core Nucleus */}
              <div className="relative w-24 sm:w-32 h-24 sm:h-32 rounded-full bg-gradient-to-tr from-[#c9a24a]/30 via-[#0fb98a]/20 to-transparent border border-[#e9c978]/40 shadow-[0_0_80px_rgba(233,201,120,0.35)] flex items-center justify-center text-5xl animate-pulse-glow">
                🧬
              </div>

            </div>
          </div>

        </div>
      </div>

      {/* 2) Interactive Sections Hub (لوحة الأقسام التفاعلية المستقلة) */}
      <div className="w-[min(1240px,92%)] mx-auto space-y-6 pt-4">
        
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pb-3 border-b border-white/10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-bold bg-[#e9c978]/10 text-[#e9c978] border border-[#e9c978]/25 mb-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>نظام التنقل الذكي</span>
            </div>
            <h2 className="font-amiri font-bold text-2xl sm:text-3xl text-white">
              أقسام المنصة والشاشات المستقلة
            </h2>
            <p className="text-xs sm:text-sm text-gray-400 mt-0.5">
              انتقال فوري وسلس لكل قسم من أقسام المنصة التعليمية
            </p>
          </div>
        </div>

        {/* Hub Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
          {hubCards.map((card) => {
            return (
              <div
                key={card.id}
                onClick={() => onNavigate(card.id)}
                className={`group cursor-pointer rounded-3xl bg-[#0a1220] border ${card.borderColor} p-6 shadow-xl transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl flex flex-col justify-between relative overflow-hidden`}
              >
                {/* Top of card */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-13 h-13 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                      {card.icon}
                    </div>
                    <span className="text-[11px] font-bold text-gray-400 bg-white/5 px-2.5 py-1 rounded-full border border-white/5">
                      {card.badge}
                    </span>
                  </div>

                  <h3 className="font-amiri font-bold text-xl text-white group-hover:text-[#e9c978] transition">
                    {card.title}
                  </h3>

                  <p className="text-xs text-gray-300 leading-relaxed">
                    {card.desc}
                  </p>
                </div>

                {/* Bottom CTA */}
                <div className="pt-4 mt-4 border-t border-white/10 flex items-center justify-between text-xs font-bold text-[#e9c978]">
                  <span>{card.btnText}</span>
                  <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
                </div>
              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
