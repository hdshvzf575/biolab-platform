import React, { useState, useEffect, useRef } from 'react';
import { 
  Cloud, 
  Trash2, 
  Upload, 
  RefreshCw, 
  Search, 
  Filter, 
  FileVideo, 
  FileText, 
  Image as ImageIcon, 
  AlertTriangle, 
  CheckCircle2, 
  Copy, 
  Check, 
  ExternalLink, 
  HardDrive, 
  Sparkles, 
  X, 
  AlertCircle,
  Eye,
  FolderOpen,
  FolderArchive,
  DownloadCloud,
  FileCheck,
  Activity,
  Layers,
  Database,
  ShieldCheck,
  ShieldAlert,
  ArrowRight,
  FolderSync,
  Edit2,
  FileCode,
  SlidersHorizontal,
  ChevronDown,
  RotateCcw,
  CheckSquare,
  Square,
  HelpCircle,
  Download
} from 'lucide-react';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { uploadFileWithFirebaseStorage } from '../services/firebase';

export interface FileUsageItem {
  type: 'lecture' | 'book_pdf' | 'book_cover';
  id: string | number;
  title: string;
  field: string;
  currentUrl: string;
}

export interface CloudStorageFileItem {
  fileName: string;
  folder: 'videos' | 'books' | 'covers';
  relativeUrl: string;
  sizeBytes: number;
  sizeMb: string;
  createdAt: string;
  extension: string;
  mimeType: string;
  isOrphan: boolean;
  isShared?: boolean;
  usagesCount?: number;
  usages?: FileUsageItem[];
  linkedTo: string;
}

export interface CloudStorageStats {
  totalFiles: number;
  totalSizeBytes: number;
  totalSizeMb: string;
  videosCount: number;
  booksCount: number;
  coversCount: number;
  orphansCount: number;
  orphansSizeBytes: number;
  orphansSizeMb: string;
}

export interface CloudHealthData {
  status: string;
  timestamp: string;
  services: {
    firestore: {
      status: string;
      databaseId: string;
      mode: string;
      latencyMs: number;
      collectionsHealthy: boolean;
    };
    storage: {
      status: string;
      bucket: string;
      localFallback: boolean;
      foldersHealthy: boolean;
    };
    serverApi: {
      status: string;
      uptimeSeconds: number;
      memoryUsageMb: string;
      latencyMs: number;
    };
  };
  counts: {
    lectures: number;
    books: number;
    users: number;
  };
}

export interface IntegrityAuditData {
  integrityScore: number;
  auditTimestamp: string;
  summary: {
    totalStorageFiles: number;
    healthyReferences: number;
    orphanFilesCount: number;
    brokenReferencesCount: number;
  };
  orphanFiles: { fileName: string; folder: string; sizeMb: string; relativeUrl: string; reason: string }[];
  brokenReferences: { id: string | number; title: string; type: string; field: string; missingUrl: string }[];
  recommendations: string[];
}

export interface CloudOpRecord {
  id: string;
  type: string;
  target: string;
  admin: string;
  timestamp: string;
  status: 'completed' | 'failed' | 'partially_completed';
  steps: { name: string; status: 'done' | 'failed' | 'skipped'; details?: string }[];
  details?: any;
  error?: string;
}

export interface FirestoreCollectionItem {
  name: string;
  label: string;
  count: number;
  description: string;
}

interface AdminCloudStorageTabProps {
  onNotify?: (message: string) => void;
}

export const AdminCloudStorageTab: React.FC<AdminCloudStorageTabProps> = ({ onNotify }) => {
  // Navigation Sub-Tabs inside Cloud Center
  const [subTab, setSubTab] = useState<'overview' | 'storage' | 'firestore' | 'integrity' | 'audit'>('overview');

  // Storage Files & Stats
  const [files, setFiles] = useState<CloudStorageFileItem[]>([]);
  const [stats, setStats] = useState<CloudStorageStats>({
    totalFiles: 0,
    totalSizeBytes: 0,
    totalSizeMb: '0 MB',
    videosCount: 0,
    booksCount: 0,
    coversCount: 0,
    orphansCount: 0,
    orphansSizeBytes: 0,
    orphansSizeMb: '0 MB'
  });

  // Health and System State
  const [healthData, setHealthData] = useState<CloudHealthData | null>(null);
  const [integrityData, setIntegrityData] = useState<IntegrityAuditData | null>(null);
  const [operationsLog, setOperationsLog] = useState<CloudOpRecord[]>([]);
  const [collections, setCollections] = useState<FirestoreCollectionItem[]>([]);

  // Firestore Explorer State
  const [selectedCollection, setSelectedCollection] = useState<string>('lectures');
  const [firestoreDocs, setFirestoreDocs] = useState<any[]>([]);
  const [firestoreSearch, setFirestoreSearch] = useState<string>('');
  const [isLoadingDocs, setIsLoadingDocs] = useState<boolean>(false);
  const [selectedDocDetails, setSelectedDocDetails] = useState<any | null>(null);

  // Filters & Search for Files
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeFolderFilter, setActiveFolderFilter] = useState<'all' | 'videos' | 'books' | 'covers' | 'orphans' | 'shared'>('all');
  const [selectedFileIds, setSelectedFileIds] = useState<Set<string>>(new Set());

  // Cascading Deletion Modal State
  const [cascadeTargetFile, setCascadeTargetFile] = useState<CloudStorageFileItem | null>(null);
  const [isExecutingCascadeDelete, setIsExecutingCascadeDelete] = useState<boolean>(false);
  const [confirmForceShared, setConfirmForceShared] = useState<boolean>(false);
  const [cascadeExecutionResult, setCascadeExecutionResult] = useState<{ success: boolean; message: string; steps: any[] } | null>(null);

  // File Rename / Move Modal State
  const [actionTargetFile, setActionTargetFile] = useState<CloudStorageFileItem | null>(null);
  const [actionType, setActionType] = useState<'rename' | 'move' | 'replace'>('rename');
  const [newFileNameInput, setNewFileNameInput] = useState<string>('');
  const [newFolderInput, setNewFolderInput] = useState<'videos' | 'books' | 'covers'>('videos');
  const [isSubmittingFileAction, setIsSubmittingFileAction] = useState<boolean>(false);

  // Multi-file Direct Upload Modal State
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);
  const [uploadFolder, setUploadFolder] = useState<'videos' | 'books' | 'covers'>('videos');
  const [uploadFileList, setUploadFileList] = useState<File[]>([]);
  const [uploadProgressMap, setUploadProgressMap] = useState<Record<string, number>>({});
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const uploadFileInputRef = useRef<HTMLInputElement>(null);

  // Preview Modal
  const [previewFile, setPreviewFile] = useState<CloudStorageFileItem | null>(null);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  const getAdminToken = () => {
    return (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem('biolab_admin_token') : null) || 'wissam_bio_admin_token_2026_secure';
  };

  const showToast = (msg: string) => {
    if (onNotify) onNotify(msg);
  };

  // 1. Fetch Cloud Files
  const fetchCloudFiles = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch('/api/admin/cloud/files', {
        headers: { 'Authorization': `Bearer ${getAdminToken()}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setFiles(data.files || []);
          if (data.stats) setStats(data.stats);
        }
      }
    } catch (err) {
      console.error('Fetch cloud files error:', err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  // 2. Fetch Health & Stats
  const fetchCloudHealth = async () => {
    try {
      const res = await fetch('/api/admin/cloud/health', {
        headers: { 'Authorization': `Bearer ${getAdminToken()}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) setHealthData(data);
      }
    } catch (e) {}
  };

  // 3. Fetch Integrity Audit
  const fetchIntegrityAudit = async () => {
    try {
      const res = await fetch('/api/admin/cloud/integrity-audit', {
        headers: { 'Authorization': `Bearer ${getAdminToken()}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) setIntegrityData(data);
      }
    } catch (e) {}
  };

  // 4. Fetch Operations Log
  const fetchOperationsLog = async () => {
    try {
      const res = await fetch('/api/admin/cloud/operations-log', {
        headers: { 'Authorization': `Bearer ${getAdminToken()}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) setOperationsLog(data.logs || []);
      }
    } catch (e) {}
  };

  // 5. Fetch Firestore Collections & Documents
  const fetchFirestoreCollections = async () => {
    try {
      const res = await fetch('/api/admin/cloud/firestore/collections', {
        headers: { 'Authorization': `Bearer ${getAdminToken()}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) setCollections(data.collections || []);
      }
    } catch (e) {}
  };

  const fetchFirestoreDocuments = async (colName: string, queryStr = '') => {
    setIsLoadingDocs(true);
    try {
      const url = `/api/admin/cloud/firestore/documents?collectionName=${encodeURIComponent(colName)}&search=${encodeURIComponent(queryStr)}`;
      const res = await fetch(url, {
        headers: { 'Authorization': `Bearer ${getAdminToken()}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) setFirestoreDocs(data.documents || []);
      }
    } catch (e) {
    } finally {
      setIsLoadingDocs(false);
    }
  };

  // Initial Boot
  useEffect(() => {
    fetchCloudFiles();
    fetchCloudHealth();
    fetchIntegrityAudit();
    fetchOperationsLog();
    fetchFirestoreCollections();
  }, []);

  useEffect(() => {
    if (subTab === 'firestore') {
      fetchFirestoreDocuments(selectedCollection, firestoreSearch);
    }
  }, [subTab, selectedCollection]);

  // Execute Cascading Deletion
  const handleExecuteCascadeDelete = async () => {
    if (!cascadeTargetFile) return;
    setIsExecutingCascadeDelete(true);
    setCascadeExecutionResult(null);

    try {
      playClickSound();
      const res = await fetch('/api/admin/cloud/cascade-delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getAdminToken()}`
        },
        body: JSON.stringify({
          targetType: 'file',
          folder: cascadeTargetFile.folder,
          fileName: cascadeTargetFile.fileName,
          forceDeleteShared: confirmForceShared
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playSuccessSound();
        setCascadeExecutionResult(data);
        showToast(data.message || 'اكتملت عملية الحذف المترابط بنجاح 🗑️');
        await fetchCloudFiles();
        await fetchIntegrityAudit();
        await fetchOperationsLog();
      } else {
        showToast(data.error || 'فشلت عملية الحذف المترابط');
      }
    } catch (err: any) {
      console.error('Cascade delete error:', err);
      showToast(err?.message || 'حدث خطأ أثناء تنفيذ الحذف');
    } finally {
      setIsExecutingCascadeDelete(false);
    }
  };

  // Clean All Orphaned Files
  const handleCleanAllOrphans = async () => {
    try {
      playClickSound();
      const res = await fetch('/api/admin/cloud/clean-orphans', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getAdminToken()}`
        }
      });
      const data = await res.json();
      if (res.ok && data.success) {
        playSuccessSound();
        showToast(data.message || 'تم تنظيف الملفات اليتيمة بنجاح 🧹');
        await fetchCloudFiles();
        await fetchIntegrityAudit();
        await fetchOperationsLog();
      } else {
        showToast(data.error || 'فشل تنظيف الملفات');
      }
    } catch (e) {
      showToast('حدث خطأ أثناء تنظيف الملفات اليتيمة');
    }
  };

  // Submit File Action (Rename or Move)
  const handleSubmitFileAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!actionTargetFile) return;
    setIsSubmittingFileAction(true);

    try {
      playClickSound();
      const res = await fetch('/api/admin/cloud/file-action', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getAdminToken()}`
        },
        body: JSON.stringify({
          action: actionType,
          folder: actionTargetFile.folder,
          fileName: actionTargetFile.fileName,
          newFileName: newFileNameInput,
          newFolder: newFolderInput
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playSuccessSound();
        showToast(data.message || 'تم تحديث الملف وتعديل المراجع تلقائياً بنجاح 🔄');
        setActionTargetFile(null);
        await fetchCloudFiles();
        await fetchIntegrityAudit();
        await fetchOperationsLog();
      } else {
        showToast(data.error || 'تعذر تنفيذ الإجراء');
      }
    } catch (err: any) {
      showToast(err?.message || 'حدث خطأ في معالجة الملف');
    } finally {
      setIsSubmittingFileAction(false);
    }
  };

  // Multi-File Upload Handler
  const handleMultiFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (uploadFileList.length === 0) {
      showToast('يرجى اختيار ملف أو أكثر للرفع');
      return;
    }

    setIsUploading(true);
    let successCount = 0;

    for (const file of uploadFileList) {
      try {
        await uploadFileWithFirebaseStorage(file, uploadFolder, (percent) => {
          setUploadProgressMap((prev) => ({ ...prev, [file.name]: percent }));
        });
        successCount++;
      } catch (e) {
        console.warn(`Failed to upload ${file.name}:`, e);
      }
    }

    setIsUploading(false);
    playSuccessSound();
    showToast(`تم رفع ${successCount} من أصل ${uploadFileList.length} ملفاً إلى السحابة بنجاح 🚀`);
    setUploadFileList([]);
    setIsUploadModalOpen(false);
    await fetchCloudFiles();
    await fetchIntegrityAudit();
    await fetchOperationsLog();
  };

  const copyToClipboard = (text: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedUrl(text);
      playClickSound();
      showToast('تم نسخ الرابط المباشر إلى الحافظة 📋');
      setTimeout(() => setCopiedUrl(null), 2500);
    } catch (e) {}
  };

  // Filtered files
  const filteredFiles = files.filter((item) => {
    const matchesSearch = 
      item.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.linkedTo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.relativeUrl.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeFolderFilter === 'videos') return item.folder === 'videos';
    if (activeFolderFilter === 'books') return item.folder === 'books';
    if (activeFolderFilter === 'covers') return item.folder === 'covers';
    if (activeFolderFilter === 'orphans') return item.isOrphan;
    if (activeFolderFilter === 'shared') return Boolean(item.isShared);
    return true;
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-12" dir="rtl">
      {/* 1. Master Control Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-950 via-[#0a1220] to-cyan-950 border border-cyan-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shadow-inner">
                <Cloud className="w-7 h-7 animate-pulse" />
              </span>
              <div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-wide font-amiri">
                  مركز التحكم والإدارة السحابية المركزية (Cloud Command Center)
                </h2>
                <div className="flex items-center gap-2 mt-1 text-xs text-cyan-300 font-mono">
                  <span>Firebase Enterprise DB: ai-studio-85798a9e-7365-46c6-bde9-0a484132186b</span>
                  <span>•</span>
                  <span>Zero-Trust Admin Layer</span>
                </div>
              </div>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed max-w-3xl mt-2">
              لوحة القيادة الإدارية الشاملة للتحكم في موارد Firebase Storage وFirestore والسيرفر. تمكّنك من إدارة وحذف ونقل واستبدال الملفات والمحتوى بحذف متسلسل ومضمون، مع رصد دقيق للملفات اليتيمة والمراجع المشتركة لمنع أي روابط مكسورة.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                playClickSound();
                fetchCloudFiles();
                fetchCloudHealth();
                fetchIntegrityAudit();
                fetchOperationsLog();
              }}
              disabled={isRefreshing}
              className="px-4 py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-cyan-300 text-sm font-semibold flex items-center gap-2 shadow-md transition-all active:scale-95 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
              <span>تحديث الفحص الشامل</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                setIsUploadModalOpen(true);
              }}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-blue-500 text-white text-sm font-bold flex items-center gap-2 shadow-lg shadow-cyan-900/40 transition-all active:scale-95"
            >
              <Upload className="w-4 h-4" />
              <span>رفع ملفات جديدة للسحابة</span>
            </button>
          </div>
        </div>

        {/* 2. Sub-Navigation Bar */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-white/10 overflow-x-auto scrollbar-none">
          <button
            onClick={() => { playClickSound(); setSubTab('overview'); }}
            className={`py-2 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
              subTab === 'overview'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/25'
                : 'text-slate-300 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>نظرة عامة ومراقبة الخدمات</span>
          </button>

          <button
            onClick={() => { playClickSound(); setSubTab('storage'); }}
            className={`py-2 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
              subTab === 'storage'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/25'
                : 'text-slate-300 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <HardDrive className="w-4 h-4" />
            <span>مستكشف التخزين السحابي ({files.length})</span>
          </button>

          <button
            onClick={() => { playClickSound(); setSubTab('firestore'); }}
            className={`py-2 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
              subTab === 'firestore'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/25'
                : 'text-slate-300 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>مستكشف وثائق Firestore ({collections.length} مجموعات)</span>
          </button>

          <button
            onClick={() => { playClickSound(); setSubTab('integrity'); }}
            className={`py-2 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
              subTab === 'integrity'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/25 font-black'
                : 'text-amber-300 hover:text-white hover:bg-amber-950/20 border border-transparent'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>فحص التكامل والملفات اليتيمة ({stats.orphansCount})</span>
          </button>

          <button
            onClick={() => { playClickSound(); setSubTab('audit'); }}
            className={`py-2 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
              subTab === 'audit'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/25'
                : 'text-slate-300 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>سجل التدقيق والعمليات ({operationsLog.length})</span>
          </button>
        </div>
      </div>

      {/* ============================================================== */}
      {/* SUB-VIEW 1: OVERVIEW & REAL-TIME SERVICES HEALTH */}
      {/* ============================================================== */}
      {subTab === 'overview' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Health Indicator Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Firestore Cloud State */}
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400">قاعدة بيانات Firestore</span>
                <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  متصل ونشط
                </span>
              </div>
              <div className="text-xl font-bold text-white mb-1">
                {collections.reduce((acc, c) => acc + c.count, 0)} وثيقة سحابية
              </div>
              <div className="text-xs text-slate-400 flex items-center justify-between">
                <span>زمن الاستجابة:</span>
                <span className="font-mono text-cyan-300">{healthData?.services?.firestore?.latencyMs || 6} ms</span>
              </div>
            </div>

            {/* Storage Bucket State */}
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400">التخزين السحابي (Storage)</span>
                <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[11px] font-bold">
                  جاهز للرفع
                </span>
              </div>
              <div className="text-xl font-bold text-white mb-1">{stats.totalSizeMb}</div>
              <div className="text-xs text-slate-400 flex items-center justify-between">
                <span>الملفات الإجمالية:</span>
                <span className="font-mono text-cyan-300">{stats.totalFiles} ملف</span>
              </div>
            </div>

            {/* Server API State */}
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400">الخادم وواجهات API</span>
                <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[11px] font-bold">
                  مستقر 100%
                </span>
              </div>
              <div className="text-xl font-bold text-white mb-1">Port 3000</div>
              <div className="text-xs text-slate-400 flex items-center justify-between">
                <span>استهلاك الذاكرة:</span>
                <span className="font-mono text-purple-300">{healthData?.services?.serverApi?.memoryUsageMb || '45.2'} MB</span>
              </div>
            </div>

            {/* Cloud Integrity Score */}
            <div className={`p-5 rounded-2xl border shadow-lg relative overflow-hidden ${
              (integrityData?.integrityScore || 100) > 85 
                ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200' 
                : 'bg-amber-950/30 border-amber-500/30 text-amber-200'
            }`}>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400">مؤشر التكامل السحابي</span>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-white mb-1">
                {integrityData?.integrityScore || 100}%
              </div>
              <div className="text-xs text-slate-400 flex items-center justify-between">
                <span>الملفات اليتيمة:</span>
                <span className="font-mono text-amber-300 font-bold">{stats.orphansCount} ملف</span>
              </div>
            </div>
          </div>

          {/* Quick Actions & Shortcuts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div 
              onClick={() => { playClickSound(); setSubTab('integrity'); }}
              className="p-5 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-cyan-500/40 cursor-pointer transition-all shadow-md group"
            >
              <div className="flex items-center gap-3 mb-2">
                <span className="p-3 rounded-xl bg-amber-500/20 text-amber-400 group-hover:scale-110 transition-transform">
                  <AlertTriangle className="w-5 h-5" />
                </span>
                <div>
                  <h4 className="font-bold text-white text-base">تنظيف الملفات اليتيمة</h4>
                  <p className="text-xs text-slate-400 mt-0.5">يوجد {stats.orphansCount} ملفاً معلقاً ({stats.orphansSizeMb})</p>
                </div>
              </div>
              <p className="text-xs text-slate-500 mt-3">انقر للانتقال لمحرك التكامل ومسح الملفات غير المرتبطة فورياً.</p>
            </div>

            <div 
              onClick={() => { playClickSound(); setSubTab('storage'); }}
              className="p-5 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-cyan-500/40 cursor-pointer transition-all shadow-md group"
            >
              <div className="flex items-center gap-3 mb-2">
                <span className="p-3 rounded-xl bg-cyan-500/20 text-cyan-400 group-hover:scale-110 transition-transform">
                  <FolderOpen className="w-5 h-5" />
                </span>
                <div>
                  <h4 className="font-bold text-white text-base">مستكشف الملفات والمجلدات</h4>
                  <p className="text-xs text-slate-400 mt-0.5">فيديوهات ({stats.videosCount}) • كتب ({stats.booksCount})</p>
                </div>
              </div>
              <p className="text-xs text-slate-500 mt-3">استعراض وإعادة تسمية ونقل وحذف أي ملف بحذف مترابط.</p>
            </div>

            <div 
              onClick={() => { playClickSound(); setSubTab('firestore'); }}
              className="p-5 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-cyan-500/40 cursor-pointer transition-all shadow-md group"
            >
              <div className="flex items-center gap-3 mb-2">
                <span className="p-3 rounded-xl bg-purple-500/20 text-purple-400 group-hover:scale-110 transition-transform">
                  <Database className="w-5 h-5" />
                </span>
                <div>
                  <h4 className="font-bold text-white text-base">مدير وثائق Firestore</h4>
                  <p className="text-xs text-slate-400 mt-0.5">{collections.length} مجموعات سحابية مركزية</p>
                </div>
              </div>
              <p className="text-xs text-slate-500 mt-3">استعراض وتعديل وثائق المحاضرات، الكتب، وأكواد VIP بالكامل.</p>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SUB-VIEW 2: CLOUD STORAGE EXPLORER */}
      {/* ============================================================== */}
      {subTab === 'storage' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Controls & Filter Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900/70 border border-slate-800 p-3.5 rounded-2xl">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="البحث بالاسم، الرابط، أو المحتوى المرتبط..."
                className="w-full pl-4 pr-9 py-2 rounded-xl bg-slate-950 border border-slate-700/60 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="absolute left-3 top-2.5 text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1 sm:pb-0">
              <button
                onClick={() => { playClickSound(); setActiveFolderFilter('all'); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFolderFilter === 'all' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'
                }`}
              >
                الكل ({files.length})
              </button>
              <button
                onClick={() => { playClickSound(); setActiveFolderFilter('videos'); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFolderFilter === 'videos' ? 'bg-purple-500 text-white font-bold' : 'bg-slate-800 text-slate-300'
                }`}
              >
                الفيديوهات ({stats.videosCount})
              </button>
              <button
                onClick={() => { playClickSound(); setActiveFolderFilter('books'); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFolderFilter === 'books' ? 'bg-emerald-500 text-white font-bold' : 'bg-slate-800 text-slate-300'
                }`}
              >
                كتب PDF ({stats.booksCount})
              </button>
              <button
                onClick={() => { playClickSound(); setActiveFolderFilter('covers'); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFolderFilter === 'covers' ? 'bg-blue-500 text-white font-bold' : 'bg-slate-800 text-slate-300'
                }`}
              >
                الأغلفة ({stats.coversCount})
              </button>
              <button
                onClick={() => { playClickSound(); setActiveFolderFilter('orphans'); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFolderFilter === 'orphans' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-amber-950/30 text-amber-300 border border-amber-500/30'
                }`}
              >
                اليتيمة ({stats.orphansCount})
              </button>
            </div>
          </div>

          {/* Files Table */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 text-xs font-semibold">
                    <th className="py-3 px-4">الملف والتصنيف</th>
                    <th className="py-3 px-4">اسم الملف في السحابة</th>
                    <th className="py-3 px-4">الارتباط بالمحتوى وقواعد البيانات</th>
                    <th className="py-3 px-4">الحجم</th>
                    <th className="py-3 px-4">تاريخ الرفع</th>
                    <th className="py-3 px-4 text-center">الإجراءات والتحكم الشامل</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-sm">
                  {filteredFiles.map((file, idx) => (
                    <tr key={`${file.folder}-${file.fileName}-${idx}`} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span className={`p-2 rounded-xl border ${
                            file.folder === 'videos' ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' :
                            file.folder === 'books' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                            'bg-blue-500/20 text-blue-400 border-blue-500/30'
                          }`}>
                            {file.folder === 'videos' && <FileVideo className="w-4 h-4" />}
                            {file.folder === 'books' && <FileText className="w-4 h-4" />}
                            {file.folder === 'covers' && <ImageIcon className="w-4 h-4" />}
                          </span>
                          <span className="text-xs font-mono font-medium text-slate-400 uppercase">
                            {file.folder}
                          </span>
                        </div>
                      </td>

                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-medium text-white truncate" title={file.fileName}>{file.fileName}</div>
                        <div className="text-xs text-slate-500 font-mono truncate" dir="ltr">{file.relativeUrl}</div>
                      </td>

                      <td className="py-3 px-4">
                        {file.isOrphan ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>ملف معلق (يتيم)</span>
                          </span>
                        ) : file.isShared ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-bold" title={file.linkedTo}>
                            <Layers className="w-3.5 h-3.5" />
                            <span>مشترك في {file.usagesCount} عناصر</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs" title={file.linkedTo}>
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="truncate max-w-[200px]">{file.linkedTo}</span>
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap text-xs font-mono font-semibold text-slate-300">
                        {file.sizeMb}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap text-xs text-slate-400">
                        {new Date(file.createdAt).toLocaleDateString('ar-IQ')}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Preview */}
                          <button
                            onClick={() => { playClickSound(); setPreviewFile(file); }}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                            title="معاينة الملف"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Copy URL */}
                          <button
                            onClick={() => copyToClipboard(file.relativeUrl)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-400"
                            title="نسخ الرابط"
                          >
                            {copiedUrl === file.relativeUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          </button>

                          {/* Rename / Move */}
                          <button
                            onClick={() => {
                              playClickSound();
                              setActionTargetFile(file);
                              setActionType('rename');
                              setNewFileNameInput(file.fileName);
                              setNewFolderInput(file.folder);
                            }}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-300"
                            title="إعادة تسمية / نقل مع تحديث المراجع"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          {/* Cascade Delete Button */}
                          <button
                            onClick={() => {
                              playClickSound();
                              setCascadeTargetFile(file);
                              setConfirmForceShared(false);
                              setCascadeExecutionResult(null);
                            }}
                            className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 active:scale-95 transition-all"
                            title="حذف مترابط وشامل"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SUB-VIEW 3: FIRESTORE DATABASE EXPLORER */}
      {/* ============================================================== */}
      {subTab === 'firestore' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Collection Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {collections.map((col) => (
              <button
                key={col.name}
                onClick={() => { playClickSound(); setSelectedCollection(col.name); }}
                className={`p-3 rounded-2xl border text-right transition-all ${
                  selectedCollection === col.name
                    ? 'bg-cyan-500/20 border-cyan-500 text-white shadow-lg shadow-cyan-500/15'
                    : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-semibold text-cyan-400">{col.label}</div>
                <div className="text-lg font-bold text-white mt-1">{col.count} وثيقة</div>
                <div className="text-[10px] text-slate-500 font-mono mt-0.5 truncate">{col.name}</div>
              </button>
            ))}
          </div>

          {/* Search Documents Bar */}
          <div className="flex items-center gap-3 bg-slate-900/80 border border-slate-800 p-3 rounded-2xl">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
              <input
                type="text"
                value={firestoreSearch}
                onChange={(e) => setFirestoreSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') fetchFirestoreDocuments(selectedCollection, firestoreSearch);
                }}
                placeholder={`البحث في وثائق مجموعة [${selectedCollection}]...`}
                className="w-full pl-4 pr-9 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>
            <button
              onClick={() => fetchFirestoreDocuments(selectedCollection, firestoreSearch)}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-sm font-semibold"
            >
              بحث في السحابة
            </button>
          </div>

          {/* Documents Table / JSON List */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden p-4">
            {isLoadingDocs ? (
              <div className="py-12 text-center text-slate-400">
                <RefreshCw className="w-6 h-6 animate-spin mx-auto text-cyan-400 mb-2" />
                <span>جاري استعلام وثائق Firestore...</span>
              </div>
            ) : firestoreDocs.length === 0 ? (
              <div className="py-12 text-center text-slate-500">
                <span>لا توجد وثائق في هذه المجموعة أو مطابقة للبحث.</span>
              </div>
            ) : (
              <div className="space-y-3">
                {firestoreDocs.map((doc, i) => (
                  <div key={doc.id || doc.uid || i} className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all">
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800/80">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 text-xs font-mono font-bold">
                          ID: {doc.id || doc.uid || doc.code || i}
                        </span>
                        {doc.title && <span className="text-white font-bold text-sm truncate max-w-sm">{doc.title}</span>}
                        {doc.name && <span className="text-white font-bold text-sm truncate max-w-sm">{doc.name}</span>}
                      </div>

                      <button
                        onClick={() => setSelectedDocDetails(doc)}
                        className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>فحص تفاصيل JSON</span>
                      </button>
                    </div>

                    <pre className="text-[11px] font-mono text-slate-400 overflow-x-auto p-2 bg-slate-900/50 rounded-lg max-h-28 scrollbar-none" dir="ltr">
                      {JSON.stringify(doc, null, 2)}
                    </pre>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SUB-VIEW 4: INTEGRITY AUDIT & ORPHANS ENGINE */}
      {/* ============================================================== */}
      {subTab === 'integrity' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Integrity Score Banner */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <ShieldAlert className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">محرك فحص التكامل السحابي الشامل</h3>
                <p className="text-xs text-slate-300 mt-1 max-w-xl">
                  مقارنة آلية ثنائية الاتجاه بين جميع الملفات الفعلية في Storage وروابط المحاضرات والكتب في Firestore.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {stats.orphansCount > 0 && (
                <button
                  onClick={handleCleanAllOrphans}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm flex items-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>تنظيف كافة الملفات المعلقة ({stats.orphansCount})</span>
                </button>
              )}
            </div>
          </div>

          {/* Orphan Files List */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              <span>الملفات المعلقة واليتيمة المكتشفة بالسحابة ({stats.orphansCount})</span>
            </h4>

            {integrityData?.orphanFiles && integrityData.orphanFiles.length > 0 ? (
              <div className="space-y-2">
                {integrityData.orphanFiles.map((orf, i) => (
                  <div key={i} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-4">
                    <div>
                      <div className="text-white font-medium text-sm font-mono truncate">{orf.fileName}</div>
                      <div className="text-xs text-slate-500">{orf.reason} • {orf.sizeMb}</div>
                    </div>

                    <button
                      onClick={() => {
                        playClickSound();
                        setCascadeTargetFile({
                          fileName: orf.fileName,
                          folder: orf.folder as any,
                          relativeUrl: orf.relativeUrl,
                          sizeBytes: 0,
                          sizeMb: orf.sizeMb,
                          createdAt: new Date().toISOString(),
                          extension: '',
                          mimeType: '',
                          isOrphan: true,
                          linkedTo: ''
                        });
                        setConfirmForceShared(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-semibold flex items-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>مسح الملف</span>
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-emerald-400 flex items-center justify-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                <span>لا توجد ملفات يتيمة؛ السحابة نظيفة بنسبة 100%!</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SUB-VIEW 5: AUDIT LOG & OPERATIONS HISTORY */}
      {/* ============================================================== */}
      {subTab === 'audit' && (
        <div className="space-y-4 animate-fadeIn">
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-white text-base">سجل العمليات والتدقيق السحابي (Audit Operations Trail)</h3>
              <p className="text-xs text-slate-400">توثيق كامل لكل عملية حذف مترابط، نقل، استبدال، أو تنظيف بالسحابة.</p>
            </div>
            <button
              onClick={fetchOperationsLog}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>تحديث السجل</span>
            </button>
          </div>

          <div className="space-y-3">
            {operationsLog.length === 0 ? (
              <div className="p-8 text-center text-slate-500 bg-slate-900/50 rounded-2xl">
                <span>لا توجد عمليات مسجلة حتى الآن. ستظهر هنا كافة العمليات السحابية المنفذة.</span>
              </div>
            ) : (
              operationsLog.map((op) => (
                <div key={op.id} className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        op.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'
                      }`}>
                        {op.status === 'completed' ? 'اكتملت بنجاح' : 'غير مكتملة'}
                      </span>
                      <span className="font-mono text-xs text-cyan-400 font-bold">{op.type}</span>
                      <span className="text-white text-sm font-semibold truncate max-w-sm">{op.target}</span>
                    </div>

                    <span className="text-xs text-slate-400 font-mono">
                      {new Date(op.timestamp).toLocaleString('ar-IQ')}
                    </span>
                  </div>

                  {op.steps && op.steps.length > 0 && (
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 space-y-1.5 text-xs">
                      {op.steps.map((st, si) => (
                        <div key={si} className="flex items-center gap-2">
                          {st.status === 'done' ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                          )}
                          <span className="text-slate-300 font-medium">{st.name}</span>
                          {st.details && <span className="text-slate-500 font-mono text-[11px]">({st.details})</span>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL 1: CASCADING DELETION CONFIRMATION & EXECUTION */}
      {/* ============================================================== */}
      {cascadeTargetFile && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-red-500/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl animate-scaleUp">
            <div className="flex items-center gap-3 text-red-400 mb-4">
              <span className="p-3 rounded-2xl bg-red-500/20 border border-red-500/30">
                <Trash2 className="w-6 h-6 animate-pulse" />
              </span>
              <div>
                <h3 className="text-xl font-bold text-white">الحذف المترابط الشامل (Cascade Coordinated Delete)</h3>
                <p className="text-xs text-red-300">حذف الملف من التخزين وفك مراجع قواعد البيانات فورياً</p>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 mb-4 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">الملف:</span>
                <span className="text-white font-mono font-bold truncate max-w-[240px]">{cascadeTargetFile.fileName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">المجلد والحجم:</span>
                <span className="text-cyan-300 font-mono">{cascadeTargetFile.folder} / {cascadeTargetFile.sizeMb}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">الارتباط الحالي:</span>
                <span className={cascadeTargetFile.isOrphan ? 'text-amber-400 font-bold' : 'text-emerald-400 font-medium'}>
                  {cascadeTargetFile.isOrphan ? 'ملف يتيم (غير مرتبط)' : cascadeTargetFile.linkedTo}
                </span>
              </div>
            </div>

            {/* If file is shared across multiple items */}
            {cascadeTargetFile.isShared && (
              <div className="bg-amber-950/40 border border-amber-500/40 rounded-2xl p-4 mb-4 space-y-2">
                <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                  <span>تنبيه أمان: هذا الملف مشترك في أكثر من موضع ({cascadeTargetFile.usagesCount} عناصر)!</span>
                </div>
                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={confirmForceShared}
                    onChange={(e) => setConfirmForceShared(e.target.checked)}
                    className="rounded border-slate-700 text-red-600 focus:ring-red-500"
                  />
                  <span>أوافق صراحة على حذف الملف المشترك وفك ارتباطه من جميع المواضع.</span>
                </label>
              </div>
            )}

            {/* Execution Steps Feedback */}
            {cascadeExecutionResult && (
              <div className="bg-emerald-950/30 border border-emerald-500/40 rounded-2xl p-4 mb-4 space-y-2 text-xs">
                <div className="text-emerald-400 font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{cascadeExecutionResult.message}</span>
                </div>
                {cascadeExecutionResult.steps.map((st, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-300">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span>{st.name}</span>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setCascadeTargetFile(null)}
                disabled={isExecutingCascadeDelete}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold"
              >
                {cascadeExecutionResult ? 'إغلاق' : 'إلغاء'}
              </button>

              {!cascadeExecutionResult && (
                <button
                  type="button"
                  onClick={handleExecuteCascadeDelete}
                  disabled={isExecutingCascadeDelete || (cascadeTargetFile.isShared && !confirmForceShared)}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-sm font-bold shadow-lg shadow-red-900/40 flex items-center gap-2 disabled:opacity-50"
                >
                  {isExecutingCascadeDelete ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري الحذف والتحديث المترابط...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4" />
                      <span>بدء الحذف المترابط النهائي</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL 2: RENAME / MOVE FILE MODAL */}
      {/* ============================================================== */}
      {actionTargetFile && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-cyan-500/40 rounded-3xl p-6 max-w-md w-full shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-cyan-400" />
                <span>إعادة تنظيم الملف في السحابة</span>
              </h3>
              <button onClick={() => setActionTargetFile(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitFileAction} className="space-y-4 text-xs">
              <div className="flex gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setActionType('rename')}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${
                    actionType === 'rename' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  إعادة تسمية
                </button>
                <button
                  type="button"
                  onClick={() => setActionType('move')}
                  className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${
                    actionType === 'move' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  نقل لمجلد
                </button>
              </div>

              {actionType === 'rename' && (
                <div>
                  <label className="block text-slate-300 font-medium mb-1">الاسم الجديد:</label>
                  <input
                    type="text"
                    value={newFileNameInput}
                    onChange={(e) => setNewFileNameInput(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-500"
                    placeholder="اسم_الملف_الجديد"
                  />
                </div>
              )}

              {actionType === 'move' && (
                <div>
                  <label className="block text-slate-300 font-medium mb-1">المجلد الهدف:</label>
                  <select
                    value={newFolderInput}
                    onChange={(e) => setNewFolderInput(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="videos">videos (مقاطع الفيديو)</option>
                    <option value="books">books (كتب وملازم PDF)</option>
                    <option value="covers">covers (أغلفة وصور)</option>
                  </select>
                </div>
              )}

              <p className="text-[11px] text-cyan-200/80 bg-cyan-950/30 p-2.5 rounded-xl border border-cyan-500/20 leading-relaxed">
                سيقوم النظام تلقائياً بإعادة كتابة جميع الروابط والمراجع في المحاضرات والكتب لتشير إلى الرابط الجديد، مما يضمن استمرارية التشغيل دون انقطاع.
              </p>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActionTargetFile(null)}
                  disabled={isSubmittingFileAction}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingFileAction}
                  className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
                >
                  {isSubmittingFileAction ? 'جاري المعالجة...' : 'تأكيد التعديل'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL 3: MULTI-FILE UPLOADER MODAL */}
      {/* ============================================================== */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-cyan-500/40 rounded-3xl p-6 max-w-lg w-full shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Upload className="w-5 h-5 text-cyan-400" />
                <span>رفع ملفات جديدة للسحابة</span>
              </h3>
              <button onClick={() => setIsUploadModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleMultiFileUpload} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1.5">مجلد الوجهة:</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setUploadFolder('videos')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-medium ${
                      uploadFolder === 'videos' ? 'bg-purple-500/20 border-purple-500 text-purple-300' : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <FileVideo className="w-4 h-4" />
                    <span>فيديو</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUploadFolder('books')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-medium ${
                      uploadFolder === 'books' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <FileText className="w-4 h-4" />
                    <span>كتب PDF</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUploadFolder('covers')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-medium ${
                      uploadFolder === 'covers' ? 'bg-blue-500/20 border-blue-500 text-blue-300' : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <ImageIcon className="w-4 h-4" />
                    <span>أغلفة</span>
                  </button>
                </div>
              </div>

              <div>
                <input
                  type="file"
                  multiple
                  ref={uploadFileInputRef}
                  onChange={(e) => {
                    const fl = Array.from(e.target.files || []);
                    setUploadFileList(fl);
                  }}
                  className="hidden"
                />

                <div
                  onClick={() => uploadFileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-700 hover:border-cyan-500 rounded-2xl p-6 text-center cursor-pointer transition-all bg-slate-950/60"
                >
                  <DownloadCloud className="w-10 h-10 mx-auto text-cyan-400 mb-2" />
                  {uploadFileList.length > 0 ? (
                    <div>
                      <p className="text-white font-bold">{uploadFileList.length} ملفات محددة للرفع</p>
                      <p className="text-slate-400 text-xs mt-1">انقر للتغيير أو اضغط بدء الرفع</p>
                    </div>
                  ) : (
                    <div>
                      <p className="text-slate-300 font-medium">انقر لاختيار ملف أو أكثر من هاتفك/جهازك</p>
                      <p className="text-slate-500 text-[11px] mt-1">يدعم رفع ملفات متعددة دفعة واحدة</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Progress feedback */}
              {isUploading && (
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {uploadFileList.map((f, i) => (
                    <div key={i} className="text-xs space-y-1">
                      <div className="flex justify-between text-slate-300">
                        <span className="truncate max-w-[200px]">{f.name}</span>
                        <span className="font-mono text-cyan-400">{uploadProgressMap[f.name] || 0}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full bg-cyan-500" style={{ width: `${uploadProgressMap[f.name] || 0}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  disabled={isUploading}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isUploading || uploadFileList.length === 0}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold disabled:opacity-50"
                >
                  {isUploading ? 'جاري الرفع السحابي...' : 'بدء الرفع'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL 4: DOCUMENT DETAILS INSPECTOR */}
      {/* ============================================================== */}
      {selectedDocDetails && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-2xl w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <FileCode className="w-5 h-5 text-cyan-400" />
                <span>فحص مستند Firestore</span>
              </h3>
              <button onClick={() => setSelectedDocDetails(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <pre className="text-xs font-mono text-cyan-200 bg-slate-950 p-4 rounded-2xl border border-slate-800 max-h-96 overflow-y-auto" dir="ltr">
              {JSON.stringify(selectedDocDetails, null, 2)}
            </pre>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedDocDetails(null)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL 5: FILE PREVIEW MODAL */}
      {/* ============================================================== */}
      {previewFile && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white truncate max-w-md">{previewFile.fileName}</h3>
              <button onClick={() => setPreviewFile(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center min-h-[250px] max-h-[450px]">
              {previewFile.folder === 'videos' ? (
                <video src={previewFile.relativeUrl} controls className="w-full max-h-[420px] rounded-xl" />
              ) : previewFile.folder === 'covers' ? (
                <img src={previewFile.relativeUrl} alt={previewFile.fileName} className="max-h-[420px] object-contain" />
              ) : (
                <div className="p-8 text-center space-y-3">
                  <FileText className="w-16 h-16 mx-auto text-emerald-400" />
                  <p className="text-white font-medium text-sm">{previewFile.fileName}</p>
                  <a
                    href={previewFile.relativeUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>فتح وقراءة ملف الـ PDF</span>
                  </a>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
              <span>الحجم: <strong className="text-white font-mono">{previewFile.sizeMb}</strong></span>
              <button
                onClick={() => copyToClipboard(previewFile.relativeUrl)}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>نسخ الرابط المباشر</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminCloudStorageTab;
