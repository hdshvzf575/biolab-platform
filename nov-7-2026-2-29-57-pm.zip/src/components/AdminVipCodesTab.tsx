import React, { useState, useEffect } from 'react';
import { 
  KeyRound, 
  Plus, 
  Trash2, 
  Copy, 
  Check, 
  Sparkles, 
  RefreshCw, 
  User, 
  Video, 
  Calendar, 
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { LectureItem, UserItem, gradeNames } from '../data/platformData';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { subscribeToCodes, saveCodeToCloud, deleteCodeFromCloud } from '../services/firebase';

interface AdminVipCodesTabProps {
  lectures: LectureItem[];
  users: UserItem[];
  showToast: (msg: string) => void;
  prefilledUid?: string | null;
  onClearPrefilledUid?: () => void;
}

export const AdminVipCodesTab: React.FC<AdminVipCodesTabProps> = ({
  lectures,
  users,
  showToast,
  prefilledUid,
  onClearPrefilledUid
}) => {
  const [codes, setCodes] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // New Code Form State
  const [codeValue, setCodeValue] = useState('');
  const [codeTitle, setCodeTitle] = useState('');
  const [targetUid, setTargetUid] = useState<string>(prefilledUid || 'ALL');
  const [targetLectureId, setTargetLectureId] = useState<string>('all');
  const [maxUses, setMaxUses] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (prefilledUid) {
      setTargetUid(prefilledUid);
      const student = users.find(u => u.uid === prefilledUid || u.id === prefilledUid);
      if (student) {
        setCodeTitle(`كود اشتراك للطالب ${student.name}`);
        const randomSuffix = Math.floor(1000 + Math.random() * 9000);
        setCodeValue(`VIP-BIO-${student.name.split(' ')[0] || 'STU'}-${randomSuffix}`);
      }
    }
  }, [prefilledUid, users]);

  const fetchCodes = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/codes');
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.codes)) {
          setCodes(data.codes);
        }
      }
    } catch (e) {
      console.warn('Failed to fetch codes:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCodes();
    // Real-time listener from central Firestore database
    const unsub = subscribeToCodes((cloudCodes) => {
      if (cloudCodes && cloudCodes.length > 0) {
        setCodes(cloudCodes);
      }
    });
    return () => unsub();
  }, []);

  const generateRandomCode = () => {
    playClickSound();
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let rand = '';
    for (let i = 0; i < 4; i++) {
      rand += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    const student = users.find(u => u.uid === targetUid || u.id === targetUid);
    const prefix = student ? (student.name.split(' ')[0] || 'STU') : 'VIP';
    setCodeValue(`VIP-BIO-2026-${prefix}-${rand}`);
  };

  const handleCreateCode = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = codeValue.trim().toUpperCase();
    if (!cleanCode) {
      showToast('يرجى كتابة رمز الكود أولاً');
      return;
    }

    setIsSubmitting(true);
    playClickSound();

    const selectedLecture = lectures.find(l => String(l.id) === String(targetLectureId));
    const selectedStudent = users.find(u => u.uid === targetUid || u.id === targetUid);
    const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

    const newCodePayload = {
      code: cleanCode,
      title: codeTitle.trim() || `كود تفعيل ${selectedLecture?.title || 'المحاضرات'}`,
      targetUid: targetUid || 'ALL',
      targetUserName: selectedStudent ? selectedStudent.name : (targetUid === 'ALL' ? 'الجميع (كود عام)' : targetUid),
      lectureId: targetLectureId === 'all' ? 'all' : Number(targetLectureId),
      lectureTitle: selectedLecture ? selectedLecture.title : 'جميع المحاضرات المدفوعة (VIP)',
      maxUses: Number(maxUses) || 1,
      usedCount: 0,
      redeemedBy: [],
      createdAt: new Date().toISOString(),
      status: 'active' as const
    };

    // 1) Write to central Firestore cloud database
    try {
      await saveCodeToCloud(newCodePayload);
    } catch (cloudErr) {
      console.warn('Cloud code save notice:', cloudErr);
    }

    // 2) Write to server API
    try {
      const res = await fetch('/api/codes', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify(newCodePayload)
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playSuccessSound();
        showToast('تم توليد الكود السري وحفظه بنجاح في السيرفر وقاعدة البيانات المركزية 🔑');
        setCodeValue('');
        setCodeTitle('');
        setTargetUid('ALL');
        if (onClearPrefilledUid) onClearPrefilledUid();
        fetchCodes();
      } else {
        showToast(data.error || 'حدث خطأ أثناء توليد الكود');
      }
    } catch (err) {
      showToast('تم حفظ الكود في قاعدة البيانات السحابية');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteCode = async (code: string) => {
    playClickSound();
    const adminToken = sessionStorage.getItem('biolab_admin_token') || 'wissam_bio_admin_token_2026_secure';

    // 1) Delete from central Firestore cloud database
    try {
      await deleteCodeFromCloud(code);
    } catch (cloudErr) {
      console.warn('Cloud code delete notice:', cloudErr);
    }

    // 2) Delete from server
    try {
      const res = await fetch(`/api/codes/${encodeURIComponent(code)}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${adminToken}`
        }
      });
      if (res.ok) {
        showToast('تم حذف الكود وإلغاؤه بنجاح من كافة الأجهزة');
        fetchCodes();
      }
    } catch (e) {
      showToast('تم حذف الكود من قاعدة البيانات السحابية');
    }
  };

  const copyCode = (code: string) => {
    playClickSound();
    try {
      navigator.clipboard.writeText(code);
      setCopiedCode(code);
      setTimeout(() => setCopiedCode(null), 2000);
      showToast('تم نسخ الكود للحافظة');
    } catch (e) {}
  };

  return (
    <div className="space-y-6 animate-fadeIn text-right">
      
      {/* Form: Generate New VIP Code */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl space-y-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-[#e9c978]" />
              <h3 className="font-amiri font-bold text-2xl text-white">
                توليد أكواد المحاضرات المدفوعة والـ VIP
              </h3>
            </div>
            <p className="text-xs text-gray-300 mt-1">
              يمكنك ربط الكود بمعرّف UID لطالب محدد حتى لا يستطيع أي طالب آخر استخدامه.
            </p>
          </div>

          <button
            onClick={fetchCodes}
            className="py-1.5 px-3 rounded-xl bg-white/5 border border-white/10 hover:border-[#e9c978]/40 text-xs font-bold text-gray-300 hover:text-white flex items-center gap-1.5 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>تحديث الأكواد</span>
          </button>
        </div>

        <form onSubmit={handleCreateCode} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            
            {/* Code Value with Generate Button */}
            <div className="sm:col-span-6 space-y-1.5">
              <label className="block text-xs font-bold text-gray-200">
                رمز الكود السري (Code)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={codeValue}
                  onChange={(e) => setCodeValue(e.target.value.toUpperCase())}
                  placeholder="مثال: VIP-BIO-2026-..."
                  required
                  className="flex-1 py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#e9c978] text-[#e9c978] font-mono font-bold text-xs focus:outline-none"
                />
                <button
                  type="button"
                  onClick={generateRandomCode}
                  className="py-2.5 px-3 rounded-xl bg-[#e9c978]/15 border border-[#e9c978]/30 hover:bg-[#e9c978] hover:text-black text-[#e9c978] font-bold text-xs transition shrink-0"
                >
                  توليد عشوائي
                </button>
              </div>
            </div>

            {/* Title / Description */}
            <div className="sm:col-span-6 space-y-1.5">
              <label className="block text-xs font-bold text-gray-200">
                عنوان الكود أو الملاحظة (اختياري)
              </label>
              <input
                type="text"
                value={codeTitle}
                onChange={(e) => setCodeTitle(e.target.value)}
                placeholder="مثال: كود تفعيل الفصل الأول للطالب علي"
                className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#e9c978] text-white text-xs focus:outline-none"
              />
            </div>

            {/* Target Student UID Link */}
            <div className="sm:col-span-6 space-y-1.5">
              <label className="block text-xs font-bold text-gray-200 flex items-center justify-between">
                <span>الطالب المستهدف (مربوط بـ UID)</span>
                <span className="text-[10px] text-[#e9c978]">أمان مشدد</span>
              </label>
              <select
                value={targetUid}
                onChange={(e) => setTargetUid(e.target.value)}
                className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#e9c978] text-white text-xs focus:outline-none"
              >
                <option value="ALL">كود عام (متاح لأي طالب يمتلك الكود)</option>
                {users.map((u) => (
                  <option key={u.id} value={u.uid || u.id}>
                    {u.name} — {u.uid || u.id} ({gradeNames[u.grade] || u.grade || 'طالب'})
                  </option>
                ))}
              </select>
              <span className="text-[10px] text-gray-400 block px-1">
                عند تحديد طالب معين، لن يتمكن أي جهاز أو طالب آخر من تفعيل الكود.
              </span>
            </div>

            {/* Target Lecture */}
            <div className="sm:col-span-4 space-y-1.5">
              <label className="block text-xs font-bold text-gray-200">
                المحاضرة المراد تفعيلها
              </label>
              <select
                value={targetLectureId}
                onChange={(e) => setTargetLectureId(e.target.value)}
                className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#e9c978] text-white text-xs focus:outline-none"
              >
                <option value="all">جميع المحاضرات المدفوعة (اشتراك شامل VIP)</option>
                {lectures.map((lec) => (
                  <option key={lec.id} value={lec.id}>
                    {lec.title} ({lec.grade})
                  </option>
                ))}
              </select>
            </div>

            {/* Max Uses */}
            <div className="sm:col-span-2 space-y-1.5">
              <label className="block text-xs font-bold text-gray-200">
                مرات الاستخدام
              </label>
              <input
                type="number"
                min="1"
                max="999"
                value={maxUses}
                onChange={(e) => setMaxUses(parseInt(e.target.value, 10) || 1)}
                className="w-full py-2.5 px-3 rounded-xl bg-black/60 border border-white/15 focus:border-[#e9c978] text-white font-mono text-center text-xs focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-black text-sm shadow-xl hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4 text-[#08111e]" />
            <span>{isSubmitting ? 'جاري حفظ الكود في السيرفر...' : 'حفظ ونشر كود التفعيل 🔑'}</span>
          </button>
        </form>
      </div>

      {/* List of Active & Generated Codes */}
      <div className="space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <h4 className="font-bold text-base text-white flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-[#e9c978]" />
            <span>الأكواد المولدة والمتاحة ({codes.length})</span>
          </h4>
          <span className="text-xs text-gray-400">
            يمكنك نسخ الكود وإرساله للطالب عبر الواتساب أو التلغرام
          </span>
        </div>

        {codes.length === 0 ? (
          <div className="p-8 rounded-2xl bg-black/40 border border-white/10 text-center space-y-2">
            <div className="text-3xl">🔑</div>
            <p className="text-sm font-bold text-gray-300">لا توجد أكواد مولدة حالياً.</p>
            <p className="text-xs text-gray-500">استخدم النموذج أعلاه لتوليد أول كود تفعيل مربوط بـ UID الطالب.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {codes.map((item) => {
              const isBound = item.targetUid && item.targetUid !== 'ALL';
              const isRedeemed = item.usedCount >= item.maxUses;

              return (
                <div
                  key={item.code}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                    isRedeemed 
                      ? 'bg-white/5 border-white/10 opacity-75' 
                      : isBound 
                      ? 'bg-[#e9c978]/5 border-[#e9c978]/30 hover:border-[#e9c978]/60 shadow-md' 
                      : 'bg-black/50 border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="space-y-1">
                      <span className="text-[10px] font-bold text-gray-400 block">
                        {item.title}
                      </span>
                      <div className="font-mono text-base font-black text-[#e9c978] tracking-wider select-all">
                        {item.code}
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => copyCode(item.code)}
                        className="py-1 px-2.5 rounded-xl bg-white/10 hover:bg-[#e9c978] hover:text-black text-gray-300 text-xs font-bold transition flex items-center gap-1"
                        title="نسخ الكود"
                      >
                        {copiedCode === item.code ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedCode === item.code ? 'تم' : 'نسخ'}</span>
                      </button>

                      <button
                        onClick={() => handleDeleteCode(item.code)}
                        className="p-1.5 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500 hover:text-white transition"
                        title="حذف الكود"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-2 border-t border-white/10 text-xs text-gray-300">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">الطالب المستهدف:</span>
                      <span className={`font-bold ${isBound ? 'text-[#0fb98a]' : 'text-gray-300'}`}>
                        {item.targetUserName || (isBound ? item.targetUid : 'كود عام لكافة الطلاب')}
                      </span>
                    </div>

                    {isBound && (
                      <div className="flex items-center justify-between font-mono text-[11px]">
                        <span className="text-gray-400">UID المقفل عليه:</span>
                        <span className="text-[#e9c978] bg-black/40 px-2 py-0.5 rounded">
                          {item.targetUid}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">المحاضرة:</span>
                      <span className="font-medium text-white truncate max-w-[180px]">
                        {item.lectureTitle || item.lectureId}
                      </span>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-gray-400">الاستخدام:</span>
                      <span className="font-mono text-xs font-bold text-gray-200">
                        {item.usedCount || 0} من {item.maxUses || 1}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
};
