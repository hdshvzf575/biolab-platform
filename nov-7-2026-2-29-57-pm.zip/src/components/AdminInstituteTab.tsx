import React, { useState, useEffect, useMemo } from 'react';
import {
  GraduationCap,
  Award,
  FileText,
  Plus,
  Trash2,
  Edit3,
  Eye,
  EyeOff,
  Archive,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Layers,
  RefreshCw,
  Calendar,
  Paperclip,
  Check,
  X,
  FileCheck,
  Activity,
  History
} from 'lucide-react';
import {
  InstitutePost,
  InstituteStageConfig,
  InstituteAuditLog,
  defaultInstituteStages,
  GradeDisplayMode,
  InstitutePostStatus
} from '../data/instituteData';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import {
  subscribeToInstitutePosts,
  subscribeToInstituteStages,
  addInstitutePostToCloud,
  updateInstitutePostInCloud,
  deleteInstitutePostFromCloud,
  updateInstituteStageInCloud
} from '../services/firebase';

interface AdminInstituteTabProps {
  showToast: (msg: string) => void;
}

export const AdminInstituteTab: React.FC<AdminInstituteTabProps> = ({ showToast }) => {
  // Sub-tabs inside Institute Administration:
  // 1. posts: Unified Posts Table & Actions
  // 2. addGrade: Add / Edit Grade Exam Result
  // 3. addHomework: Add / Edit Homework
  // 4. stages: Manage the 6 Stages (Active / Hidden)
  // 5. audit: Audit Log
  const [subTab, setSubTab] = useState<'posts' | 'addGrade' | 'addHomework' | 'stages' | 'audit'>('posts');

  // Stages & Posts state
  const [stages, setStages] = useState<InstituteStageConfig[]>(defaultInstituteStages);
  const [posts, setPosts] = useState<InstitutePost[]>([]);
  const [auditLogs, setAuditLogs] = useState<InstituteAuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Filters for Unified Posts Table
  const [searchQuery, setSearchQuery] = useState('');
  const [stageFilter, setStageFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'grade' | 'homework'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'draft' | 'archived' | 'hidden'>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  // Grade Form State (Simple System: تاريخ، اسم الامتحان، نوعه، وجدول: اسم الطالب، صفه، شعبته، درجته)
  const [gradeStageId, setGradeStageId] = useState('g6');
  const [gradeSubject, setGradeSubject] = useState('علم الأحياء');
  const [gradeTitle, setGradeTitle] = useState('');
  const [gradeExamType, setGradeExamType] = useState('امتحان شهري تحريري');
  const [gradeExamDate, setGradeExamDate] = useState(new Date().toISOString().split('T')[0]);
  const [gradeDisplayMode, setGradeDisplayMode] = useState<GradeDisplayMode>('table');
  const [gradeMaxScore, setGradeMaxScore] = useState<number>(100);
  const [gradeMinPassing, setGradeMinPassing] = useState<number>(50);
  const [gradeAverageScore, setGradeAverageScore] = useState<string>('88');
  const [gradeHighestScore, setGradeHighestScore] = useState<string>('100');
  const [gradeSuccessRate, setGradeSuccessRate] = useState<string>('95');
  const [gradeNotes, setGradeNotes] = useState('');
  const [gradeAttachmentUrl, setGradeAttachmentUrl] = useState('');
  const [gradeAttachmentName, setGradeAttachmentName] = useState('');
  
  // Interactive Students Table rows
  const [studentRows, setStudentRows] = useState<Array<{
    id: string;
    studentName: string;
    gradeClass: string;
    section: string;
    score: number;
    rating?: string;
    note?: string;
  }>>([
    { id: '1', studentName: 'علي حيدر الزبيدي', gradeClass: 'السادس العلمي', section: 'أ', score: 100, rating: 'ممتاز ⭐️', note: 'إجابة نموذجية' },
    { id: '2', studentName: 'فاطمة أحمد الساعدي', gradeClass: 'السادس العلمي', section: 'أ', score: 98, rating: 'ممتاز', note: 'دقة عالية' },
    { id: '3', studentName: 'حسين محمد الكرخي', gradeClass: 'السادس العلمي', section: 'ب', score: 95, rating: 'ممتاز', note: 'تركيز ممتاز' },
    { id: '4', studentName: 'زينب جاسم العامري', gradeClass: 'السادس العلمي', section: 'أ', score: 92, rating: 'ممتاز', note: 'مستوى ممتاز' }
  ]);
  const [showBulkPasteModal, setShowBulkPasteModal] = useState(false);
  const [bulkPasteText, setBulkPasteText] = useState('');

  const [editingGradePostId, setEditingGradePostId] = useState<string | null>(null);

  // Homework Form State
  const [hwStageId, setHwStageId] = useState('g6');
  const [hwSubject, setHwSubject] = useState('علم الأحياء');
  const [hwTitle, setHwTitle] = useState('');
  const [hwDetails, setHwDetails] = useState('');
  const [hwPublishDate, setHwPublishDate] = useState(new Date().toISOString().split('T')[0]);
  const [hwDueDate, setHwDueDate] = useState('');
  const [hwNotes, setHwNotes] = useState('');
  const [hwAttachmentUrl, setHwAttachmentUrl] = useState('');
  const [hwAttachmentName, setHwAttachmentName] = useState('');
  const [editingHwPostId, setEditingHwPostId] = useState<string | null>(null);

  // Modals state
  const [postToDelete, setPostToDelete] = useState<InstitutePost | null>(null);
  const [previewPost, setPreviewPost] = useState<InstitutePost | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch data
  const fetchAllInstituteData = async () => {
    setIsLoading(true);
    try {
      const [stagesRes, postsRes, auditRes] = await Promise.all([
        fetch('/api/institute/stages'),
        fetch('/api/institute/posts?admin=true'),
        fetch('/api/institute/audit')
      ]);

      if (stagesRes.ok) {
        const sData = await stagesRes.json();
        if (sData.success && Array.isArray(sData.stages)) setStages(sData.stages);
      }
      if (postsRes.ok) {
        const pData = await postsRes.json();
        if (pData.success && Array.isArray(pData.posts)) setPosts(pData.posts);
      }
      if (auditRes.ok) {
        const aData = await auditRes.json();
        if (aData.success && Array.isArray(aData.logs)) setAuditLogs(aData.logs);
      }
    } catch (e) {
      console.warn('Failed to fetch institute data from server');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllInstituteData();

    // Live subscription to institute posts in Firestore
    const unsubPosts = subscribeToInstitutePosts((cloudPosts) => {
      if (Array.isArray(cloudPosts) && cloudPosts.length > 0) {
        setPosts(cloudPosts);
      }
    });

    // Live subscription to institute stages in Firestore
    const unsubStages = subscribeToInstituteStages((cloudStages) => {
      if (Array.isArray(cloudStages) && cloudStages.length > 0) {
        setStages(cloudStages);
      }
    });

    return () => {
      unsubPosts();
      unsubStages();
    };
  }, []);

  // Filtered Posts
  const filteredPosts = useMemo(() => {
    return posts.filter((post) => {
      const matchesSearch =
        !searchQuery.trim() ||
        post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (post.notes && post.notes.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesStage = stageFilter === 'all' || post.stageId === stageFilter;
      const matchesType = typeFilter === 'all' || post.type === typeFilter;
      const matchesStatus = statusFilter === 'all' || post.status === statusFilter;

      return matchesSearch && matchesStage && matchesType && matchesStatus;
    });
  }, [posts, searchQuery, stageFilter, typeFilter, statusFilter]);

  // Paginated Posts
  const totalPages = Math.ceil(filteredPosts.length / pageSize) || 1;
  const paginatedPosts = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredPosts.slice(start, start + pageSize);
  }, [filteredPosts, currentPage, pageSize]);

  // Toggle stage active / hidden with Firestore sync
  const handleToggleStageActive = async (stage: InstituteStageConfig) => {
    const nextActive = !stage.isActive;
    try {
      await updateInstituteStageInCloud(stage.id, { isActive: nextActive });
    } catch (e) {
      console.warn('Firestore stage update notice:', e);
    }
    try {
      const res = await fetch(`/api/institute/stages/${stage.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: nextActive })
      });
      if (res.ok) {
        setStages((prev) => prev.map((s) => (s.id === stage.id ? { ...s, isActive: nextActive } : s)));
        showToast(nextActive ? `تم تفعيل ${stage.name}` : `تم إخفاء ${stage.name} عن الطلاب`);
        playClickSound();
        fetchAllInstituteData();
      }
    } catch (e) {
      showToast('تعذر تحديث حالة المرحلة في السيرفر');
    }
  };

  // Parse raw text for records
  // Student Row Manipulation Functions
  const addStudentRow = () => {
    playClickSound();
    setStudentRows((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        studentName: '',
        gradeClass: getStageName(gradeStageId),
        section: 'أ',
        score: 100,
        rating: 'ممتاز',
        note: ''
      }
    ]);
  };

  const removeStudentRow = (id: string) => {
    playClickSound();
    setStudentRows((prev) => (prev.length > 1 ? prev.filter((r) => r.id !== id) : prev));
  };

  const updateStudentRow = (id: string, field: string, value: any) => {
    setStudentRows((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const updated: any = { ...r, [field]: value };
        if (field === 'score') {
          const sc = Number(value) || 0;
          updated.rating = sc >= 90 ? 'ممتاز' : sc >= 80 ? 'جيد جداً' : sc >= 70 ? 'جيد' : sc >= (Number(gradeMinPassing) || 50) ? 'متوسط' : 'يحتاج لمتابعة';
        }
        return updated;
      })
    );
  };

  const handleApplyBulkPaste = () => {
    if (!bulkPasteText.trim()) return;
    const lines = bulkPasteText.split('\n').filter((l) => l.trim().length > 0);
    const newRows = lines.map((line, idx) => {
      const parts = line.split(/[,;\t|:]/).map((p) => p.trim());
      const name = parts[0] || `طالب ${idx + 1}`;
      const cls = parts[1] || getStageName(gradeStageId);
      const sec = parts[2] || 'أ';
      const sc = Number(parts[3]) || 90;
      const nt = parts[4] || '';
      const rt = sc >= 90 ? 'ممتاز' : sc >= 80 ? 'جيد جداً' : sc >= 70 ? 'جيد' : sc >= 50 ? 'متوسط' : 'يحتاج لمتابعة';
      return {
        id: `bulk-${Date.now()}-${idx}`,
        studentName: name,
        gradeClass: cls,
        section: sec,
        score: sc,
        rating: rt,
        note: nt
      };
    });

    if (newRows.length > 0) {
      playSuccessSound();
      setStudentRows(newRows);
      setShowBulkPasteModal(false);
      setBulkPasteText('');
      showToast(`تم استيراد ${newRows.length} طالب إلى جدول الدرجات بنجاح`);
    }
  };

  // Submit Grade Post (Create or Update)
  const handleSaveGradePost = async (publishStatus: InstitutePostStatus = 'published') => {
    if (!gradeTitle.trim()) {
      showToast('يرجى كتابة اسم الامتحان أو عنوان الاختبار');
      return;
    }

    const validStudents = studentRows.filter((r) => r.studentName.trim().length > 0);
    if (validStudents.length === 0) {
      showToast('يرجى إضافة طالب واحد على الأقل مع اسمه في جدول الدرجات');
      return;
    }

    setIsSubmitting(true);
    const maxSc = Number(gradeMaxScore) || 100;
    const minPass = Number(gradeMinPassing) || 50;

    const parsedRecs = validStudents.map((r, idx) => {
      const sc = Number(r.score) || 0;
      const autoRating = r.rating?.trim() || (sc >= 90 ? 'ممتاز' : sc >= 80 ? 'جيد جداً' : sc >= 70 ? 'جيد' : sc >= minPass ? 'متوسط' : 'يحتاج لمتابعة');
      return {
        studentName: r.studentName.trim(),
        gradeClass: r.gradeClass.trim() || getStageName(gradeStageId),
        section: r.section.trim() || 'أ',
        score: sc,
        maxScore: maxSc,
        rating: autoRating,
        note: r.note?.trim() || undefined,
        studentCode: `STU-${100 + idx}`
      };
    });

    const scores = parsedRecs.map((r) => r.score);
    const calculatedAvg = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 85;
    const calculatedHigh = scores.length > 0 ? Math.max(...scores) : 100;
    const passedCount = scores.filter((s) => s >= minPass).length;
    const calculatedSuccessRate = scores.length > 0 ? Math.round((passedCount / scores.length) * 100) : 100;

    const payload = {
      type: 'grade',
      stageId: gradeStageId,
      subject: gradeSubject.trim() || 'علم الأحياء',
      title: gradeTitle.trim(),
      examType: gradeExamType.trim(),
      date: gradeExamDate,
      publishDate: new Date().toISOString().split('T')[0],
      status: publishStatus,
      displayMode: gradeDisplayMode,
      maxScore: maxSc,
      minPassingScore: minPass,
      averageScore: calculatedAvg,
      highestScore: calculatedHigh,
      successRate: calculatedSuccessRate,
      studentCount: parsedRecs.length,
      notes: gradeNotes.trim(),
      attachmentUrl: gradeAttachmentUrl.trim() || undefined,
      attachmentName: gradeAttachmentName.trim() || undefined,
      records: parsedRecs
    };

    const targetPostId = editingGradePostId || `post-${gradeStageId}-grade-${Date.now()}`;
    const fullPayload: any = {
      ...payload,
      id: targetPostId,
      createdAt: editingGradePostId ? undefined : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // 1. Direct Firestore write
    try {
      if (editingGradePostId) {
        await updateInstitutePostInCloud(editingGradePostId, fullPayload);
      } else {
        await addInstitutePostToCloud(fullPayload);
      }
    } catch (cloudErr) {
      console.warn('Direct Firestore post write notice:', cloudErr);
    }

    // 2. Server API sync for logs & caching
    try {
      let res;
      if (editingGradePostId) {
        res = await fetch(`/api/institute/posts/${editingGradePostId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(fullPayload)
        });
      } else {
        res = await fetch('/api/institute/posts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(fullPayload)
        });
      }

      if (res.ok) {
        playSuccessSound();
        showToast(
          publishStatus === 'draft'
            ? 'تم حفظ نتائج الاختبار كمسودة بنجاح'
            : 'تم نشر نتائج الاختبار بنجاح لجميع طلاب المعهد 🌐'
        );
        resetGradeForm();
        setSubTab('posts');
        fetchAllInstituteData();
      }
    } catch (e) {
      showToast('حدث خطأ أثناء حفظ نتائج الاختبار');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Homework Post (Create or Update)
  const handleSaveHomeworkPost = async (publishStatus: InstitutePostStatus = 'published') => {
    if (!hwTitle.trim()) {
      showToast('يرجى كتابة عنوان الواجب');
      return;
    }

    setIsSubmitting(true);
    const payload = {
      type: 'homework',
      stageId: hwStageId,
      subject: hwSubject.trim(),
      title: hwTitle.trim(),
      date: hwPublishDate,
      publishDate: hwPublishDate,
      dueDate: hwDueDate || undefined,
      status: publishStatus,
      details: hwDetails.trim(),
      notes: hwNotes.trim(),
      attachmentUrl: hwAttachmentUrl.trim() || undefined,
      attachmentName: hwAttachmentName.trim() || undefined
    };

    const targetPostId = editingHwPostId || `post-${hwStageId}-homework-${Date.now()}`;
    const fullPayload: any = {
      ...payload,
      id: targetPostId,
      createdAt: editingHwPostId ? undefined : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // 1. Direct Firestore write
    try {
      if (editingHwPostId) {
        await updateInstitutePostInCloud(editingHwPostId, fullPayload);
      } else {
        await addInstitutePostToCloud(fullPayload);
      }
    } catch (cloudErr) {
      console.warn('Direct Firestore hw write notice:', cloudErr);
    }

    // 2. Server API sync for logs & caching
    try {
      let res;
      if (editingHwPostId) {
        res = await fetch(`/api/institute/posts/${editingHwPostId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(fullPayload)
        });
      } else {
        res = await fetch('/api/institute/posts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(fullPayload)
        });
      }

      if (res.ok) {
        playSuccessSound();
        showToast(
          publishStatus === 'draft'
            ? 'تم حفظ الواجب كمسودة بنجاح'
            : 'تم نشر الواجب لطلاب المرحلة بنجاح 🌐'
        );
        resetHwForm();
        setSubTab('posts');
        fetchAllInstituteData();
      }
    } catch (e) {
      showToast('حدث خطأ أثناء حفظ الواجب');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Quick Post Status Change (نشر / إخفاء / أرشفة)
  const handleChangePostStatus = async (post: InstitutePost, nextStatus: InstitutePostStatus) => {
    try {
      await updateInstitutePostInCloud(post.id, { status: nextStatus });
    } catch (cloudErr) {
      console.warn('Firestore post status notice:', cloudErr);
    }
    try {
      const res = await fetch(`/api/institute/posts/${post.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      if (res.ok) {
        playClickSound();
        setPosts((prev) => prev.map((p) => (p.id === post.id ? { ...p, status: nextStatus } : p)));
        const labels: Record<string, string> = {
          published: 'تم نشر المنشور للطلاب',
          hidden: 'تم إخفاء المنشور عن الطلاب',
          archived: 'تم نقل المنشور إلى الأرشيف',
          draft: 'تم تعيين المنشور كمسودة'
        };
        showToast(labels[nextStatus] || 'تم تحديث حالة المنشور');
        fetchAllInstituteData();
      }
    } catch (e) {
      showToast('تعذر تحديث المنشور');
    }
  };

  // Delete Post
  const handleConfirmDeletePost = async () => {
    if (!postToDelete) return;
    try {
      await deleteInstitutePostFromCloud(postToDelete.id);
    } catch (cloudErr) {
      console.warn('Firestore post delete notice:', cloudErr);
    }
    try {
      const res = await fetch(`/api/institute/posts/${postToDelete.id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        playClickSound();
        setPosts((prev) => prev.filter((p) => p.id !== postToDelete.id));
        showToast(`تم حذف المنشور "${postToDelete.title}" نهائياً`);
        setPostToDelete(null);
        fetchAllInstituteData();
      }
    } catch (e) {
      showToast('تعذر حذف المنشور من السيرفر');
    }
  };

  // Start Editing
  const startEditPost = (post: InstitutePost) => {
    if (post.type === 'grade') {
      setEditingGradePostId(post.id);
      setGradeStageId(post.stageId);
      setGradeSubject(post.subject);
      setGradeTitle(post.title);
      setGradeExamDate(post.date || new Date().toISOString().split('T')[0]);
      setGradeDisplayMode(post.displayMode || 'table');
      setGradeMaxScore(post.maxScore || 100);
      setGradeMinPassing(post.minPassingScore || 50);
      setGradeAverageScore(post.averageScore?.toString() || '');
      setGradeHighestScore(post.highestScore?.toString() || '');
      setGradeSuccessRate(post.successRate?.toString() || '');
      setGradeNotes(post.notes || '');
      setGradeAttachmentUrl(post.attachmentUrl || '');
      setGradeAttachmentName(post.attachmentName || '');

      if (post.examType) {
        setGradeExamType(post.examType);
      }

      if (post.records && post.records.length > 0) {
        setStudentRows(
          post.records.map((r, i) => ({
            id: String(i + 1),
            studentName: r.studentName || `طالب ${i + 1}`,
            gradeClass: r.gradeClass || getStageName(post.stageId),
            section: r.section || 'أ',
            score: r.score || 0,
            rating: r.rating || (r.score >= 90 ? 'ممتاز' : r.score >= 80 ? 'جيد جداً' : r.score >= 50 ? 'ناجح' : 'راسب'),
            note: r.note || ''
          }))
        );
      }
      setSubTab('addGrade');
    } else {
      setEditingHwPostId(post.id);
      setHwStageId(post.stageId);
      setHwSubject(post.subject);
      setHwTitle(post.title);
      setHwDetails(post.details || '');
      setHwPublishDate(post.publishDate || post.date || new Date().toISOString().split('T')[0]);
      setHwDueDate(post.dueDate || '');
      setHwNotes(post.notes || '');
      setHwAttachmentUrl(post.attachmentUrl || '');
      setHwAttachmentName(post.attachmentName || '');
      setSubTab('addHomework');
    }
  };

  const resetGradeForm = () => {
    setEditingGradePostId(null);
    setGradeTitle('');
    setGradeExamType('امتحان شهري تحريري');
    setGradeExamDate(new Date().toISOString().split('T')[0]);
    setGradeNotes('');
    setGradeAttachmentUrl('');
    setGradeAttachmentName('');
    const curStage = getStageName(gradeStageId);
    setStudentRows([
      { id: '1', studentName: '', gradeClass: curStage, section: 'أ', score: 100, rating: 'ممتاز', note: '' },
      { id: '2', studentName: '', gradeClass: curStage, section: 'أ', score: 95, rating: 'ممتاز', note: '' },
      { id: '3', studentName: '', gradeClass: curStage, section: 'ب', score: 88, rating: 'جيد جداً', note: '' }
    ]);
  };

  const resetHwForm = () => {
    setEditingHwPostId(null);
    setHwTitle('');
    setHwDetails('');
    setHwDueDate('');
    setHwNotes('');
    setHwAttachmentUrl('');
    setHwAttachmentName('');
  };

  const getStageName = (id: string) => {
    const found = stages.find((s) => s.id === id);
    return found ? found.name : id;
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Tab Header Banner */}
      <div className="p-6 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-[#0fb98a] animate-ping" />
            <span className="px-3 py-0.5 rounded-full text-xs font-bold bg-[#e9c978]/15 text-[#e9c978] border border-[#e9c978]/30">
              نظام إدارة طلاب المعهد الخاص
            </span>
          </div>
          <h3 className="font-amiri font-bold text-2xl text-white">
            إدارة الدرجات، الواجبات، والمراحل الدراسية
          </h3>
          <p className="text-xs text-gray-400 mt-0.5">
            نشر ومزامنة نتائج الاختبارات والواجبات فورياً لجميع طلاب المعهد الخاص عبر جدول بسيط وسهل الإدارة
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchAllInstituteData}
            disabled={isLoading}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-gray-300 hover:text-white transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#e9c978]' : ''}`} />
            <span>تحديث البيانات</span>
          </button>
        </div>
      </div>

      {/* Sub Navigation Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 p-1.5 rounded-2xl bg-white/5 border border-white/10 text-xs font-bold">
        <button
          onClick={() => { playClickSound(); setSubTab('posts'); }}
          className={`py-2.5 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
            subTab === 'posts'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <Layers className="w-4 h-4 shrink-0" />
          <span>جدول المنشورات ({posts.length})</span>
        </button>

        <button
          onClick={() => { playClickSound(); resetGradeForm(); setSubTab('addGrade'); }}
          className={`py-2.5 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
            subTab === 'addGrade'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <Award className="w-4 h-4 shrink-0" />
          <span>{editingGradePostId ? 'تعديل الدرجات' : 'نشر درجات جديدة'}</span>
        </button>

        <button
          onClick={() => { playClickSound(); resetHwForm(); setSubTab('addHomework'); }}
          className={`py-2.5 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
            subTab === 'addHomework'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileText className="w-4 h-4 shrink-0" />
          <span>{editingHwPostId ? 'تعديل واجب' : 'نشر واجب جديد'}</span>
        </button>

        <button
          onClick={() => { playClickSound(); setSubTab('stages'); }}
          className={`py-2.5 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
            subTab === 'stages'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <GraduationCap className="w-4 h-4 shrink-0" />
          <span>المراحل الست ({stages.length})</span>
        </button>

        <button
          onClick={() => { playClickSound(); setSubTab('audit'); }}
          className={`py-2.5 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
            subTab === 'audit'
              ? 'bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] shadow-md'
              : 'text-gray-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <History className="w-4 h-4 shrink-0" />
          <span>سجل العمليات ({auditLogs.length})</span>
        </button>
      </div>

      {/* ========================================================
          SUB-TAB 1: UNIFIED POSTS TABLE
          ======================================================== */}
      {subTab === 'posts' && (
        <div className="space-y-4">
          {/* Action Row */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => { playClickSound(); resetGradeForm(); setSubTab('addGrade'); }}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs shadow-md hover:brightness-110 flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>نشر درجات</span>
              </button>

              <button
                onClick={() => { playClickSound(); resetHwForm(); setSubTab('addHomework'); }}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs border border-white/10 flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>نشر واجب</span>
              </button>
            </div>

            <div className="text-xs text-gray-400">
              إجمالي المنشورات المطابقة: <strong className="text-[#e9c978]">{filteredPosts.length}</strong>
            </div>
          </div>

          {/* Filters Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 p-4 rounded-2xl bg-[#0a1220] border border-white/10">
            {/* Search */}
            <div className="sm:col-span-5 relative">
              <Search className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                placeholder="ابحث بالاسم، المادة، أو الملاحظة..."
                className="w-full py-2 pr-9 pl-3 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-gray-500 text-xs focus:outline-none focus:border-[#e9c978]"
              />
            </div>

            {/* Type */}
            <div className="sm:col-span-2">
              <select
                value={typeFilter}
                onChange={(e) => { setTypeFilter(e.target.value as any); setCurrentPage(1); }}
                className="w-full py-2 px-2.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
              >
                <option value="all">كل الأنواع</option>
                <option value="grade">درجات فقط</option>
                <option value="homework">واجبات فقط</option>
              </select>
            </div>

            {/* Stage */}
            <div className="sm:col-span-3">
              <select
                value={stageFilter}
                onChange={(e) => { setStageFilter(e.target.value); setCurrentPage(1); }}
                className="w-full py-2 px-2.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
              >
                <option value="all">كل المراحل الست</option>
                {stages.map((st) => (
                  <option key={st.id} value={st.id}>{st.name}</option>
                ))}
              </select>
            </div>

            {/* Status */}
            <div className="sm:col-span-2">
              <select
                value={statusFilter}
                onChange={(e) => { setStatusFilter(e.target.value as any); setCurrentPage(1); }}
                className="w-full py-2 px-2.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
              >
                <option value="all">كل الحالات</option>
                <option value="published">منشور</option>
                <option value="draft">مسودة</option>
                <option value="hidden">مخفي</option>
                <option value="archived">مؤرشف</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto rounded-2xl bg-[#0a1220] border border-white/10 shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-white/5 text-gray-400 border-b border-white/10 font-bold">
                <tr>
                  <th className="py-3 px-4">النوع</th>
                  <th className="py-3 px-4">عنوان المنشور</th>
                  <th className="py-3 px-4">المرحلة</th>
                  <th className="py-3 px-4">المادة</th>
                  <th className="py-3 px-4">الحالة</th>
                  <th className="py-3 px-4">التاريخ</th>
                  <th className="py-3 px-4 text-center">الإجراءات والتحكم</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-gray-200">
                {paginatedPosts.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-gray-400">
                      لا توجد منشورات تطابق معايير البحث والفلترة.
                    </td>
                  </tr>
                ) : (
                  paginatedPosts.map((post) => {
                    const isGrade = post.type === 'grade';
                    return (
                      <tr key={post.id} className="hover:bg-white/5 transition">
                        {/* Type */}
                        <td className="py-3 px-4 whitespace-nowrap">
                          {isGrade ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold bg-[#e9c978]/15 text-[#e9c978] border border-[#e9c978]/30">
                              <Award className="w-3 h-3" />
                              <span>درجات</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold bg-sky-500/15 text-sky-300 border border-sky-500/30">
                              <FileText className="w-3 h-3" />
                              <span>واجب</span>
                            </span>
                          )}
                        </td>

                        {/* Title */}
                        <td className="py-3 px-4 font-bold text-white max-w-[240px] truncate">
                          {post.title}
                          {post.attachmentUrl && (
                            <span className="mr-1.5 text-[10px] text-gray-400" title="يحتوي على مرفق">📎</span>
                          )}
                        </td>

                        {/* Stage */}
                        <td className="py-3 px-4 whitespace-nowrap text-gray-300">
                          {getStageName(post.stageId)}
                        </td>

                        {/* Subject */}
                        <td className="py-3 px-4 whitespace-nowrap text-gray-300">
                          {post.subject}
                        </td>

                        {/* Status */}
                        <td className="py-3 px-4 whitespace-nowrap">
                          {post.status === 'published' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                              منشور علناً
                            </span>
                          )}
                          {post.status === 'draft' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              مسودة
                            </span>
                          )}
                          {post.status === 'hidden' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-500/20 text-gray-300 border border-gray-500/30">
                              مخفي
                            </span>
                          )}
                          {post.status === 'archived' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                              مؤرشف
                            </span>
                          )}
                        </td>

                        {/* Date */}
                        <td className="py-3 px-4 whitespace-nowrap text-gray-400 font-mono text-[11px]">
                          {post.publishDate || post.date}
                        </td>

                        {/* Actions */}
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Preview */}
                            <button
                              onClick={() => setPreviewPost(post)}
                              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-gray-300 hover:text-white"
                              title="معاينة المنشور"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>

                            {/* Toggle Publish / Hide */}
                            {post.status === 'published' ? (
                              <button
                                onClick={() => handleChangePostStatus(post, 'hidden')}
                                className="p-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300"
                                title="إخفاء المنشور"
                              >
                                <EyeOff className="w-3.5 h-3.5" />
                              </button>
                            ) : (
                              <button
                                onClick={() => handleChangePostStatus(post, 'published')}
                                className="p-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300"
                                title="نشر المنشور"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {/* Archive */}
                            {post.status !== 'archived' && (
                              <button
                                onClick={() => handleChangePostStatus(post, 'archived')}
                                className="p-1.5 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 text-purple-300"
                                title="أرشفة"
                              >
                                <Archive className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {/* Edit */}
                            <button
                              onClick={() => startEditPost(post)}
                              className="p-1.5 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 text-sky-300"
                              title="تعديل المنشور"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete */}
                            <button
                              onClick={() => setPostToDelete(post)}
                              className="p-1.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-400"
                              title="حذف المنشور"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between text-xs text-gray-400 pt-2 px-1">
              <span>صفحة {currentPage} من {totalPages}</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30"
                >
                  السابق
                </button>
                <button
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30"
                >
                  التالي
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          SUB-TAB 2: ADD / EDIT GRADE EXAM RESULTS
          ======================================================== */}
      {subTab === 'addGrade' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <h4 className="font-amiri font-bold text-2xl text-white">
                {editingGradePostId ? 'تعديل نتائج الاختبار' : 'إنشاء ونشر نتائج درجات جديدة'}
              </h4>
              <p className="text-xs text-gray-400">
                أدخل تفاصيل الاختبار والدرجات، مع خيار الحفظ كمسودة أو النشر المباشر لجميع الطلاب.
              </p>
            </div>
            {editingGradePostId && (
              <button
                onClick={resetGradeForm}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-gray-300"
              >
                إلغاء التعديل
              </button>
            )}
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleSaveGradePost('published'); }} className="space-y-4">
            {/* Row 1: Stage, Subject, Exam Type, Exam Date */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">المرحلة الدراسية</label>
                <select
                  value={gradeStageId}
                  onChange={(e) => {
                    const stId = e.target.value;
                    setGradeStageId(stId);
                    const stName = getStageName(stId);
                    setStudentRows(prev => prev.map(r => ({ ...r, gradeClass: stName })));
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                >
                  {stages.map((st) => (
                    <option key={st.id} value={st.id}>{st.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">المادة الدراسية</label>
                <input
                  type="text"
                  value={gradeSubject}
                  onChange={(e) => setGradeSubject(e.target.value)}
                  placeholder="مثال: علم الأحياء"
                  required
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">نوع الامتحان</label>
                <select
                  value={gradeExamType}
                  onChange={(e) => setGradeExamType(e.target.value)}
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                >
                  <option value="امتحان يومي تحريري">امتحان يومي تحريري</option>
                  <option value="امتحان شهري تحريري">امتحان شهري تحريري</option>
                  <option value="امتحان نصف السنة">امتحان نصف السنة</option>
                  <option value="امتحان فصلي شامل">امتحان فصلي شامل</option>
                  <option value="امتحان تراكمي دوري">امتحان تراكمي دوري</option>
                  <option value="امتحان وزاري تجريبي">امتحان وزاري تجريبي</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">تاريخ الامتحان</label>
                <input
                  type="date"
                  value={gradeExamDate}
                  onChange={(e) => setGradeExamDate(e.target.value)}
                  required
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>
            </div>

            {/* Row 2: Exam Name / Title & Max Score */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-8">
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                  اسم الامتحان أو موضوع الاختبار <span className="text-[#e9c978]">*</span>
                </label>
                <input
                  type="text"
                  value={gradeTitle}
                  onChange={(e) => setGradeTitle(e.target.value)}
                  placeholder="مثال: امتحان الأحياء الشهري الأول - الفصل الأول: الخلية وتركيبها"
                  required
                  className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:border-[#e9c978]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">الدرجة النهائية</label>
                <input
                  type="number"
                  value={gradeMaxScore}
                  onChange={(e) => setGradeMaxScore(Number(e.target.value))}
                  className="w-full py-3 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs text-center"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">درجة النجاح</label>
                <input
                  type="number"
                  value={gradeMinPassing}
                  onChange={(e) => setGradeMinPassing(Number(e.target.value))}
                  className="w-full py-3 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs text-center"
                />
              </div>
            </div>

            {/* ========================================================
                SIMPLE STUDENTS TABLE (نظام إدخال درجات الطلاب البسيط)
                ======================================================== */}
            <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-[#e9c978]/25 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
                <div>
                  <h5 className="font-bold text-sm text-white flex items-center gap-2">
                    <span className="text-[#e9c978]">📋</span>
                    جدول درجات الطلاب (اسم الطالب، صفه، شعبته، درجته)
                  </h5>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    أضف الطلاب مباشرة في الجدول أو استخدم خاصية اللصق السريع لاستيراد الدرجات دفعة واحدة
                  </p>
                </div>

                <div className="flex items-center gap-2 self-stretch sm:self-auto">
                  <button
                    type="button"
                    onClick={() => setShowBulkPasteModal(true)}
                    className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold transition flex items-center gap-1.5 border border-white/10"
                  >
                    <span>📋 لصق سريع للأسماء والدرجات</span>
                  </button>

                  <button
                    type="button"
                    onClick={addStudentRow}
                    className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] text-xs font-black transition flex items-center gap-1.5 shadow-md hover:brightness-110 active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة طالب</span>
                  </button>
                </div>
              </div>

              {/* Editable Table */}
              <div className="rounded-xl border border-white/10 overflow-x-auto bg-black/20">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-white/5 border-b border-white/10 text-gray-300 font-bold">
                      <th className="p-2.5 text-center w-10">#</th>
                      <th className="p-2.5 min-w-[160px]">اسم الطالب الرباعي</th>
                      <th className="p-2.5 min-w-[110px]">الصف الدراسي</th>
                      <th className="p-2.5 min-w-[70px]">الشعبة</th>
                      <th className="p-2.5 min-w-[90px] text-center">الدرجة ({gradeMaxScore})</th>
                      <th className="p-2.5 min-w-[90px] text-center">التقدير</th>
                      <th className="p-2.5 min-w-[130px]">ملاحظة الأستاذ</th>
                      <th className="p-2.5 text-center w-12">حذف</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {studentRows.map((row, idx) => (
                      <tr key={row.id} className="hover:bg-white/5 transition">
                        <td className="p-2 text-center text-gray-500 font-mono">
                          {idx + 1}
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={row.studentName}
                            onChange={(e) => updateStudentRow(row.id, 'studentName', e.target.value)}
                            placeholder="مثال: أحمد علي عبد الله"
                            className="w-full py-1.5 px-2.5 rounded-lg bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={row.gradeClass}
                            onChange={(e) => updateStudentRow(row.id, 'gradeClass', e.target.value)}
                            placeholder="الصف"
                            className="w-full py-1.5 px-2 rounded-lg bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={row.section}
                            onChange={(e) => updateStudentRow(row.id, 'section', e.target.value)}
                            placeholder="أ / ب / ج"
                            className="w-full py-1.5 px-2 rounded-lg bg-black/50 border border-white/10 text-white text-xs text-center focus:outline-none focus:border-[#e9c978]"
                          />
                        </td>
                        <td className="p-2 text-center">
                          <input
                            type="number"
                            value={row.score}
                            onChange={(e) => updateStudentRow(row.id, 'score', Number(e.target.value))}
                            className="w-20 py-1.5 px-2 rounded-lg bg-black/50 border border-white/10 text-white text-xs font-bold text-center focus:outline-none focus:border-[#e9c978]"
                          />
                        </td>
                        <td className="p-2 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            row.score >= 90 ? 'bg-emerald-500/20 text-emerald-400' :
                            row.score >= 80 ? 'bg-blue-500/20 text-blue-400' :
                            row.score >= 70 ? 'bg-amber-500/20 text-amber-400' :
                            row.score >= gradeMinPassing ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {row.rating || (row.score >= 90 ? 'ممتاز' : row.score >= 80 ? 'جيد جداً' : row.score >= 50 ? 'ناجح' : 'راسب')}
                          </span>
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={row.note || ''}
                            onChange={(e) => updateStudentRow(row.id, 'note', e.target.value)}
                            placeholder="ملاحظة أو توجيه..."
                            className="w-full py-1.5 px-2 rounded-lg bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                          />
                        </td>
                        <td className="p-2 text-center">
                          <button
                            type="button"
                            onClick={() => removeStudentRow(row.id)}
                            className="p-1 rounded-lg hover:bg-red-500/20 text-gray-400 hover:text-red-400"
                            title="حذف هذا السطر"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Quick Summary Pill Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs text-gray-300">
                <div className="flex items-center gap-4">
                  <span>إجمالي الطلاب: <strong className="text-[#e9c978]">{studentRows.filter(r => r.studentName.trim()).length}</strong></span>
                  <span>أعلى درجة: <strong className="text-emerald-400">{studentRows.length > 0 ? Math.max(...studentRows.map(r => r.score || 0)) : 0}</strong></span>
                  <span>متوسط الدرجات: <strong className="text-blue-400">{studentRows.length > 0 ? Math.round(studentRows.reduce((a, b) => a + (b.score || 0), 0) / studentRows.length) : 0}</strong></span>
                </div>

                <button
                  type="button"
                  onClick={addStudentRow}
                  className="text-xs text-[#e9c978] hover:underline font-bold"
                >
                  + سطر طالب إضافي
                </button>
              </div>
            </div>

            {/* Modal: Bulk Paste Students */}
            {showBulkPasteModal && (
              <div className="p-4 rounded-2xl bg-[#09152a] border border-[#e9c978]/40 space-y-3">
                <div className="flex items-center justify-between">
                  <h6 className="font-bold text-xs text-[#e9c978]">
                    📋 لصق سريع لأسماء ودرجات الطلاب (من ملف Excel أو نص):
                  </h6>
                  <button
                    type="button"
                    onClick={() => setShowBulkPasteModal(false)}
                    className="text-xs text-gray-400 hover:text-white"
                  >
                    إلغاء
                  </button>
                </div>
                <p className="text-[11px] text-gray-300">
                  اكتب أو الصق سطراً لكل طالب بالصيغة: <code>اسم الطالب, الصف, الشعبة, الدرجة</code> (أو افصل بينها بفواصل أو مسافات):
                </p>
                <textarea
                  rows={5}
                  value={bulkPasteText}
                  onChange={(e) => setBulkPasteText(e.target.value)}
                  placeholder="محمد أحمد, السادس العلمي, أ, 98&#10;فاطمة علي, السادس العلمي, أ, 95&#10;حسن كريم, السادس العلمي, ب, 88"
                  className="w-full p-3 rounded-xl bg-black/60 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-[#e9c978]"
                  dir="rtl"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowBulkPasteModal(false)}
                    className="px-3 py-1.5 rounded-lg bg-white/10 text-xs text-gray-300"
                  >
                    تراجع
                  </button>
                  <button
                    type="button"
                    onClick={handleApplyBulkPaste}
                    className="px-4 py-1.5 rounded-lg bg-[#e9c978] text-[#08111e] text-xs font-bold"
                  >
                    تحويل وإدراج في الجدول
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">رابط ملف كشف النتائج أو صورة المخطط (اختياري)</label>
                <input
                  type="text"
                  value={gradeAttachmentUrl}
                  onChange={(e) => setGradeAttachmentUrl(e.target.value)}
                  placeholder="https://... رابط صورة أو PDF"
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">اسم الملف المرفق (اختياري)</label>
                <input
                  type="text"
                  value={gradeAttachmentName}
                  onChange={(e) => setGradeAttachmentName(e.target.value)}
                  placeholder="مثال: كشف أسماء الأوائل والدرجات.pdf"
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1.5">ملاحظات وتوجيهات إضافية للطلاب</label>
              <textarea
                value={gradeNotes}
                onChange={(e) => setGradeNotes(e.target.value)}
                placeholder="توجيهات للأستاذ بشأن الأخطاء الشائعة في الامتحان أو موعد الإعادة..."
                rows={2}
                className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
              />
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:flex-1 py-3 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs sm:text-sm shadow-xl hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Award className="w-4 h-4" />
                <span>{editingGradePostId ? 'تحديث ونشر التعديلات' : 'نشر النتائج الآن للطلاب 🌐'}</span>
              </button>

              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => handleSaveGradePost('draft')}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/10 text-white font-bold text-xs transition disabled:opacity-50"
              >
                حفظ كمسودة
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================
          SUB-TAB 3: ADD / EDIT HOMEWORK
          ======================================================== */}
      {subTab === 'addHomework' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-[#0a1220] border border-[#e9c978]/30 shadow-2xl space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <h4 className="font-amiri font-bold text-2xl text-white">
                {editingHwPostId ? 'تعديل الواجب المدرسي' : 'إضافة ونشر واجب مدرسي جديد'}
              </h4>
              <p className="text-xs text-gray-400">
                حدد المرحلة الدراسية وموعد التسليم وتفاصيل الواجب أو التحضير المطلوب.
              </p>
            </div>
            {editingHwPostId && (
              <button
                onClick={resetHwForm}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-gray-300"
              >
                إلغاء التعديل
              </button>
            )}
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleSaveHomeworkPost('published'); }} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">المرحلة الدراسية</label>
                <select
                  value={hwStageId}
                  onChange={(e) => setHwStageId(e.target.value)}
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                >
                  {stages.map((st) => (
                    <option key={st.id} value={st.id}>{st.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">المادة الدراسية</label>
                <input
                  type="text"
                  value={hwSubject}
                  onChange={(e) => setHwSubject(e.target.value)}
                  placeholder="مثال: علم الأحياء"
                  required
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">موعد التسليم النهائي (اختياري)</label>
                <input
                  type="date"
                  value={hwDueDate}
                  onChange={(e) => setHwDueDate(e.target.value)}
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1.5">عنوان الواجب</label>
              <input
                type="text"
                value={hwTitle}
                onChange={(e) => setHwTitle(e.target.value)}
                placeholder="مثال: حل أسئلة الفصل الثالث ورسم مخطط التكاثر في الفيروسات"
                required
                className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:border-[#e9c978]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1.5">تفاصيل الواجب أو التحضير المطلوب</label>
              <textarea
                value={hwDetails}
                onChange={(e) => setHwDetails(e.target.value)}
                placeholder="اكتب الصفحات المطلوبة، أرقام الأسئلة، وملاحظات التحضير للامتحان اليومي..."
                rows={4}
                required
                className="w-full py-3 px-4 rounded-xl bg-black/50 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:border-[#e9c978]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">رابط المرفق (PDF أو صورة ملخص)</label>
                <input
                  type="text"
                  value={hwAttachmentUrl}
                  onChange={(e) => setHwAttachmentUrl(e.target.value)}
                  placeholder="https://... رابط ملف المرفق"
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">اسم المرفق</label>
                <input
                  type="text"
                  value={hwAttachmentName}
                  onChange={(e) => setHwAttachmentName(e.target.value)}
                  placeholder="مثال: ورقة عمل - التكاثر في البكتيريا.pdf"
                  className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-1.5">ملاحظات إضافية من الإدارة</label>
              <textarea
                value={hwNotes}
                onChange={(e) => setHwNotes(e.target.value)}
                placeholder="توجيهات حول آلية الفحص أو كويز مفاجئ..."
                rows={2}
                className="w-full py-2.5 px-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs focus:outline-none focus:border-[#e9c978]"
              />
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:flex-1 py-3 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-xs sm:text-sm shadow-xl hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <FileText className="w-4 h-4" />
                <span>{editingHwPostId ? 'تحديث ونشر الواجب' : 'نشر الواجب لطلاب المرحلة 🌐'}</span>
              </button>

              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => handleSaveHomeworkPost('draft')}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/10 text-white font-bold text-xs transition disabled:opacity-50"
              >
                حفظ كمسودة
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================
          SUB-TAB 4: MANAGE 6 STAGES
          ======================================================== */}
      {subTab === 'stages' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-[#0a1220] border border-white/10 text-xs text-gray-300 flex items-center justify-between">
            <span>التحكم في ظهور أو إخفاء المراحل الدراسية الست لطلاب المنصة:</span>
            <span className="text-[11px] text-[#e9c978]">التعديل ينعكس فورياً لجميع الزوار</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {stages.map((st) => {
              const stagePosts = posts.filter((p) => p.stageId === st.id);
              const isActive = st.isActive !== false;

              return (
                <div
                  key={st.id}
                  className="p-5 rounded-3xl bg-[#0a1220] border border-white/10 shadow-lg space-y-4 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-2xl">
                        {st.icon}
                      </div>

                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${
                        isActive
                          ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                          : 'bg-red-500/15 text-red-400 border-red-500/30'
                      }`}>
                        {isActive ? 'مفعلة ونشطة ✅' : 'مخفية ⛔'}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-amiri font-bold text-lg text-white">
                        {st.name}
                      </h4>
                      <p className="text-xs text-gray-400">{st.alias}</p>
                    </div>

                    <div className="text-[11px] text-gray-400 flex items-center justify-between pt-1">
                      <span>إجمالي المنشورات:</span>
                      <strong className="text-white">{stagePosts.length} منشور</strong>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                    <button
                      onClick={() => handleToggleStageActive(st)}
                      className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs transition ${
                        isActive
                          ? 'bg-red-500/15 hover:bg-red-500/25 text-red-400 border border-red-500/30'
                          : 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {isActive ? 'إخفاء المرحلة عن الطلاب' : 'تفعيل المرحلة للطلاب'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================
          SUB-TAB 5: AUDIT LOG
          ======================================================== */}
      {subTab === 'audit' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-2xl bg-[#0a1220] border border-white/10 text-xs text-gray-400">
            <span>سجل العمليات الإدارية والإجراءات الحساسة الخاصة بقسم طلاب المعهد:</span>
            <span>{auditLogs.length} عملية مسجلة</span>
          </div>

          <div className="overflow-x-auto rounded-2xl bg-[#0a1220] border border-white/10 shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-white/5 text-gray-400 border-b border-white/10 font-bold">
                <tr>
                  <th className="py-3 px-4">نوع العملية</th>
                  <th className="py-3 px-4">الهدف / العنوان</th>
                  <th className="py-3 px-4">نوع المحتوى</th>
                  <th className="py-3 px-4">المسؤول</th>
                  <th className="py-3 px-4">التاريخ والوقت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-gray-200">
                {auditLogs.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-gray-400">
                      لا توجد عمليات مسجلة حتى الآن.
                    </td>
                  </tr>
                ) : (
                  auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-white/5 transition">
                      <td className="py-3 px-4 font-bold text-[#e9c978]">{log.action}</td>
                      <td className="py-3 px-4 font-semibold text-white max-w-[280px] truncate">
                        {log.targetTitle}
                      </td>
                      <td className="py-3 px-4 text-gray-400">
                        {log.targetType === 'grade' ? 'درجات' : log.targetType === 'homework' ? 'واجب' : 'مرحلة'}
                      </td>
                      <td className="py-3 px-4 text-gray-300">{log.adminName}</td>
                      <td className="py-3 px-4 text-gray-400 font-mono text-[11px]" dir="ltr">
                        {new Date(log.timestamp).toLocaleString('ar-IQ')}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {postToDelete && (
        <div className="fixed inset-0 z-[1200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div
            className="w-full max-w-sm rounded-3xl bg-[#0a1220] border border-red-500/40 p-6 space-y-4 text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/20 border border-red-500/40 text-red-400 flex items-center justify-center text-2xl mx-auto">
              ⚠️
            </div>
            <h4 className="font-amiri font-bold text-xl text-white">تأكيد حذف المنشور</h4>
            <p className="text-xs text-gray-300 leading-relaxed">
              هل أنت متأكد من رغبتك في حذف المنشور التالي نهائياً؟
              <br />
              <strong className="text-[#e9c978] block mt-1">"{postToDelete.title}"</strong>
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleConfirmDeletePost}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs transition"
              >
                نعم، احذف نهائياً
              </button>
              <button
                onClick={() => setPostToDelete(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 text-xs font-semibold"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Preview Modal before or after publishing */}
      {previewPost && (
        <div className="fixed inset-0 z-[1200] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div
            className="w-full max-w-2xl rounded-3xl bg-[#0a1220] border border-[#e9c978]/40 p-6 space-y-4 max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#e9c978]/15 text-[#e9c978]">
                  معاينة المنشور ({previewPost.type === 'grade' ? 'درجات' : 'واجب'})
                </span>
                <span className="text-xs text-gray-400">· {getStageName(previewPost.stageId)}</span>
              </div>
              <button
                onClick={() => setPreviewPost(null)}
                className="w-8 h-8 rounded-lg bg-white/5 text-gray-400 hover:text-white flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <h3 className="font-amiri font-bold text-2xl text-white">
                {previewPost.title}
              </h3>

              <div className="flex items-center gap-4 text-xs text-gray-300">
                <span>المادة: <b className="text-white">{previewPost.subject}</b></span>
                <span>التاريخ: <b className="text-white">{previewPost.date}</b></span>
                {previewPost.dueDate && (
                  <span>موعد التسليم: <b className="text-amber-300">{previewPost.dueDate}</b></span>
                )}
              </div>

              {previewPost.details && (
                <div className="p-4 rounded-2xl bg-black/40 border border-white/5 text-xs text-gray-200 whitespace-pre-line leading-relaxed">
                  {previewPost.details}
                </div>
              )}

              {previewPost.notes && (
                <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-gray-300">
                  <strong className="text-[#e9c978] block mb-0.5">ملاحظات:</strong>
                  {previewPost.notes}
                </div>
              )}

              {previewPost.records && previewPost.records.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-gray-400 block">
                    سجلات الدرجات بالأكواد ({previewPost.records.length} طالب):
                  </span>
                  <div className="max-h-48 overflow-y-auto rounded-xl border border-white/10 bg-black/30 p-2 text-xs divide-y divide-white/5">
                    {previewPost.records.map((r, idx) => (
                      <div key={idx} className="flex items-center justify-between py-1.5 px-2">
                        <span className="font-mono font-bold text-[#e9c978]">{r.studentCode}</span>
                        <span className="font-mono text-white">{r.score} / {previewPost.maxScore || 100}</span>
                        <span className="text-gray-400 text-[11px]">{r.rating || 'ناجح'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {previewPost.attachmentUrl && (
                <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
                  <span>المرفق: {previewPost.attachmentName || previewPost.attachmentUrl}</span>
                  <a
                    href={previewPost.attachmentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#e9c978] font-bold"
                  >
                    عرض الرابط ↗
                  </a>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-white/10 flex justify-end">
              <button
                onClick={() => setPreviewPost(null)}
                className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs"
              >
                إغلاق المعاينة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
