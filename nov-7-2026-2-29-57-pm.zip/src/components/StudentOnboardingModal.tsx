import React, { useState, useEffect, useMemo } from 'react';
import { 
  GraduationCap, 
  Dna, 
  User, 
  Calendar, 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle2, 
  Copy, 
  Check, 
  Sparkles, 
  Edit3, 
  School, 
  BookOpen, 
  X,
  ShieldCheck
} from 'lucide-react';
import { playClickSound, playSuccessSound } from '../utils/audioEffects';
import { registerStudentInCloud, loginWithGoogle, syncAuthUserWithProfile } from '../services/firebase';

export interface UserProfile {
  uid: string;
  name: string;
  track: 'school';
  grade: string;
  birthDate: string;
  birthYear: number;
  registeredAt: string;
}

interface StudentOnboardingModalProps {
  isOpen: boolean;
  initialProfile?: UserProfile | null;
  onComplete: (profile: UserProfile) => void;
  onClose?: () => void;
}

const ARABIC_MONTHS = [
  { value: 1, name: 'كانون الثاني (1)' },
  { value: 2, name: 'شباط (2)' },
  { value: 3, name: 'آذار (3)' },
  { value: 4, name: 'نيسان (4)' },
  { value: 5, name: 'أيار (5)' },
  { value: 6, name: 'حزيران (6)' },
  { value: 7, name: 'تموز (7)' },
  { value: 8, name: 'آب (8)' },
  { value: 9, name: 'أيلول (9)' },
  { value: 10, name: 'تشرين الأول (10)' },
  { value: 11, name: 'تشرين الثاني (11)' },
  { value: 12, name: 'كانون الأول (12)' }
];

const SCHOOL_GRADES = [
  { id: 'g1', name: 'الأول المتوسط', stage: 'متوسطة' },
  { id: 'g2', name: 'الثاني المتوسط', stage: 'متوسطة' },
  { id: 'g3', name: 'الثالث المتوسط', stage: 'متوسطة' },
  { id: 'g4', name: 'الرابع العلمي', stage: 'إعدادية' },
  { id: 'g5', name: 'الخامس العلمي', stage: 'إعدادية' },
  { id: 'g6', name: 'السادس العلمي', stage: 'إعدادية - وزاري' }
];

function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

function generateUID(): string {
  // Format: UID-BIO-XXXX-XXXX
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let part1 = '';
  let part2 = '';
  for (let i = 0; i < 4; i++) {
    part1 += chars.charAt(Math.floor(Math.random() * chars.length));
    part2 += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `UID-BIO-${part1}-${part2}`;
}

export const StudentOnboardingModal: React.FC<StudentOnboardingModalProps> = ({
  isOpen,
  initialProfile,
  onComplete,
  onClose
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form Fields
  const [track, setTrack] = useState<'school'>('school');
  const [grade, setGrade] = useState<string>('g6');
  const [name, setName] = useState<string>('');
  
  // Birth date state
  const [birthYear, setBirthYear] = useState<number>(2007);
  const [birthMonth, setBirthMonth] = useState<number>(4);
  const [birthDay, setBirthDay] = useState<number>(15);

  const [uid, setUid] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [copiedUid, setCopiedUid] = useState(false);

  // Quick Google Sign-In for students directly from onboarding
  const handleGoogleOnboarding = async () => {
    setIsGoogleLoading(true);
    setErrorMessage(null);
    try {
      playClickSound();
      const cred = await loginWithGoogle();
      const user = cred.user;
      
      const formattedBirthDate = `${birthYear}-${String(birthMonth).padStart(2, '0')}-${String(birthDay).padStart(2, '0')}`;
      const studentName = (user.displayName || name || user.email?.split('@')[0] || 'طالب مسجل').trim();

      const profile = await syncAuthUserWithProfile(user, {
        name: studentName,
        grade,
        track: 'school'
      });

      profile.birthDate = formattedBirthDate;
      profile.birthYear = birthYear;

      try {
        localStorage.setItem('biolab_user_profile', JSON.stringify(profile));
        localStorage.setItem('biolab_session_id', profile.uid);
        localStorage.setItem('biolab_student_registered', 'true');
      } catch (e) {}

      // Write to central Firestore cloud database
      try {
        await registerStudentInCloud(profile);
      } catch (cloudErr) {
        console.warn('Direct cloud registration notice:', cloudErr);
      }

      // Sync with backend API
      try {
        await fetch('/api/users/profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(profile)
        });
      } catch (err) {}

      playSuccessSound();
      onComplete(profile);
    } catch (err: any) {
      console.error('Google onboarding error:', err);
      if (err?.code !== 'auth/popup-closed-by-user' && err?.code !== 'auth/cancelled-popup-request') {
        setErrorMessage(err?.message || 'تعذر تسجيل الدخول بحساب Google، يرجى المحاولة لاحقاً');
      }
    } finally {
      setIsGoogleLoading(false);
    }
  };

  // Initialize or pre-fill
  useEffect(() => {
    if (initialProfile) {
      setTrack(initialProfile.track || 'school');
      setGrade(initialProfile.grade || 'g6');
      setName(initialProfile.name || '');
      setUid(initialProfile.uid || generateUID());
      if (initialProfile.birthDate) {
        const parts = initialProfile.birthDate.split('-');
        if (parts.length === 3) {
          setBirthYear(parseInt(parts[0], 10) || 2007);
          setBirthMonth(parseInt(parts[1], 10) || 4);
          setBirthDay(parseInt(parts[2], 10) || 15);
        }
      }
    } else {
      // Check if existing saved UID in storage
      try {
        const saved = localStorage.getItem('biolab_user_profile');
        if (saved) {
          const parsed = JSON.parse(saved);
          setTrack(parsed.track || 'school');
          setGrade(parsed.grade || 'g6');
          setName(parsed.name || '');
          setUid(parsed.uid || generateUID());
          if (parsed.birthDate) {
            const parts = parsed.birthDate.split('-');
            if (parts.length === 3) {
              setBirthYear(parseInt(parts[0], 10) || 2007);
              setBirthMonth(parseInt(parts[1], 10) || 4);
              setBirthDay(parseInt(parts[2], 10) || 15);
            }
          }
        } else {
          setUid(generateUID());
        }
      } catch (e) {
        setUid(generateUID());
      }
    }
  }, [initialProfile, isOpen]);

  // Adjust max days when month or year changes
  const maxDays = useMemo(() => {
    return getDaysInMonth(birthYear, birthMonth);
  }, [birthYear, birthMonth]);

  useEffect(() => {
    if (birthDay > maxDays) {
      setBirthDay(maxDays);
    }
  }, [maxDays, birthDay]);

  // Calculate age estimate
  const estimatedAge = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;
    let age = currentYear - birthYear;
    if (currentMonth < birthMonth) age--;
    return Math.max(age, 5);
  }, [birthYear, birthMonth]);

  if (!isOpen) return null;

  // Step 1: Validate Track Selection
  const handleProceedFromStep1 = () => {
    playClickSound();
    setErrorMessage(null);
    setStep(2);
  };

  // Step 2: Validate Name
  const handleProceedFromStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    const trimmed = name.trim();
    if (!trimmed) {
      setErrorMessage('يرجى كتابة اسمك للمتابعة.');
      return;
    }
    if (trimmed.length < 2) {
      setErrorMessage('يرجى إدخال اسم صحيح مكون من حرفين على الأقل.');
      return;
    }
    playClickSound();
    setStep(3);
  };

  // Step 3: Validate Birth Date
  const handleProceedFromStep3 = () => {
    setErrorMessage(null);
    const now = new Date();
    const entered = new Date(birthYear, birthMonth - 1, birthDay);
    if (entered > now) {
      setErrorMessage('تاريخ الميلاد لا يمكن أن يكون في المستقبل.');
      return;
    }
    if (birthYear < 1940 || birthYear > now.getFullYear() - 5) {
      setErrorMessage('يرجى اختيار سنة ميلاد صحيحة.');
      return;
    }
    playClickSound();
    setStep(4);
  };

  // Final Confirmation & Submission
  const handleFinalConfirm = async () => {
    setIsSubmitting(true);
    playClickSound();

    const formattedBirthDate = `${birthYear}-${String(birthMonth).padStart(2, '0')}-${String(birthDay).padStart(2, '0')}`;
    const resolvedUid = uid || generateUID();

    const profileData: UserProfile = {
      uid: resolvedUid,
      name: name.trim(),
      track: 'school',
      grade,
      birthDate: formattedBirthDate,
      birthYear,
      registeredAt: new Date().toISOString()
    };

    // Save locally
    try {
      localStorage.setItem('biolab_user_profile', JSON.stringify(profileData));
      localStorage.setItem('biolab_session_id', resolvedUid);
      localStorage.setItem('biolab_student_registered', 'true');
    } catch (e) {}

    // 1) Write to central Firestore cloud database
    try {
      await registerStudentInCloud(profileData);
    } catch (cloudErr) {
      console.warn('Direct cloud registration notice:', cloudErr);
    }

    // 2) Sync with backend API
    try {
      await fetch('/api/users/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profileData)
      });
    } catch (err) {
      console.warn('Profile synced locally, remote sync queued:', err);
    }

    playSuccessSound();
    setIsSubmitting(false);
    onComplete(profileData);
  };

  const copyToClipboard = (text: string) => {
    playClickSound();
    try {
      navigator.clipboard.writeText(text);
      setCopiedUid(true);
      setTimeout(() => setCopiedUid(false), 2000);
    } catch (e) {}
  };

  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fadeIn overflow-y-auto">
      <div 
        className="relative w-full max-w-lg rounded-3xl bg-[#0a1220] border border-[#e9c978]/40 shadow-[0_20px_60px_rgba(0,0,0,0.85)] p-6 sm:p-8 text-[#eaf0f8] my-auto overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Decorative Glow Elements */}
        <div className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-[#e9c978]/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-44 h-44 rounded-full bg-[#0fb98a]/15 blur-3xl pointer-events-none" />

        {/* Close Button (only if initial profile exists / editing mode) */}
        {onClose && (
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="absolute top-5 left-5 w-9 h-9 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white flex items-center justify-center transition border border-white/10"
            title="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Step Progress Tracker */}
        <div className="flex items-center justify-between gap-2 mb-6 px-1">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex-1 flex flex-col items-center gap-1.5">
              <div 
                className={`w-full h-1.5 rounded-full transition-all duration-300 ${
                  s < step 
                    ? 'bg-[#0fb98a]' 
                    : s === step 
                    ? 'bg-[#e9c978]' 
                    : 'bg-white/10'
                }`}
              />
              <span className={`text-[10px] font-bold ${
                s === step ? 'text-[#e9c978]' : s < step ? 'text-[#0fb98a]' : 'text-gray-500'
              }`}>
                {s === 1 && 'المسار'}
                {s === 2 && 'الاسم'}
                {s === 3 && 'الميلاد'}
                {s === 4 && 'التأكيد'}
              </span>
            </div>
          ))}
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded-2xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs text-center font-bold animate-fadeIn">
            ⚠️ {errorMessage}
          </div>
        )}

        {/* ==================================================== */}
        {/* STEP 1: اختيار المرحلة والصف الدراسي */}
        {/* ==================================================== */}
        {step === 1 && (
          <div className="space-y-5 animate-fadeIn">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#c9a24a] to-[#e9c978] text-[#04080f] flex items-center justify-center text-2xl mx-auto shadow-lg shadow-[#c9a24a]/25 border border-[#e9c978]/50">
                🧬
              </div>
              <h2 className="font-amiri font-bold text-2xl sm:text-3xl text-white">
                اختر مرحلتك الدراسية
              </h2>
              <p className="text-xs text-gray-300 leading-relaxed max-w-sm mx-auto">
                حدد صفك الدراسي لعرض المنهج المعتمد، المحاضرات المرئية، والملازم والكتب المخصصة لك.
              </p>
            </div>

            {/* Quick Google Sign In for Students */}
            <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-blue-950/40 via-black/50 to-[#e9c978]/10 border border-blue-500/30 text-center space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-[#e9c978]">تسجيل دخول سريع للطلاب</span>
                <span className="px-2 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-300 font-bold border border-blue-500/30">
                  Google Auth 🌐
                </span>
              </div>
              <p className="text-[11px] text-gray-300 leading-relaxed text-right">
                سجّل الدخول بحساب Google بنقرة واحدة لحفظ تقدمك ومتابعة دروس وملازم المنصة فوراً.
              </p>
              <button
                type="button"
                onClick={handleGoogleOnboarding}
                disabled={isGoogleLoading || isSubmitting}
                className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-gray-100 text-gray-800 font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 transition shadow-md active:scale-98 disabled:opacity-50"
              >
                {isGoogleLoading ? (
                  <span className="animate-spin text-gray-700">⌛</span>
                ) : (
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                )}
                <span>{isGoogleLoading ? 'جاري الاتصال بحساب Google...' : 'المتابعة السريعة باستخدام حساب Google'}</span>
              </button>
            </div>

            <div className="relative flex items-center justify-center my-1">
              <div className="border-t border-white/10 w-full" />
              <span className="bg-[#0a1220] px-3 text-[11px] text-gray-500 absolute font-medium">
                أو اختر مرحلتك وتابع يدوياً
              </span>
            </div>

            {/* School Grade Selection Grid */}
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-bold text-[#e9c978]">
                المراحل الدراسية المعتمدة (من الأول المتوسط إلى السادس العلمي):
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {SCHOOL_GRADES.map((g) => {
                  const isSelected = grade === g.id;
                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setGrade(g.id);
                        setTrack('school');
                      }}
                      className={`p-3.5 rounded-2xl border-2 transition-all duration-200 text-right flex items-center justify-between ${
                        isSelected
                          ? 'bg-[#e9c978]/15 border-[#e9c978] shadow-lg shadow-[#e9c978]/15 scale-[1.01]'
                          : 'bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/[0.08]'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <div className="font-bold text-sm text-white flex items-center gap-2">
                          <span>{g.name}</span>
                          {g.id === 'g6' && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#e9c978]/25 text-[#e9c978]">
                              الوزاري
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-gray-400 block">{g.stage}</span>
                      </div>
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        isSelected ? 'border-[#e9c978] bg-[#e9c978] text-[#08111e]' : 'border-gray-500'
                      }`}>
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              type="button"
              onClick={handleProceedFromStep1}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-sm shadow-xl hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2 mt-4"
            >
              <span>متابعة الخطوة التالية (الاسم والبيانات)</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* ==================================================== */}
        {/* STEP 2: إدخال اسم المستخدم */}
        {/* ==================================================== */}
        {step === 2 && (
          <form onSubmit={handleProceedFromStep2} className="space-y-5 animate-fadeIn">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-[#e9c978]/15 border border-[#e9c978]/30 text-[#e9c978] flex items-center justify-center text-2xl mx-auto shadow-md">
                <User className="w-7 h-7" />
              </div>
              <h2 className="font-amiri font-bold text-2xl sm:text-3xl text-white">
                ما اسمك؟
              </h2>
              <p className="text-xs text-gray-300 leading-relaxed max-w-sm mx-auto">
                اكتب الاسم الذي ترغب في ظهوره داخل التطبيق وفي سجلات التقييم ورخصة الحساب.
              </p>
            </div>

            <div className="space-y-2 text-right pt-2">
              <label className="block text-xs font-bold text-gray-200">
                اسم الطالب الكامل
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: علي كرار البصري أو د. زينب الموسوي"
                  required
                  autoFocus
                  className="w-full py-3.5 px-4 rounded-2xl bg-black/60 border border-white/20 focus:border-[#e9c978] text-white placeholder:text-gray-500 text-sm focus:outline-none transition shadow-inner"
                />
              </div>
              <span className="text-[11px] text-gray-400 block px-1">
                الاسم سيظهر في أعلى التطبيق وبطاقة الهوية الدراسية الخاصة بك.
              </span>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setStep(1);
                }}
                className="py-3 px-4 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 text-gray-300 text-xs font-bold transition flex items-center gap-1.5"
              >
                <ArrowRight className="w-4 h-4" />
                <span>رجوع</span>
              </button>

              <button
                type="submit"
                className="flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-sm shadow-xl hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2"
              >
                <span>متابعة</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}

        {/* ==================================================== */}
        {/* STEP 3: تاريخ الميلاد واحتساب العمر بدقة */}
        {/* ==================================================== */}
        {step === 3 && (
          <div className="space-y-5 animate-fadeIn">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-[#0fb98a]/15 border border-[#0fb98a]/30 text-[#0fb98a] flex items-center justify-center text-2xl mx-auto shadow-md">
                <Calendar className="w-7 h-7" />
              </div>
              <h2 className="font-amiri font-bold text-2xl sm:text-3xl text-white">
                ما تاريخ ميلادك؟
              </h2>
              <p className="text-xs text-gray-300 leading-relaxed max-w-sm mx-auto">
                يساعدنا تاريخ الميلاد في تخصيص التوصيات التعليمية وتوثيق الحساب الأكاديمي.
              </p>
            </div>

            <div className="space-y-4 pt-2 text-right">
              {/* Selectors Grid: Year, Month, Day */}
              <div className="grid grid-cols-3 gap-2.5">
                {/* Year */}
                <div className="space-y-1.5">
                  <label className="block text-[11px] font-bold text-gray-300">
                    السنة
                  </label>
                  <select
                    value={birthYear}
                    onChange={(e) => {
                      playClickSound();
                      setBirthYear(parseInt(e.target.value, 10));
                    }}
                    className="w-full py-3 px-2 rounded-2xl bg-black/60 border border-white/20 text-white text-xs font-bold focus:outline-none focus:border-[#e9c978]"
                  >
                    {Array.from({ length: 65 }, (_, i) => 2022 - i).map((y) => (
                      <option key={y} value={y} className="bg-[#0a1220] text-white">
                        {y}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Month */}
                <div className="space-y-1.5">
                  <label className="block text-[11px] font-bold text-gray-300">
                    الشهر
                  </label>
                  <select
                    value={birthMonth}
                    onChange={(e) => {
                      playClickSound();
                      setBirthMonth(parseInt(e.target.value, 10));
                    }}
                    className="w-full py-3 px-2 rounded-2xl bg-black/60 border border-white/20 text-white text-xs font-bold focus:outline-none focus:border-[#e9c978]"
                  >
                    {ARABIC_MONTHS.map((m) => (
                      <option key={m.value} value={m.value} className="bg-[#0a1220] text-white">
                        {m.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Day */}
                <div className="space-y-1.5">
                  <label className="block text-[11px] font-bold text-gray-300">
                    اليوم
                  </label>
                  <select
                    value={birthDay}
                    onChange={(e) => {
                      playClickSound();
                      setBirthDay(parseInt(e.target.value, 10));
                    }}
                    className="w-full py-3 px-2 rounded-2xl bg-black/60 border border-white/20 text-white text-xs font-bold focus:outline-none focus:border-[#e9c978]"
                  >
                    {Array.from({ length: maxDays }, (_, i) => i + 1).map((d) => (
                      <option key={d} value={d} className="bg-[#0a1220] text-white">
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Age Summary Pill */}
              <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
                <span className="text-gray-400">العمر التقريبي المحسوب:</span>
                <span className="font-bold text-[#e9c978] font-mono text-sm">
                  {estimatedAge} سنة
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setStep(2);
                }}
                className="py-3 px-4 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 text-gray-300 text-xs font-bold transition flex items-center gap-1.5"
              >
                <ArrowRight className="w-4 h-4" />
                <span>رجوع</span>
              </button>

              <button
                type="button"
                onClick={handleProceedFromStep3}
                className="flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#e9c978] to-[#c9a24a] text-[#08111e] font-bold text-sm shadow-xl hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2"
              >
                <span>مراجعة ملخص الحساب</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* STEP 4: بطاقة الملخص والتأكيد النهائي ومعرّف UID */}
        {/* ==================================================== */}
        {step === 4 && (
          <div className="space-y-5 animate-fadeIn">
            <div className="text-center space-y-1.5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#0fb98a] to-[#2dd4bf] text-[#04080f] flex items-center justify-center text-2xl mx-auto shadow-lg shadow-[#0fb98a]/20">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h2 className="font-amiri font-bold text-2xl sm:text-3xl text-white">
                ملخص بيانات الحساب
              </h2>
              <p className="text-xs text-gray-300">
                تحقق من بياناتك قبل التأكيد والدخول إلى المنصة.
              </p>
            </div>

            {/* Academic Student ID Card */}
            <div className="p-5 rounded-3xl bg-gradient-to-br from-[#0e192d] to-[#08101d] border border-[#e9c978]/40 shadow-xl space-y-4 text-right relative overflow-hidden">
              <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-[#e9c978] via-[#0fb98a] to-[#e9c978]" />

              {/* UID Block */}
              <div className="p-3 rounded-2xl bg-black/60 border border-white/10 flex items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="text-[10px] text-gray-400 block font-bold">معرّف الطالب الدائم (UID):</span>
                  <span className="font-mono text-sm sm:text-base font-black text-[#e9c978] tracking-wider select-all">
                    {uid}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard(uid)}
                  className="py-1.5 px-3 rounded-xl bg-white/10 hover:bg-[#e9c978] hover:text-black text-gray-300 text-xs font-bold transition flex items-center gap-1.5 shrink-0"
                  title="نسخ المعرّف"
                >
                  {copiedUid ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUid ? 'تم النسخ' : 'نسخ'}</span>
                </button>
              </div>

              {/* Attributes Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-2xl bg-white/5 border border-white/5 space-y-1">
                  <span className="text-[10px] text-gray-400 block">الاسم:</span>
                  <span className="font-bold text-white text-sm block truncate">
                    {name}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-white/5 border border-white/5 space-y-1">
                  <span className="text-[10px] text-gray-400 block">المسار الأكاديمي:</span>
                  <span className="font-bold text-[#e9c978] text-xs block">
                    طالب مدرسة 🏫
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-white/5 border border-white/5 space-y-1">
                  <span className="text-[10px] text-gray-400 block">الصف / المرحلة:</span>
                  <span className="font-bold text-gray-200 text-xs block">
                    {SCHOOL_GRADES.find(g => g.id === grade)?.name || grade}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-white/5 border border-white/5 space-y-1">
                  <span className="text-[10px] text-gray-400 block">تاريخ الميلاد:</span>
                  <span className="font-bold text-gray-200 text-xs block font-mono">
                    {birthYear}/{birthMonth}/{birthDay} ({estimatedAge} سنة)
                  </span>
                </div>
              </div>

              <div className="text-[11px] text-gray-400 bg-black/30 p-2.5 rounded-xl border border-white/5 leading-relaxed">
                💡 <span className="font-semibold text-gray-300">ملاحظة:</span> يمكنك إعطاء معرّف UID للأستاذ لتفعيل الأكواد والمحاضرات المدفوعة المخصصة لك.
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                onClick={handleFinalConfirm}
                disabled={isSubmitting}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#0fb98a] to-[#2dd4bf] text-[#08111e] font-black text-sm sm:text-base shadow-xl hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>جاري تثبيت الحساب...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-[#08111e]" />
                    <span>تأكيد ومتابعة لدخول المنصة</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setStep(1);
                }}
                className="w-full py-2.5 px-4 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-bold transition flex items-center justify-center gap-1.5"
              >
                <Edit3 className="w-3.5 h-3.5 text-[#e9c978]" />
                <span>تعديل البيانات</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
