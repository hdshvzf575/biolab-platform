import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register Service Worker with safe update handling and loop prevention
const updateSW = registerSW({
  immediate: true,
  onNeedRefresh() {
    try {
      const lastUpdate = parseInt(sessionStorage.getItem('biolab_last_sw_update') || '0', 10);
      const now = Date.now();
      // Enforce at least 60 seconds interval between service worker activations
      if (now - lastUpdate > 60000) {
        sessionStorage.setItem('biolab_last_sw_update', String(now));
        updateSW(true);
      }
    } catch (e) {
      updateSW(true);
    }
  },
  onOfflineReady() {
    console.log('[PWA] BioLab platform ready for offline usage.');
  },
  onRegisteredSW(_swUrl, registration) {
    if (registration) {
      // Periodically check for updates every 30 minutes in the background
      setInterval(() => {
        registration.update().catch(() => {});
      }, 30 * 60 * 1000);
    }
  }
});

// Guard against controllerchange infinite reload loops in WebViews
if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
  let refreshing = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (refreshing) return;
    try {
      const lastReload = parseInt(sessionStorage.getItem('biolab_last_sw_reload') || '0', 10);
      const now = Date.now();
      if (now - lastReload < 60000) {
        // Less than 60 seconds since last reload; prevent reload loops
        return;
      }
      sessionStorage.setItem('biolab_last_sw_reload', String(now));
      refreshing = true;
      window.location.reload();
    } catch (e) {
      if (!refreshing) {
        refreshing = true;
        window.location.reload();
      }
    }
  });
}

// Gracefully handle and suppress WebSocket HMR disconnection in preview iframe environment
window.addEventListener('error', (event) => {
  if (
    event.message?.includes('WebSocket') ||
    event.message?.includes('WebSocket closed without opened')
  ) {
    event.stopImmediatePropagation();
    event.preventDefault();
  }
});

window.addEventListener('unhandledrejection', (event) => {
  const reason = event.reason;
  if (
    reason?.message?.includes('WebSocket') ||
    reason?.message?.includes('WebSocket closed without opened') ||
    String(reason).includes('WebSocket')
  ) {
    event.stopImmediatePropagation();
    event.preventDefault();
  }
});

createRoot(document.getElementById('root')!).render(<App />);
