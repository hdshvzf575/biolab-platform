import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  limit, 
  where,
  getDocFromServer,
  writeBatch
} from 'firebase/firestore';
import { 
  getStorage, 
  ref as storageRef, 
  uploadBytesResumable, 
  getDownloadURL 
} from 'firebase/storage';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  GoogleAuthProvider,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  User as FirebaseUser,
  UserCredential
} from 'firebase/auth';

import firebaseConfig from '../../firebase-applet-config.json';
import { LectureItem, UserItem } from '../data/platformData';
import { UserProfile } from '../components/StudentOnboardingModal';
import { AppUpdateData } from '../components/AppUpdateModal';
import { setCachedGoogleToken, getCachedGoogleToken, setGoogleAccountLinked } from '../utils/appEnvironment';

// Initialize Firebase App defensively
let app: any = null;
try {
  app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
} catch (initErr) {
  console.warn('Firebase app initialization notice:', initErr);
  if (getApps().length > 0) {
    app = getApp();
  }
}

// Initialize Firestore with configured database ID
const rawDbId = (firebaseConfig as any)?.firestoreDatabaseId;
const dbId = (rawDbId && typeof rawDbId === 'string' && rawDbId.trim() && rawDbId !== '(default)') 
  ? rawDbId.trim() 
  : 'ai-studio-85798a9e-7365-46c6-bde9-0a484132186b';

export const db = getFirestore(app, dbId);

// Initialize Firebase Storage
export const storage = getStorage(app);

// Initialize Firebase Authentication with local session persistence
export const auth = getAuth(app);
try {
  setPersistence(auth, browserLocalPersistence).catch((err) => {
    console.warn('Firebase Auth persistence setup notice:', err?.message || err);
  });
} catch (e) {}

export const googleAuthProvider = new GoogleAuthProvider();
googleAuthProvider.addScope('https://www.googleapis.com/auth/drive.readonly');
googleAuthProvider.setCustomParameters({ prompt: 'select_account' });

// Token access helpers re-exported
export { getCachedGoogleToken, setCachedGoogleToken };
export const getCachedGoogleAccessToken = getCachedGoogleToken;
export const setCachedGoogleAccessToken = setCachedGoogleToken;

// Test Firestore Connection on Boot with safe timeout
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    const testDoc = doc(db, 'test', 'connection');
    // Wrap with 3.5s timeout so app never blocks or hangs if network is offline
    const connectionPromise = getDocFromServer(testDoc);
    const timeoutPromise = new Promise<never>((_, reject) => 
      setTimeout(() => reject(new Error('Firestore connection timeout')), 3500)
    );
    
    await Promise.race([connectionPromise, timeoutPromise]);
    console.log('✅ تم الاتصال بقاعدة بيانات Firebase Firestore السحابية المركزية بنجاح');
    return true;
  } catch (error: any) {
    if (error?.message?.includes('the client is offline') || error?.code === 'unavailable') {
      console.warn('⚠️ وضع العمل غير المتصل (Offline) مفعل - يتم استخدام الذاكرة المحلية المؤقتة لحين عودة الاتصال');
    } else {
      console.warn('Firebase connection check notice:', error?.message || error);
    }
    return false;
  }
}

// ==========================================
// 1. LECTURES CLOUD SYNC (مزامنة المحاضرات السحابية الفورية)
// ==========================================

/**
 * Real-time listener for lectures.
 * Pushes updates automatically to all connected devices (Web, Preview, Android APK) in real-time.
 * Guarantees zero crash and safe unsubscribe function.
 */
export function subscribeToLectures(
  onUpdate: (lectures: LectureItem[]) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const lecturesCol = collection(db, 'lectures');
    
    return onSnapshot(
      lecturesCol,
      (snapshot) => {
        try {
          // DEBUG LOG: Verify exactly what is coming from Firestore
          console.log('Lectures Snapshot Received (Docs Count: ' + snapshot.size + '):', 
            snapshot.docs.map(doc => ({ 
              _docId: doc.id, 
              ...doc.data() 
            }))
          );

          const items: LectureItem[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            const docId = docSnap.id;
            
            // Generate a numeric ID for compatibility with existing UI logic if field 'id' is missing
            let numericId = data.id;
            if (numericId === undefined || numericId === null) {
              numericId = isNaN(Number(docId)) ? Date.now() : Number(docId);
            }

            items.push({
              id: numericId,
              _docId: docId, // Expose Firestore Document ID for administrative operations
              title: data.title || (data.title === '' ? 'محاضرة بدون عنوان' : ''),
              desc: data.desc || '',
              grade: data.grade || 'unassigned', // Don't filter out unassigned grades
              videoUrl: data.videoUrl || '',
              isPaid: Boolean(data.isPaid),
              secretCode: data.secretCode || null,
              createdAt: data.createdAt || new Date().toISOString(),
              viewsCount: data.viewsCount || 0,
              isMalformed: !data.title || !data.videoUrl || !data.grade // Flag for admin panel
            });
          });

          // Sort newest first
          items.sort((a, b) => {
            const timeA = new Date(a.createdAt || 0).getTime() || a.id;
            const timeB = new Date(b.createdAt || 0).getTime() || b.id;
            return timeB - timeA;
          });

          onUpdate(items);
        } catch (innerErr: any) {
          console.error('Error parsing lectures snapshot:', innerErr);
          if (onError) onError(innerErr);
        }
      },
      (error) => {
        console.warn('Firestore lectures subscription error/offline:', error?.message || error);
        if (onError) onError(error);
      }
    );
  } catch (err: any) {
    console.error('Failed to setup Firestore lectures listener:', err);
    if (onError) onError(err);
    return () => {};
  }
}

/**
 * Perform a diagnostic check on Firestore lectures and return a report.
 * Checks for missing titles, video URLs, grades, and invalid IDs.
 */
export async function diagnoseFirestoreLectures(): Promise<{
  totalDocs: number;
  healthyDocs: number;
  issues: { docId: string; title?: string; grade?: string; issueType: string; details: string }[];
}> {
  try {
    const lecturesCol = collection(db, 'lectures');
    const snapshot = await getDocs(lecturesCol);
    const issues: any[] = [];
    let healthyCount = 0;

    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      const docId = docSnap.id;
      const docIssues: string[] = [];

      if (!data.title) docIssues.push('Missing Title');
      if (!data.videoUrl) docIssues.push('Missing Video URL');
      if (!data.grade) docIssues.push('Missing Grade');
      
      // Check for logical ID consistency
      const logicalId = data.id;
      if (logicalId === undefined || logicalId === null) {
        docIssues.push('Missing logical ID field');
      }

      if (docIssues.length > 0) {
        issues.push({
          docId,
          title: data.title,
          grade: data.grade,
          issueType: docIssues.join(', '),
          details: JSON.stringify(data)
        });
      } else {
        healthyCount++;
      }
    });

    return {
      totalDocs: snapshot.size,
      healthyDocs: healthyCount,
      issues
    };
  } catch (err: any) {
    console.error('Diagnostic error:', err);
    throw err;
  }
}

/**
 * Add new lecture to central cloud database
 */
export async function addLectureToCloud(lecture: LectureItem): Promise<void> {
  try {
    const docRef = doc(db, 'lectures', String(lecture.id));
    await setDoc(docRef, {
      ...lecture,
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.error('Error adding lecture to cloud:', err);
    throw err;
  }
}

/**
 * Update existing lecture in central cloud database
 */
export async function updateLectureInCloud(id: number, updates: Partial<LectureItem>): Promise<void> {
  try {
    const docRef = doc(db, 'lectures', String(id));
    await updateDoc(docRef, {
      ...updates,
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.error('Error updating lecture in cloud:', err);
    throw err;
  }
}

/**
 * Delete lecture from central cloud database (immediately removes it from all users)
 */
export async function deleteLectureFromCloud(id: number): Promise<void> {
  try {
    const docRef = doc(db, 'lectures', String(id));
    await deleteDoc(docRef);
  } catch (err) {
    console.error('Error deleting lecture from cloud:', err);
    throw err;
  }
}

// ==========================================
// 2. USERS & ONBOARDING CLOUD SYNC (إدارة وتسجيل الطلاب بالـ UID)
// ==========================================

/**
 * Real-time listener for registered users in Admin Panel
 */
export function subscribeToUsers(
  onUpdate: (users: UserItem[]) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const usersCol = collection(db, 'users');

    return onSnapshot(
      usersCol,
      (snapshot) => {
        try {
          const users: UserItem[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            const emailStr = data.emailOrPhone || '';
            const isGoogleAuth = data.authProvider === 'google' || Boolean(data.firebaseUid) || emailStr.includes('@');

            users.push({
              id: data.id || docSnap.id,
              uid: data.uid || docSnap.id,
              firebaseUid: data.firebaseUid || data.uid || docSnap.id,
              name: data.name || 'طالب مسجل',
              emailOrPhone: emailStr,
              photoURL: data.photoURL || undefined,
              authProvider: (data.authProvider as any) || (isGoogleAuth ? 'google' : 'guest'),
              grade: data.grade || 'g6',
              track: data.track || 'school',
              birthDate: data.birthDate || undefined,
              birthYear: data.birthYear ? Number(data.birthYear) : undefined,
              role: data.role || 'student',
              status: data.status || 'active',
              isVip: Boolean(data.isVip),
              deviceType: data.deviceType || 'android-apk',
              registeredAt: data.registeredAt || new Date().toISOString().split('T')[0],
              lastActive: data.lastActive || 'متصل الآن',
              unlockedLectures: Array.isArray(data.unlockedLectures) ? data.unlockedLectures : [],
              notes: data.notes || ''
            });
          });

          // Sort newest registration first
          users.sort((a, b) => (b.registeredAt || '').localeCompare(a.registeredAt || ''));
          onUpdate(users);
        } catch (innerErr: any) {
          console.error('Error parsing users snapshot:', innerErr);
          if (onError) onError(innerErr);
        }
      },
      (err) => {
        console.warn('Firestore users subscription warning/offline:', err?.message || err);
        if (onError) onError(err);
      }
    );
  } catch (err: any) {
    console.error('Failed to setup Firestore users listener:', err);
    if (onError) onError(err);
    return () => {};
  }
}

/**
 * Register or update student profile with persistent UID in central database
 */
export async function registerStudentInCloud(profile: UserProfile): Promise<void> {
  try {
    const cleanUid = profile.uid || `UID-BIO-${Math.floor(1000 + Math.random() * 9000)}`;
    const docRef = doc(db, 'users', cleanUid);
    const anyProfile = profile as any;
    
    const payload = {
      id: cleanUid,
      uid: cleanUid,
      name: profile.name.trim(),
      track: profile.track || 'school',
      grade: profile.grade || 'g6',
      birthDate: profile.birthDate || null,
      birthYear: profile.birthYear || (profile.birthDate ? Number(profile.birthDate.split('-')[0]) : null),
      role: anyProfile.role || 'student',
      status: anyProfile.status || 'active',
      isVip: Boolean(anyProfile.isVip),
      deviceType: anyProfile.deviceType || (typeof window !== 'undefined' && window.innerWidth < 768 ? 'web-mobile' : 'web-desktop'),
      registeredAt: profile.registeredAt || new Date().toISOString().split('T')[0],
      lastActive: 'متصل الآن',
      unlockedLectures: anyProfile.unlockedLectures || [],
      notes: anyProfile.notes || ''
    };

    await setDoc(docRef, payload, { merge: true });
  } catch (err) {
    console.warn('Notice: direct cloud registration failed, relying on server sync:', err);
  }
}

/**
 * Update user status (block/activate/VIP) in cloud database
 */
export async function updateUserInCloud(userId: string, updates: Partial<UserItem>): Promise<void> {
  try {
    const docRef = doc(db, 'users', userId);
    await updateDoc(docRef, updates);
  } catch (err) {
    console.error('Error updating user in cloud:', err);
    throw err;
  }
}

/**
 * Delete student from cloud database
 */
export async function deleteUserFromCloud(userId: string): Promise<void> {
  try {
    const docRef = doc(db, 'users', userId);
    await deleteDoc(docRef);
  } catch (err) {
    console.error('Error deleting user from cloud:', err);
    throw err;
  }
}

// ==========================================
// 3. VIP CODES CLOUD SYNC (أكواد المحاضرات المدفوعة المربوطة بـ UID)
// ==========================================

export interface CloudVipCode {
  code: string;
  title: string;
  targetUid: string;
  targetUserName?: string;
  lectureId: number | string;
  lectureTitle?: string;
  maxUses?: number;
  usedCount?: number;
  redeemedBy?: string[];
  createdAt: string;
  expiresAt?: string | null;
  status: 'active' | 'revoked';
}

/**
 * Real-time listener for VIP Codes
 */
export function subscribeToCodes(
  onUpdate: (codes: CloudVipCode[]) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const codesCol = collection(db, 'lecture_codes');

    return onSnapshot(
      codesCol,
      (snapshot) => {
        try {
          const codes: CloudVipCode[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            codes.push({
              code: docSnap.id,
              title: data.title || '',
              targetUid: data.targetUid || 'ALL',
              targetUserName: data.targetUserName || 'الجميع',
              lectureId: data.lectureId ?? 'all',
              lectureTitle: data.lectureTitle || '',
              maxUses: data.maxUses || 1,
              usedCount: data.usedCount || 0,
              redeemedBy: Array.isArray(data.redeemedBy) ? data.redeemedBy : [],
              createdAt: data.createdAt || new Date().toISOString(),
              expiresAt: data.expiresAt || null,
              status: data.status || 'active'
            });
          });
          onUpdate(codes);
        } catch (innerErr: any) {
          console.error('Error parsing codes snapshot:', innerErr);
          if (onError) onError(innerErr);
        }
      },
      (err) => {
        console.warn('Firestore codes subscription warning/offline:', err?.message || err);
        if (onError) onError(err);
      }
    );
  } catch (err: any) {
    console.error('Failed to setup Firestore codes listener:', err);
    if (onError) onError(err);
    return () => {};
  }
}

/**
 * Create or save VIP code in central cloud database
 */
export async function saveCodeToCloud(codeRecord: CloudVipCode): Promise<void> {
  try {
    const cleanCode = codeRecord.code.trim().toUpperCase();
    const docRef = doc(db, 'lecture_codes', cleanCode);
    await setDoc(docRef, {
      ...codeRecord,
      code: cleanCode
    });
  } catch (err) {
    console.error('Error saving code to cloud:', err);
    throw err;
  }
}

/**
 * Redeem VIP code in central database with UID validation
 */
export async function redeemCodeInCloud(
  inputCode: string,
  userUid: string
): Promise<{ success: boolean; message?: string; error?: string; lectureId?: number | string }> {
  try {
    const cleanCode = inputCode.trim().toUpperCase();
    const cleanUid = userUid.trim().toUpperCase();

    const docRef = doc(db, 'lecture_codes', cleanCode);
    const snap = await getDoc(docRef);

    if (!snap.exists()) {
      return { success: false, error: 'الكود السري المدخل غير صحيح، تأكد من الأحرف والأرقام.' };
    }

    const codeData = snap.data() as CloudVipCode;

    if (codeData.status !== 'active') {
      return { success: false, error: 'تم إيقاف أو إلغاء تفعيل هذا الكود من قبل الإدارة.' };
    }

    // UID Verification
    const targetUid = String(codeData.targetUid || 'ALL').trim().toUpperCase();
    if (targetUid !== 'ALL' && targetUid !== cleanUid) {
      return {
        success: false,
        error: `هذا الكود مخصص لمعرّف مستخدم آخر (${codeData.targetUid}) ولا يطابق معرّف حسابك (${userUid}). يرجى مراجعة الأستاذ.`
      };
    }

    // Expiry check
    if (codeData.expiresAt && new Date(codeData.expiresAt).getTime() < Date.now()) {
      return { success: false, error: 'انتهت صلاحية هذا الكود.' };
    }

    // Max uses check
    const usedCount = codeData.usedCount || 0;
    const maxUses = codeData.maxUses || 1;
    const redeemedBy = Array.isArray(codeData.redeemedBy) ? codeData.redeemedBy : [];

    if (usedCount >= maxUses) {
      if (redeemedBy.includes(cleanUid)) {
        return {
          success: true,
          message: 'تم تفعيل هذا الكود مسبقاً لحسابك! يمكنك المشاهدة الآن.',
          lectureId: codeData.lectureId
        };
      }
      return { success: false, error: 'تم استهلاك الحد الأقصى لاستخدام هذا الكود.' };
    }

    // Record redemption
    const updatedRedeemed = redeemedBy.includes(cleanUid) ? redeemedBy : [...redeemedBy, cleanUid];
    await updateDoc(docRef, {
      usedCount: usedCount + 1,
      redeemedBy: updatedRedeemed
    });

    return {
      success: true,
      message: `تم تفعيل «${codeData.title || codeData.lectureTitle || 'المحاضرة'}» بنجاح لحسابك! 🎉`,
      lectureId: codeData.lectureId
    };
  } catch (err: any) {
    console.error('Error redeeming code in cloud:', err);
    return { success: false, error: err?.message || 'حدث خطأ أثناء الاتصال بقاعدة البيانات لتفعيل الكود' };
  }
}

/**
 * Delete / revoke VIP code from central database
 */
export async function deleteCodeFromCloud(codeStr: string): Promise<void> {
  try {
    const cleanCode = codeStr.trim().toUpperCase();
    const docRef = doc(db, 'lecture_codes', cleanCode);
    await deleteDoc(docRef);
  } catch (err) {
    console.error('Error deleting code from cloud:', err);
    throw err;
  }
}

// ==========================================
// 4. LIVE APP UPDATES & ANNOUNCEMENTS
// ==========================================

export function subscribeToAppUpdate(
  onUpdate: (data: AppUpdateData) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const docRef = doc(db, 'settings', 'app_update');
    return onSnapshot(
      docRef,
      (docSnap) => {
        try {
          if (docSnap.exists()) {
            onUpdate(docSnap.data() as AppUpdateData);
          }
        } catch (innerErr: any) {
          console.error('Error parsing app update snapshot:', innerErr);
          if (onError) onError(innerErr);
        }
      },
      (error) => {
        console.warn('Firestore app update subscription warning/offline:', error?.message || error);
        if (onError) onError(error);
      }
    );
  } catch (err: any) {
    console.error('Failed to setup Firestore app update listener:', err);
    if (onError) onError(err);
    return () => {};
  }
}

export async function publishAppUpdateToCloud(updateData: AppUpdateData): Promise<void> {
  try {
    const docRef = doc(db, 'settings', 'app_update');
    await setDoc(docRef, updateData, { merge: true });
  } catch (err) {
    console.error('Error publishing app update to cloud:', err);
    throw err;
  }
}

// ==========================================
// 4.5 CURRICULUM BOOKS & BOOKLETS CLOUD SYNC (مزامنة الكتب والملازم الوزارية)
// ==========================================

/**
 * Real-time listener for curriculum books and booklets
 */
export function subscribeToCurriculumBooks(
  onUpdate: (books: any[]) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const booksCol = collection(db, 'curriculum_books');

    return onSnapshot(
      booksCol,
      (snapshot) => {
        try {
          const items: any[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            items.push({
              id: docSnap.id,
              ...data
            });
          });

          // Always notify subscribers, even when collection becomes empty
          onUpdate(items);
        } catch (innerErr: any) {
          console.error('Error parsing curriculum books snapshot:', innerErr);
          if (onError) onError(innerErr);
        }
      },
      (error) => {
        console.warn('Firestore curriculum books subscription notice:', error?.message || error);
        if (onError) onError(error);
      }
    );
  } catch (err: any) {
    console.error('Failed to setup Firestore curriculum books listener:', err);
    if (onError) onError(err);
    return () => {};
  }
}

/**
 * Robust file upload handler integrating with Firebase Storage.
 * Allows uploading PDF files, cover images, and videos from the device file picker.
 * Features progress callbacks and automatic resilient streaming fallback to server endpoints
 * (/api/upload/book, /api/upload/cover, /api/upload/video) if client storage bucket access is restricted.
 */
export async function uploadFileWithFirebaseStorage(
  file: File,
  folder: 'books' | 'covers' | 'videos',
  onProgress?: (percent: number) => void
): Promise<{ url: string; fileSize?: string; fileName: string; method: 'firebase-storage' | 'server-storage' }> {
  const cleanFileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
  const path = `${folder}/${cleanFileName}`;
  const fileSizeBytes = file.size;
  const fileSizeMb = (fileSizeBytes / (1024 * 1024)).toFixed(2) + ' MB';

  // 1. Attempt upload to Firebase Storage
  try {
    const fileRef = storageRef(storage, path);
    const contentType = file.type || (
      folder === 'books' ? 'application/pdf' : 
      folder === 'covers' ? 'image/jpeg' : 
      'video/mp4'
    );
    const uploadTask = uploadBytesResumable(fileRef, file, { contentType });

    const downloadUrl = await new Promise<string>((resolve, reject) => {
      // Add a safety timeout for the upload task to trigger fallback if stuck
      const timeout = setTimeout(() => {
        uploadTask.cancel();
        reject(new Error('Firebase Storage upload timed out after 35s - triggering resilient fallback.'));
      }, 35000);

      uploadTask.on(
        'state_changed',
        (snapshot) => {
          if (snapshot.totalBytes > 0) {
            const progress = Math.min(99, Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100));
            if (onProgress) onProgress(progress);
          }
        },
        (error) => {
          clearTimeout(timeout);
          reject(error);
        },
        async () => {
          clearTimeout(timeout);
          try {
            const url = await getDownloadURL(uploadTask.snapshot.ref);
            if (onProgress) onProgress(100);
            resolve(url);
          } catch (urlErr) {
            reject(urlErr);
          }
        }
      );
    });

    return {
      url: downloadUrl,
      fileSize: fileSizeMb,
      fileName: file.name,
      method: 'firebase-storage'
    };
  } catch (storageErr: any) {
    console.warn(`Firebase Storage direct upload notice (${storageErr?.message || storageErr}), falling back to streaming server storage:`);

    // 2. Resilient Streaming Server Upload Fallback
    const endpoint = folder === 'books' ? '/api/upload/book' : folder === 'covers' ? '/api/upload/cover' : '/api/upload/video';
    const formField = folder === 'books' ? 'file' : folder === 'covers' ? 'cover' : 'video';
    const adminToken = (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem('biolab_admin_token') : null) || 'wissam_bio_admin_token_2026_secure';

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      const formData = new FormData();
      formData.append(formField, file);

      xhr.upload.onprogress = (evt) => {
        if (evt.lengthComputable && onProgress) {
          const percent = Math.min(99, Math.round((evt.loaded / evt.total) * 100));
          onProgress(percent);
        }
      };

      xhr.onload = () => {
        try {
          const data = JSON.parse(xhr.responseText);
          if (xhr.status >= 200 && xhr.status < 300 && data.success) {
            if (onProgress) onProgress(100);
            resolve({
              url: data.url,
              fileSize: data.fileSize || fileSizeMb,
              fileName: file.name,
              method: 'server-storage'
            });
          } else {
            reject(new Error(data.error || `Server upload returned status ${xhr.status}`));
          }
        } catch (e: any) {
          reject(new Error('Invalid response from upload server'));
        }
      };

      xhr.onerror = () => reject(new Error('Network error during file upload'));
      xhr.open('POST', endpoint);
      xhr.setRequestHeader('Authorization', `Bearer ${adminToken}`);
      xhr.send(formData);
    });
  }
}

/**
 * Update a Firestore curriculum book document with the generated download URL.
 */
export async function updateFirestoreBookWithFileUrl(
  bookId: string,
  fileType: 'pdf' | 'cover',
  downloadUrl: string,
  extraFields?: Record<string, any>
): Promise<void> {
  const docRef = doc(db, 'curriculum_books', String(bookId));
  const updatePayload: Record<string, any> = {
    updatedAt: new Date().toISOString(),
    ...(extraFields || {})
  };

  if (fileType === 'pdf') {
    updatePayload.pdfUrl = downloadUrl;
    updatePayload.fileUrl = downloadUrl;
    updatePayload.isAvailable = true;
    updatePayload.verificationStatus = 'verified';
  } else if (fileType === 'cover') {
    updatePayload.coverUrl = downloadUrl;
  }

  await setDoc(docRef, updatePayload, { merge: true });
}

/**
 * Add new curriculum book or booklet to cloud
 */
export async function addCurriculumBookToCloud(book: any): Promise<void> {
  try {
    const docRef = doc(db, 'curriculum_books', String(book.id));
    await setDoc(docRef, {
      ...book,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (err) {
    console.error('Error adding curriculum book to cloud:', err);
    throw err;
  }
}

/**
 * Update existing curriculum book or booklet in cloud
 */
export async function updateCurriculumBookInCloud(id: string, updates: Partial<any>): Promise<void> {
  try {
    const docRef = doc(db, 'curriculum_books', String(id));
    await setDoc(docRef, {
      ...updates,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (err) {
    console.error('Error updating curriculum book in cloud:', err);
    throw err;
  }
}

/**
 * Delete curriculum book or booklet from cloud
 */
export async function deleteCurriculumBookFromCloud(id: string): Promise<void> {
  try {
    const docRef = doc(db, 'curriculum_books', String(id));
    await deleteDoc(docRef);
  } catch (err) {
    console.error('Error deleting curriculum book from cloud:', err);
    throw err;
  }
}

// ==========================================
// 4.6 INSTITUTE STAGES & POSTS CLOUD SYNC (مزامنة منشورات ودرجات المعهد الحضوري)
// ==========================================

export function subscribeToInstituteStages(
  onUpdate: (stages: any[]) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const col = collection(db, 'institute_stages');
    return onSnapshot(
      col,
      (snapshot) => {
        try {
          const items: any[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ id: docSnap.id, ...docSnap.data() });
          });
          items.sort((a, b) => (a.order || 0) - (b.order || 0));
          onUpdate(items);
        } catch (err: any) {
          if (onError) onError(err);
        }
      },
      (error) => {
        console.warn('Firestore institute stages subscription notice:', error?.message || error);
        if (onError) onError(error);
      }
    );
  } catch (err: any) {
    if (onError) onError(err);
    return () => {};
  }
}

export function subscribeToInstitutePosts(
  onUpdate: (posts: any[]) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const col = collection(db, 'institute_posts');
    return onSnapshot(
      col,
      (snapshot) => {
        try {
          const items: any[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ id: docSnap.id, ...docSnap.data() });
          });
          items.sort((a, b) => new Date(b.date || b.createdAt || 0).getTime() - new Date(a.date || a.createdAt || 0).getTime());
          onUpdate(items);
        } catch (err: any) {
          if (onError) onError(err);
        }
      },
      (error) => {
        console.warn('Firestore institute posts subscription notice:', error?.message || error);
        if (onError) onError(error);
      }
    );
  } catch (err: any) {
    if (onError) onError(err);
    return () => {};
  }
}

export async function addInstitutePostToCloud(post: any): Promise<void> {
  const docRef = doc(db, 'institute_posts', String(post.id));
  await setDoc(docRef, { ...post, updatedAt: new Date().toISOString() }, { merge: true });
}

export async function updateInstitutePostInCloud(id: string, updates: Partial<any>): Promise<void> {
  const docRef = doc(db, 'institute_posts', String(id));
  await setDoc(docRef, { ...updates, updatedAt: new Date().toISOString() }, { merge: true });
}

export async function deleteInstitutePostFromCloud(id: string): Promise<void> {
  const docRef = doc(db, 'institute_posts', String(id));
  await deleteDoc(docRef);
}

export async function updateInstituteStageInCloud(id: string, updates: Partial<any>): Promise<void> {
  const docRef = doc(db, 'institute_stages', String(id));
  await setDoc(docRef, { ...updates, updatedAt: new Date().toISOString() }, { merge: true });
}

// ==========================================
// 4.7 PERMANENT CLOUD BACKUPS (نظام النسخ الاحتياطي السحابي الدائم وحماية المحتوى)
// ==========================================

export async function createCloudDataBackup(): Promise<{ backupId: string; timestamp: string; count: Record<string, number> }> {
  const backupId = `backup_${Date.now()}`;
  const timestamp = new Date().toISOString();

  const collectionsToBackup = ['curriculum_books', 'lectures', 'users', 'lecture_codes', 'settings', 'institute_posts', 'institute_stages'];
  const snapshotData: Record<string, any[]> = {};
  const counts: Record<string, number> = {};

  for (const colName of collectionsToBackup) {
    try {
      const snap = await getDocs(collection(db, colName));
      const list: any[] = [];
      snap.forEach(d => list.push({ _id: d.id, ...d.data() }));
      snapshotData[colName] = list;
      counts[colName] = list.length;
    } catch (e) {
      snapshotData[colName] = [];
      counts[colName] = 0;
    }
  }

  const backupDocRef = doc(db, 'backups', backupId);
  await setDoc(backupDocRef, {
    backupId,
    timestamp,
    counts,
    data: snapshotData,
    createdBy: 'admin',
    source: 'central_cloud'
  });

  return { backupId, timestamp, count: counts };
}

export function subscribeToBackups(
  onUpdate: (backups: any[]) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const col = collection(db, 'backups');
    return onSnapshot(
      col,
      (snapshot) => {
        try {
          const items: any[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            items.push({
              backupId: docSnap.id,
              timestamp: data.timestamp || '',
              counts: data.counts || {},
              source: data.source || 'central_cloud'
            });
          });
          items.sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));
          onUpdate(items);
        } catch (err: any) {
          if (onError) onError(err);
        }
      },
      (error) => {
        if (onError) onError(error);
      }
    );
  } catch (err: any) {
    if (onError) onError(err);
    return () => {};
  }
}

// ==========================================
// 5. DATABASE AUTO-SEEDING (حماية المحتوى القائم ومنع فقدانه)
// ==========================================

/**
 * Seeds initial lectures and starter data ONLY ONCE if Firestore is completely fresh.
 * Checks a persistent system seed record so that admin deletions are never overwritten.
 */
export async function seedCloudDatabaseIfEmpty(
  initialLecturesList: LectureItem[],
  initialUsersList: UserItem[],
  initialBooksList?: any[]
): Promise<void> {
  try {
    const seedStatusDoc = doc(db, 'system', 'seed_status');
    const seedStatusSnap = await getDoc(seedStatusDoc);
    const alreadySeeded = seedStatusSnap.exists() && seedStatusSnap.data()?.seeded === true;

    if (alreadySeeded) {
      // Database was already initialized. Never overwrite or re-inject deleted lectures!
      return;
    }

    const lecturesCol = collection(db, 'lectures');
    const existingLecturesSnap = await getDocs(query(lecturesCol, limit(1)));
    
    const booksCol = collection(db, 'curriculum_books');
    const existingBooksSnap = await getDocs(query(booksCol, limit(1)));

    const needsLectures = existingLecturesSnap.empty && initialLecturesList.length > 0;
    const needsBooks = existingBooksSnap.empty && initialBooksList && initialBooksList.length > 0;

    if (needsLectures || needsBooks) {
      console.log('🌱 مزامنة المحتوى التأسيسي الأولي لمرة واحدة لحماية البيانات...');
      const batch = writeBatch(db);

      if (needsLectures) {
        for (const lec of initialLecturesList) {
          const ref = doc(db, 'lectures', String(lec.id));
          batch.set(ref, {
            ...lec,
            createdAt: lec.createdAt || new Date().toISOString()
          });
        }
        for (const u of initialUsersList.slice(0, 5)) {
          const uRef = doc(db, 'users', u.uid || u.id);
          batch.set(uRef, u);
        }
      }

      if (needsBooks && initialBooksList) {
        for (const b of initialBooksList) {
          if (b.stage === 'university' || b.title?.includes('كامبل')) continue;
          const bRef = doc(db, 'curriculum_books', String(b.id));
          batch.set(bRef, {
            ...b,
            updatedAt: new Date().toISOString()
          });
        }
      }

      batch.set(seedStatusDoc, {
        seeded: true,
        lastSeedCheck: new Date().toISOString()
      }, { merge: true });

      await batch.commit();
      console.log('✅ اكتملت المزامنة التأسيسية وحفظ المحتوى بنجاح 🚀');
    } else {
      // Mark as seeded so future runs never attempt to re-inject
      await setDoc(seedStatusDoc, {
        seeded: true,
        lastSeedCheck: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err) {
    console.warn('Auto-seed check notice (app will continue smoothly):', err);
  }
}

// ==========================================
// 6. FIREBASE AUTHENTICATION & STUDENT LINKING (نظام المصادقة وحسابات الطلاب)
// ==========================================

export type { FirebaseUser, UserCredential };

/**
 * Log in student or admin using Email and Password
 */
export async function loginWithEmail(email: string, pass: string): Promise<UserCredential> {
  const cleanEmail = email.trim();
  const cred = await signInWithEmailAndPassword(auth, cleanEmail, pass);
  
  // Auto-set admin token if email is authorized admin
  if (isUserAdmin(cred.user, cleanEmail)) {
    try {
      sessionStorage.setItem('biolab_admin_token', 'wissam_bio_admin_token_2026_secure');
    } catch (e) {}
  }
  return cred;
}

/**
 * Register new student account with Email, Password and optional Display Name
 */
export async function registerWithEmail(
  email: string, 
  pass: string, 
  displayName?: string
): Promise<UserCredential> {
  const cleanEmail = email.trim();
  const cred = await createUserWithEmailAndPassword(auth, cleanEmail, pass);
  
  if (displayName && displayName.trim() && cred.user) {
    try {
      await updateProfile(cred.user, { displayName: displayName.trim() });
    } catch (e) {
      console.warn('Display name update notice:', e);
    }
  }

  // Auto-set admin token if admin email
  if (isUserAdmin(cred.user, cleanEmail)) {
    try {
      sessionStorage.setItem('biolab_admin_token', 'wissam_bio_admin_token_2026_secure');
    } catch (e) {}
  }

  return cred;
}

/**
 * Sign in student or admin using Google Provider
 * Uses popup by default with resilient fallback to redirect if popup is blocked on mobile WebView
 */
export async function loginWithGoogle(): Promise<UserCredential> {
  try {
    const cred = await signInWithPopup(auth, googleAuthProvider);
    try {
      const oauthCred = GoogleAuthProvider.credentialFromResult(cred);
      if (oauthCred?.accessToken) {
        setCachedGoogleToken(oauthCred.accessToken);
        setGoogleAccountLinked(true);
      }
    } catch (tokenErr) {
      console.warn('OAuth credential extraction notice:', tokenErr);
    }

    // Note: Google Sign-In is for platform users and students.
    // Admin access is granted exclusively through the dedicated Admin Panel credentials.
    return cred;
  } catch (popupErr: any) {
    if (popupErr?.code === 'auth/popup-blocked' || popupErr?.code === 'auth/cancelled-popup-request') {
      await signInWithRedirect(auth, googleAuthProvider);
      throw new Error('جاري تحويلك لصفحة تسجيل الدخول بحساب Google...');
    }
    throw popupErr;
  }
}

/**
 * Check if the user just returned from a Google sign-in redirect
 */
export async function checkRedirectAuthResult(): Promise<UserCredential | null> {
  try {
    const result = await getRedirectResult(auth);
    if (result) {
      try {
        const oauthCred = GoogleAuthProvider.credentialFromResult(result);
        if (oauthCred?.accessToken) {
          setCachedGoogleToken(oauthCred.accessToken);
          setGoogleAccountLinked(true);
        }
      } catch (tokenErr) {
        console.warn('OAuth redirect credential extraction notice:', tokenErr);
      }
    }
    return result;
  } catch (e) {
    console.warn('Redirect auth check notice:', e);
    return null;
  }
}

/**
 * Send password reset email to student
 */
export async function sendPasswordReset(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

/**
 * Log out current Firebase user and clear admin token
 */
export async function logoutUser(): Promise<void> {
  try {
    await signOut(auth);
  } finally {
    try {
      sessionStorage.removeItem('biolab_admin_token');
    } catch (e) {}
  }
}

/**
 * Subscribe to real-time auth state changes
 */
export function onAuthStatusChanged(callback: (user: FirebaseUser | null) => void): () => void {
  return onAuthStateChanged(auth, callback);
}

/**
 * Check if a user or email is recognized as the platform Administrator
 */
export function isUserAdmin(user: FirebaseUser | null, email?: string): boolean {
  const candidate = (user?.email || email || '').trim().toLowerCase();
  return (
    candidate === 'abdullahmiqdad2007@gmail.com' ||
    candidate === 'admin@wissam.com'
  );
}

/**
 * Translate Firebase Auth error codes to user-friendly Arabic explanations
 */
export function translateAuthError(err: any): string {
  const code = (err?.code || (typeof err === 'string' ? err : '')).toLowerCase();
  const rawMsg = err?.message || '';

  if (code.includes('invalid-credential') || code.includes('wrong-password') || code.includes('user-not-found')) {
    return 'البريد الإلكتروني أو كلمة المرور غير صحيحة، يرجى التحقق والمحاولة مجدداً.';
  }
  if (code.includes('email-already-in-use')) {
    return 'هذا البريد الإلكتروني مسجل لدينا بالفعل، يمكنك تسجيل الدخول به مباشرة.';
  }
  if (code.includes('invalid-email')) {
    return 'صيغة البريد الإلكتروني غير صالحة، يرجى كتابة بريد إلكتروني صحيح.';
  }
  if (code.includes('weak-password')) {
    return 'كلمة المرور ضعيفة، يجب أن تحتوي على 6 خانات أو أرقام على الأقل.';
  }
  if (code.includes('popup-closed-by-user')) {
    return 'تم إغلاق نافذة تسجيل الدخول من قِبلك قبل إتمام العملية.';
  }
  if (code.includes('cancelled-popup-request')) {
    return 'تم إلغاء عملية تسجيل الدخول.';
  }
  if (code.includes('popup-blocked')) {
    return 'قام المتصفح بحظر النافذة المنبثقة، يرجى السماح بالنوافذ المنبثقة في الإعدادات.';
  }
  if (code.includes('network-request-failed')) {
    return 'تعذر الاتصال بالشبكة، يرجى التحقق من اتصال الإنترنت.';
  }
  if (code.includes('too-many-requests')) {
    return 'محاولات دخول خاطئة متتالية، يرجى الانتظار دقيقة واحدة ثم المحاولة مجدداً.';
  }
  if (code.includes('user-disabled')) {
    return 'تم تعطيل هذا الحساب من قبل إدارة المنصة.';
  }

  return rawMsg || 'حدث خطأ غير متوقع أثناء تسجيل الدخول، يرجى المحاولة لاحقاً.';
}

/**
 * Link Firebase Auth user with BioLab student profile in Firestore.
 * Preserves all existing students in Firestore and ensures UID consistency.
 */
export async function syncAuthUserWithProfile(
  user: FirebaseUser,
  candidateData?: { name?: string; grade?: string; track?: 'school' }
): Promise<UserProfile> {
  const userDocRef = doc(db, 'users', user.uid);
  let existingData: any = null;

  try {
    const userSnap = await getDoc(userDocRef);
    if (userSnap.exists()) {
      existingData = userSnap.data();
    }
  } catch (e) {
    console.warn('Notice: Firestore user direct check failed (offline or permission):', e);
  }

  // If not found by auth UID, check if this user already has an existing BioLab profile by email
  if (!existingData && user.email) {
    try {
      const usersCol = collection(db, 'users');
      const emailQuery = query(usersCol, where('emailOrPhone', '==', user.email.trim()));
      const snap = await getDocs(emailQuery);
      if (!snap.empty) {
        existingData = snap.docs[0].data();
        // Link the auth UID to this existing student doc
        const existingDocRef = doc(db, 'users', snap.docs[0].id);
        await updateDoc(existingDocRef, {
          firebaseUid: user.uid,
          lastActive: 'متصل الآن'
        }).catch(() => {});
      }
    } catch (e) {}
  }

  // Check local profile in localStorage for existing UID-BIO-XXXX
  let localSavedProfile: UserProfile | null = null;
  try {
    const saved = localStorage.getItem('biolab_user_profile');
    if (saved) localSavedProfile = JSON.parse(saved);
  } catch (e) {}

  const uid = existingData?.uid || localSavedProfile?.uid || `UID-BIO-${Math.floor(1000 + Math.random() * 9000)}`;
  const displayName = existingData?.name || user.displayName || candidateData?.name || localSavedProfile?.name || 'طالب مسجل';
  const grade = existingData?.grade || candidateData?.grade || localSavedProfile?.grade || 'g6';
  const track = existingData?.track || candidateData?.track || localSavedProfile?.track || 'school';
  const birthDate = existingData?.birthDate || localSavedProfile?.birthDate || '2007-04-15';
  const birthYear = existingData?.birthYear || localSavedProfile?.birthYear || 2007;
  const registeredAt = existingData?.registeredAt || localSavedProfile?.registeredAt || new Date().toISOString().split('T')[0];

  const profile: UserProfile = {
    uid,
    name: displayName,
    track,
    grade,
    birthDate,
    birthYear,
    registeredAt
  };

  // Save to localStorage immediately
  try {
    localStorage.setItem('biolab_user_profile', JSON.stringify(profile));
  } catch (e) {}

  // Save/merge to Firestore under user.uid
  const isGoogle = user.providerData?.some(p => p.providerId === 'google.com') || Boolean(user.photoURL);
  const payloadToSave = {
    id: user.uid,
    uid,
    firebaseUid: user.uid,
    name: displayName,
    emailOrPhone: user.email || '',
    photoURL: user.photoURL || null,
    authProvider: isGoogle ? 'google' : (existingData?.authProvider || 'password'),
    track,
    grade,
    birthDate,
    birthYear,
    role: existingData?.role === 'vip' ? 'vip' : 'student',
    status: existingData?.status || 'active',
    isVip: Boolean(existingData?.isVip || (localSavedProfile && (localSavedProfile as any).isVip)),
    deviceType: typeof window !== 'undefined' && window.innerWidth < 768 ? 'web-mobile' : 'web-desktop',
    registeredAt,
    lastActive: 'متصل الآن',
    unlockedLectures: existingData?.unlockedLectures || []
  };

  try {
    await setDoc(userDocRef, payloadToSave, { merge: true });
    // Also update server session API
    await fetch('/api/users/sync-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: user.uid,
        uid,
        name: displayName,
        track,
        grade,
        deviceType: payloadToSave.deviceType
      })
    }).catch(() => {});
  } catch (err) {
    console.warn('User profile sync to cloud notice:', err);
  }

  return profile;
}
