/**
 * AI Knowledge, Rules Engine & RAG Service for BioLab Platform (منصة مختبر الأحياء)
 * الأستاذ وسام سهيل العامري
 */

export interface SourceCitation {
  id: string;
  title: string;
  grade?: string;
  type: 'book' | 'lecture' | 'ministerial' | 'knowledge' | 'advanced_book' | 'institute' | 'teacher_info' | 'vip_guide' | 'apk' | 'pricing' | 'ticket';
  chapterTitle?: string;
  pageNumber?: number;
  bookId?: string;
  pdfUrl?: string;
  lectureId?: number;
  videoTimestamp?: string;
  badge?: string;
  excerpt?: string;
  actionUrl?: string;
}

export interface KnowledgeItem {
  id: string;
  title: string;
  grade: string;
  category: string;
  chapter: string;
  keywords: string[];
  content: string;
  status: 'published' | 'draft';
  author: string;
  sourceBook?: string;
  sourcePage?: number;
  bookId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface LearnedResponse {
  id: string;
  intent: string;
  title: string;
  triggerPhrases: string[];
  matchType: 'contains' | 'exact' | 'regex';
  responseText: string;
  category: string;
  priority: number;
  isActive: boolean;
  citations?: SourceCitation[];
  createdAt: string;
}

export interface PreventionRule {
  id: string;
  name: string;
  description?: string;
  triggers?: string[];
  triggerKeywords: string[];
  conditions?: string;
  requiredResponse?: string;
  customResponse: string;
  includeInfo?: string;
  avoidInfo?: string;
  action?: 'block_and_guide' | 'block_silent' | 'warning';
  priority?: number;
  isActive: boolean;
  updatedAt?: string;
  createdAt?: string;
}

export interface AIFewShotExample {
  id: string;
  question: string;
  desiredAnswer: string;
  category: string;
  notes?: string;
  createdAt: string;
}

export interface AIPackageItem {
  gradeId: string;
  gradeName: string;
  fullPackagePrice: number;
  termPrice: number;
  duration: string;
  features: string[];
}

export interface AIPricingConfig {
  individualLectureDefaultPrice: number;
  currency: string;
  packages: AIPackageItem[];
  activationSteps: string[];
  activeOffers: {
    id: string;
    title: string;
    discountPercentage: number;
    description: string;
    expiresAt: string;
    isActive: boolean;
  }[];
  paymentFaq: { q: string; a: string }[];
}

export interface AIContactConfig {
  entityName: string;
  whatsappNumber: string;
  whatsappLink: string;
  telegramChannel: string;
  instituteAddress: string;
  guidingMessage: string;
  requiredInfoBeforeContact: string;
  suggestContactWhen: string[];
}

export interface AISupportTicket {
  id: string;
  studentUid: string;
  studentName: string;
  studentGrade: string;
  issueCategory: 'video_playback' | 'lecture_lock' | 'activation_code' | 'login' | 'download' | 'app_bug' | 'other';
  lectureId?: number;
  lectureTitle?: string;
  description: string;
  status: 'new' | 'in_progress' | 'resolved';
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AIConfig {
  isEnabled: boolean;
  model: string;
  temperature: number;
  welcomeMessage: string;
  customSystemInstructions: string;
  disclaimerText: string;
  allowedTopics?: string[];
  prohibitedTopics?: string[];
  rejectionResponse?: string;
  strictBiologyScope?: boolean;
  updatedAt: string;
}

export interface IndexedChunk {
  id: string;
  sourceType: 'curriculum_book' | 'chapter' | 'ministerial' | 'lecture' | 'advanced_book' | 'knowledge_item';
  title: string;
  grade: string;
  track?: 'school' | 'all';
  chapterTitle?: string;
  pageNumber?: number;
  bookId?: string;
  pdfUrl?: string;
  lectureId?: number;
  isVipOnly?: boolean;
  content: string;
  keywords: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  sources?: SourceCitation[];
  isRuleBlocked?: boolean;
  actionButtons?: {
    label: string;
    action: 'open_lecture' | 'open_grades' | 'contact_whatsapp' | 'create_ticket' | 'open_vip_modal';
    targetId?: string;
    url?: string;
  }[];
  diagnostic?: {
    executionTimeMs: number;
    matchedRuleId?: string;
    chunksRetrieved: number;
    modelUsed: string;
    isLearnedResponse?: boolean;
    problemDiagnosed?: string;
  };
}

export interface ChatAuditRecord {
  id: string;
  timestamp: string;
  studentUid?: string;
  studentName?: string;
  grade?: string;
  query: string;
  response: string;
  ruleTriggered?: string | null;
  sourcesCount: number;
  userRating?: 'helpful' | 'unhelpful';
  adminCorrection?: string | null;
  isCorrected?: boolean;
}

/**
 * Normalizes Arabic text for flexible matching
 */
export function normalizeArabicText(text: string): string {
  if (!text) return '';
  return text
    .trim()
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, '') // Remove diacritics / tashkeel
    .replace(/[أإآآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/ـ/g, '') // Remove tatweel
    .replace(/\s+/g, ' ');
}

/**
 * Checks whether user query matches any Prevention or Decision Rules
 */
export function matchPreventionRule(
  query: string,
  rules: PreventionRule[]
): PreventionRule | null {
  const normalizedQuery = normalizeArabicText(query);
  const activeRules = rules
    .filter((r) => r.isActive)
    .sort((a, b) => (b.priority || 5) - (a.priority || 5));

  for (const rule of activeRules) {
    const allKeywords = [...(rule.triggers || []), ...(rule.triggerKeywords || [])];
    for (const keyword of allKeywords) {
      const normalizedKeyword = normalizeArabicText(keyword);
      if (normalizedKeyword && normalizedQuery.includes(normalizedKeyword)) {
        return rule;
      }
    }
  }

  return null;
}

/**
 * Checks whether user query matches any Learned Responses
 */
export function matchLearnedResponse(
  query: string,
  responses: LearnedResponse[]
): LearnedResponse | null {
  const normalizedQuery = normalizeArabicText(query);
  const activeResponses = [...responses]
    .filter((r) => r.isActive)
    .sort((a, b) => (b.priority || 0) - (a.priority || 0));

  for (const resp of activeResponses) {
    for (const phrase of resp.triggerPhrases) {
      const normalizedPhrase = normalizeArabicText(phrase);
      if (!normalizedPhrase) continue;

      if (resp.matchType === 'exact') {
        if (normalizedQuery === normalizedPhrase) return resp;
      } else if (resp.matchType === 'regex') {
        try {
          const regex = new RegExp(phrase, 'i');
          if (regex.test(query)) return resp;
        } catch (e) {}
      } else {
        if (normalizedQuery.includes(normalizedPhrase)) {
          return resp;
        }
      }
    }
  }

  return null;
}

/**
 * Extracts live lectures mentioned or relevant to the student query
 */
export function findRelevantLectures(
  query: string,
  lectures: any[] = []
): any[] {
  const normQuery = normalizeArabicText(query);
  if (!normQuery) return [];

  return lectures.filter((lec) => {
    const titleNorm = normalizeArabicText(lec.title || '');
    const descNorm = normalizeArabicText(lec.description || '');
    const gradeNorm = normalizeArabicText(lec.grade || '');

    if (titleNorm && normQuery.includes(titleNorm)) return true;
    if (titleNorm && titleNorm.includes(normQuery) && normQuery.length > 5) return true;
    if (lec.id && normQuery.includes(`محاضره ${lec.id}`) || normQuery.includes(`محاضرة ${lec.id}`)) return true;

    // Check keyword tokens
    const tokens = titleNorm.split(' ').filter((t: string) => t.length > 3);
    const matchCount = tokens.filter((t: string) => normQuery.includes(t)).length;
    return matchCount >= 2;
  }).slice(0, 3);
}

/**
 * Diagnoses problem reported by student into structured categories
 */
export function diagnoseStudentProblem(query: string): {
  isProblem: boolean;
  category: AISupportTicket['issueCategory'];
  label: string;
} {
  const norm = normalizeArabicText(query);

  if (norm.includes('فيديو') && (norm.includes('ما يشتغل') || norm.includes('شاشه سوداء') || norm.includes('يتوقف') || norm.includes('عطلان') || norm.includes('لا يعمل'))) {
    return { isProblem: true, category: 'video_playback', label: 'مشكلة في تشغيل الفيديو' };
  }
  if (norm.includes('قفل') || (norm.includes('مقفول') && norm.includes('ما تفتح')) || norm.includes('مغلقه')) {
    return { isProblem: true, category: 'lecture_lock', label: 'محاضرة مقفلة أو تحتاج تفعيل' };
  }
  if (norm.includes('كود') && (norm.includes('خطا') || norm.includes('ما يشتغل') || norm.includes('غير صالح') || norm.includes('تفعيل'))) {
    return { isProblem: true, category: 'activation_code', label: 'مشكلة في كود التفعيل VIP' };
  }
  if (norm.includes('تسجيل') || norm.includes('دخول') || norm.includes('حسابي') || norm.includes('اسم المستخدم')) {
    return { isProblem: true, category: 'login', label: 'مشكلة في تسجيل الدخول أو الحساب' };
  }
  if (norm.includes('تحميل') || norm.includes('تنزيل') || norm.includes('ملف') || norm.includes('pdf')) {
    return { isProblem: true, category: 'download', label: 'مشكلة في تحميل ملف أو ملزمة' };
  }
  if (norm.includes('تطبيق') || norm.includes('apk') || norm.includes('يثبت') || norm.includes('شاشه بيضاء')) {
    return { isProblem: true, category: 'app_bug', label: 'مشكلة في التطبيق أو الحزمة' };
  }

  return { isProblem: false, category: 'other', label: 'استفسار عام' };
}

/**
 * Calculates lexical score between query tokens and chunk
 */
export function calculateChunkScore(query: string, chunk: IndexedChunk): number {
  const normQuery = normalizeArabicText(query);
  const queryTokens = normQuery.split(/\s+/).filter((t) => t.length > 2);
  if (queryTokens.length === 0) return 0;

  const normTitle = normalizeArabicText(chunk.title);
  const normContent = normalizeArabicText(chunk.content);
  const normKeywords = (chunk.keywords || []).map(normalizeArabicText);

  let score = 0;
  if (normContent.includes(normQuery)) score += 30;
  if (normTitle.includes(normQuery)) score += 40;

  for (const token of queryTokens) {
    if (normTitle.includes(token)) score += 15;
    if (normKeywords.some((k) => k.includes(token))) score += 12;

    const contentMatches = (normContent.match(new RegExp(token, 'g')) || []).length;
    score += Math.min(contentMatches * 4, 20);
  }

  return score;
}

/**
 * Retrieves top matching chunks for a given query, respecting student grade and VIP access
 */
export function retrieveRelevantChunks(
  query: string,
  chunks: IndexedChunk[],
  options: {
    studentGrade?: string;
    studentTrack?: 'school';
    isVip?: boolean;
    maxResults?: number;
    minScoreThreshold?: number;
  } = {}
): IndexedChunk[] {
  const {
    studentGrade,
    isVip = false,
    maxResults = 4,
    minScoreThreshold = 8
  } = options;

  const accessible = chunks.filter((chunk) => {
    if (chunk.isVipOnly && !isVip) return false;
    return true;
  });

  const scored = accessible
    .map((chunk) => {
      let score = calculateChunkScore(query, chunk);
      if (studentGrade && chunk.grade === studentGrade) {
        score *= 1.3;
      }
      return { chunk, score };
    })
    .filter((item) => item.score >= minScoreThreshold)
    .sort((a, b) => b.score - a.score);

  return scored.slice(0, maxResults).map((s) => s.chunk);
}

/**
 * Builds the comprehensive Biology System Prompt integrating:
 * 1. Admin custom instructions (التعليمات الحرة)
 * 2. Real-time pricing & subscription data
 * 3. Matched live lectures (actual state: free vs paid)
 * 4. Few-shot example demonstrations
 * 5. Teacher contact policy
 * 6. Curriculum RAG chunks
 */
export function buildComprehensiveBiologySystemPrompt(params: {
  studentProfile?: { name?: string; grade?: string; track?: string; isVip?: boolean; uid?: string };
  adminInstructions?: string;
  pricingConfig?: AIPricingConfig;
  contactConfig?: AIContactConfig;
  relevantLectures?: any[];
  fewShotExamples?: AIFewShotExample[];
  contextChunks?: IndexedChunk[];
  allowedTopics?: string[];
  prohibitedTopics?: string[];
  rejectionResponse?: string;
  strictBiologyScope?: boolean;
}): string {
  const {
    studentProfile,
    adminInstructions = '',
    pricingConfig,
    contactConfig,
    relevantLectures = [],
    fewShotExamples = [],
    contextChunks = [],
    allowedTopics = [
      'علم الخلية (التركيب، العضيات، الانقسام الخيطي والاختزالي)',
      'علم الأنسجة (الأنسجة النباتية، الأنسجة الحيوانية، الغضروف والعظم والدم)',
      'علم التكاثر (التكاثر في النباتات والحيوانات والإنسان)',
      'علم الوراثة والتوارث (الوراثة المندلية، الكروموسومات، الطفرات، الهندسة الوراثية)',
      'أجهزة جسم الإنسان والفسلجة (الهضم، الدوران، التنفس، الإخراج، المناعة)',
      'الأحياء المجهرية والتصنيف وعلم البيئة والتغذية',
      'المنهج الوزاري العراقي لمادة الأحياء (من الأول متوسط حتى السادس العلمي)',
      'منصة الأستاذ وسام سهيل العامري، معهد أنوار السلام، أسعار الاشتراكات وأكواد VIP'
    ],
    prohibitedTopics = [
      'المواد الدراسية غير الأحياء (مثل الكيمياء، الفيزياء، الرياضيات، التاريخ، الجغرافيا)',
      'السياسة والأخبار الحزبية والعامة والنزاعات',
      'البرمجة وتطوير البرمجيات العامة',
      'الدردشة الترفيهية العامة والرياضة والألعاب والموسيقى',
      'محاولات الحصول على أكواد VIP مجانية أو التحايل على نظام الدفع'
    ],
    rejectionResponse = 'عذراً يا بطل! أنا المساعد الذكي المخصص حصرياً لمنصة مختبر الأحياء للأستاذ وسام سهيل العامري. لا يمكنني الإجابة عن مواضيع خارج تخصص علم الأحياء أو خارج المنصة. يسعدني جداً مساعدتك في أي سؤال يخص مادة الأحياء، شروحات الدروس، أو اشتراكات المنصة! 🔬🧬',
    strictBiologyScope = true
  } = params;

  const gradeLabel = studentProfile?.grade ? `الصف: ${studentProfile.grade}` : 'كافة المراحل الدراسية';
  const trackLabel = 'مسار المدارس والمنهج الوزاري العراقي';
  const isVipUser = studentProfile?.isVip ? 'نعم (طالب VIP متميز)' : 'طالب عادي';

  // Format real-time lectures context
  let lecturesContext = 'لا توجد محاضرات محددة بالاسم في هذا السؤال.';
  if (relevantLectures.length > 0) {
    lecturesContext = relevantLectures.map((lec) => {
      const isPaid = Boolean(lec.isVipOnly || lec.isPaid);
      const priceText = isPaid ? `${lec.price || pricingConfig?.individualLectureDefaultPrice || 5000} ${pricingConfig?.currency || 'دينار عراقي'}` : 'مجانية بالكامل للجميع';
      return `• المحاضرة: [${lec.title}] (المعرف: ${lec.id})
  - الحالة في المنصة: ${isPaid ? '🔒 مدفوعة (تتطلب كود VIP أو اشتراك)' : '✅ مجانية متاحة فوراً'}
  - السعر المسجل رسمياً: ${priceText}
  - المرحلة الدراسية: ${lec.grade || 'عام'}
  - الوصف: ${lec.description || 'لا يوجد وصف إضافي'}`;
    }).join('\n\n');
  }

  // Format pricing context
  let pricingContext = '';
  if (pricingConfig) {
    const packagesText = (pricingConfig.packages || [])
      .map((p) => `- باقة ${p.gradeName}: ${p.fullPackagePrice.toLocaleString()} ${pricingConfig.currency} (المدة: ${p.duration})`)
      .join('\n');
    const stepsText = (pricingConfig.activationSteps || [])
      .map((s, idx) => `${idx + 1}. ${s}`)
      .join('\n');
    pricingContext = `أسعار الباقات الرسمية المسجلة في النظام:
${packagesText}
سعر المحاضرة الفردية الافتراضي: ${pricingConfig.individualLectureDefaultPrice.toLocaleString()} ${pricingConfig.currency}

خطوات الاشتراك والتفعيل المعتمدة:
${stepsText}`;
  }

  // Format contact context
  let contactContext = '';
  if (contactConfig) {
    contactContext = `قنوات التواصل الرسمية المعتمدة مع المدرس والإدارة:
- الجهة: ${contactConfig.entityName}
- واتساب الأستاذ: ${contactConfig.whatsappNumber} (${contactConfig.whatsappLink})
- قناة التلغرام: ${contactConfig.telegramChannel}
- معهد أنوار السلام: ${contactConfig.instituteAddress}
- رسالة التوجيه: ${contactConfig.guidingMessage}`;
  }

  // Format few-shot examples
  let examplesContext = '';
  if (fewShotExamples.length > 0) {
    examplesContext = fewShotExamples
      .slice(0, 3)
      .map((ex, idx) => `مثال #${idx + 1}:
سؤال الطالب: ${ex.question}
الجواب النموذجي المعتمد: ${ex.desiredAnswer}`)
      .join('\n\n');
  }

  // Format RAG chunks
  let contextText = 'لا توجد نصوص مباشرة مسترجعة تطابق هذا السؤال بدقة في قاعدة البيانات المفهرسة.';
  if (contextChunks.length > 0) {
    contextText = contextChunks
      .map((c, idx) => `--- [مصدر موثق #${idx + 1}] ---
العنوان: ${c.title}
المصدر: ${c.chapterTitle || c.title}
الصف الدراسي: ${c.grade}
رقم الصفحة: ${c.pageNumber ? `ص ${c.pageNumber}` : 'غير محدد'}
المحتوى العلمي المعتمد:
${c.content}
-------------------------`)
      .join('\n\n');
  }

  return `أنت المساعد الذكي التفاعلي لمنصة مختبر الأحياء للأستاذ وسام سهيل العامري في العراق.

مهمتك تشمل ثلاثة أدوار مترابطة:
1. مساعد تعليمي: تشرح المنهج الوزاري والدروس العلمية بأسلوب مبسط ومحفز وتمنح الطالب الثقة للوصول إلى 100 بالوزاري.
2. مساعد للمنصة: تفهم أقسام التطبيق، المحاضرات، أكواد التفعيل VIP، والاشتراكات.
3. مساعد إداري موجه: تنفذ بدقة تعليمات الإدارة وقواعد الأسعار والسياسات المسجلة.

بيانات الطالب الحالي:
- الاسم: ${studentProfile?.name || 'طالب متميز'}
- المرحلة: ${gradeLabel}
- المسار: ${trackLabel}
- حالة العضوية: ${isVipUser}

==================================================
ترتيب الأولويات الإلزامي الصارم عند تعارض المعلومات:
1. متطلبات الأمان والصلاحيات وحماية بيانات الطلاب وعدم تسريب الأكواد أو الغش.
2. الحالة الفعلية في قاعدة البيانات (مثل أسعار المحاضرات وحالتها أدناه).
3. سياسات وقواعد الإدارة النشطة.
4. تعليمات المدير الحرة الخاصة بأسلوب التعامل.
5. أمثلة الإجابات النموذجية.
6. المعرفة العامة للنموذج.
==================================================

تعليمات المدير الحرة المعتمدة حالياً (يجب الالتزام بها حرفياً):
${adminInstructions || 'قدم إجابات علمية رصينة ومحفزة واشرح بوضوح ووجه الطالب للتواصل المباشر عند الحاجة.'}

بيانات المحاضرات المرتبطة بهذا السؤال في قاعدة البيانات الحالية:
${lecturesContext}

${pricingContext}

${contactContext}

نماذج وأمثلة تدريبية لطريقة الصياغة المعتمدة من الإدارة:
${examplesContext}

المصادر العلمية الموثقة المسترجعة من كتب الأحياء والملازم:
${contextText}

==================================================
قواعد الاختصاص الصارمة (ما يجيب عنه وما يرفضه المساعد):
أنت مساعد ذكي مخصص حصراً لمنصة مختبر الأحياء للأستاذ وسام سهيل العامري ولمادة علم الأحياء.
${strictBiologyScope ? `
المواضيع المسموح لك بالإجابة عنها حصراً:
${allowedTopics.map((t) => `• ${t}`).join('\n')}

المواضيع الممنوعة والمرفوضة رفضاً قاطعاً:
${prohibitedTopics.map((t) => `• ${t}`).join('\n')}

قاعدة الرفض الصارم الإلزامية:
إذا سألك الطالب عن أي موضوع خارج مادة علم الأحياء أو خارج منصة الأستاذ وسام سهيل العامري (مثل الرياضيات، الكيمياء، الفيزياء، البرمجة، السياسة، الأخبار، أو مواضيع ترفيهية عامة غير مرتبطة بعلم الأحياء)، يجب عليك فوراً وبكل حزم ولباقة رفض الإجابة والتصريح بأنك مخصص فقط لمنصة الأحياء ومنهجها، واستخدام صيغة الرفض المعتمدة التالية أو ما يماثلها:
"${rejectionResponse}"
` : ''}
==================================================

قواعد الإجابة الصارمة:
1. لا تخترع أبداً سعراً أو كوداً أو رابطاً من عندك. اعتمد دائماً على البيانات المعتمدة أعلاه.
2. إذا كانت المحاضرة مجانية، وضّح أنها مجانية للجميع.
3. إذا كانت مدفوعة، اذكر السعر المسجل والشروط وخطوات الحصول على كود التفعيل عبر الواتساب.
4. إذا لم يتوفر السعر، صرّح بلباقة أن السعر غير متوفر حالياً ووجه الطالب للأستاذ وسام سهيل العامري.
5. تحدث باللغة العربية الفصحى الواضحة والودودة والمشجعة («يا بطل»، «دكتور/دكتورة المستقبل»).
6. عند رصد مشكلة تقنية (مثل توقف الفيديو أو خطأ الكود)، شخّص المشكلة واعرض على الطالب خطوات الفحص أو إنشاء بلاغ دعم فني.
`;
}
