/**
 * Android Permission & Native Device Bridge Service
 * Provides genuine, bi-directional integration between React web frontend and Android Native Kotlin layer.
 * 
 * Capabilities:
 * 1. Runtime Notifications (Android 13+ POST_NOTIFICATIONS, Android 8-12 channels, Web fallback).
 * 2. Scoped Storage & Direct Downloads (MediaStore / DownloadManager to device Downloads folder).
 * 3. Just-In-Time Permission Requests with educational rationale dialogs.
 * 4. Deep linking and Android System App Settings redirects when blocked.
 */

declare global {
  interface Window {
    AndroidBridge?: {
      isAndroidApp: () => boolean;
      getAndroidVersion: () => number;
      checkNotificationPermission: () => 'granted' | 'denied' | 'prompt';
      requestNotificationPermission: () => void;
      checkStoragePermission: () => 'granted' | 'denied' | 'prompt';
      checkStorageAccess?: () => 'granted' | 'denied' | 'prompt';
      requestStoragePermission: () => void;
      requestStorageAccess?: () => void;
      downloadFile: (url: string, fileName: string, mimeType: string, description: string) => boolean;
      showLocalNotification: (title: string, message: string, channelType: string, targetUrl: string) => void;
      openAppSettings: () => void;
      openNotificationSettings: () => void;
    };
    onAndroidNotificationPermissionResult?: (granted: boolean) => void;
    onAndroidStoragePermissionResult?: (granted: boolean) => void;
  }
}

export type PermissionType = 'notifications' | 'storage';
export type PermissionState = 'granted' | 'denied' | 'prompt' | 'unsupported';

class AndroidPermissionBridgeService {
  private notificationListeners: ((granted: boolean) => void)[] = [];
  private storageListeners: ((granted: boolean) => void)[] = [];

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('androidNotificationPermissionResult', (event: any) => {
        const granted = Boolean(event.detail?.granted);
        this.handleNotificationResult(granted);
      });

      window.addEventListener('androidStoragePermissionResult', (event: any) => {
        const granted = Boolean(event.detail?.granted);
        this.handleStorageResult(granted);
      });

      // Global window fallback callbacks for older WebView engines
      window.onAndroidNotificationPermissionResult = (granted: boolean) => {
        this.handleNotificationResult(granted);
      };
      window.onAndroidStoragePermissionResult = (granted: boolean) => {
        this.handleStorageResult(granted);
      };
    }
  }

  private handleNotificationResult(granted: boolean) {
    try {
      localStorage.setItem('biolab_notifications_allowed', granted ? 'true' : 'false');
      if (granted) {
        localStorage.setItem('biolab_notifications_granted_at', new Date().toISOString());
      }
    } catch (e) {}

    const callbacks = [...this.notificationListeners];
    this.notificationListeners = [];
    callbacks.forEach(cb => {
      try { cb(granted); } catch (e) {}
    });

    window.dispatchEvent(new CustomEvent('biolab_notification_state_changed', {
      detail: { granted }
    }));
  }

  private handleStorageResult(granted: boolean) {
    try {
      localStorage.setItem('biolab_storage_allowed', granted ? 'true' : 'false');
      if (granted) {
        localStorage.setItem('biolab_storage_granted_at', new Date().toISOString());
      }
    } catch (e) {}

    const callbacks = [...this.storageListeners];
    this.storageListeners = [];
    callbacks.forEach(cb => {
      try { cb(granted); } catch (e) {}
    });

    window.dispatchEvent(new CustomEvent('biolab_storage_state_changed', {
      detail: { granted }
    }));
  }

  /**
   * Check if running inside the official Android APK
   */
  public isAndroidNative(): boolean {
    if (typeof window === 'undefined') return false;
    return Boolean(
      window.AndroidBridge && 
      typeof window.AndroidBridge.isAndroidApp === 'function' && 
      window.AndroidBridge.isAndroidApp()
    );
  }

  /**
   * Get Android SDK Version (e.g. 33 for Android 13, 34 for Android 14, 35 for Android 15)
   */
  public getAndroidSdkVersion(): number {
    if (this.isAndroidNative()) {
      try {
        return window.AndroidBridge!.getAndroidVersion();
      } catch (e) {
        return 33;
      }
    }
    return 0;
  }

  /**
   * Inspect current Notification permission state
   */
  public async checkNotificationPermission(): Promise<PermissionState> {
    if (this.isAndroidNative()) {
      try {
        const res = window.AndroidBridge!.checkNotificationPermission();
        return (res === 'granted' || res === 'denied' || res === 'prompt') ? res : 'prompt';
      } catch (e) {
        return 'prompt';
      }
    }

    // Web / PWA fallback
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') return 'granted';
      if (Notification.permission === 'denied') return 'denied';
      return 'prompt';
    }

    return 'unsupported';
  }

  /**
   * Request Notification permission (triggers official OS dialog and returns granted status)
   */
  public requestNotificationPermission(): Promise<boolean> {
    return new Promise((resolve) => {
      if (this.isAndroidNative()) {
        // If already granted, return true immediately
        try {
          const current = window.AndroidBridge!.checkNotificationPermission();
          if (current === 'granted') {
            this.handleNotificationResult(true);
            resolve(true);
            return;
          }
        } catch (e) {}

        const timeout = setTimeout(() => {
          this.checkNotificationPermission().then(state => resolve(state === 'granted'));
        }, 15000);

        this.notificationListeners.push((granted) => {
          clearTimeout(timeout);
          resolve(granted);
        });

        try {
          window.AndroidBridge!.requestNotificationPermission();
        } catch (e) {
          clearTimeout(timeout);
          resolve(false);
        }
        return;
      }

      // Web / PWA fallback
      if (typeof window !== 'undefined' && 'Notification' in window) {
        Notification.requestPermission().then((permission) => {
          const granted = permission === 'granted';
          this.handleNotificationResult(granted);
          resolve(granted);
        }).catch(() => {
          resolve(false);
        });
        return;
      }

      resolve(false);
    });
  }

  /**
   * Inspect current Storage access state
   */
  public async checkStorageAccess(): Promise<PermissionState> {
    if (this.isAndroidNative()) {
      try {
        const bridge = window.AndroidBridge!;
        const res = bridge.checkStorageAccess ? bridge.checkStorageAccess() : bridge.checkStoragePermission();
        return (res === 'granted' || res === 'denied' || res === 'prompt') ? res : 'prompt';
      } catch (e) {
        return 'prompt';
      }
    }

    // Browsers natively handle downloads to the Downloads directory
    return 'granted';
  }

  public async checkStoragePermission(): Promise<PermissionState> {
    return this.checkStorageAccess();
  }

  /**
   * Request Storage Access (triggers official OS dialog and returns granted status)
   * Supports Scoped Storage on Android 10+ (API 29+) and runtime storage permission on Android 9 and below
   */
  public requestStorageAccess(): Promise<boolean> {
    return new Promise((resolve) => {
      if (this.isAndroidNative()) {
        // Android 10+ (API >= 29) uses Scoped Storage (Environment.DIRECTORY_DOWNLOADS works without storage permission)
        if (this.getAndroidSdkVersion() >= 29) {
          this.handleStorageResult(true);
          resolve(true);
          return;
        }

        const timeout = setTimeout(() => {
          this.checkStorageAccess().then(state => resolve(state === 'granted'));
        }, 15000);

        this.storageListeners.push((granted) => {
          clearTimeout(timeout);
          resolve(granted);
        });

        try {
          const bridge = window.AndroidBridge!;
          if (typeof bridge.requestStorageAccess === 'function') {
            bridge.requestStorageAccess();
          } else {
            bridge.requestStoragePermission();
          }
        } catch (e) {
          clearTimeout(timeout);
          resolve(false);
        }
        return;
      }

      // Web / Desktop fallback
      this.handleStorageResult(true);
      resolve(true);
    });
  }

  public requestStoragePermission(): Promise<boolean> {
    return this.requestStorageAccess();
  }

  /**
   * Download a file (PDF, Booklet, Video) into device Downloads folder
   */
  public async downloadFile(options: {
    url: string;
    fileName: string;
    mimeType?: string;
    description?: string;
  }): Promise<boolean> {
    const { url, fileName, mimeType = 'application/pdf', description = 'منصة الكائنات | الأستاذ وسام سهيل العامري' } = options;

    if (this.isAndroidNative()) {
      // Ensure storage access on older Android if needed
      const storageState = await this.checkStorageAccess();
      if (storageState !== 'granted') {
        const granted = await this.requestStorageAccess();
        if (!granted) {
          return false;
        }
      }

      try {
        const cleanName = fileName.endsWith('.pdf') ? fileName : `${fileName}.pdf`;
        return window.AndroidBridge!.downloadFile(url, cleanName, mimeType, description);
      } catch (e) {
        console.warn('Native download exception, falling back to browser flow:', e);
      }
    }

    // Standard Browser / PWA fallback
    try {
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName.endsWith('.pdf') ? fileName : `${fileName}.pdf`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      return true;
    } catch (e) {
      console.error('Browser download failed:', e);
      return false;
    }
  }

  /**
   * Show local Android status bar notification
   */
  public async sendLocalNotification(options: {
    title: string;
    message: string;
    channelType?: 'lectures' | 'announcements' | 'updates' | 'downloads';
    targetUrl?: string;
  }): Promise<boolean> {
    const { title, message, channelType = 'updates', targetUrl = '' } = options;

    if (this.isAndroidNative()) {
      try {
        window.AndroidBridge!.showLocalNotification(title, message, channelType, targetUrl);
        return true;
      } catch (e) {
        console.warn('Could not post native notification:', e);
      }
    }

    // Web Notification fallback
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body: message,
          icon: 'https://res.cloudinary.com/zijsnksq/image/upload/f_auto,q_auto/68566',
          badge: 'https://res.cloudinary.com/zijsnksq/image/upload/f_auto,q_auto/68566'
        });
        return true;
      } catch (e) {}
    }

    return false;
  }

  /**
   * Open Android App Details Settings (where user can toggle permissions if blocked)
   */
  public openAppSettings() {
    if (this.isAndroidNative()) {
      try {
        window.AndroidBridge!.openAppSettings();
      } catch (e) {}
    }
  }

  /**
   * Open Android App Notification Settings
   */
  public openNotificationSettings() {
    if (this.isAndroidNative()) {
      try {
        window.AndroidBridge!.openNotificationSettings();
      } catch (e) {
        this.openAppSettings();
      }
    }
  }

  /**
   * Check if notifications are active in localStorage or system
   */
  public isNotificationsSubscribed(): boolean {
    if (typeof window === 'undefined') return false;
    try {
      return localStorage.getItem('biolab_notifications_allowed') === 'true';
    } catch (e) {
      return false;
    }
  }
}

// Single instance export
export const androidPermissionBridge = new AndroidPermissionBridgeService();

// Standalone function exports for direct component consumption
export const requestNotificationPermission = (): Promise<boolean> => {
  return androidPermissionBridge.requestNotificationPermission();
};

export const requestStorageAccess = (): Promise<boolean> => {
  return androidPermissionBridge.requestStorageAccess();
};

export const requestStoragePermission = (): Promise<boolean> => {
  return androidPermissionBridge.requestStorageAccess();
};

export const checkNotificationPermission = (): Promise<PermissionState> => {
  return androidPermissionBridge.checkNotificationPermission();
};

export const checkStorageAccess = (): Promise<PermissionState> => {
  return androidPermissionBridge.checkStorageAccess();
};

export const checkStoragePermission = (): Promise<PermissionState> => {
  return androidPermissionBridge.checkStorageAccess();
};
