import { videoProviderRegistry } from './VideoProviderRegistry';
import { ResolvedVideoInfo, VideoPlaybackMode } from './videoProviders/BaseVideoProvider';

export class VideoUrlResolver {
  /**
   * Resolves any input URL into standard playback specifications.
   * Preserves the original URL while determining the best playback mode and embed path.
   */
  public static async resolve(url: string): Promise<ResolvedVideoInfo> {
    return await videoProviderRegistry.resolve(url);
  }

  /**
   * Synchronously inspects a URL to identify its video provider name and preliminary info.
   */
  public static detectProvider(url: string): { id: string; name: string } {
    const provider = videoProviderRegistry.getProviderForUrl(url);
    return {
      id: provider.id,
      name: provider.name
    };
  }

  /**
   * Extracts or generates the best thumbnail for the video URL.
   */
  public static getThumbnail(url: string, fallback?: string): string {
    const thumb = videoProviderRegistry.extractThumbnail(url);
    return thumb || fallback || 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80';
  }

  /**
   * Validates if a string is a potentially valid video URL.
   */
  public static isValidVideoUrl(url: string): boolean {
    if (!url || typeof url !== 'string') return false;
    const trimmed = url.trim();
    if (trimmed.length < 5) return false;
    return (
      trimmed.startsWith('http://') ||
      trimmed.startsWith('https://') ||
      trimmed.startsWith('/uploads/') ||
      trimmed.startsWith('blob:') ||
      trimmed.startsWith('<iframe')
    );
  }

  /**
   * Extracts clean web URL if an <iframe> embed code was pasted.
   */
  public static sanitizeUrl(input: string): string {
    if (!input) return '';
    const trimmed = input.trim();
    if (trimmed.includes('<iframe') && trimmed.includes('src=')) {
      const match = trimmed.match(/src=["']([^"']+)["']/i);
      if (match && match[1]) return match[1];
    }
    return trimmed;
  }
}

export type { ResolvedVideoInfo, VideoPlaybackMode };
