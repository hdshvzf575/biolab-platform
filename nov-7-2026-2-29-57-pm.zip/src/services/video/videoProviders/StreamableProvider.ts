import { IVideoProvider, ResolvedVideoInfo } from './BaseVideoProvider';

export class StreamableProvider implements IVideoProvider {
  public id = 'streamable';
  public name = 'ستريملبل (Streamable)';

  private extractVideoId(url: string): string | null {
    if (!url) return null;
    const match = url.match(/streamable\.com\/(?:e\/)?([a-zA-Z0-9]+)/i);
    return match ? match[1] : null;
  }

  public canHandle(url: string): boolean {
    if (!url) return false;
    return url.toLowerCase().includes('streamable.com');
  }

  public resolve(url: string): ResolvedVideoInfo {
    const videoId = this.extractVideoId(url);
    if (!videoId) {
      return {
        originalUrl: url,
        providerId: this.id,
        providerName: this.name,
        playbackMode: 'external_fallback',
        playbackUrl: url,
        canEmbed: false,
        requiresExternalOpen: true
      };
    }

    const embedUrl = `https://streamable.com/e/${videoId}`;

    return {
      originalUrl: url,
      providerId: this.id,
      providerName: this.name,
      playbackMode: 'official_iframe',
      playbackUrl: embedUrl,
      canEmbed: true,
      extraInfo: `Streamable ID: ${videoId}`
    };
  }
}
