import { IVideoProvider, ResolvedVideoInfo } from './BaseVideoProvider';

export class AnonMp4Provider implements IVideoProvider {
  public id = 'anon_mp4';
  public name = 'منصة AnonMP4';

  public canHandle(url: string): boolean {
    if (!url) return false;
    const lower = url.toLowerCase();
    return (
      lower.includes('anonmp4.com') ||
      lower.includes('anonmp4.org') ||
      lower.includes('anonfile.net') ||
      lower.includes('anonfiles.com')
    );
  }

  private extractId(url: string): string | null {
    if (!url) return null;
    // Matches /view/ID, /v/ID, /embed/ID, /download/ID
    const match = url.match(/(?:view|v|embed|download)\/([a-zA-Z0-9_-]+)/i);
    if (match) return match[1];

    // Or trailing segment
    const segments = url.split('?')[0].split('/').filter(Boolean);
    const last = segments[segments.length - 1];
    return (last && last.length >= 4) ? last : null;
  }

  public resolve(url: string): ResolvedVideoInfo {
    const cleanUrl = url.split('?')[0].toLowerCase();
    
    // If it's a direct mp4 link on their CDN
    if (cleanUrl.endsWith('.mp4') || cleanUrl.endsWith('.webm')) {
      return {
        originalUrl: url,
        providerId: this.id,
        providerName: this.name,
        playbackMode: 'html5_video',
        playbackUrl: url,
        canEmbed: true,
        mimeType: 'video/mp4'
      };
    }

    const videoId = this.extractId(url);
    let embedUrl = url;

    // Convert view or download link into official embed player link
    if (url.includes('anonmp4.com') && videoId) {
      if (!url.includes('/embed/')) {
        embedUrl = `https://anonmp4.com/embed/${videoId}`;
      }
    }

    return {
      originalUrl: url,
      providerId: this.id,
      providerName: this.name,
      playbackMode: 'anon_mp4_embed',
      playbackUrl: embedUrl,
      canEmbed: true,
      requiresExternalOpen: false,
      extraInfo: videoId ? `معرف الفيديو: ${videoId}` : undefined
    };
  }

  public extractThumbnail(): string | null {
    return 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80';
  }
}
