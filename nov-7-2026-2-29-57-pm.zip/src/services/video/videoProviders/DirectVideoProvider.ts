import { IVideoProvider, ResolvedVideoInfo } from './BaseVideoProvider';

export class DirectVideoProvider implements IVideoProvider {
  public id = 'direct_video';
  public name = 'ملف فيديو مباشر (HTML5 Direct Video)';

  public canHandle(url: string): boolean {
    if (!url) return false;
    const cleanUrl = url.split('?')[0].toLowerCase().trim();
    
    // Direct file extensions
    if (
      cleanUrl.endsWith('.mp4') ||
      cleanUrl.endsWith('.webm') ||
      cleanUrl.endsWith('.ogg') ||
      cleanUrl.endsWith('.mov') ||
      cleanUrl.endsWith('.m4v') ||
      cleanUrl.endsWith('.m3u8')
    ) {
      return true;
    }

    // Local / Server uploads
    if (cleanUrl.startsWith('/uploads/videos/') || cleanUrl.startsWith('/uploads/')) {
      return true;
    }

    // Firebase Storage or Cloud bucket video tokens
    if (url.includes('firebasestorage.googleapis.com') && (url.includes('videos%2F') || url.includes('video'))) {
      return true;
    }

    // Blob or file URIs
    if (url.startsWith('blob:') || url.startsWith('content://')) {
      return true;
    }

    return false;
  }

  public resolve(url: string): ResolvedVideoInfo {
    const cleanUrl = url.split('?')[0].toLowerCase().trim();
    let mimeType = 'video/mp4';
    if (cleanUrl.endsWith('.webm')) mimeType = 'video/webm';
    else if (cleanUrl.endsWith('.ogg')) mimeType = 'video/ogg';
    else if (cleanUrl.endsWith('.mov')) mimeType = 'video/quicktime';
    else if (cleanUrl.endsWith('.m3u8')) mimeType = 'application/x-mpegURL';

    return {
      originalUrl: url,
      providerId: this.id,
      providerName: this.name,
      playbackMode: 'html5_video',
      playbackUrl: url,
      canEmbed: true,
      mimeType,
      thumbnailUrl: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80'
    };
  }

  public extractThumbnail(): string | null {
    return 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80';
  }
}
