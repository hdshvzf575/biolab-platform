import { IVideoProvider, ResolvedVideoInfo } from './BaseVideoProvider';

export class DailymotionProvider implements IVideoProvider {
  public id = 'dailymotion';
  public name = 'ديلي موشن (Dailymotion)';

  private extractVideoId(url: string): string | null {
    if (!url) return null;
    const match = url.match(/(?:dailymotion\.com\/(?:video|embed\/video)\/|dai\.ly\/)([a-zA-Z0-9]+)/i);
    return match ? match[1] : null;
  }

  public canHandle(url: string): boolean {
    if (!url) return false;
    const lower = url.toLowerCase();
    return lower.includes('dailymotion.com') || lower.includes('dai.ly');
  }

  public resolve(url: string): ResolvedVideoInfo {
    const videoId = this.extractVideoId(url);
    if (!videoId) {
      return {
        originalUrl: url,
        providerId: this.id,
        providerName: this.name,
        playbackMode: 'external_fallback',
        playbackUrl: url,
        canEmbed: false,
        requiresExternalOpen: true,
        errorMessage: 'تعذر استخراج معرف فيديو Dailymotion'
      };
    }

    const embedUrl = `https://www.dailymotion.com/embed/video/${videoId}`;
    const thumbnailUrl = `https://www.dailymotion.com/thumbnail/video/${videoId}`;

    return {
      originalUrl: url,
      providerId: this.id,
      providerName: this.name,
      playbackMode: 'official_iframe',
      playbackUrl: embedUrl,
      thumbnailUrl,
      canEmbed: true,
      extraInfo: `Dailymotion ID: ${videoId}`
    };
  }

  public extractThumbnail(url: string): string | null {
    const videoId = this.extractVideoId(url);
    return videoId ? `https://www.dailymotion.com/thumbnail/video/${videoId}` : null;
  }
}
