import { IVideoProvider, ResolvedVideoInfo } from './BaseVideoProvider';
import { getCachedGoogleToken } from '../../../utils/appEnvironment';

export class GoogleDriveVideoProvider implements IVideoProvider {
  public id = 'google_drive';
  public name = 'جوجل درايف (Google Drive Video)';

  private extractFileId(url: string): string | null {
    if (!url) return null;
    // Matches /file/d/FILE_ID or id=FILE_ID
    const match = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/i) || url.match(/[?&]id=([a-zA-Z0-9_-]+)/i);
    return match ? match[1] : null;
  }

  public canHandle(url: string): boolean {
    if (!url) return false;
    const lower = url.toLowerCase();
    return lower.includes('drive.google.com') || lower.includes('docs.google.com');
  }

  public resolve(url: string): ResolvedVideoInfo {
    const fileId = this.extractFileId(url);
    if (!fileId) {
      return {
        originalUrl: url,
        providerId: this.id,
        providerName: this.name,
        playbackMode: 'external_fallback',
        playbackUrl: url,
        canEmbed: false,
        requiresExternalOpen: true,
        errorMessage: 'تعذر استخراج معرف الملف من رابط Google Drive'
      };
    }

    // Direct in-app streaming route through platform's video proxy
    // Eliminates external Google Drive redirects and embeds as native platform video
    const token = getCachedGoogleToken();
    const streamUrl = token
      ? `/api/stream-drive/${fileId}?token=${encodeURIComponent(token)}`
      : `/api/stream-drive/${fileId}`;

    return {
      originalUrl: url,
      providerId: this.id,
      providerName: this.name,
      playbackMode: 'html5_video',
      playbackUrl: streamUrl,
      canEmbed: true,
      mimeType: 'video/mp4',
      extraInfo: `Drive ID: ${fileId}`
    };
  }

  public extractThumbnail(): string | null {
    return 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=800&q=80';
  }
}
