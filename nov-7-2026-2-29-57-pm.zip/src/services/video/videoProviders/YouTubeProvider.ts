import { IVideoProvider, ResolvedVideoInfo } from './BaseVideoProvider';

export class YouTubeProvider implements IVideoProvider {
  public id = 'youtube';
  public name = 'يوتيوب (YouTube)';

  private extractVideoId(url: string): string | null {
    if (!url) return null;
    const trimmed = url.trim();
    // Regular expressions covering watch?v=, embed/, shorts/, youtu.be/, and youtube-nocookie
    const regExp = /(?:youtube(?:-nocookie)?\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?|shorts)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i;
    const match = trimmed.match(regExp);
    return match ? match[1] : null;
  }

  public canHandle(url: string): boolean {
    if (!url) return false;
    const lower = url.toLowerCase();
    return lower.includes('youtube.com') || lower.includes('youtu.be') || lower.includes('youtube-nocookie.com');
  }

  public resolve(url: string): ResolvedVideoInfo {
    const videoId = this.extractVideoId(url);
    if (!videoId) {
      return {
        originalUrl: url,
        providerId: this.id,
        providerName: this.name,
        playbackMode: 'external_fallback',
        playbackUrl: url,
        canEmbed: false,
        requiresExternalOpen: true,
        errorMessage: 'تعذر استخراج معرف فيديو YouTube من هذا الرابط'
      };
    }

    // Official privacy-enhanced embed URL with optimized parameters
    const embedUrl = `https://www.youtube-nocookie.com/embed/${videoId}?rel=0&modestbranding=1&playsinline=1&enablejsapi=1`;
    const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

    return {
      originalUrl: url,
      providerId: this.id,
      providerName: this.name,
      playbackMode: 'official_iframe',
      playbackUrl: embedUrl,
      thumbnailUrl,
      canEmbed: true,
      extraInfo: `Video ID: ${videoId}`
    };
  }

  public extractThumbnail(url: string): string | null {
    const videoId = this.extractVideoId(url);
    return videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : null;
  }
}
