import { IVideoProvider, ResolvedVideoInfo } from './BaseVideoProvider';

export class GenericEmbedProvider implements IVideoProvider {
  public id = 'generic_embed';
  public name = 'رابط خارجي / مشغل مخصص (External Video / Embed)';

  private extractSrcFromIframe(input: string): string | null {
    if (!input) return null;
    if (input.includes('<iframe') && input.includes('src=')) {
      const match = input.match(/src=["']([^"']+)["']/i);
      return match ? match[1] : null;
    }
    return null;
  }

  public canHandle(url: string): boolean {
    if (!url) return false;
    const trimmed = url.trim();
    return (
      trimmed.startsWith('http://') ||
      trimmed.startsWith('https://') ||
      trimmed.startsWith('<iframe') ||
      trimmed.startsWith('/')
    );
  }

  public resolve(url: string): ResolvedVideoInfo {
    const trimmed = url.trim();
    const extractedIframeSrc = this.extractSrcFromIframe(trimmed);
    const effectiveUrl = extractedIframeSrc || trimmed;

    // Direct check if it happens to be an mp4/webm with parameters
    const lower = effectiveUrl.split('?')[0].toLowerCase();
    if (lower.endsWith('.mp4') || lower.endsWith('.webm') || lower.endsWith('.mov')) {
      return {
        originalUrl: url,
        providerId: this.id,
        providerName: 'رابط فيديو مباشر',
        playbackMode: 'html5_video',
        playbackUrl: effectiveUrl,
        canEmbed: true,
        mimeType: lower.endsWith('.webm') ? 'video/webm' : 'video/mp4'
      };
    }

    return {
      originalUrl: url,
      providerId: this.id,
      providerName: this.name,
      playbackMode: 'official_iframe',
      playbackUrl: effectiveUrl,
      canEmbed: true,
      requiresExternalOpen: false,
      extraInfo: 'مشغل خارجي - يدعم التضمين مع إمكانية الفتح في تبويب مستقل'
    };
  }

  public extractThumbnail(): string | null {
    return 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80';
  }
}
