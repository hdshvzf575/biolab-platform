/**
 * Base Video Provider Interface and Types
 * Unified Video Architecture for BioLab Wissam Platform
 */

export type VideoPlaybackMode = 
  | 'html5_video'          // Direct HTML5 <video> (MP4, WebM, OGG, MOV, HLS)
  | 'official_iframe'      // Official Provider Embed (YouTube, Vimeo, Dailymotion, Google Drive)
  | 'anon_mp4_embed'       // AnonMP4 Player / Direct Embed
  | 'external_fallback';   // Sites forbidding iframe embedding (X-Frame-Options: DENY)

export interface ResolvedVideoInfo {
  originalUrl: string;
  providerId: string;
  providerName: string;
  playbackMode: VideoPlaybackMode;
  playbackUrl: string;
  thumbnailUrl?: string;
  canEmbed: boolean;
  requiresExternalOpen?: boolean;
  mimeType?: string;
  errorMessage?: string;
  extraInfo?: string;
}

export interface IVideoProvider {
  id: string;
  name: string;
  canHandle(url: string): boolean;
  resolve(url: string): Promise<ResolvedVideoInfo> | ResolvedVideoInfo;
  extractThumbnail?(url: string): string | null;
}
