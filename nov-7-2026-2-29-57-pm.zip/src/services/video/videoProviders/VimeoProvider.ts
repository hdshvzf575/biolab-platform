import { IVideoProvider, ResolvedVideoInfo } from './BaseVideoProvider';

export class VimeoProvider implements IVideoProvider {
  public id = 'vimeo';
  public name = 'فيميو (Vimeo)';

  private extractVideoId(url: string): string | null {
    if (!url) return null;
    const match = url.match(/(?:vimeo\.com\/|player\.vimeo\.com\/video\/)([0-9]+)/i);
    return match ? match[1] : null;
  }

  public canHandle(url: string): boolean {
    if (!url) return false;
    const lower = url.toLowerCase();
    return lower.includes('vimeo.com');
  }

  public resolve(url: string): ResolvedVideoInfo {
    const videoId = this.extractVideoId(url);
    if (!videoId) {
      return {
        originalUrl: url,
        providerId: this.id,
        providerName: this.name,
        playbackMode: 'external_fallback',
        playbackUrl: url,
        canEmbed: false,
        requiresExternalOpen: true,
        errorMessage: 'تعذر استخراج معرف فيديو Vimeo'
      };
    }

    const embedUrl = `https://player.vimeo.com/video/${videoId}?dnt=1&playsinline=1`;

    return {
      originalUrl: url,
      providerId: this.id,
      providerName: this.name,
      playbackMode: 'official_iframe',
      playbackUrl: embedUrl,
      canEmbed: true,
      extraInfo: `Vimeo ID: ${videoId}`
    };
  }

  public extractThumbnail(): string | null {
    return 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=800&q=80';
  }
}
