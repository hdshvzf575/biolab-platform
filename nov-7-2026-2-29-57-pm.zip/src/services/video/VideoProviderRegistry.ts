import { IVideoProvider, ResolvedVideoInfo } from './videoProviders/BaseVideoProvider';
import { DirectVideoProvider } from './videoProviders/DirectVideoProvider';
import { YouTubeProvider } from './videoProviders/YouTubeProvider';
import { AnonMp4Provider } from './videoProviders/AnonMp4Provider';
import { GoogleDriveVideoProvider } from './videoProviders/GoogleDriveVideoProvider';
import { VimeoProvider } from './videoProviders/VimeoProvider';
import { DailymotionProvider } from './videoProviders/DailymotionProvider';
import { StreamableProvider } from './videoProviders/StreamableProvider';
import { GenericEmbedProvider } from './videoProviders/GenericEmbedProvider';

export class VideoProviderRegistry {
  private providers: IVideoProvider[] = [];
  private fallbackProvider: IVideoProvider;

  constructor() {
    this.fallbackProvider = new GenericEmbedProvider();

    // Priority registration: Specific known services first, then direct video, then fallback
    this.registerProvider(new YouTubeProvider());
    this.registerProvider(new AnonMp4Provider());
    this.registerProvider(new GoogleDriveVideoProvider());
    this.registerProvider(new VimeoProvider());
    this.registerProvider(new DailymotionProvider());
    this.registerProvider(new StreamableProvider());
    this.registerProvider(new DirectVideoProvider());
    this.registerProvider(this.fallbackProvider);
  }

  public registerProvider(provider: IVideoProvider): void {
    // Avoid duplicate IDs
    this.providers = this.providers.filter(p => p.id !== provider.id);
    this.providers.push(provider);
  }

  public getProviderForUrl(url: string): IVideoProvider {
    if (!url || typeof url !== 'string') {
      return this.fallbackProvider;
    }

    const trimmed = url.trim();
    for (const provider of this.providers) {
      if (provider.canHandle(trimmed)) {
        return provider;
      }
    }

    return this.fallbackProvider;
  }

  public async resolve(url: string): Promise<ResolvedVideoInfo> {
    if (!url || typeof url !== 'string' || !url.trim()) {
      return {
        originalUrl: '',
        providerId: 'invalid',
        providerName: 'رابط غير متاح',
        playbackMode: 'external_fallback',
        playbackUrl: '',
        canEmbed: false,
        errorMessage: 'رابط الفيديو فارغ أو غير متاح'
      };
    }

    const provider = this.getProviderForUrl(url.trim());
    return await provider.resolve(url.trim());
  }

  public extractThumbnail(url: string): string | null {
    if (!url) return null;
    const provider = this.getProviderForUrl(url.trim());
    if (provider.extractThumbnail) {
      return provider.extractThumbnail(url.trim());
    }
    return null;
  }
}

export const videoProviderRegistry = new VideoProviderRegistry();
