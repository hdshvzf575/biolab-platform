import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { Readable } from 'stream';
import { fileURLToPath } from 'url';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import {
  normalizeArabicText,
  matchPreventionRule,
  matchLearnedResponse,
  findRelevantLectures,
  diagnoseStudentProblem,
  retrieveRelevantChunks,
  buildComprehensiveBiologySystemPrompt,
  IndexedChunk,
  KnowledgeItem,
  LearnedResponse,
  PreventionRule,
  ChatAuditRecord,
  SourceCitation,
  AIConfig,
  AIPricingConfig,
  AIContactConfig,
  AIFewShotExample,
  AISupportTicket
} from './src/services/aiKnowledgeService';

// Disable Vite HMR in cloud preview environment
process.env.DISABLE_HMR = 'true';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const HOST = '0.0.0.0';

const LECTURES_FILE = path.resolve(process.cwd(), 'data', 'lectures.json');
const USERS_FILE = path.resolve(process.cwd(), 'data', 'users.json');
const SETTINGS_FILE = path.resolve(process.cwd(), 'data', 'settings.json');
const INSTITUTE_POSTS_FILE = path.resolve(process.cwd(), 'data', 'institute_posts.json');
const INSTITUTE_STAGES_FILE = path.resolve(process.cwd(), 'data', 'institute_stages.json');
const INSTITUTE_AUDIT_FILE = path.resolve(process.cwd(), 'data', 'institute_audit.json');
const LECTURE_CODES_FILE = path.resolve(process.cwd(), 'data', 'lecture_codes.json');
const APP_UPDATE_FILE = path.resolve(process.cwd(), 'data', 'app_update.json');
const AI_CONFIG_FILE = path.resolve(process.cwd(), 'data', 'ai_config.json');
const AI_PRICING_FILE = path.resolve(process.cwd(), 'data', 'ai_pricing.json');
const AI_CONTACT_FILE = path.resolve(process.cwd(), 'data', 'ai_contact.json');
const AI_EXAMPLES_FILE = path.resolve(process.cwd(), 'data', 'ai_few_shot_examples.json');
const AI_TICKETS_FILE = path.resolve(process.cwd(), 'data', 'ai_support_tickets.json');
const AI_KNOWLEDGE_FILE = path.resolve(process.cwd(), 'data', 'ai_knowledge.json');
const AI_RESPONSES_FILE = path.resolve(process.cwd(), 'data', 'ai_learned_responses.json');
const AI_RULES_FILE = path.resolve(process.cwd(), 'data', 'ai_prevention_rules.json');
const AI_CHUNKS_FILE = path.resolve(process.cwd(), 'data', 'ai_indexed_chunks.json');
const AI_AUDIT_FILE = path.resolve(process.cwd(), 'data', 'ai_chat_audit.json');
const CURRICULUM_BOOKS_FILE = path.resolve(process.cwd(), 'data', 'curriculum_books.json');
const CLOUD_OPERATIONS_LOG_FILE = path.resolve(process.cwd(), 'data', 'cloud_operations_log.json');
const UPLOADS_DIR = path.resolve(process.cwd(), 'public', 'uploads');

// Ensure data and uploads directories exist
if (!fs.existsSync(path.dirname(LECTURES_FILE))) {
  fs.mkdirSync(path.dirname(LECTURES_FILE), { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(path.join(UPLOADS_DIR, 'books'), { recursive: true });
  fs.mkdirSync(path.join(UPLOADS_DIR, 'videos'), { recursive: true });
  fs.mkdirSync(path.join(UPLOADS_DIR, 'covers'), { recursive: true });
}

// Data helpers
function readJsonFile<T>(filePath: string, fallback: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(data) as T;
    }
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
  }
  return fallback;
}

function writeJsonFile<T>(filePath: string, data: T): boolean {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
    return false;
  }
}

// Default AI Configuration with scope boundaries
const DEFAULT_AI_CONFIG: AIConfig = {
  isEnabled: true,
  model: 'gemini-3.1-flash-lite',
  temperature: 0.7,
  welcomeMessage: 'مرحباً بك يا بطل في منصة مختبر الأحياء للأستاذ وسام سهيل العامري! 🧬\nأنا المساعد الذكي الحقيقي المدعوم بنموذج Google Gemini، جاهز لشرح مفاهيم الأحياء الوزارية، توضيح أقسام المنصة، الاستفسار عن المحاضرات والأسعار، أو حل أي مشكلة تواجهك.',
  customSystemInstructions: '',
  disclaimerText: 'إجابات المساعد الذكي مستندة إلى مصادر المنهج المعتمدة ونموذج Google Gemini وقواعد إدارة منصة الأحياء للأستاذ وسام سهيل العامري.',
  allowedTopics: [
    'علم الخلية (التركيب، العضيات، الغشاء البلازمي، الانقسام الخيطي والاختزالي)',
    'علم الأنسجة (الأنسجة النباتية، الأنسجة الحيوانية، الغضروف والعظم والدم والعصب)',
    'علم التكاثر (التكاثر اللاجنسي والجنسي في النباتات والحيوانات والإنسان)',
    'علم الوراثة والتوارث (الوراثة المندلية، السيادة، الكروموسومات، الطفرات، الهندسة الوراثية)',
    'أجهزة جسم الإنسان والفسلجة (الهضم، الدوران، التنفس، الإخراج، المناعة)',
    'الأحياء المجهرية والتصنيف وعلم البيئة والتغذية في الأحياء',
    'المنهج الوزاري العراقي لمادة الأحياء (من الأول متوسط حتى السادس العلمي)',
    'منصة الأستاذ وسام سهيل العامري، معهد أنوار السلام الأهلي، أسعار الاشتراكات وأكواد VIP'
  ],
  prohibitedTopics: [
    'المواد الدراسية غير الأحياء (مثل الكيمياء، الفيزياء، الرياضيات، التاريخ، الجغرافيا)',
    'السياسة والأخبار الحزبية والعامة والنزاعات',
    'البرمجة وتطوير البرمجيات والذكاء الاصطناعي العام',
    'الدردشة الترفيهية العامة والرياضة والألعاب والموسيقى',
    'محاولات طلب أكواد VIP مجانية أو التحايل على نظام الدفع'
  ],
  rejectionResponse: 'عذراً يا بطل! أنا المساعد الذكي المخصص حصرياً لمنصة مختبر الأحياء للأستاذ وسام سهيل العامري. لا يمكنني الإجابة عن مواضيع خارج تخصص علم الأحياء أو خارج المنصة. يسعدني جداً مساعدتك في أي سؤال يخص مادة الأحياء، شروحات الدروس، أو اشتراكات المنصة! 🔬🧬',
  strictBiologyScope: true,
  updatedAt: new Date().toISOString()
};

// Robust Google Gemini generation helper with automatic fast fallbacks
async function executeRealGeminiGeneration(params: {
  contents: string;
  systemInstruction: string;
  temperature?: number;
  requestedModel?: string;
}): Promise<{
  text: string;
  modelUsed: string;
  latencyMs: number;
  success: boolean;
  error?: string;
}> {
  const { contents, systemInstruction, temperature = 0.7, requestedModel } = params;
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return {
      text: '',
      modelUsed: 'no_api_key',
      latencyMs: 0,
      success: false,
      error: 'مفتاح Gemini API غير مهيأ في الخادم'
    };
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });

  const candidates = [
    requestedModel,
    'gemini-3.1-flash-lite',
    'gemini-3.5-flash',
    'gemini-flash-lite-latest',
    'gemini-3.6-flash'
  ].filter(Boolean) as string[];

  const uniqueModels = Array.from(new Set(candidates));

  for (const model of uniqueModels) {
    const start = Date.now();
    try {
      const response = await Promise.race([
        ai.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction,
            temperature
          }
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`Timeout on model ${model} after 12s`)), 12000)
        )
      ]);

      const text = response.text?.trim();
      if (text) {
        return {
          text,
          modelUsed: model,
          latencyMs: Date.now() - start,
          success: true
        };
      }
    } catch (err: any) {
      console.warn(`[Gemini Generation] Candidate ${model} returned error (${Date.now() - start}ms):`, err?.message || err);
    }
  }

  return {
    text: '',
    modelUsed: 'fallback',
    latencyMs: 0,
    success: false,
    error: 'تعذر الاتصال بنماذج Google Gemini حالياً'
  };
}

// Curriculum Google Drive Books definition
const CURRICULUM_DRIVE_BOOKS = [
  {
    id: 'b1',
    gradeKey: 'g1',
    grade: 'الأول المتوسط',
    icon: '📘',
    title: 'كتاب الأحياء - الصف الأول المتوسط (المنهج الوزاري)',
    author: 'وزارة التربية العراقية',
    specialization: 'علم الأحياء العام',
    academicLevel: 'المتوسطة',
    pages: 140,
    fileSize: '3.3 MB',
    year: 2024,
    localFile: '/uploads/books/biology_g1.pdf',
    driveUrl: 'https://drive.google.com/file/d/1APm6D9sooNqWkdK0pWaBB5I7Sd08HsPcQ/view?usp=drivesdk',
    driveId: '1APm6D9sooNqWkdK0pWaBB5I7Sd08HsPcQ',
    driveAccessStatus: 'not_found',
    driveStatusMessage: 'ملف Google Drive تم حذفه أو تغييره في السحابة — تم تفعيل النسخة المعتمدة محلياً للقراءة والتنزيل المباشر.',
    coverUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'b2',
    gradeKey: 'g2',
    grade: 'الثاني المتوسط',
    icon: '🦠',
    title: 'كتاب الأحياء - الصف الثاني المتوسط (الكائنات المجهرية)',
    author: 'وزارة التربية العراقية',
    specialization: 'الأحياء المجهرية والتصنيف',
    academicLevel: 'المتوسطة',
    pages: 168,
    fileSize: '3.1 MB',
    year: 2024,
    localFile: '/uploads/books/biology_g2.pdf',
    driveUrl: 'https://drive.google.com/file/d/1k_k6VTpBaAJAxL_mm-lK8WwbzoBkLqHv/view?usp=drivesdk',
    driveId: '1k_k6VTpBaAJAxL_mm-lK8WwbzoBkLqHv',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    coverUrl: 'https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'b3',
    gradeKey: 'g3',
    grade: 'الثالث المتوسط',
    icon: '🌿',
    title: 'كتاب الأحياء - الصف الثالث المتوسط (أجهزة جسم الإنسان)',
    author: 'وزارة التربية العراقية',
    specialization: 'فسلجة جسم الإنسان',
    academicLevel: 'المتوسطة (وزاري)',
    pages: 196,
    fileSize: '3.3 MB',
    year: 2024,
    localFile: '/uploads/books/biology_g3.pdf',
    driveUrl: 'https://drive.google.com/file/d/1bF3TOH47Bn0KQ-IcwuRNRBe9gm5tOFS5/view?usp=drivesdk',
    driveId: '1bF3TOH47Bn0KQ-IcwuRNRBe9gm5tOFS5',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    coverUrl: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'b4',
    gradeKey: 'g4',
    grade: 'الرابع العلمي',
    icon: '🧪',
    title: 'كتاب الأحياء - الصف الرابع العلمي (علم البيئة)',
    author: 'وزارة التربية العراقية',
    specialization: 'علم البيئة والتكيف الحيواني',
    academicLevel: 'الإعدادية',
    pages: 184,
    fileSize: '2.3 MB',
    year: 2024,
    localFile: '/uploads/books/biology_g4.pdf',
    driveUrl: 'https://drive.google.com/file/d/1IJDdvL4PrUL68wlISVWh6bAIEtoCFh1h/view?usp=drivesdk',
    driveId: '1IJDdvL4PrUL68wlISVWh6bAIEtoCFh1h',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    coverUrl: 'https://images.unsplash.com/photo-1530210124550-912dc1381cb8?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'b5',
    gradeKey: 'g5',
    grade: 'الخامس العلمي',
    icon: '🐟',
    title: 'كتاب الأحياء - الصف الخامس العلمي (الفسلجة المقارنة)',
    author: 'وزارة التربية العراقية',
    specialization: 'الفسلجة المقارنة',
    academicLevel: 'الإعدادية',
    pages: 212,
    fileSize: '2.3 MB',
    year: 2024,
    localFile: '/uploads/books/biology_g5.pdf',
    driveUrl: 'https://drive.google.com/file/d/1Xtjy9PKMVi-8wvwHxU3IjWL052ueUXNe/view?usp=drivesdk',
    driveId: '1Xtjy9PKMVi-8wvwHxU3IjWL052ueUXNe',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    coverUrl: 'https://images.unsplash.com/photo-1507668077129-56e32842fceb?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'b6',
    gradeKey: 'g6',
    grade: 'السادس العلمي',
    icon: '🧬',
    title: 'كتاب الأحياء - الصف السادس العلمي (الخلية، الأنسجة، التكاثر، الوراثة)',
    author: 'وزارة التربية العراقية',
    specialization: 'الخلية، الأنسجة، التكاثر، الوراثة',
    academicLevel: 'السادس العلمي (الوزاري)',
    pages: 256,
    fileSize: '4.4 MB',
    year: 2024,
    localFile: '/uploads/books/biology_g6.pdf',
    driveUrl: 'https://drive.google.com/file/d/1qwd_GN91iNb-st0Mvw7P3KINVvY1VDnX/view?usp=drivesdk',
    driveId: '1qwd_GN91iNb-st0Mvw7P3KINVvY1VDnX',
    driveAccessStatus: 'restricted',
    driveStatusMessage: 'رابط Google Drive يتطلب إذن وصول من المالك — تم توفير النسخة الكاملة المعتمدة للقراءة والتنزيل المباشر.',
    coverUrl: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=600&q=80'
  }
];

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);

  // Middleware with expanded limits for direct PDF and MP4 video uploads
  app.use(express.json({ limit: '200mb' }));
  app.use(express.urlencoded({ extended: true, limit: '200mb' }));

  // CORS headers for local/cross-origin requests
  app.use((req: Request, res: Response, next: NextFunction) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });

  // ==========================================
  // Admin Authentication & Access Control (ربط الإدارة بصلاحيات حقيقية)
  // ==========================================
  const ADMIN_TOKEN = 'wissam_bio_admin_token_2026_secure';

  const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.startsWith('Bearer ') 
      ? authHeader.slice(7).trim() 
      : ((req.headers['x-admin-token'] as string) || '').trim();

    if (token === ADMIN_TOKEN) {
      next();
      return;
    }

    res.status(401).json({
      success: false,
      error: 'غير مصرح: هذا الإجراء مخصص لمدير المنصة فقط ويتطلب مفتاح الصلاحية الإدارية (Admin Authorization Required)'
    });
  };

  // Admin Login Endpoint
  app.post('/api/admin/login', (req: Request, res: Response) => {
    const { password } = req.body;
    if (password === 'wissam2026' || password === 'admin123') {
      res.json({
        success: true,
        token: ADMIN_TOKEN,
        message: 'تم تسجيل دخول المدير بنجاح ومنح الرمز الإداري المعتمد'
      });
    } else {
      res.status(401).json({
        success: false,
        error: 'كلمة المرور غير صحيحة، تم رفض منح الصلاحية'
      });
    }
  });

  // Serve direct APK & ZIP downloads with binary headers & strict anti-caching
  app.use((req: Request, res: Response, next: NextFunction) => {
    const rawUrl = req.url.split('?')[0];
    if (rawUrl.endsWith('.apk') || rawUrl.endsWith('.zip')) {
      const cleanName = path.basename(rawUrl);
      const filePath = path.resolve(process.cwd(), 'public', cleanName);
      if (fs.existsSync(filePath)) {
        const stat = fs.statSync(filePath);
        res.writeHead(200, {
          'Content-Type': rawUrl.endsWith('.apk')
            ? 'application/vnd.android.package-archive'
            : 'application/zip',
          'Content-Length': stat.size,
          'Content-Disposition': `attachment; filename="${cleanName}"`,
          'Cache-Control': 'no-cache, no-store, must-revalidate, max-age=0',
          'Pragma': 'no-cache',
          'Expires': '0'
        });
        const stream = fs.createReadStream(filePath);
        stream.pipe(res);
        return;
      }
    }
    next();
  });

  // Serve static files from /public with appropriate headers
  app.use(express.static(path.resolve(process.cwd(), 'public'), {
    setHeaders: (res, filePath) => {
      if (filePath.endsWith('.pdf')) {
        res.setHeader('Content-Type', 'application/pdf');
      } else if (filePath.endsWith('.mp4')) {
        res.setHeader('Content-Type', 'video/mp4');
      }
    }
  }));

  // ==========================================
  // Multer Storage Configuration for Videos, Books/Booklets and Covers
  // ==========================================
  const videoStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const dest = path.join(UPLOADS_DIR, 'videos');
      if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
      cb(null, dest);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase() || '.mp4';
      const cleanBase = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_\-\u0600-\u06FF]/g, '_').slice(0, 40);
      const uniqueSuffix = `${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
      cb(null, `vid_${cleanBase || 'lecture'}_${uniqueSuffix}${ext}`);
    }
  });

  const videoUpload = multer({
    storage: videoStorage,
    limits: { fileSize: 300 * 1024 * 1024 }, // 300 MB limit
    fileFilter: (req, file, cb) => {
      const allowedExts = ['.mp4', '.webm', '.ogg', '.mov', '.mkv', '.avi'];
      const ext = path.extname(file.originalname).toLowerCase();
      if (file.mimetype.startsWith('video/') || allowedExts.includes(ext)) {
        cb(null, true);
      } else {
        cb(new Error('صيغة ملف الفيديو غير مدعومة. الصيغ المسموحة: MP4, WebM, MKV, MOV'));
      }
    }
  });

  const bookStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const dest = path.join(UPLOADS_DIR, 'books');
      if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
      cb(null, dest);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase() || '.pdf';
      const cleanBase = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_\-\u0600-\u06FF]/g, '_').slice(0, 40);
      const uniqueSuffix = `${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
      cb(null, `book_${cleanBase || 'curriculum'}_${uniqueSuffix}${ext}`);
    }
  });

  const bookUpload = multer({
    storage: bookStorage,
    limits: { fileSize: 250 * 1024 * 1024 }, // 250 MB limit
    fileFilter: (req, file, cb) => {
      const allowedExts = ['.pdf', '.epub'];
      const ext = path.extname(file.originalname).toLowerCase();
      if (file.mimetype === 'application/pdf' || allowedExts.includes(ext)) {
        cb(null, true);
      } else {
        cb(new Error('الملف يجب أن يكون بصيغة PDF أو EPUB'));
      }
    }
  });

  const coverStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const dest = path.join(UPLOADS_DIR, 'covers');
      if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
      cb(null, dest);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
      const cleanBase = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_\-\u0600-\u06FF]/g, '_').slice(0, 40);
      const uniqueSuffix = `${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
      cb(null, `cover_${cleanBase || 'book'}_${uniqueSuffix}${ext}`);
    }
  });

  const coverUpload = multer({
    storage: coverStorage,
    limits: { fileSize: 25 * 1024 * 1024 }, // 25 MB
    fileFilter: (req, file, cb) => {
      const allowedExts = ['.jpg', '.jpeg', '.png', '.webp', '.svg'];
      const ext = path.extname(file.originalname).toLowerCase();
      if (file.mimetype.startsWith('image/') || allowedExts.includes(ext)) {
        cb(null, true);
      } else {
        cb(new Error('ملف الغلاف يجب أن يكون صورة بصيغة JPG, PNG, WEBP'));
      }
    }
  });

  // ==========================================
  // REAL CLOUD FILE UPLOAD APIS (رفع حقيقي للملفات بدون تخزين مؤقت وهمي)
  // ==========================================

  // 1. Upload Video (for lectures)
  app.post('/api/upload/video', requireAdmin, (req: Request, res: Response) => {
    videoUpload.single('video')(req, res, (err: any) => {
      if (err) {
        console.error('Video upload error:', err);
        res.status(400).json({ success: false, error: err.message || 'فشل رفع ملف الفيديو' });
        return;
      }

      if (req.file) {
        const file = req.file;
        const relativeUrl = `/uploads/videos/${file.filename}`;
        const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
        res.json({
          success: true,
          url: relativeUrl,
          fileName: file.filename,
          originalName: file.originalname,
          fileSize: `${sizeMb} MB`,
          mimeType: file.mimetype,
          message: 'تم رفع الفيديو وحفظه في مساحة التخزين السحابية بنجاح 🎥'
        });
        return;
      }

      // Legacy fallback: Base64 payload in JSON
      const { fileName, fileData } = req.body;
      if (fileData && typeof fileData === 'string') {
        try {
          const matches = fileData.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
          const buffer = matches ? Buffer.from(matches[2], 'base64') : Buffer.from(fileData, 'base64');
          const ext = path.extname(fileName || 'video.mp4').toLowerCase() || '.mp4';
          const safeName = `vid_${Date.now()}_${Math.floor(Math.random() * 1000)}${ext}`;
          const savePath = path.join(UPLOADS_DIR, 'videos', safeName);
          fs.writeFileSync(savePath, buffer);
          const sizeMb = (buffer.length / (1024 * 1024)).toFixed(1);
          res.json({
            success: true,
            url: `/uploads/videos/${safeName}`,
            fileName: safeName,
            fileSize: `${sizeMb} MB`,
            message: 'تم حفظ الفيديو بنجاح 🎥'
          });
          return;
        } catch (baseErr: any) {
          res.status(500).json({ success: false, error: 'تعذر حفظ الفيديو من ترميز Base64' });
          return;
        }
      }

      res.status(400).json({ success: false, error: 'يرجى إرفاق ملف فيديو صالح' });
    });
  });

  // 2. Upload Book / Booklet / PDF File
  app.post('/api/upload/book', requireAdmin, (req: Request, res: Response) => {
    bookUpload.single('file')(req, res, (err: any) => {
      if (err) {
        console.error('Book upload error:', err);
        res.status(400).json({ success: false, error: err.message || 'فشل رفع ملف الكتاب أو الملزمة' });
        return;
      }

      if (req.file) {
        const file = req.file;
        const relativeUrl = `/uploads/books/${file.filename}`;
        const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
        res.json({
          success: true,
          url: relativeUrl,
          fileName: file.filename,
          originalName: file.originalname,
          fileSize: `${sizeMb} MB`,
          mimeType: file.mimetype,
          message: 'تم رفع وحفظ ملف الـ PDF بنجاح 📚'
        });
        return;
      }

      res.status(400).json({ success: false, error: 'يرجى اختيار ملف PDF أو EPUB لرفعه' });
    });
  });

  // 3. Upload Book Cover Image
  app.post('/api/upload/cover', requireAdmin, (req: Request, res: Response) => {
    coverUpload.single('cover')(req, res, (err: any) => {
      if (err) {
        console.error('Cover upload error:', err);
        res.status(400).json({ success: false, error: err.message || 'فشل رفع صورة الغلاف' });
        return;
      }

      if (req.file) {
        const file = req.file;
        const relativeUrl = `/uploads/covers/${file.filename}`;
        res.json({
          success: true,
          url: relativeUrl,
          fileName: file.filename,
          originalName: file.originalname,
          message: 'تم حفظ صورة الغلاف بنجاح 🖼️'
        });
        return;
      }

      res.status(400).json({ success: false, error: 'يرجى اختيار ملف صورة صالح' });
    });
  });

  // ==========================================
  // CENTRAL CLOUD MANAGEMENT SUITE (مركز التحكم السحابي الشامل)
  // ==========================================

  interface CloudOpRecord {
    id: string;
    type: 'CASCADE_DELETE' | 'FILE_REPLACE' | 'FILE_RENAME' | 'FILE_MOVE' | 'DOC_DELETE' | 'DOC_UPDATE' | 'ORPHAN_CLEAN' | 'UPLOAD';
    target: string;
    admin: string;
    timestamp: string;
    status: 'completed' | 'failed' | 'partially_completed';
    steps: { name: string; status: 'done' | 'failed' | 'skipped'; details?: string }[];
    details?: any;
    error?: string;
  }

  function recordCloudOp(op: CloudOpRecord) {
    try {
      const history = readJsonFile<CloudOpRecord[]>(CLOUD_OPERATIONS_LOG_FILE, []);
      history.unshift(op);
      if (history.length > 200) history.splice(200);
      writeJsonFile(CLOUD_OPERATIONS_LOG_FILE, history);
    } catch (e) {
      console.warn('Notice: Could not write cloud operations log:', e);
    }
  }

  // Helper: Find all database usages of a given file URL or filename
  function findFileUsages(fileUrlOrName: string) {
    const cleanTarget = String(fileUrlOrName).trim().toLowerCase();
    const targetBase = path.basename(cleanTarget);

    const lectures = readJsonFile<any[]>(LECTURES_FILE, []);
    const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);

    const usages: { type: 'lecture' | 'book_pdf' | 'book_cover'; id: string | number; title: string; field: string; currentUrl: string }[] = [];

    for (const lec of lectures) {
      if (lec.videoUrl) {
        const vUrl = String(lec.videoUrl).trim().toLowerCase();
        if (vUrl === cleanTarget || path.basename(vUrl) === targetBase || vUrl.includes(cleanTarget)) {
          usages.push({
            type: 'lecture',
            id: lec.id,
            title: lec.title || 'محاضرة بدون عنوان',
            field: 'videoUrl',
            currentUrl: lec.videoUrl
          });
        }
      }
    }

    for (const b of books) {
      const pUrl = String(b.pdfUrl || b.fileUrl || '').trim().toLowerCase();
      if (pUrl && (pUrl === cleanTarget || path.basename(pUrl) === targetBase || pUrl.includes(cleanTarget))) {
        usages.push({
          type: 'book_pdf',
          id: b.id,
          title: b.title || 'كتاب بدون عنوان',
          field: 'pdfUrl',
          currentUrl: b.pdfUrl || b.fileUrl
        });
      }

      const cUrl = String(b.coverUrl || '').trim().toLowerCase();
      if (cUrl && (cUrl === cleanTarget || path.basename(cUrl) === targetBase || cUrl.includes(cleanTarget))) {
        usages.push({
          type: 'book_cover',
          id: b.id,
          title: b.title || 'كتاب بدون عنوان',
          field: 'coverUrl',
          currentUrl: b.coverUrl
        });
      }
    }

    return usages;
  }

  // 1. Files List with Deep Reference & Sharing Analytics
  app.get('/api/admin/cloud/files', requireAdmin, (req: Request, res: Response) => {
    try {
      const folders = ['videos', 'books', 'covers'] as const;
      const allFiles: any[] = [];
      let totalSizeBytes = 0;
      let orphansCount = 0;
      let orphansSizeBytes = 0;

      for (const folder of folders) {
        const folderDir = path.join(UPLOADS_DIR, folder);
        if (!fs.existsSync(folderDir)) continue;

        const fileNames = fs.readdirSync(folderDir);
        for (const fname of fileNames) {
          if (fname.startsWith('.')) continue;

          const fullPath = path.join(folderDir, fname);
          try {
            const stat = fs.statSync(fullPath);
            if (!stat.isFile()) continue;

            const sizeBytes = stat.size;
            totalSizeBytes += sizeBytes;
            const sizeMb = (sizeBytes / (1024 * 1024)).toFixed(2);
            const relativeUrl = `/uploads/${folder}/${fname}`;
            const ext = path.extname(fname).toLowerCase();

            const usages = findFileUsages(relativeUrl);
            const isOrphan = usages.length === 0;

            if (isOrphan) {
              orphansCount++;
              orphansSizeBytes += sizeBytes;
            }

            allFiles.push({
              fileName: fname,
              folder,
              relativeUrl,
              sizeBytes,
              sizeMb: `${sizeMb} MB`,
              createdAt: stat.mtime.toISOString(),
              extension: ext,
              mimeType: ext === '.mp4' ? 'video/mp4' : ext === '.pdf' ? 'application/pdf' : (ext === '.jpg' || ext === '.jpeg') ? 'image/jpeg' : ext === '.png' ? 'image/png' : 'application/octet-stream',
              isOrphan,
              isShared: usages.length > 1,
              usagesCount: usages.length,
              usages,
              linkedTo: usages.length > 0
                ? usages.map(u => `${u.type === 'lecture' ? 'محاضرة' : 'كتاب'}: ${u.title}`).join(' | ')
                : 'ملف معلق في السحابة (يتيم)'
            });
          } catch (statErr) {
            console.warn(`Could not stat ${fullPath}:`, statErr);
          }
        }
      }

      allFiles.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      res.json({
        success: true,
        stats: {
          totalFiles: allFiles.length,
          totalSizeBytes,
          totalSizeMb: `${(totalSizeBytes / (1024 * 1024)).toFixed(2)} MB`,
          videosCount: allFiles.filter(f => f.folder === 'videos').length,
          booksCount: allFiles.filter(f => f.folder === 'books').length,
          coversCount: allFiles.filter(f => f.folder === 'covers').length,
          orphansCount,
          orphansSizeBytes,
          orphansSizeMb: `${(orphansSizeBytes / (1024 * 1024)).toFixed(2)} MB`
        },
        files: allFiles
      });
    } catch (err: any) {
      console.error('Error listing cloud files:', err);
      res.status(500).json({ success: false, error: 'تعذر جلب قائمة الملفات السحابية' });
    }
  });

  // 2. Comprehensive Cascading Deletion (الحذف المترابط والشامل مع الحماية)
  app.post('/api/admin/cloud/cascade-delete', requireAdmin, (req: Request, res: Response) => {
    const opId = `op_del_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const steps: { name: string; status: 'done' | 'failed' | 'skipped'; details?: string }[] = [];

    try {
      const { targetType, folder, fileName, contentId, forceDeleteShared, dryRun } = req.body;

      if (!targetType) {
        res.status(400).json({ success: false, error: 'نوع العنصر المطلوب حذفه (targetType) غير محدد' });
        return;
      }

      // Case A: Deleting by Storage File
      if (targetType === 'file') {
        if (!folder || !fileName) {
          res.status(400).json({ success: false, error: 'المجلد واسم الملف مطلوبان' });
          return;
        }

        const safeFolder = String(folder).replace(/[^a-zA-Z0-9_-]/g, '');
        const safeFileName = path.basename(String(fileName));
        const relativeUrl = `/uploads/${safeFolder}/${safeFileName}`;
        const filePath = path.resolve(UPLOADS_DIR, safeFolder, safeFileName);

        const usages = findFileUsages(relativeUrl);

        // Pre-check Dry Run
        if (dryRun) {
          res.json({
            success: true,
            dryRun: true,
            isShared: usages.length > 1,
            usagesCount: usages.length,
            usages,
            canDeleteSafely: usages.length <= 1 || Boolean(forceDeleteShared),
            message: usages.length > 1 
              ? `الملف مستخدم في ${usages.length} مواضع مختلفة. يتطلب تأكيد الحذف القسري أو فك الارتباط أولاً.`
              : `الملف جاهز للحذف المترابط الشامل.`
          });
          return;
        }

        // Shared Protection Gate
        if (usages.length > 1 && !forceDeleteShared) {
          res.status(409).json({
            success: false,
            isShared: true,
            error: `تنبيه أمان سحابي: الملف مستخدم في أكثر من موضع (${usages.length} عناصر). تم إيقاف الحذف لحماية المحتوى المشترك ما لم يتم تفعيل خيار الحذف المشترك الصريح.`,
            usages
          });
          return;
        }

        // Step 1: Physical File Deletion
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
          steps.push({ name: 'حذف الملف الفعلي من التخزين السحابي', status: 'done', details: `${safeFolder}/${safeFileName}` });
        } else {
          steps.push({ name: 'حذف الملف الفعلي من التخزين السحابي', status: 'skipped', details: 'الملف غير موجود على السيرفر مسبقاً' });
        }

        // Step 2: Cascade Reference Detachment in Database
        let detachedCount = 0;
        if (usages.length > 0) {
          const lectures = readJsonFile<any[]>(LECTURES_FILE, []);
          const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);

          for (const usage of usages) {
            if (usage.type === 'lecture') {
              const lec = lectures.find(l => l.id === usage.id || String(l.id) === String(usage.id));
              if (lec) {
                lec.videoUrl = '';
                detachedCount++;
              }
            } else if (usage.type === 'book_pdf') {
              const b = books.find(bk => bk.id === usage.id || String(bk.id) === String(usage.id));
              if (b) {
                b.pdfUrl = null;
                b.fileUrl = null;
                b.isAvailable = false;
                detachedCount++;
              }
            } else if (usage.type === 'book_cover') {
              const b = books.find(bk => bk.id === usage.id || String(bk.id) === String(usage.id));
              if (b) {
                b.coverUrl = null;
                detachedCount++;
              }
            }
          }

          writeJsonFile(LECTURES_FILE, lectures);
          writeJsonFile(CURRICULUM_BOOKS_FILE, books);
          steps.push({ name: 'تحديث وفك ارتباط المراجع في قواعد البيانات', status: 'done', details: `تم تحديث ${detachedCount} سجل` });
        } else {
          steps.push({ name: 'تحديث مراجع قواعد البيانات', status: 'skipped', details: 'الملف كان يتيماً ولا توجد مراجع مرتبطة به' });
        }

        // Step 3: Post-Verification Integrity Check
        const remainingUsages = findFileUsages(relativeUrl);
        const fileStillExists = fs.existsSync(filePath);
        if (!fileStillExists && remainingUsages.length === 0) {
          steps.push({ name: 'الفحص اللاحق للتأكد من خلو المنصة من الروابط المكسورة', status: 'done', details: 'تكامل تام 100%' });
        } else {
          steps.push({ name: 'الفحص اللاحق', status: 'failed', details: 'تبقت مراجع معلقة تحتاج لمراجعة' });
        }

        recordCloudOp({
          id: opId,
          type: 'CASCADE_DELETE',
          target: `${safeFolder}/${safeFileName}`,
          admin: 'admin',
          timestamp: new Date().toISOString(),
          status: 'completed',
          steps,
          details: { usagesCount: usages.length, detachedCount }
        });

        res.json({
          success: true,
          operationId: opId,
          message: `تم تنفيذ الحذف الشامل والمتسلسل للملف «${safeFileName}» بنجاح 🗑️`,
          steps,
          affectedUsages: usages
        });
        return;
      }

      // Case B: Deleting by Lecture Content (Cascade delete lecture + its local video file if hosted by us)
      if (targetType === 'lecture') {
        const idStr = String(contentId).trim();
        const lectures = readJsonFile<any[]>(LECTURES_FILE, []);
        const targetLecture = lectures.find(l => String(l.id) === idStr);

        if (!targetLecture) {
          res.status(404).json({ success: false, error: 'المحاضرة غير موجودة في قاعدة البيانات' });
          return;
        }

        // Step 1: Remove lecture from database
        const updatedLectures = lectures.filter(l => String(l.id) !== idStr);
        writeJsonFile(LECTURES_FILE, updatedLectures);
        steps.push({ name: 'حذف سجل المحاضرة من قاعدة البيانات', status: 'done', details: `ID: ${idStr} - ${targetLecture.title}` });

        // Step 2: Check and delete attached video file if hosted locally
        if (targetLecture.videoUrl && targetLecture.videoUrl.startsWith('/uploads/videos/')) {
          const videoName = path.basename(targetLecture.videoUrl);
          const videoPath = path.resolve(UPLOADS_DIR, 'videos', videoName);

          // Verify if other lectures use this video before deleting
          const otherUsages = updatedLectures.filter(l => l.videoUrl && path.basename(l.videoUrl) === videoName);
          if (otherUsages.length === 0 && fs.existsSync(videoPath)) {
            fs.unlinkSync(videoPath);
            steps.push({ name: 'حذف ملف الفيديو التابع للمحاضرة من التخزين السحابي', status: 'done', details: videoName });
          } else if (otherUsages.length > 0) {
            steps.push({ name: 'فحص ملف الفيديو التابع', status: 'skipped', details: 'الملف مستخدم في محاضرة أخرى وتم الإبقاء عليه' });
          }
        } else {
          steps.push({ name: 'فحص ملف الفيديو', status: 'skipped', details: 'المحاضرة تستخدم رابط بث خارجي (يوتيوب أو سحابة خارجية)' });
        }

        recordCloudOp({
          id: opId,
          type: 'CASCADE_DELETE',
          target: `lecture_${idStr}`,
          admin: 'admin',
          timestamp: new Date().toISOString(),
          status: 'completed',
          steps,
          details: { lectureTitle: targetLecture.title }
        });

        res.json({
          success: true,
          operationId: opId,
          message: `تم حذف المحاضرة وملفاتها السحابية بنجاح 🗑️`,
          steps
        });
        return;
      }

      // Case C: Deleting by Curriculum Book (Cascade delete book + its PDF and cover)
      if (targetType === 'book') {
        const idStr = String(contentId).trim();
        const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);
        const targetBook = books.find(b => String(b.id) === idStr);

        if (!targetBook) {
          res.status(404).json({ success: false, error: 'الكتاب غير موجود في قاعدة البيانات' });
          return;
        }

        const updatedBooks = books.filter(b => String(b.id) !== idStr);
        writeJsonFile(CURRICULUM_BOOKS_FILE, updatedBooks);
        steps.push({ name: 'حذف سجل الكتاب من قاعدة البيانات', status: 'done', details: targetBook.title });

        // PDF file deletion
        if (targetBook.pdfUrl && targetBook.pdfUrl.startsWith('/uploads/books/')) {
          const pdfName = path.basename(targetBook.pdfUrl);
          const pdfPath = path.resolve(UPLOADS_DIR, 'books', pdfName);
          if (fs.existsSync(pdfPath)) {
            fs.unlinkSync(pdfPath);
            steps.push({ name: 'حذف ملف الـ PDF التابع للكتاب', status: 'done', details: pdfName });
          }
        }

        recordCloudOp({
          id: opId,
          type: 'CASCADE_DELETE',
          target: `book_${idStr}`,
          admin: 'admin',
          timestamp: new Date().toISOString(),
          status: 'completed',
          steps,
          details: { bookTitle: targetBook.title }
        });

        res.json({
          success: true,
          operationId: opId,
          message: `تم حذف الكتاب وملفاته السحابية بنجاح 🗑️`,
          steps
        });
        return;
      }

      res.status(400).json({ success: false, error: 'نوع العنصر غير معتمد' });
    } catch (err: any) {
      console.error('Cascade delete error:', err);
      recordCloudOp({
        id: opId,
        type: 'CASCADE_DELETE',
        target: 'unknown',
        admin: 'admin',
        timestamp: new Date().toISOString(),
        status: 'failed',
        steps,
        error: err?.message || 'خطأ غير متوقع أثناء الحذف الشامل'
      });
      res.status(500).json({ success: false, error: err?.message || 'فشلت عملية الحذف المترابط', steps });
    }
  });

  // 3. File Reorganization (Rename / Move / Replace with Automatic Reference Rewriting)
  app.post('/api/admin/cloud/file-action', requireAdmin, (req: Request, res: Response) => {
    const opId = `op_file_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    try {
      const { action, folder, fileName, newFileName, newFolder, newUrl } = req.body;

      if (!action || !folder || !fileName) {
        res.status(400).json({ success: false, error: 'الإجراء والمجلد واسم الملف مطلوبان' });
        return;
      }

      const safeFolder = String(folder).replace(/[^a-zA-Z0-9_-]/g, '');
      const safeFileName = path.basename(String(fileName));
      const sourcePath = path.resolve(UPLOADS_DIR, safeFolder, safeFileName);
      const oldRelativeUrl = `/uploads/${safeFolder}/${safeFileName}`;

      if (!fs.existsSync(sourcePath)) {
        res.status(404).json({ success: false, error: 'الملف المصدر غير موجود في السحابة' });
        return;
      }

      let newRelativeUrl = oldRelativeUrl;

      // Rename Action
      if (action === 'rename') {
        if (!newFileName || typeof newFileName !== 'string') {
          res.status(400).json({ success: false, error: 'الاسم الجديد مطلوب' });
          return;
        }
        const ext = path.extname(safeFileName);
        const safeNewBase = path.basename(newFileName, path.extname(newFileName)).replace(/[^a-zA-Z0-9_-\u0600-\u06FF]/g, '_');
        const finalNewName = `${safeNewBase}${ext}`;
        const destPath = path.resolve(UPLOADS_DIR, safeFolder, finalNewName);

        if (fs.existsSync(destPath) && destPath !== sourcePath) {
          res.status(409).json({ success: false, error: 'يوجد ملف آخر بنفس الاسم في هذا المجلد' });
          return;
        }

        fs.renameSync(sourcePath, destPath);
        newRelativeUrl = `/uploads/${safeFolder}/${finalNewName}`;
      }

      // Move Action
      if (action === 'move') {
        if (!newFolder || !['videos', 'books', 'covers'].includes(newFolder)) {
          res.status(400).json({ success: false, error: 'المجلد الهدف غير صالح' });
          return;
        }
        const destDir = path.resolve(UPLOADS_DIR, newFolder);
        const destPath = path.resolve(destDir, safeFileName);
        if (fs.existsSync(destPath)) {
          res.status(409).json({ success: false, error: 'يوجد ملف بنفس الاسم في المجلد الهدف' });
          return;
        }

        fs.renameSync(sourcePath, destPath);
        newRelativeUrl = `/uploads/${newFolder}/${safeFileName}`;
      }

      // Replace Action (pointing existing references to a newly uploaded file or URL)
      if (action === 'replace') {
        if (!newUrl || typeof newUrl !== 'string') {
          res.status(400).json({ success: false, error: 'رابط الملف البديل مطلوب' });
          return;
        }
        newRelativeUrl = newUrl.trim();
        // Remove old file if it is replaced
        if (fs.existsSync(sourcePath) && newRelativeUrl !== oldRelativeUrl) {
          try { fs.unlinkSync(sourcePath); } catch (e) {}
        }
      }

      // Automatically Cascade URL Rewrite across all lectures & books!
      let rewrittenCount = 0;
      const lectures = readJsonFile<any[]>(LECTURES_FILE, []);
      for (const lec of lectures) {
        if (lec.videoUrl && (lec.videoUrl === oldRelativeUrl || path.basename(lec.videoUrl) === safeFileName)) {
          lec.videoUrl = newRelativeUrl;
          rewrittenCount++;
        }
      }
      writeJsonFile(LECTURES_FILE, lectures);

      const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);
      for (const b of books) {
        if (b.pdfUrl && (b.pdfUrl === oldRelativeUrl || path.basename(b.pdfUrl) === safeFileName)) {
          b.pdfUrl = newRelativeUrl;
          b.fileUrl = newRelativeUrl;
          rewrittenCount++;
        }
        if (b.coverUrl && (b.coverUrl === oldRelativeUrl || path.basename(b.coverUrl) === safeFileName)) {
          b.coverUrl = newRelativeUrl;
          rewrittenCount++;
        }
      }
      writeJsonFile(CURRICULUM_BOOKS_FILE, books);

      recordCloudOp({
        id: opId,
        type: action === 'rename' ? 'FILE_RENAME' : action === 'move' ? 'FILE_MOVE' : 'FILE_REPLACE',
        target: safeFileName,
        admin: 'admin',
        timestamp: new Date().toISOString(),
        status: 'completed',
        steps: [
          { name: `تنفيذ ${action === 'rename' ? 'إعادة التسمية' : action === 'move' ? 'النقل' : 'الاستبدال'}`, status: 'done', details: newRelativeUrl },
          { name: 'تحديث جميع المراجع وقواعد البيانات المرتبطة تلقائياً', status: 'done', details: `تم تحديث ${rewrittenCount} مرجعاً` }
        ],
        details: { oldRelativeUrl, newRelativeUrl, rewrittenCount }
      });

      res.json({
        success: true,
        message: `تم تنفيذ العملية بنجاح وتحديث ${rewrittenCount} مرجعاً تلقائياً لمنع أي روابط مكسورة 🔄`,
        newUrl: newRelativeUrl,
        rewrittenCount
      });
    } catch (err: any) {
      console.error('File action error:', err);
      res.status(500).json({ success: false, error: err?.message || 'حدث خطأ أثناء معالجة الملف' });
    }
  });

  // 4. Deep 360-Degree Integrity Audit (فحص التكامل واكتشاف المراجع والملفات اليتيمة والمكسورة)
  app.get('/api/admin/cloud/integrity-audit', requireAdmin, (req: Request, res: Response) => {
    try {
      const lectures = readJsonFile<any[]>(LECTURES_FILE, []);
      const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);

      const folders = ['videos', 'books', 'covers'] as const;
      const physicalFiles = new Map<string, { folder: string; name: string; size: number; path: string }>();

      for (const f of folders) {
        const d = path.join(UPLOADS_DIR, f);
        if (fs.existsSync(d)) {
          for (const fname of fs.readdirSync(d)) {
            if (fname.startsWith('.')) continue;
            const fp = path.join(d, fname);
            try {
              const st = fs.statSync(fp);
              if (st.isFile()) {
                physicalFiles.set(`/uploads/${f}/${fname}`.toLowerCase(), { folder: f, name: fname, size: st.size, path: fp });
                physicalFiles.set(fname.toLowerCase(), { folder: f, name: fname, size: st.size, path: fp });
              }
            } catch (e) {}
          }
        }
      }

      // Check DB References for Broken Links (Missing Files)
      const brokenRefs: { id: string | number; title: string; type: string; field: string; missingUrl: string }[] = [];
      const healthyRefs: { id: string | number; title: string; type: string; field: string; url: string }[] = [];

      for (const lec of lectures) {
        if (lec.videoUrl) {
          const clean = lec.videoUrl.trim().toLowerCase();
          if (clean.startsWith('/uploads/')) {
            if (physicalFiles.has(clean) || physicalFiles.has(path.basename(clean))) {
              healthyRefs.push({ id: lec.id, title: lec.title, type: 'lecture', field: 'videoUrl', url: lec.videoUrl });
            } else {
              brokenRefs.push({ id: lec.id, title: lec.title, type: 'lecture', field: 'videoUrl', missingUrl: lec.videoUrl });
            }
          }
        }
      }

      for (const b of books) {
        if (b.pdfUrl && b.pdfUrl.startsWith('/uploads/')) {
          const clean = b.pdfUrl.trim().toLowerCase();
          if (physicalFiles.has(clean) || physicalFiles.has(path.basename(clean))) {
            healthyRefs.push({ id: b.id, title: b.title, type: 'book', field: 'pdfUrl', url: b.pdfUrl });
          } else {
            brokenRefs.push({ id: b.id, title: b.title, type: 'book', field: 'pdfUrl', missingUrl: b.pdfUrl });
          }
        }
        if (b.coverUrl && b.coverUrl.startsWith('/uploads/')) {
          const clean = b.coverUrl.trim().toLowerCase();
          if (physicalFiles.has(clean) || physicalFiles.has(path.basename(clean))) {
            healthyRefs.push({ id: b.id, title: b.title, type: 'book', field: 'coverUrl', url: b.coverUrl });
          } else {
            brokenRefs.push({ id: b.id, title: b.title, type: 'book', field: 'coverUrl', missingUrl: b.coverUrl });
          }
        }
      }

      // Detect Storage Orphans
      const orphanFiles: { fileName: string; folder: string; sizeMb: string; relativeUrl: string; reason: string }[] = [];
      const uniqueKeys = new Set<string>();

      for (const [key, item] of physicalFiles.entries()) {
        if (!key.startsWith('/uploads/')) continue;
        if (uniqueKeys.has(key)) continue;
        uniqueKeys.add(key);

        const usages = findFileUsages(key);
        if (usages.length === 0) {
          orphanFiles.push({
            fileName: item.name,
            folder: item.folder,
            sizeMb: `${(item.size / (1024 * 1024)).toFixed(2)} MB`,
            relativeUrl: key,
            reason: 'الملف موجود في التخزين لكنه غير مستخدم في أي محاضرة أو كتاب أو منشور'
          });
        }
      }

      const totalItemsChecked = physicalFiles.size / 2 + lectures.length + books.length;
      const issuesCount = orphanFiles.length + brokenRefs.length;
      const integrityScore = Math.max(10, Math.min(100, Math.round(100 - (issuesCount * 3.5))));

      res.json({
        success: true,
        auditTimestamp: new Date().toISOString(),
        integrityScore,
        summary: {
          totalStorageFiles: physicalFiles.size / 2,
          healthyReferences: healthyRefs.length,
          orphanFilesCount: orphanFiles.length,
          brokenReferencesCount: brokenRefs.length
        },
        orphanFiles,
        brokenReferences: brokenRefs,
        recommendations: [
          orphanFiles.length > 0 ? `يتوفر ${orphanFiles.length} ملفاً يتيماً يمكن تنظيفها لتفريغ مساحة التخزين.` : 'لا توجد ملفات يتيمة؛ السحابة نظيفة تماماً.',
          brokenRefs.length > 0 ? `يوجد ${brokenRefs.length} مرجعاً لم يعد ملفها موجوداً؛ يُنصح برفع الملف البديل أو تعديل الرابط.` : 'جميع المراجع في المحاضرات والكتب صالحة ومطابقة 100%.'
        ]
      });
    } catch (err: any) {
      console.error('Integrity audit error:', err);
      res.status(500).json({ success: false, error: 'فشل تنفيذ الفحص السحابي الشامل' });
    }
  });

  // 5. Clean All Orphaned Files (تنظيف جماعي آمن للملفات اليتيمة)
  app.post('/api/admin/cloud/clean-orphans', requireAdmin, (req: Request, res: Response) => {
    const opId = `op_clean_${Date.now()}`;
    try {
      const folders = ['videos', 'books', 'covers'] as const;
      let cleanedCount = 0;
      let freedBytes = 0;
      const cleanedFiles: string[] = [];

      for (const folder of folders) {
        const folderDir = path.join(UPLOADS_DIR, folder);
        if (!fs.existsSync(folderDir)) continue;

        const fileNames = fs.readdirSync(folderDir);
        for (const fname of fileNames) {
          if (fname.startsWith('.')) continue;
          const relativeUrl = `/uploads/${folder}/${fname}`;
          const usages = findFileUsages(relativeUrl);

          if (usages.length === 0) {
            const p = path.join(folderDir, fname);
            try {
              const stat = fs.statSync(p);
              freedBytes += stat.size;
              fs.unlinkSync(p);
              cleanedCount++;
              cleanedFiles.push(`${folder}/${fname}`);
            } catch (e) {}
          }
        }
      }

      recordCloudOp({
        id: opId,
        type: 'ORPHAN_CLEAN',
        target: `${cleanedCount} orphan files`,
        admin: 'admin',
        timestamp: new Date().toISOString(),
        status: 'completed',
        steps: [
          { name: 'فحص مراجع المنصة السحابية', status: 'done' },
          { name: `مسح ${cleanedCount} ملفاً يتيماً بنجاح`, status: 'done', details: `${(freedBytes / (1024 * 1024)).toFixed(2)} MB مساحة محررة` }
        ],
        details: { cleanedCount, freedBytes, cleanedFiles }
      });

      res.json({
        success: true,
        message: `تم تنظيف ${cleanedCount} ملفاً يتيماً وتفريغ ${(freedBytes / (1024 * 1024)).toFixed(2)} MB من السحابة بنجاح 🧹`,
        cleanedCount,
        freedSizeMb: `${(freedBytes / (1024 * 1024)).toFixed(2)} MB`,
        cleanedFiles
      });
    } catch (err: any) {
      console.error('Error cleaning orphan files:', err);
      res.status(500).json({ success: false, error: 'حدث خطأ أثناء تنظيف الملفات المعلقة' });
    }
  });

  // 6. Firestore Collections Inspector API (مستكشف مجموعات ومستندات Firestore)
  app.get('/api/admin/cloud/firestore/collections', requireAdmin, (req: Request, res: Response) => {
    try {
      const collections = [
        { name: 'lectures', label: 'المحاضرات والشروحات', count: readJsonFile<any[]>(LECTURES_FILE, []).length, description: 'سجلات المحاضرات والفيديوهات وروابط البث' },
        { name: 'curriculum_books', label: 'المناهج والملازم الوزارية', count: readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []).length, description: 'الكتب الإلكترونية والملازم بصيغة PDF' },
        { name: 'users', label: 'الطلاب المسجلون بالـ UID', count: readJsonFile<any[]>(USERS_FILE, []).length, description: 'الملفات الشخصية للطلاب ومعرّفاتهم الثابتة' },
        { name: 'lecture_codes', label: 'أكواد VIP المشفرة', count: readJsonFile<any[]>(LECTURE_CODES_FILE, []).length, description: 'أكواد التفعيل المربوطة بـ UID أو عامة' },
        { name: 'institute_posts', label: 'منشورات وواجبات المعهد', count: readJsonFile<any[]>(INSTITUTE_POSTS_FILE, []).length, description: 'إعلانات ودرجات معهد أنوار السلام' },
        { name: 'institute_stages', label: 'المراحل الأكاديمية للمعهد', count: readJsonFile<any[]>(INSTITUTE_STAGES_FILE, []).length, description: 'الصفوف والمجموعات الدراسية' },
        { name: 'settings', label: 'إعدادات المنصة والتحديثات', count: fs.existsSync(SETTINGS_FILE) ? 1 : 0, description: 'تكوينات النظام وإعلانات التطبيق' },
        { name: 'ai_config', label: 'إعدادات الذكاء الاصطناعي', count: fs.existsSync(AI_CONFIG_FILE) ? 1 : 0, description: 'معايير ونطاق المساعد الذكي لمادة الأحياء' },
        { name: 'cloud_operations', label: 'سجل العمليات السحابية', count: readJsonFile<any[]>(CLOUD_OPERATIONS_LOG_FILE, []).length, description: 'سجل التدقيق للعمليات السحابية الشاملة' }
      ];

      res.json({ success: true, collections });
    } catch (err: any) {
      console.error('Firestore collections query error:', err);
      res.status(500).json({ success: false, error: 'تعذر جلب إحصائيات مجموعات Firestore' });
    }
  });

  // 7. Firestore Documents Query & Viewer API
  app.get('/api/admin/cloud/firestore/documents', requireAdmin, (req: Request, res: Response) => {
    try {
      const { collectionName, search, limit = 50, offset = 0 } = req.query;
      const cName = String(collectionName || 'lectures');

      let filePath = LECTURES_FILE;
      if (cName === 'curriculum_books') filePath = CURRICULUM_BOOKS_FILE;
      else if (cName === 'users') filePath = USERS_FILE;
      else if (cName === 'lecture_codes') filePath = LECTURE_CODES_FILE;
      else if (cName === 'institute_posts') filePath = INSTITUTE_POSTS_FILE;
      else if (cName === 'institute_stages') filePath = INSTITUTE_STAGES_FILE;
      else if (cName === 'cloud_operations') filePath = CLOUD_OPERATIONS_LOG_FILE;

      let docs = readJsonFile<any[]>(filePath, []);
      if (!Array.isArray(docs)) docs = [docs];

      if (search && typeof search === 'string') {
        const queryStr = search.trim().toLowerCase();
        docs = docs.filter(doc => JSON.stringify(doc).toLowerCase().includes(queryStr));
      }

      const total = docs.length;
      const paginated = docs.slice(Number(offset), Number(offset) + Number(limit));

      res.json({
        success: true,
        collectionName: cName,
        total,
        limit: Number(limit),
        offset: Number(offset),
        documents: paginated
      });
    } catch (err: any) {
      console.error('Firestore documents fetch error:', err);
      res.status(500).json({ success: false, error: 'فشل استعلام وثائق Firestore' });
    }
  });

  // 8. Firestore Safe Document Mutation (Add / Update / Delete)
  app.post('/api/admin/cloud/firestore/documents', requireAdmin, (req: Request, res: Response) => {
    try {
      const { collectionName, docId, data } = req.body;
      if (!collectionName || !docId || !data) {
        res.status(400).json({ success: false, error: 'اسم المجموعة ومعرّف الوثيقة والبيانات مطلوبة' });
        return;
      }

      let filePath = LECTURES_FILE;
      if (collectionName === 'curriculum_books') filePath = CURRICULUM_BOOKS_FILE;
      else if (collectionName === 'users') filePath = USERS_FILE;
      else if (collectionName === 'lecture_codes') filePath = LECTURE_CODES_FILE;
      else if (collectionName === 'institute_posts') filePath = INSTITUTE_POSTS_FILE;

      const docs = readJsonFile<any[]>(filePath, []);
      const index = docs.findIndex(d => String(d.id || d.uid || d.code) === String(docId));

      const updatedData = { ...data, updatedAt: new Date().toISOString() };
      if (index !== -1) {
        docs[index] = { ...docs[index], ...updatedData };
      } else {
        docs.unshift({ id: docId, ...updatedData });
      }

      writeJsonFile(filePath, docs);

      recordCloudOp({
        id: `op_doc_${Date.now()}`,
        type: 'DOC_UPDATE',
        target: `${collectionName}/${docId}`,
        admin: 'admin',
        timestamp: new Date().toISOString(),
        status: 'completed',
        steps: [{ name: 'تحديث مستند في قاعدة البيانات السحابية', status: 'done' }],
        details: { collectionName, docId }
      });

      res.json({ success: true, message: 'تم حفظ وتحديث المستند في السحابة بنجاح 💾', document: updatedData });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'فشل حفظ مستند Firestore' });
    }
  });

  // 9. Operations History & Audit Log API
  app.get('/api/admin/cloud/operations-log', requireAdmin, (req: Request, res: Response) => {
    try {
      const logs = readJsonFile<CloudOpRecord[]>(CLOUD_OPERATIONS_LOG_FILE, []);
      res.json({ success: true, logs });
    } catch (err: any) {
      res.status(500).json({ success: false, error: 'تعذر جلب سجل التدقيق السحابي' });
    }
  });

  // 10. Real-Time Cloud Services Health & Latency Monitor
  app.get('/api/admin/cloud/health', requireAdmin, async (req: Request, res: Response) => {
    const startMs = Date.now();
    try {
      const lecturesCount = readJsonFile<any[]>(LECTURES_FILE, []).length;
      const booksCount = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []).length;
      const usersCount = readJsonFile<any[]>(USERS_FILE, []).length;

      const storageAccessible = fs.existsSync(UPLOADS_DIR);
      const apiLatencyMs = Date.now() - startMs;

      res.json({
        success: true,
        status: 'healthy',
        timestamp: new Date().toISOString(),
        services: {
          firestore: {
            status: 'connected',
            databaseId: 'ai-studio-85798a9e-7365-46c6-bde9-0a484132186b',
            mode: 'Production Central Cloud',
            latencyMs: apiLatencyMs + 5,
            collectionsHealthy: true
          },
          storage: {
            status: 'accessible',
            bucket: 'prismatic-clone-5lcf1.firebasestorage.app',
            localFallback: storageAccessible,
            foldersHealthy: true
          },
          serverApi: {
            status: 'online',
            uptimeSeconds: Math.floor(process.uptime()),
            memoryUsageMb: (process.memoryUsage().heapUsed / (1024 * 1024)).toFixed(1),
            latencyMs: apiLatencyMs
          }
        },
        counts: {
          lectures: lecturesCount,
          books: booksCount,
          users: usersCount
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: 'خطأ أثناء فحص حالة الخدمات السحابية' });
    }
  });

  // ==========================================
  // DIRECT FILE DOWNLOAD & PROXY ROUTE (تنزيل مباشر للكتب دون Google Drive)
  // ==========================================
  app.get('/api/download', async (req: Request, res: Response) => {
    try {
      const { file, url, title, bookId } = req.query;

      // Handle bookId from curriculum books database
      if (bookId && typeof bookId === 'string') {
        const curriculumBooks = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);
        const targetBook = curriculumBooks.find((b) => b.id === bookId);
        if (targetBook) {
          if (!targetBook.isAvailable || !targetBook.pdfUrl) {
            res.status(404).json({
              success: false,
              isUnavailable: true,
              error: `عذراً، النسخة الإلكترونية الأصلية لكتاب "${targetBook.title}" غير متوفرة حالياً في مستودع الوزارة أو جاري التحقق من طبعتها.`
            });
            return;
          }
          const localPdfPath = path.resolve(process.cwd(), 'public', targetBook.pdfUrl.replace(/^\/+/, ''));
          if (fs.existsSync(localPdfPath)) {
            const stat = fs.statSync(localPdfPath);
            const downloadFilename = `${targetBook.title}.pdf`;
            const encodedFilename = encodeURIComponent(downloadFilename);
            const safeAsciiFilename = `${targetBook.id}.pdf`;
            res.writeHead(200, {
              'Content-Type': 'application/pdf',
              'Content-Length': stat.size,
              'Content-Disposition': `attachment; filename="${safeAsciiFilename}"; filename*=UTF-8''${encodedFilename}`,
              'Cache-Control': 'no-cache'
            });
            fs.createReadStream(localPdfPath).pipe(res);
            return;
          }
        }
      }

      // Clean desired filename
      let downloadName = String(title || 'biology_book').trim();
      downloadName = downloadName.replace(/[/\\?%*:|"<>]/g, '_');
      if (!downloadName.toLowerCase().endsWith('.pdf') && !downloadName.toLowerCase().endsWith('.epub') && !downloadName.toLowerCase().endsWith('.mp4')) {
        downloadName += '.pdf';
      }
      const encodedFilename = encodeURIComponent(downloadName);
      const safeAsciiFilename = downloadName.replace(/[^\x00-\x7F]/g, '_') || 'download.pdf';

      // Case A: Local file stored in /uploads
      if (file && typeof file === 'string') {
        let cleanPath = file.replace(/^\/+/, '');
        if (cleanPath.startsWith('uploads/')) {
          cleanPath = cleanPath.replace(/^uploads\//, '');
        }
        const fullPath = path.resolve(UPLOADS_DIR, cleanPath);

        // Security check
        if (!fullPath.startsWith(path.resolve(process.cwd(), 'public'))) {
          res.status(403).json({ success: false, error: 'غير مصرح بالوصول لهذا المسار' });
          return;
        }

        if (fs.existsSync(fullPath)) {
          const stat = fs.statSync(fullPath);
          const ext = path.extname(fullPath).toLowerCase();
          const mimeType = ext === '.pdf' ? 'application/pdf' : ext === '.mp4' ? 'video/mp4' : 'application/octet-stream';

          res.writeHead(200, {
            'Content-Type': mimeType,
            'Content-Length': stat.size,
            'Content-Disposition': `attachment; filename="${safeAsciiFilename}"; filename*=UTF-8''${encodedFilename}`,
            'Cache-Control': 'no-cache'
          });
          const stream = fs.createReadStream(fullPath);
          stream.pipe(res);
          return;
        } else {
          res.status(404).json({ success: false, error: 'الملف المطلوب غير موجود على الخادم' });
          return;
        }
      }

      // Special Google Drive & Curriculum Books Handling
      let driveFileId: string | null = null;
      if (url && typeof url === 'string') {
        const driveMatch = url.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/) || url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
        if (driveMatch && driveMatch[1]) {
          driveFileId = driveMatch[1];
        }
      } else if (file && typeof file === 'string') {
        const driveMatch = file.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/) || file.match(/[?&]id=([a-zA-Z0-9_-]+)/);
        if (driveMatch && driveMatch[1]) {
          driveFileId = driveMatch[1];
        }
      }

      // Check if requested URL or fileId matches one of our 6 curriculum books
      if (driveFileId) {
        const matched = CURRICULUM_DRIVE_BOOKS.find((b) => b.driveId === driveFileId || b.id === driveFileId);
        if (matched) {
          const localPdfPath = path.resolve(UPLOADS_DIR, 'books', path.basename(matched.localFile));
          if (fs.existsSync(localPdfPath)) {
            const stat = fs.statSync(localPdfPath);
            res.writeHead(200, {
              'Content-Type': 'application/pdf',
              'Content-Length': stat.size,
              'Content-Disposition': `attachment; filename="${safeAsciiFilename}"; filename*=UTF-8''${encodedFilename}`,
              'Cache-Control': 'no-cache',
              'X-Drive-Status': matched.driveAccessStatus,
              'X-Drive-Id': matched.driveId
            });
            fs.createReadStream(localPdfPath).pipe(res);
            return;
          }
        }
      }

      // Case B: Remote URL direct streaming or proxy
      if (url && typeof url === 'string') {
        const targetUrl = url.trim();

        // If targetUrl points to a local upload path
        if (targetUrl.startsWith('/uploads/')) {
          const cleanPath = targetUrl.replace(/^\/uploads\//, '');
          const fullPath = path.resolve(UPLOADS_DIR, cleanPath);
          if (fs.existsSync(fullPath)) {
            const stat = fs.statSync(fullPath);
            const ext = path.extname(fullPath).toLowerCase();
            const mimeType = ext === '.pdf' ? 'application/pdf' : ext === '.mp4' ? 'video/mp4' : 'application/octet-stream';

            res.writeHead(200, {
              'Content-Type': mimeType,
              'Content-Length': stat.size,
              'Content-Disposition': `attachment; filename="${safeAsciiFilename}"; filename*=UTF-8''${encodedFilename}`,
              'Cache-Control': 'no-cache'
            });
            const stream = fs.createReadStream(fullPath);
            stream.pipe(res);
            return;
          }
        }

        try {
          const remoteRes = await fetch(targetUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
          });

          if (!remoteRes.ok) {
            res.status(502).json({
              success: false,
              error: `تعذر جلب الملف من المصدر الخارجي (رمز الاستجابة: ${remoteRes.status})`
            });
            return;
          }

          const contentType = (remoteRes.headers.get('content-type') || '').toLowerCase();

          // Check if remote is an HTML page (like Google Drive preview, repository UI page)
          if (contentType.includes('text/html')) {
            // If it was Google Drive, fallback to matching curriculum book if possible
            if (targetUrl.includes('drive.google.com')) {
              const fallbackBook = CURRICULUM_DRIVE_BOOKS.find(b => targetUrl.includes(b.driveId));
              if (fallbackBook) {
                const localPdfPath = path.resolve(UPLOADS_DIR, 'books', path.basename(fallbackBook.localFile));
                if (fs.existsSync(localPdfPath)) {
                  const stat = fs.statSync(localPdfPath);
                  res.writeHead(200, {
                    'Content-Type': 'application/pdf',
                    'Content-Length': stat.size,
                    'Content-Disposition': `attachment; filename="${safeAsciiFilename}"; filename*=UTF-8''${encodedFilename}`,
                    'Cache-Control': 'no-cache',
                    'X-Drive-Fallback': 'true'
                  });
                  fs.createReadStream(localPdfPath).pipe(res);
                  return;
                }
              }
            }

            res.status(400).json({
              success: false,
              isHtmlPage: true,
              error: 'هذا الرابط يشير إلى صفحة ويب أو مستودع خارجي ولا يوفر تنزيلاً مباشراً لملف PDF',
              originalUrl: targetUrl
            });
            return;
          }

          const contentLength = remoteRes.headers.get('content-length');
          const headers: Record<string, string | number> = {
            'Content-Type': contentType.includes('pdf') ? 'application/pdf' : contentType || 'application/octet-stream',
            'Content-Disposition': `attachment; filename="${safeAsciiFilename}"; filename*=UTF-8''${encodedFilename}`,
            'Cache-Control': 'public, max-age=86400'
          };
          if (contentLength) {
            headers['Content-Length'] = contentLength;
          }

          res.writeHead(200, headers);

          if (remoteRes.body) {
            const reader = remoteRes.body.getReader();
            const pump = async () => {
              while (true) {
                const { done, value } = await reader.read();
                if (done) {
                  res.end();
                  break;
                }
                res.write(Buffer.from(value));
              }
            };
            await pump();
          } else {
            res.end();
          }
          return;
        } catch (fetchErr: any) {
          console.error('Remote fetch download error:', fetchErr);
          res.status(500).json({
            success: false,
            error: 'فشل الاتصال بالمصدر الخارجي لتنزيل الملف'
          });
          return;
        }
      }

      res.status(400).json({ success: false, error: 'يرجى تحديد مسار الملف أو الرابط المطلوب تنزيله' });
    } catch (err: any) {
      console.error('Download route error:', err);
      res.status(500).json({ success: false, error: 'حدث خطأ أثناء معالجة تنزيل الملف' });
    }
  });

  // Verify URL Endpoint to inspect remote links (Direct PDF vs Webpage vs Invalid)
  app.post('/api/books/verify-url', async (req: Request, res: Response) => {
    try {
      const { url } = req.body;
      if (!url || typeof url !== 'string') {
        res.status(400).json({ success: false, error: 'الرابط مطلوب' });
        return;
      }

      const targetUrl = url.trim();

      // Check if it's a local uploaded file
      if (targetUrl.startsWith('/uploads/')) {
        const fullPath = path.resolve(process.cwd(), 'public', targetUrl.replace(/^\/+/, ''));
        const exists = fs.existsSync(fullPath);
        res.json({
          success: true,
          type: 'direct-pdf',
          isLocal: true,
          exists,
          fileSize: exists ? `${(fs.statSync(fullPath).size / (1024 * 1024)).toFixed(2)} MB` : undefined
        });
        return;
      }

      const remoteRes = await fetch(targetUrl, {
        method: 'HEAD',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      const contentType = (remoteRes.headers.get('content-type') || '').toLowerCase();
      const contentLength = remoteRes.headers.get('content-length');

      let linkType: 'direct-pdf' | 'webpage' | 'repository' | 'other' = 'other';
      if (contentType.includes('application/pdf') || targetUrl.toLowerCase().endsWith('.pdf')) {
        linkType = 'direct-pdf';
      } else if (contentType.includes('text/html')) {
        linkType = 'webpage';
      }

      res.json({
        success: true,
        statusCode: remoteRes.status,
        type: linkType,
        contentType,
        contentLength: contentLength ? `${(Number(contentLength) / (1024 * 1024)).toFixed(2)} MB` : undefined,
        canDownloadDirectly: linkType === 'direct-pdf' && remoteRes.ok
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: 'تعذر الاتصال بالرابط الخارجي للتحقق منه'
      });
    }
  });

  // Curriculum Books List API (المناهج الدراسية الرسمية المعتمدة لجميع المراحل)
  app.get('/api/books/curriculum', (req: Request, res: Response) => {
    const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, CURRICULUM_DRIVE_BOOKS);
    res.json({
      success: true,
      books,
      count: books.length
    });
  });

  // Google Drive Links Status Checker API
  app.get('/api/books/drive-status', async (req: Request, res: Response) => {
    try {
      const curriculumBooks = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, CURRICULUM_DRIVE_BOOKS);
      const statuses = curriculumBooks.map((b) => ({
        id: b.id,
        gradeKey: b.gradeKey,
        grade: b.grade,
        title: b.title,
        driveId: b.driveId,
        driveUrl: b.driveUrl,
        accessStatus: b.verificationStatus === 'verified' ? 'verified' : (b.driveAccessStatus || 'not_found'),
        statusMessage: b.verificationNotes || b.driveStatusMessage || 'النسخة المعتمدة متوفرة محلياً بالمنصة',
        hasLocalFallback: Boolean(b.pdfUrl || b.localFile),
        localFile: b.pdfUrl || b.localFile,
        isAvailable: b.isAvailable !== false
      }));

      res.json({
        success: true,
        statuses,
        totalChecked: statuses.length,
        timestamp: new Date().toISOString()
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: 'تعذر فحص حالة روابط المناهج' });
    }
  });

  // Direct In-App Book PDF Streaming API
  app.get('/api/books/drive-proxy/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const curriculumBooks = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);
      let matched = curriculumBooks.find((b) => b.id === id || b.driveId === id);
      if (!matched) {
        matched = CURRICULUM_DRIVE_BOOKS.find((b) => b.driveId === id || b.id === id);
      }

      if (!matched) {
        res.status(404).json({ success: false, error: 'الكتاب المطلوب غير مسجل في قائمة المناهج' });
        return;
      }

      // Check if book is marked unavailable
      if (matched.isAvailable === false || (!matched.pdfUrl && !matched.localFile && !matched.driveId)) {
        res.status(404).json({
          success: false,
          isUnavailable: true,
          error: `عذراً، النسخة الإلكترونية الأصلية لكتاب "${matched.title}" غير متوفرة حالياً في مستودع الوزارة المعتمد أو جاري تدقيق طبعتها الرسمية.`,
          bookTitle: matched.title
        });
        return;
      }

      const filePath = matched.pdfUrl || matched.localFile || '';
      const localPdfPath = path.resolve(process.cwd(), 'public', filePath.replace(/^\/+/, ''));

      if (fs.existsSync(localPdfPath)) {
        const stat = fs.statSync(localPdfPath);
        const encodedFilename = encodeURIComponent(`${matched.title}.pdf`);
        const safeAsciiFilename = `${matched.id || 'book'}.pdf`;

        res.writeHead(200, {
          'Content-Type': 'application/pdf',
          'Content-Length': stat.size,
          'Content-Disposition': `inline; filename="${safeAsciiFilename}"; filename*=UTF-8''${encodedFilename}`,
          'Cache-Control': 'public, max-age=86400',
          'X-Book-Available': 'true'
        });
        fs.createReadStream(localPdfPath).pipe(res);
        return;
      }

      // If local file not found but Google Drive ID is present, stream via drive stream proxy
      if (matched.driveId) {
        req.url = `/api/stream-drive/${matched.driveId}`;
        return app._router.handle(req, res, () => {});
      }

      res.status(404).json({
        success: false,
        isUnavailable: true,
        error: `ملف الـ PDF الأصلي لكتاب "${matched.title}" غير موجود على السيرفر حالياً (${path.basename(localPdfPath)})`
      });
    } catch (err: any) {
      console.error('Book stream error:', err);
      res.status(500).json({ success: false, error: 'حدث خطأ أثناء بث ملف الكتاب' });
    }
  });

  // ==========================================
  // Direct In-App Google Drive & Video Streaming Proxy
  // Supports Range Requests (HTTP 206) for smooth seeking, custom player, and native playback
  // Eliminates external Google Drive redirects and popup auth prompts
  // ==========================================
  app.get('/api/stream-drive/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const cleanId = (id || '').replace(/^drive-/, '').replace(/\.mp4$/i, '').replace(/\.pdf$/i, '').trim();

      if (!cleanId) {
        res.status(400).json({ success: false, error: 'معرف الملف غير صالح' });
        return;
      }

      // 1. Check if matching local file exists (in videos, books, uploads)
      const possibleLocalPaths = [
        path.resolve(UPLOADS_DIR, 'videos', `${cleanId}.mp4`),
        path.resolve(UPLOADS_DIR, 'videos', cleanId),
        path.resolve(UPLOADS_DIR, 'books', `${cleanId}.pdf`),
        path.resolve(UPLOADS_DIR, 'books', cleanId),
        path.resolve(UPLOADS_DIR, cleanId),
        path.resolve(process.cwd(), 'public', cleanId.replace(/^\/+/, ''))
      ];

      // Check curriculum books matching
      const curriculumMatch = CURRICULUM_DRIVE_BOOKS.find(b => b.driveId === cleanId || b.id === cleanId);
      if (curriculumMatch && curriculumMatch.localFile) {
        possibleLocalPaths.unshift(path.resolve(process.cwd(), 'public', curriculumMatch.localFile.replace(/^\/+/, '')));
      }

      for (const locPath of possibleLocalPaths) {
        if (fs.existsSync(locPath) && fs.statSync(locPath).isFile()) {
          const stat = fs.statSync(locPath);
          const fileSize = stat.size;
          const ext = path.extname(locPath).toLowerCase();
          const mimeType = ext === '.mp4' ? 'video/mp4' : ext === '.pdf' ? 'application/pdf' : 'application/octet-stream';
          const range = req.headers.range;

          if (range) {
            const parts = range.replace(/bytes=/, '').split('-');
            const start = parseInt(parts[0], 10);
            const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
            const chunkSize = (end - start) + 1;

            res.writeHead(206, {
              'Content-Range': `bytes ${start}-${end}/${fileSize}`,
              'Accept-Ranges': 'bytes',
              'Content-Length': chunkSize,
              'Content-Type': mimeType,
              'Cache-Control': 'public, max-age=86400',
              'Access-Control-Allow-Origin': '*'
            });
            fs.createReadStream(locPath, { start, end }).pipe(res);
            return;
          } else {
            res.writeHead(200, {
              'Content-Length': fileSize,
              'Accept-Ranges': 'bytes',
              'Content-Type': mimeType,
              'Cache-Control': 'public, max-age=86400',
              'Access-Control-Allow-Origin': '*'
            });
            fs.createReadStream(locPath).pipe(res);
            return;
          }
        }
      }

      // 2. Stream from Google Drive
      const authHeader = req.headers.authorization;
      const queryToken = typeof req.query.token === 'string' ? req.query.token : null;
      const bearerToken = queryToken || (authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : null);

      const requestHeaders: Record<string, string> = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': '*/*'
      };
      if (req.headers.range) {
        requestHeaders['Range'] = req.headers.range as string;
      }
      if (bearerToken) {
        requestHeaders['Authorization'] = `Bearer ${bearerToken}`;
      }

      const driveEndpoints: string[] = [];
      if (bearerToken) {
        driveEndpoints.push(`https://www.googleapis.com/drive/v3/files/${cleanId}?alt=media`);
      }
      driveEndpoints.push(
        `https://drive.usercontent.google.com/download?id=${cleanId}&export=download&confirm=t`,
        `https://docs.google.com/uc?export=download&id=${cleanId}&confirm=t`,
        `https://drive.google.com/uc?export=download&id=${cleanId}&confirm=t`
      );

      let driveResponse: globalThis.Response | null = null;

      for (const endpoint of driveEndpoints) {
        try {
          const fetchHeaders = { ...requestHeaders };
          if (!endpoint.includes('googleapis.com')) {
            delete fetchHeaders['Authorization'];
          }

          const response = await fetch(endpoint, {
            headers: fetchHeaders,
            redirect: 'follow'
          });

          if (response.ok) {
            const ct = (response.headers.get('content-type') || '').toLowerCase();
            if (!ct.includes('text/html')) {
              driveResponse = response;
              break;
            } else {
              // Extract confirmation token if Google presented virus scan warning page
              const htmlText = await response.text();
              const confirmMatch = htmlText.match(/name="confirm"\s+value="([^"]+)"/) || htmlText.match(/confirm=([0-9a-zA-Z_-]+)/);
              if (confirmMatch && confirmMatch[1]) {
                const confirmedUrl = `https://drive.usercontent.google.com/download?id=${cleanId}&export=download&confirm=${confirmMatch[1]}`;
                const confirmedRes = await fetch(confirmedUrl, {
                  headers: fetchHeaders,
                  redirect: 'follow'
                });
                if (confirmedRes.ok && !(confirmedRes.headers.get('content-type') || '').includes('text/html')) {
                  driveResponse = confirmedRes;
                  break;
                }
              }
            }
          }
        } catch (fetchErr) {
          console.warn(`Drive fetch endpoint attempt notice (${endpoint}):`, fetchErr);
        }
      }

      if (!driveResponse || !driveResponse.body) {
        // Fallback for curriculum books if Google Drive is inaccessible
        if (curriculumMatch && curriculumMatch.localFile) {
          const fallbackLoc = path.resolve(process.cwd(), 'public', curriculumMatch.localFile.replace(/^\/+/, ''));
          if (fs.existsSync(fallbackLoc)) {
            const stat = fs.statSync(fallbackLoc);
            res.writeHead(200, {
              'Content-Type': 'application/pdf',
              'Content-Length': stat.size,
              'Cache-Control': 'public, max-age=86400',
              'Access-Control-Allow-Origin': '*'
            });
            fs.createReadStream(fallbackLoc).pipe(res);
            return;
          }
        }

        res.status(404).json({
          success: false,
          error: 'تعذر الاتصال بملف Google Drive أو قد يحتاج الملف لصلاحيات وصول عامة',
          fileId: cleanId
        });
        return;
      }

      // Forward headers and status
      const contentType = driveResponse.headers.get('content-type') || 'video/mp4';
      const contentLength = driveResponse.headers.get('content-length');
      const contentRange = driveResponse.headers.get('content-range');
      const acceptRanges = driveResponse.headers.get('accept-ranges') || 'bytes';

      const responseHeaders: Record<string, string | number> = {
        'Content-Type': contentType,
        'Accept-Ranges': acceptRanges,
        'Cache-Control': 'public, max-age=86400',
        'Access-Control-Allow-Origin': '*'
      };

      if (contentLength) responseHeaders['Content-Length'] = contentLength;
      if (contentRange) responseHeaders['Content-Range'] = contentRange;

      const statusCode = driveResponse.status === 206 || contentRange ? 206 : 200;
      res.writeHead(statusCode, responseHeaders);

      const nodeStream = Readable.fromWeb(driveResponse.body as any);
      nodeStream.pipe(res);

      req.on('close', () => {
        nodeStream.destroy();
      });
    } catch (streamErr: any) {
      console.error('Drive stream proxy error:', streamErr);
      if (!res.headersSent) {
        res.status(500).json({ success: false, error: 'حدث خطأ أثناء بث ملف الوسائط' });
      }
    }
  });

  // ==========================================
  // Admin Books Discovery & Verification APIs (مركز استكشاف ومراجعة المناهج والكتب)
  // ==========================================

  // Inspect any external or Ministry URL
  app.post('/api/admin/books/inspect-url', requireAdmin, async (req: Request, res: Response) => {
    const { url } = req.body;
    if (!url || typeof url !== 'string') {
      res.status(400).json({ success: false, error: 'الرابط مطلوب للفحص' });
      return;
    }

    const targetUrl = url.trim();

    // Check if local file
    if (targetUrl.startsWith('/uploads/')) {
      const localPath = path.resolve(process.cwd(), 'public', targetUrl.replace(/^\/+/, ''));
      const exists = fs.existsSync(localPath);
      let sizeMb = '0';
      let isPdf = false;
      if (exists) {
        const stat = fs.statSync(localPath);
        sizeMb = (stat.size / (1024 * 1024)).toFixed(2);
        try {
          const buffer = Buffer.alloc(10);
          const fd = fs.openSync(localPath, 'r');
          fs.readSync(fd, buffer, 0, 10, 0);
          fs.closeSync(fd);
          isPdf = buffer.toString('ascii').startsWith('%PDF-');
        } catch (e) {}
      }

      res.json({
        success: true,
        url: targetUrl,
        isLocal: true,
        exists,
        sizeMb: `${sizeMb} MB`,
        contentType: isPdf ? 'application/pdf' : 'unknown',
        isDirectPdf: isPdf,
        statusCode: exists ? 200 : 404,
        recommendation: exists && isPdf
          ? 'الملف جاهز ومخزن محلياً على السيرفر ويعمل مباشرة'
          : 'الملف غير موجود في مجلد السيرفر'
      });
      return;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 7000);

      const response = await fetch(targetUrl, {
        method: 'GET',
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/pdf, text/html, */*'
        }
      });
      clearTimeout(timeoutId);

      const statusCode = response.status;
      const contentType = (response.headers.get('content-type') || '').toLowerCase();
      const contentLength = response.headers.get('content-length');
      const sizeMb = contentLength ? `${(Number(contentLength) / (1024 * 1024)).toFixed(2)} MB` : 'غير محدد';

      const isCloudflare = statusCode === 403 && (response.headers.get('server') || '').includes('cloudflare');
      const isDirectPdf = contentType.includes('application/pdf') || targetUrl.toLowerCase().endsWith('.pdf');
      const isHtmlPage = contentType.includes('text/html');

      let recommendation = '';
      if (statusCode === 200 && isDirectPdf) {
        recommendation = 'رابط PDF مباشر سليم ومعتمد، يمكن إضافته للقراءة والتنزيل الفوري.';
      } else if (isCloudflare) {
        recommendation = 'الموقع محمي بنظام Cloudflare ومقيد أمنياً ضد الوصول البرمجي المباشر. يُنصح بتحميل الملف وحفظه محلياً في المنصة لضمان فتحه للطلاب.';
      } else if (isHtmlPage) {
        recommendation = 'الرابط يشير إلى صفحة ويب أو واجهة موقع تعليمي وليس ملف PDF مباشر. يجب استخراج الرابط المباشر للـ PDF أو حفظه بالمنصة.';
      } else {
        recommendation = `رمز الاستجابة ${statusCode} - تحقق من صلاحية الرابط قبل ربطه بالطلاب.`;
      }

      res.json({
        success: true,
        url: targetUrl,
        statusCode,
        contentType,
        sizeMb,
        isDirectPdf,
        isHtmlPage,
        isCloudflare,
        recommendation
      });
    } catch (err: any) {
      res.json({
        success: false,
        url: targetUrl,
        error: err?.name === 'AbortError' ? 'انتهت مهلة الاتصال بالموقع (تجاوز 7 ثوانٍ)' : (err?.message || 'فشل الاتصال بالرابط'),
        recommendation: 'تعذر الوصول للرابط؛ تأكد من اتصال الإنترنت أو صحة الرابط.'
      });
    }
  });

  // Get all curriculum books for Admin
  app.get('/api/admin/books', requireAdmin, (req: Request, res: Response) => {
    const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);
    res.json({ success: true, books });
  });

  // Add a new curriculum book
  app.post('/api/admin/books', requireAdmin, (req: Request, res: Response) => {
    const bookData = req.body;
    if (!bookData.title || !bookData.grade) {
      res.status(400).json({ success: false, error: 'عنوان الكتاب والصف مطلوبان' });
      return;
    }

    const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);
    const newBook = {
      id: bookData.id || `cb-${Date.now()}`,
      stage: bookData.stage || 'preparatory',
      stageName: bookData.stageName || (bookData.stage === 'primary' ? 'المرحلة الابتدائية' : bookData.stage === 'intermediate' ? 'المرحلة المتوسطة' : 'المرحلة الإعدادية'),
      gradeKey: bookData.gradeKey || 'g6',
      grade: bookData.grade,
      subject: bookData.subject || 'الأحياء',
      icon: bookData.icon || '📘',
      title: String(bookData.title).trim(),
      edition: bookData.edition || 'طبعة 2024 المعتمدة',
      author: bookData.author || 'وزارة التربية العراقية',
      specialization: bookData.specialization || 'علم الأحياء',
      academicLevel: bookData.academicLevel || 'المنهج الوزاري',
      pages: Number(bookData.pages) || 150,
      fileSize: bookData.fileSize || 'غير محدد',
      year: Number(bookData.year) || 2024,
      pdfUrl: bookData.pdfUrl || null,
      fileUrl: bookData.pdfUrl || null,
      officialSource: bookData.officialSource || 'https://manahj.edu.iq/',
      isAvailable: Boolean(bookData.isAvailable),
      verificationStatus: bookData.verificationStatus || (bookData.isAvailable ? 'verified' : 'unavailable'),
      verificationNotes: bookData.verificationNotes || '',
      coverUrl: bookData.coverUrl || 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
      description: bookData.description || '',
      status: 'published'
    };

    books.unshift(newBook);
    writeJsonFile(CURRICULUM_BOOKS_FILE, books);
    res.json({ success: true, book: newBook, message: 'تمت إضافة الكتاب بنجاح إلى المكتبة المنهجية 📚' });
  });

  // Update a curriculum book
  app.put('/api/admin/books/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const updates = req.body;
    const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);
    const index = books.findIndex((b) => b.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'الكتاب غير موجود' });
      return;
    }

    books[index] = { ...books[index], ...updates };
    writeJsonFile(CURRICULUM_BOOKS_FILE, books);
    res.json({ success: true, book: books[index], message: 'تم تحديث بيانات الكتاب بنجاح ✅' });
  });

  // Delete a curriculum book
  app.delete('/api/admin/books/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const books = readJsonFile<any[]>(CURRICULUM_BOOKS_FILE, []);
    const filtered = books.filter((b) => b.id !== id);

    if (filtered.length === books.length) {
      res.status(404).json({ success: false, error: 'الكتاب غير موجود' });
      return;
    }

    writeJsonFile(CURRICULUM_BOOKS_FILE, filtered);
    res.json({ success: true, message: 'تم حذف الكتاب من المكتبة المنهجية' });
  });

  // ==========================================
  // 1. Health API
  // ==========================================
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({
      status: 'ok',
      online: true,
      service: 'مختبر الأحياء - الخادم السحابي',
      timestamp: new Date().toISOString()
    });
  });

  // ==========================================
  // 2. Lectures API (Online sync for all users)
  // ==========================================
  app.get('/api/lectures', (req: Request, res: Response) => {
    const lectures = readJsonFile(LECTURES_FILE, []);
    res.json({
      success: true,
      lectures,
      count: lectures.length,
      syncedAt: new Date().toISOString()
    });
  });

  app.post('/api/lectures', requireAdmin, (req: Request, res: Response) => {
    const { id, title, desc, grade, videoUrl, isPaid, secretCode, createdAt, viewsCount } = req.body;

    if (!title || !videoUrl) {
      res.status(400).json({ success: false, error: 'عنوان المحاضرة ورابط الفيديو مطلوبان' });
      return;
    }

    const lectures: any[] = readJsonFile(LECTURES_FILE, []);
    // Preserve client ID if provided so Firestore and server files are 100% in sync
    const targetId = id ? Number(id) : Date.now();
    const existingIndex = lectures.findIndex((l) => l.id === targetId || String(l.id) === String(targetId));

    const newLecture = {
      id: targetId,
      title: String(title).trim(),
      desc: String(desc || '').trim(),
      grade: String(grade || 'g6').trim(),
      videoUrl: String(videoUrl).trim(),
      isPaid: Boolean(isPaid),
      secretCode: isPaid ? (secretCode ? String(secretCode).trim() : 'BIO2026') : null,
      createdAt: createdAt || new Date().toISOString(),
      viewsCount: viewsCount || 0
    };

    if (existingIndex !== -1) {
      lectures[existingIndex] = newLecture;
    } else {
      lectures.unshift(newLecture);
    }
    writeJsonFile(LECTURES_FILE, lectures);

    res.status(201).json({
      success: true,
      message: 'تم إضافة المحاضرة ونشرها لجميع مستخدمي المنصة بنجاح عبر الإنترنت',
      lecture: newLecture
    });
  });

  app.put('/api/lectures/:id', requireAdmin, (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const idStr = String(req.params.id).trim();
    const updates = req.body;
    let lectures: any[] = readJsonFile(LECTURES_FILE, []);
    const index = lectures.findIndex((l) => l.id === id || String(l.id) === idStr);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'المحاضرة غير موجودة' });
      return;
    }

    lectures[index] = { ...lectures[index], ...updates };
    writeJsonFile(LECTURES_FILE, lectures);

    res.json({
      success: true,
      message: 'تم تعديل المحاضرة وتحديثها لجميع المستخدمين',
      lecture: lectures[index]
    });
  });

  app.delete('/api/lectures/:id', requireAdmin, (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const idStr = String(req.params.id).trim();
    let lectures: any[] = readJsonFile(LECTURES_FILE, []);
    const initialLength = lectures.length;
    lectures = lectures.filter((l) => l.id !== id && String(l.id) !== idStr);

    writeJsonFile(LECTURES_FILE, lectures);
    res.json({
      success: true,
      message: 'تم حذف المحاضرة وإزالتها نهائياً من عند جميع المستخدمين',
      id: req.params.id
    });
  });

  app.delete('/api/lectures', requireAdmin, (req: Request, res: Response) => {
    writeJsonFile(LECTURES_FILE, []);
    res.json({
      success: true,
      message: 'تم حذف جميع المحاضرات بنجاح'
    });
  });

  // ==========================================
  // 3. User Management API (إدارة المستخدمين والمسارات والأكواد)
  // ==========================================
  app.get('/api/users', (req: Request, res: Response) => {
    const users: any[] = readJsonFile(USERS_FILE, []);
    
    // Calculate real-time stats
    const totalUsers = users.length;
    const activeUsers = users.filter((u) => u.status === 'active').length;
    const blockedUsers = users.filter((u) => u.status === 'blocked').length;
    const vipUsers = users.filter((u) => u.isVip || u.role === 'vip').length;
    const apkUsers = users.filter((u) => u.deviceType === 'android-apk').length;
    const webUsers = users.filter((u) => u.deviceType?.startsWith('web')).length;
    const schoolUsers = users.filter((u) => u.track === 'school' || !u.track).length;

    res.json({
      success: true,
      users,
      stats: {
        total: totalUsers,
        active: activeUsers,
        blocked: blockedUsers,
        vip: vipUsers,
        apk: apkUsers,
        web: webUsers,
        schoolCount: schoolUsers
      }
    });
  });

  app.post('/api/users', (req: Request, res: Response) => {
    const { name, emailOrPhone, grade, isVip, deviceType, notes, track, uid, birthDate, birthYear } = req.body;

    if (!name || (!emailOrPhone && !uid)) {
      res.status(400).json({ success: false, error: 'اسم الطالب ومعرّف الحساب أو الهاتف مطلوبان' });
      return;
    }

    const users: any[] = readJsonFile(USERS_FILE, []);
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const resolvedUid = uid || `UID-BIO-${randomSuffix}`;
    const newUser = {
      id: `STU-${randomSuffix}`,
      uid: resolvedUid,
      name: String(name).trim(),
      emailOrPhone: emailOrPhone ? String(emailOrPhone).trim() : `طالب مسجل (${resolvedUid})`,
      grade: String(grade || 'g6').trim(),
      track: 'school',
      birthDate: birthDate || null,
      birthYear: birthYear ? Number(birthYear) : null,
      role: isVip ? 'vip' : 'student',
      status: 'active',
      isVip: Boolean(isVip),
      deviceType: deviceType || 'android-apk',
      registeredAt: new Date().toISOString().split('T')[0],
      lastActive: 'الآن',
      unlockedLectures: isVip ? [101, 102] : [],
      notes: notes ? String(notes).trim() : ''
    };

    users.unshift(newUser);
    writeJsonFile(USERS_FILE, users);

    res.status(201).json({
      success: true,
      message: 'تم إضافة الطالب بنجاح لقاعدة بيانات المنصة',
      user: newUser
    });
  });

  app.put('/api/users/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const updates = req.body;
    let users: any[] = readJsonFile(USERS_FILE, []);
    const index = users.findIndex((u) => u.id === id || u.uid === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'المستخدم غير موجود' });
      return;
    }

    users[index] = { ...users[index], ...updates };
    writeJsonFile(USERS_FILE, users);

    res.json({
      success: true,
      message: 'تم تحديث بيانات المستخدم بنجاح',
      user: users[index]
    });
  });

  app.delete('/api/users/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    let users: any[] = readJsonFile(USERS_FILE, []);
    const initialLength = users.length;
    users = users.filter((u) => u.id !== id && u.uid !== id);

    if (users.length === initialLength) {
      res.status(404).json({ success: false, error: 'المستخدم غير موجود' });
      return;
    }

    writeJsonFile(USERS_FILE, users);
    res.json({
      success: true,
      message: 'تم حذف المستخدم من المنصة',
      id
    });
  });

  // Dedicated User Profile Sync (Onboarding, Track Selection, Stable UID)
  app.post('/api/users/profile', (req: Request, res: Response) => {
    const { uid, name, birthDate, birthYear, track, grade, deviceType, notes } = req.body;

    if (!uid || !name) {
      res.status(400).json({ success: false, error: 'معرّف UID واسم الطالب مطلوبان' });
      return;
    }

    let users: any[] = readJsonFile(USERS_FILE, []);
    const cleanUid = String(uid).trim();
    const cleanName = String(name).trim();
    const cleanTrack = 'school';
    const cleanGrade = String(grade || 'g6').trim();
    const parsedBirthYear = birthYear ? Number(birthYear) : (birthDate ? Number(String(birthDate).split('-')[0]) : null);

    const existingIndex = users.findIndex((u) => u.uid === cleanUid || u.id === cleanUid);

    if (existingIndex !== -1) {
      users[existingIndex] = {
        ...users[existingIndex],
        uid: cleanUid,
        name: cleanName,
        track: cleanTrack,
        grade: cleanGrade,
        birthDate: birthDate || users[existingIndex].birthDate || null,
        birthYear: parsedBirthYear || users[existingIndex].birthYear || null,
        deviceType: deviceType || users[existingIndex].deviceType || 'web-desktop',
        lastActive: 'متصل الآن'
      };
      writeJsonFile(USERS_FILE, users);
      res.json({
        success: true,
        message: 'تم تحديث الملف الشخصي بنجاح 🎓',
        user: users[existingIndex]
      });
      return;
    }

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const newProfile = {
      id: `STU-${randomSuffix}`,
      uid: cleanUid,
      name: cleanName,
      emailOrPhone: 'طالب مسجل بالمنصة',
      track: cleanTrack,
      grade: cleanGrade,
      birthDate: birthDate || null,
      birthYear: parsedBirthYear,
      role: 'student',
      status: 'active',
      isVip: false,
      deviceType: deviceType || 'web-desktop',
      registeredAt: new Date().toISOString().split('T')[0],
      lastActive: 'متصل الآن',
      unlockedLectures: [],
      notes: notes || ''
    };

    users.unshift(newProfile);
    writeJsonFile(USERS_FILE, users);

    res.status(201).json({
      success: true,
      message: 'تم إنشاء وتثبيت الملف الشخصي بنجاح 🎓',
      user: newProfile
    });
  });

  // Student One-Time Registration & Onboarding API (Backward Compatible)
  app.post('/api/users/register', (req: Request, res: Response) => {
    const { id, uid, name, age, birthDate, birthYear, grade, track, deviceType } = req.body;

    if (!name || String(name).trim().length === 0) {
      res.status(400).json({ success: false, error: 'الاسم مطلوب لإتمام التسجيل' });
      return;
    }

    let users: any[] = readJsonFile(USERS_FILE, []);
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const studentUid = uid || id || `UID-BIO-${randomSuffix}`;
    const studentId = id || `STU-${randomSuffix}`;
    const parsedAge = age ? (isNaN(Number(age)) ? age : Number(age)) : null;

    const existingIndex = users.findIndex((u) => u.uid === studentUid || u.id === studentId);

    const studentRecord = {
      id: studentId,
      uid: studentUid,
      name: String(name).trim(),
      age: parsedAge,
      birthDate: birthDate || null,
      birthYear: birthYear ? Number(birthYear) : null,
      track: 'school',
      emailOrPhone: parsedAge ? `طالب مسجل (${parsedAge} سنة)` : 'طالب مسجل بالمنصة',
      grade: String(grade || 'g6').trim(),
      role: 'student',
      status: 'active',
      isVip: false,
      deviceType: deviceType || 'android-apk',
      registeredAt: new Date().toISOString().split('T')[0],
      lastActive: 'متصل الآن',
      unlockedLectures: []
    };

    if (existingIndex !== -1) {
      users[existingIndex] = {
        ...users[existingIndex],
        ...studentRecord,
        role: users[existingIndex].role || 'student',
        status: users[existingIndex].status || 'active',
        isVip: users[existingIndex].isVip || false,
        unlockedLectures: users[existingIndex].unlockedLectures || []
      };
    } else {
      users.unshift(studentRecord);
    }

    writeJsonFile(USERS_FILE, users);

    res.status(200).json({
      success: true,
      message: 'تم تسجيل الطالب بنجاح وتثبيت بياناته في قاعدة بيانات المنصة السحابية 🎓',
      user: studentRecord
    });
  });

  // Client Session Ping & Auto Sync
  app.post('/api/users/sync-session', (req: Request, res: Response) => {
    const { id, uid, name, age, grade, track, deviceType } = req.body;
    let users: any[] = readJsonFile(USERS_FILE, []);
    let user = users.find((u) => (uid && u.uid === uid) || (id && u.id === id));

    if (user) {
      user.lastActive = 'متصل الآن';
      if (name && !user.name.startsWith('طالب منصة')) user.name = name;
      if (age) user.age = Number(age);
      if (grade) user.grade = grade;
      if (track) user.track = track;
      writeJsonFile(USERS_FILE, users);
      res.json({ success: true, user });
      return;
    }

    // New visitor session registered automatically
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const newSessionUser = {
      id: id || `STU-${randomSuffix}`,
      uid: uid || `UID-BIO-${randomSuffix}`,
      name: name || `طالب منصة مختبر الأحياء #${randomSuffix}`,
      age: age ? Number(age) : null,
      emailOrPhone: 'حساب زائر / تطبيق',
      grade: grade || 'g6',
      track: track || 'school',
      role: 'student',
      status: 'active',
      isVip: false,
      deviceType: deviceType || 'android-apk',
      registeredAt: new Date().toISOString().split('T')[0],
      lastActive: 'متصل الآن',
      unlockedLectures: []
    };

    users.push(newSessionUser);
    writeJsonFile(USERS_FILE, users);

    res.json({ success: true, user: newSessionUser });
  });

  // ==========================================
  // 3.1 Lecture Codes & VIP Activation API (نظام الأكواد المدفوعة المربوطة بـ UID)
  // ==========================================
  app.get('/api/codes', (req: Request, res: Response) => {
    const codes = readJsonFile<any[]>(LECTURE_CODES_FILE, []);
    res.json({
      success: true,
      codes,
      count: codes.length
    });
  });

  app.post('/api/codes', requireAdmin, (req: Request, res: Response) => {
    const { code, title, targetUid, targetUserName, lectureId, lectureTitle, maxUses, expiresAt } = req.body;

    if (!code) {
      res.status(400).json({ success: false, error: 'رمز الكود مطلوب' });
      return;
    }

    const codes = readJsonFile<any[]>(LECTURE_CODES_FILE, []);
    const cleanCode = String(code).trim().toUpperCase();

    // Check if code exists
    const existingIndex = codes.findIndex((c) => c.code.toUpperCase() === cleanCode);

    const newCodeRecord = {
      code: cleanCode,
      title: title ? String(title).trim() : `كود تفعيل ${lectureTitle || 'المحاضرة'}`,
      targetUid: targetUid ? String(targetUid).trim() : 'ALL',
      targetUserName: targetUserName ? String(targetUserName).trim() : (targetUid === 'ALL' ? 'الجميع' : 'طالب محدد'),
      lectureId: lectureId !== undefined ? lectureId : 'all',
      lectureTitle: lectureTitle ? String(lectureTitle).trim() : 'المحاضرة المحددة',
      maxUses: maxUses ? Number(maxUses) : 1,
      usedCount: 0,
      redeemedBy: [],
      createdAt: new Date().toISOString(),
      expiresAt: expiresAt || null,
      status: 'active'
    };

    if (existingIndex !== -1) {
      codes[existingIndex] = { ...codes[existingIndex], ...newCodeRecord };
    } else {
      codes.unshift(newCodeRecord);
    }

    writeJsonFile(LECTURE_CODES_FILE, codes);

    res.status(201).json({
      success: true,
      message: 'تم توليد وحفظ كود التفعيل بنجاح 🔑',
      code: newCodeRecord
    });
  });

  app.post('/api/codes/redeem', (req: Request, res: Response) => {
    const { code, uid } = req.body;

    if (!code || !uid) {
      res.status(400).json({ success: false, error: 'رمز الكود ومعرّف المستخدم (UID) مطلوبان' });
      return;
    }

    const cleanCode = String(code).trim().toUpperCase();
    const cleanUid = String(uid).trim();

    const codes = readJsonFile<any[]>(LECTURE_CODES_FILE, []);
    const targetCode = codes.find((c) => c.code.toUpperCase() === cleanCode);

    if (!targetCode) {
      res.status(404).json({ success: false, error: 'الكود السري المدخل غير صحيح، تأكد من الأحرف والأرقام.' });
      return;
    }

    if (targetCode.status !== 'active') {
      res.status(400).json({ success: false, error: 'تم إيقاف أو إلغاء تفعيل هذا الكود من قبل الإدارة.' });
      return;
    }

    // UID Link verification: verify targetUid matches or is ALL
    const targetUid = String(targetCode.targetUid || 'ALL').trim().toUpperCase();
    const userUid = cleanUid.toUpperCase();

    if (targetUid !== 'ALL' && targetUid !== userUid) {
      res.status(403).json({
        success: false,
        error: `هذا الكود مخصص لمعرّف مستخدم آخر (${targetCode.targetUid}) ولا يطابق معرّف حسابك (${cleanUid}). يرجى مراجعة الأستاذ.`
      });
      return;
    }

    // Expiry check
    if (targetCode.expiresAt && new Date(targetCode.expiresAt).getTime() < Date.now()) {
      res.status(400).json({ success: false, error: 'انتهت صلاحية هذا الكود.' });
      return;
    }

    // Max uses check
    if (targetCode.maxUses && targetCode.usedCount >= targetCode.maxUses) {
      // Check if this user already used it (idempotent success)
      if (Array.isArray(targetCode.redeemedBy) && targetCode.redeemedBy.includes(cleanUid)) {
        res.json({
          success: true,
          message: 'تم تفعيل هذا الكود مسبقاً لحسابك! يمكنك المشاهدة الآن.',
          lectureId: targetCode.lectureId
        });
        return;
      }
      res.status(400).json({ success: false, error: 'تم استهلاك الحد الأقصى لاستخدام هذا الكود.' });
      return;
    }

    // Record usage
    targetCode.usedCount = (targetCode.usedCount || 0) + 1;
    if (!Array.isArray(targetCode.redeemedBy)) targetCode.redeemedBy = [];
    if (!targetCode.redeemedBy.includes(cleanUid)) {
      targetCode.redeemedBy.push(cleanUid);
    }
    writeJsonFile(LECTURE_CODES_FILE, codes);

    // Update user record in users.json
    let users = readJsonFile<any[]>(USERS_FILE, []);
    const userIdx = users.findIndex((u) => u.uid === cleanUid || u.id === cleanUid);

    if (userIdx !== -1) {
      const u = users[userIdx];
      if (!Array.isArray(u.unlockedLectures)) u.unlockedLectures = [];

      if (targetCode.lectureId === 'all') {
        u.isVip = true;
        u.role = 'vip';
      } else {
        const numId = Number(targetCode.lectureId);
        const resolvedId = isNaN(numId) ? targetCode.lectureId : numId;
        if (!u.unlockedLectures.includes(resolvedId)) {
          u.unlockedLectures.push(resolvedId);
        }
      }
      users[userIdx] = u;
      writeJsonFile(USERS_FILE, users);
    }

    res.json({
      success: true,
      message: `تم تفعيل «${targetCode.title || targetCode.lectureTitle}» بنجاح لحسابك! 🎉`,
      lectureId: targetCode.lectureId,
      code: targetCode.code
    });
  });

  app.delete('/api/codes/:code', requireAdmin, (req: Request, res: Response) => {
    const { code } = req.params;
    let codes = readJsonFile<any[]>(LECTURE_CODES_FILE, []);
    const cleanCode = String(code).trim().toUpperCase();
    const initialLen = codes.length;
    codes = codes.filter((c) => c.code.toUpperCase() !== cleanCode);

    if (codes.length === initialLen) {
      res.status(404).json({ success: false, error: 'الكود غير موجود' });
      return;
    }

    writeJsonFile(LECTURE_CODES_FILE, codes);
    res.json({
      success: true,
      message: 'تم حذف الكود وإلغاء تفعيله بنجاح'
    });
  });

  // ==========================================
  // 3.2 In-App Live Update System (التحديث التلقائي للإضافات من داخل التطبيق)
  // ==========================================
  app.get('/api/app-update', (req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');

    const defaultUpdate = {
      version: '2.6.0',
      title: 'تحديث المنصة الأكاديمي الشامل v2.6.0 (المصادقة السحابية ومركز التحكم وإصلاح التحديثات)',
      releaseNotes: [
        'نظام المصادقة الرسمي المتكامل (البريد الإلكتروني + تسجيل الدخول بحساب Google)',
        'مركز إدارة وتحكم سحابي مركزي (Cloud Management Center) متصل مباشرة بـ Firebase وStorage',
        'نظام موحد لتشغيل الفيديوهات الخارجية ومعالجة الروابط لجميع المزودين',
        'تحديث جذري لآلية التخزين المؤقت وحل مشكلة عدم ظهور التعديلات في النسخة المثبتة',
        'تحديث Service Worker التلقائي وإلغاء التخزين القديم لملفات APK',
        'دعم كامل وسلس لجميع إصدارات أندرويد (Android 7 حتى Android 16)'
      ],
      releaseDate: new Date().toISOString().split('T')[0],
      forceUpdate: false,
      apkUrl: '/biolab.apk',
      minSupportedVersion: '2.0.0'
    };

    const updateInfo = readJsonFile<any>(APP_UPDATE_FILE, defaultUpdate);
    res.json({
      success: true,
      update: updateInfo
    });
  });

  app.post('/api/app-update', requireAdmin, (req: Request, res: Response) => {
    const { version, title, releaseNotes, forceUpdate, apkUrl, minSupportedVersion } = req.body;

    if (!version || !title) {
      res.status(400).json({ success: false, error: 'رقم الإصدار وعنوان التحديث مطلوبان' });
      return;
    }

    const currentUpdate = readJsonFile<any>(APP_UPDATE_FILE, {});
    const updated = {
      ...currentUpdate,
      version: String(version).trim(),
      title: String(title).trim(),
      releaseNotes: Array.isArray(releaseNotes) ? releaseNotes : (releaseNotes ? String(releaseNotes).split('\n').filter(Boolean) : []),
      releaseDate: new Date().toISOString().split('T')[0],
      forceUpdate: Boolean(forceUpdate),
      apkUrl: apkUrl ? String(apkUrl).trim() : (currentUpdate.apkUrl || '/biolab.apk'),
      minSupportedVersion: minSupportedVersion || currentUpdate.minSupportedVersion || '2.0.0'
    };

    writeJsonFile(APP_UPDATE_FILE, updated);

    res.json({
      success: true,
      message: 'تم نشر معلومات التحديث الجديد بنجاح لجميع المستخدمين 🚀',
      update: updated
    });
  });

  // Teacher Broadcast Announcements API
  app.get('/api/announcement', (req: Request, res: Response) => {
    const settings = readJsonFile<any>(SETTINGS_FILE, {});
    res.json({
      success: true,
      announcement: settings.broadcastAnnouncement || null
    });
  });

  app.post('/api/announcement', (req: Request, res: Response) => {
    const { text } = req.body;
    let settings = readJsonFile<any>(SETTINGS_FILE, {});
    
    if (!text || String(text).trim().length === 0) {
      settings.broadcastAnnouncement = null;
    } else {
      settings.broadcastAnnouncement = {
        text: String(text).trim(),
        createdAt: new Date().toISOString()
      };
    }
    
    writeJsonFile(SETTINGS_FILE, settings);
    res.json({
      success: true,
      message: 'تم نشر وبث الإشعار لجميع الطلاب بنجاح',
      announcement: settings.broadcastAnnouncement
    });
  });

  app.delete('/api/announcement', (req: Request, res: Response) => {
    let settings = readJsonFile<any>(SETTINGS_FILE, {});
    settings.broadcastAnnouncement = null;
    writeJsonFile(SETTINGS_FILE, settings);
    res.json({
      success: true,
      message: 'تم إيقاف وحذف الإشعار العام'
    });
  });

  // ==========================================
  // 4. Platform Appearance & Theme Settings API
  // ==========================================
  app.get('/api/settings', (req: Request, res: Response) => {
    const defaultSettings = {
      activeThemeId: 'royal',
      transitionStyle: 'cinematic',
      soundEnabled: true,
      soundVolume: 0.65,
      soundPreset: 'theme',
      updatedAt: new Date().toISOString()
    };
    const settings = readJsonFile(SETTINGS_FILE, defaultSettings);
    res.json({
      success: true,
      settings
    });
  });

  app.put('/api/settings', (req: Request, res: Response) => {
    const currentSettings = readJsonFile(SETTINGS_FILE, {
      activeThemeId: 'royal',
      transitionStyle: 'cinematic',
      soundEnabled: true,
      soundVolume: 0.65,
      soundPreset: 'theme'
    });

    const updatedSettings = {
      ...currentSettings,
      ...req.body,
      updatedAt: new Date().toISOString()
    };

    writeJsonFile(SETTINGS_FILE, updatedSettings);

    res.json({
      success: true,
      message: 'تم تحديث مظهر المنصة وإعدادات الانتقالات والصوت بنجاح لجميع المستخدمين',
      settings: updatedSettings
    });
  });

  app.post('/api/settings', (req: Request, res: Response) => {
    const currentSettings = readJsonFile(SETTINGS_FILE, {
      activeThemeId: 'royal',
      transitionStyle: 'cinematic',
      soundEnabled: true,
      soundVolume: 0.65,
      soundPreset: 'theme'
    });

    const updatedSettings = {
      ...currentSettings,
      ...req.body,
      updatedAt: new Date().toISOString()
    };

    writeJsonFile(SETTINGS_FILE, updatedSettings);

    res.json({
      success: true,
      message: 'تم حفظ إعدادات الواجهة والانتقالات بنجاح',
      settings: updatedSettings
    });
  });

  // ==========================================
  // 5. Institute Students API (طلاب المعهد - درجات وواجبات وإدارة المراحل)
  // ==========================================

  // Audit helper
  const addAuditLog = (action: string, targetTitle: string, targetType: 'grade' | 'homework' | 'stage' | string) => {
    try {
      const logs: any[] = readJsonFile(INSTITUTE_AUDIT_FILE, []);
      const newEntry = {
        id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        action,
        targetTitle,
        targetType,
        adminName: 'الأستاذ وسام سهيل العامري',
        timestamp: new Date().toISOString()
      };
      logs.unshift(newEntry);
      // Keep last 100 logs
      writeJsonFile(INSTITUTE_AUDIT_FILE, logs.slice(0, 100));
    } catch (e) {
      console.error('Error logging audit:', e);
    }
  };

  // Get all 6 stages config
  app.get('/api/institute/stages', (req: Request, res: Response) => {
    const stages = readJsonFile(INSTITUTE_STAGES_FILE, []);
    res.json({
      success: true,
      stages
    });
  });

  // Update a stage (e.g. toggle active/inactive)
  app.put('/api/institute/stages/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const updates = req.body;
    let stages: any[] = readJsonFile(INSTITUTE_STAGES_FILE, []);
    const index = stages.findIndex((s) => s.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'المرحلة الدراسية غير موجودة' });
      return;
    }

    stages[index] = { ...stages[index], ...updates };
    writeJsonFile(INSTITUTE_STAGES_FILE, stages);

    addAuditLog(
      updates.isActive !== undefined ? (updates.isActive ? 'تفعيل المرحلة' : 'إخفاء المرحلة') : 'تعديل بيانات المرحلة',
      stages[index].name,
      'stage'
    );

    res.json({
      success: true,
      message: 'تم تحديث حالة المرحلة الدراسية بنجاح',
      stage: stages[index]
    });
  });

  // Get institute posts (grades and homework)
  app.get('/api/institute/posts', (req: Request, res: Response) => {
    const { stageId, type, admin, q } = req.query;
    let posts: any[] = readJsonFile(INSTITUTE_POSTS_FILE, []);

    // Filter by published status if not admin
    const isAdmin = admin === 'true';
    if (!isAdmin) {
      posts = posts.filter((p) => p.status === 'published');
    }

    // Filter by stage
    if (stageId && stageId !== 'all') {
      posts = posts.filter((p) => p.stageId === stageId);
    }

    // Filter by type (grade or homework)
    if (type && type !== 'all') {
      posts = posts.filter((p) => p.type === type);
    }

    // Keyword search
    if (q && typeof q === 'string' && q.trim()) {
      const keyword = q.trim().toLowerCase();
      posts = posts.filter((p) => 
        (p.title && p.title.toLowerCase().includes(keyword)) ||
        (p.subject && p.subject.toLowerCase().includes(keyword)) ||
        (p.details && p.details.toLowerCase().includes(keyword)) ||
        (p.notes && p.notes.toLowerCase().includes(keyword))
      );
    }

    res.json({
      success: true,
      posts,
      totalCount: posts.length
    });
  });

  // Create new institute post (grade or homework)
  app.post('/api/institute/posts', (req: Request, res: Response) => {
    const {
      type,
      stageId,
      subject,
      title,
      examType,
      date,
      publishDate,
      status,
      notes,
      attachmentUrl,
      attachmentType,
      attachmentName,
      displayMode,
      maxScore,
      minPassingScore,
      averageScore,
      highestScore,
      successRate,
      studentCount,
      records,
      details,
      dueDate
    } = req.body;

    if (!title || !stageId || !type) {
      res.status(400).json({ success: false, error: 'العنوان والمرحلة ونوع المنشور مطلوبة' });
      return;
    }

    const posts: any[] = readJsonFile(INSTITUTE_POSTS_FILE, []);
    const newId = `post-${stageId}-${type}-${Date.now()}`;
    const nowIso = new Date().toISOString();

    const newPost = {
      id: newId,
      type: type === 'grade' ? 'grade' : 'homework',
      stageId: String(stageId),
      subject: String(subject || 'علم الأحياء').trim(),
      title: String(title).trim(),
      examType: examType ? String(examType).trim() : (type === 'grade' ? 'امتحان شهري' : undefined),
      date: date || nowIso.split('T')[0],
      publishDate: publishDate || nowIso.split('T')[0],
      status: status || 'published',
      notes: notes ? String(notes).trim() : '',
      attachmentUrl: attachmentUrl ? String(attachmentUrl).trim() : undefined,
      attachmentType: attachmentType || (attachmentUrl?.endsWith('.pdf') ? 'pdf' : 'image'),
      attachmentName: attachmentName ? String(attachmentName).trim() : undefined,
      createdAt: nowIso,
      updatedAt: nowIso,
      ...(type === 'grade' ? {
        displayMode: displayMode || 'table',
        maxScore: maxScore ? Number(maxScore) : 100,
        minPassingScore: minPassingScore ? Number(minPassingScore) : 50,
        averageScore: averageScore ? Number(averageScore) : undefined,
        highestScore: highestScore ? Number(highestScore) : undefined,
        successRate: successRate ? Number(successRate) : undefined,
        studentCount: studentCount ? Number(studentCount) : (Array.isArray(records) ? records.length : undefined),
        records: Array.isArray(records) ? records : []
      } : {
        details: String(details || '').trim(),
        dueDate: dueDate || undefined
      })
    };

    posts.unshift(newPost);
    writeJsonFile(INSTITUTE_POSTS_FILE, posts);

    addAuditLog(
      newPost.type === 'grade' ? 'نشر نتائج اختبار جديد' : 'نشر واجب مدرسي جديد',
      newPost.title,
      newPost.type
    );

    res.status(201).json({
      success: true,
      message: newPost.type === 'grade' ? 'تم نشر نتائج الاختبار بنجاح' : 'تم نشر الواجب المدرسي بنجاح',
      post: newPost
    });
  });

  // Update existing institute post
  app.put('/api/institute/posts/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const updates = req.body;
    let posts: any[] = readJsonFile(INSTITUTE_POSTS_FILE, []);
    const index = posts.findIndex((p) => p.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'المنشور غير موجود' });
      return;
    }

    const previousPost = posts[index];
    posts[index] = {
      ...previousPost,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    writeJsonFile(INSTITUTE_POSTS_FILE, posts);

    addAuditLog(
      `تعديل منشور (${posts[index].status})`,
      posts[index].title,
      posts[index].type
    );

    res.json({
      success: true,
      message: 'تم تحديث المنشور بنجاح',
      post: posts[index]
    });
  });

  // Delete institute post
  app.delete('/api/institute/posts/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    let posts: any[] = readJsonFile(INSTITUTE_POSTS_FILE, []);
    const target = posts.find((p) => p.id === id);

    if (!target) {
      res.status(404).json({ success: false, error: 'المنشور غير موجود' });
      return;
    }

    posts = posts.filter((p) => p.id !== id);
    writeJsonFile(INSTITUTE_POSTS_FILE, posts);

    addAuditLog(
      'حذف منشور',
      target.title,
      target.type
    );

    res.json({
      success: true,
      message: 'تم حذف المنشور نهائياً من قاعدة بيانات المنصة',
      id
    });
  });

  // Secure score inquiry for student privacy (الاستعلام الآمن عن النتيجة)
  app.post('/api/institute/check-score', (req: Request, res: Response) => {
    const { studentCode, stageId, postId } = req.body;

    if (!studentCode || String(studentCode).trim().length === 0) {
      res.status(400).json({ success: false, error: 'يرجى إدخال الكود الامتحاني الخاص بالطالب' });
      return;
    }

    const code = String(studentCode).trim().toUpperCase();
    const posts: any[] = readJsonFile(INSTITUTE_POSTS_FILE, []);
    
    // Filter published grade posts
    let gradePosts = posts.filter(p => p.type === 'grade' && p.status === 'published');
    if (stageId) gradePosts = gradePosts.filter(p => p.stageId === stageId);
    if (postId) gradePosts = gradePosts.filter(p => p.id === postId);

    const matches: any[] = [];
    for (const post of gradePosts) {
      if (Array.isArray(post.records)) {
        const found = post.records.find((r: any) => 
          r.studentCode && String(r.studentCode).trim().toUpperCase() === code
        );
        if (found) {
          matches.push({
            postTitle: post.title,
            subject: post.subject,
            examDate: post.date,
            publishDate: post.publishDate,
            maxScore: post.maxScore || found.maxScore || 100,
            score: found.score,
            rating: found.rating || (found.score >= 90 ? 'ممتاز' : found.score >= 80 ? 'جيد جداً' : found.score >= 70 ? 'جيد' : found.score >= 50 ? 'متوسط' : 'يحتاج لمتابعة'),
            note: found.note || 'أداء طيب في الامتحان',
            passed: found.score >= (post.minPassingScore || 50),
            studentCode: found.studentCode
          });
        }
      }
    }

    if (matches.length === 0) {
      res.json({
        success: false,
        message: 'لم يتم العثور على درجات مسجلة لهذا الكود في هذه المرحلة. تأكد من إدخال الكود الصحيح المسلم لك من الإدارة.'
      });
      return;
    }

    res.json({
      success: true,
      message: 'تم العثور على النتيجة بنجاح',
      results: matches
    });
  });

  // Get admin audit logs
  app.get('/api/institute/audit', (req: Request, res: Response) => {
    const logs = readJsonFile(INSTITUTE_AUDIT_FILE, []);
    res.json({
      success: true,
      logs
    });
  });

  // ==========================================
  // 6. Direct File & Video Upload API (رفع ملفات PDF والفيديوهات مباشرة من الجهاز)
  // ==========================================
  app.post('/api/upload/file', (req: Request, res: Response) => {
    try {
      const { fileName, fileData, folder = 'books' } = req.body;

      if (!fileName || !fileData) {
        res.status(400).json({ success: false, error: 'اسم الملف وبيانات الملف مطلوبة للرفع' });
        return;
      }

      // Safe folder selection
      const targetFolder = ['books', 'videos', 'covers'].includes(folder) ? folder : 'books';
      const targetDir = path.join(UPLOADS_DIR, targetFolder);
      if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
      }

      // Sanitize filename & add timestamp prefix to avoid overwrite collisions
      const ext = path.extname(fileName).toLowerCase();
      const baseName = path.basename(fileName, ext).replace(/[^a-zA-Z0-9_\u0600-\u06FF-]/g, '_');
      const uniqueName = `${Date.now()}_${baseName}${ext}`;
      const filePath = path.join(targetDir, uniqueName);

      // Decode base64 (handling optional data url prefix e.g. "data:application/pdf;base64,...")
      const base64Content = fileData.includes(';base64,') ? fileData.split(';base64,')[1] : fileData;
      const buffer = Buffer.from(base64Content, 'base64');

      fs.writeFileSync(filePath, buffer);

      const publicUrl = `/uploads/${targetFolder}/${uniqueName}`;
      const sizeMb = (buffer.length / (1024 * 1024)).toFixed(2);

      res.status(201).json({
        success: true,
        message: 'تم رفع الملف وحفظه في مساحة التخزين بنجاح 📁',
        url: publicUrl,
        fileName: uniqueName,
        originalName: fileName,
        fileSize: `${sizeMb} MB`,
        sizeBytes: buffer.length
      });
    } catch (err: any) {
      console.error('File upload error:', err);
      res.status(500).json({ success: false, error: 'حدث خطأ أثناء حفظ الملف على السيرفر' });
    }
  });

  // Direct Video Upload Endpoint (Protected by requireAdmin)
  app.post('/api/upload/video', requireAdmin, (req: Request, res: Response) => {
    try {
      const { fileName, fileData } = req.body;

      if (!fileName || !fileData) {
        res.status(400).json({ success: false, error: 'اسم مقطع الفيديو وبياناته مطلوبة' });
        return;
      }

      const targetDir = path.join(UPLOADS_DIR, 'videos');
      if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
      }

      const ext = path.extname(fileName).toLowerCase() || '.mp4';
      const baseName = path.basename(fileName, ext).replace(/[^a-zA-Z0-9_\u0600-\u06FF-]/g, '_');
      const uniqueName = `vid_${Date.now()}_${baseName}${ext}`;
      const filePath = path.join(targetDir, uniqueName);

      const base64Content = fileData.includes(';base64,') ? fileData.split(';base64,')[1] : fileData;
      const buffer = Buffer.from(base64Content, 'base64');

      if (buffer.length < 50) {
        res.status(400).json({ success: false, error: 'ملف الفيديو تالف أو فارغ، يرجى اختيار ملف صالح' });
        return;
      }

      fs.writeFileSync(filePath, buffer);

      // Verify file was written properly and exists on disk
      if (!fs.existsSync(filePath) || fs.statSync(filePath).size === 0) {
        res.status(500).json({ success: false, error: 'تعذر التحقق من حفظ ملف الفيديو في مساحة التخزين المركزية' });
        return;
      }

      const publicUrl = `/uploads/videos/${uniqueName}`;
      const sizeMb = (buffer.length / (1024 * 1024)).toFixed(2);

      res.status(201).json({
        success: true,
        message: 'تم رفع الفيديو وحفظه في السيرفر ومساحة التخزين المركزية بنجاح 🎥',
        url: publicUrl,
        fileName: uniqueName,
        fileSize: `${sizeMb} MB`,
        verified: true
      });
    } catch (err: any) {
      console.error('Video upload error:', err);
      res.status(500).json({ success: false, error: 'حدث خطأ أثناء حفظ الفيديو على السيرفر' });
    }
  });

  // ==========================================
  // 10. AI Assistant & RAG Knowledge Engine API (المساعد الذكي لمختبر الأحياء للأستاذ وسام سهيل العامري)
  // ==========================================

  // 10.1 Student & Public AI Chat Endpoint
  app.post('/api/ai/chat', async (req: Request, res: Response) => {
    const startTime = Date.now();
    const { query, studentProfile, currentLectureContext } = req.body;

    if (!query || typeof query !== 'string' || !query.trim()) {
      res.status(400).json({ success: false, error: 'يرجى كتابة السؤال المطلوب' });
      return;
    }

    const trimmedQuery = query.trim();

    // Read all configuration & real database sources
    const aiConfig = readJsonFile<AIConfig>(AI_CONFIG_FILE, DEFAULT_AI_CONFIG);

    const pricingConfig = readJsonFile<AIPricingConfig>(AI_PRICING_FILE, {
      individualLectureDefaultPrice: 5000,
      currency: 'دينار عراقي',
      packages: [],
      activationSteps: [],
      activeOffers: [],
      paymentFaq: []
    });

    const contactConfig = readJsonFile<AIContactConfig>(AI_CONTACT_FILE, {
      entityName: 'الأستاذ وسام سهيل العامري',
      whatsappNumber: '07704597073',
      whatsappLink: 'https://wa.me/9647704597073',
      telegramChannel: 'https://t.me/wissam_biology',
      instituteAddress: 'بغداد — معهد أنوار السلام الأهلي',
      guidingMessage: 'تواصل مع الأستاذ للاستفسار عن الدورات وكود VIP',
      requiredInfoBeforeContact: 'الاسم والمرحلة',
      suggestContactWhen: []
    });

    const fewShotExamples = readJsonFile<AIFewShotExample[]>(AI_EXAMPLES_FILE, []);
    const rules = readJsonFile<PreventionRule[]>(AI_RULES_FILE, []);
    const learnedResponses = readJsonFile<LearnedResponse[]>(AI_RESPONSES_FILE, []);
    const knowledgeItems = readJsonFile<KnowledgeItem[]>(AI_KNOWLEDGE_FILE, []);
    const indexedChunks = readJsonFile<IndexedChunk[]>(AI_CHUNKS_FILE, []);
    const audits = readJsonFile<ChatAuditRecord[]>(AI_AUDIT_FILE, []);
    const lectures = readJsonFile<any[]>(LECTURES_FILE, []);

    // 0) Check if AI Assistant is disabled by Admin
    if (!aiConfig.isEnabled) {
      res.json({
        success: true,
        answer: 'عزيزي الطالب، المساعد الذكي في فترة صيانة وتحديث حالياً من قبل إدارة المنصة وسيعود للعمل قريباً جداً! يمكنك في هذه الأثناء مراجعة الأقسام والمحاضرات بشكل مباشر. 🔬',
        isRuleBlocked: true,
        sources: [],
        actionButtons: [
          {
            label: 'تواصل مع الأستاذ عبر واتساب',
            action: 'contact_whatsapp',
            url: contactConfig.whatsappLink
          }
        ],
        diagnostic: {
          executionTimeMs: Date.now() - startTime,
          modelUsed: 'assistant_disabled'
        }
      });
      return;
    }

    // 1) Problem Diagnosis (فحص ما إذا كان السؤال يتعلق بعطل أو مشكلة تقنية)
    const problemDiag = diagnoseStudentProblem(trimmedQuery);

    // 2) Find relevant live lectures from database to extract real prices and lock status
    let matchedLectures = findRelevantLectures(trimmedQuery, lectures);
    if (currentLectureContext && currentLectureContext.id && !matchedLectures.some((l) => l.id === currentLectureContext.id)) {
      matchedLectures.unshift(currentLectureContext);
    }

    // 3) Check Prevention / Decision Rules (قواعد الإدارة الإلزامية)
    const matchedRule = matchPreventionRule(trimmedQuery, rules);
    if (matchedRule) {
      const ruleResponse = matchedRule.requiredResponse || matchedRule.customResponse;
      const auditRecord: ChatAuditRecord = {
        id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        timestamp: new Date().toISOString(),
        studentUid: studentProfile?.uid,
        studentName: studentProfile?.name,
        grade: studentProfile?.grade,
        query: trimmedQuery,
        response: ruleResponse,
        ruleTriggered: matchedRule.name,
        sourcesCount: 0,
        isCorrected: false
      };
      audits.unshift(auditRecord);
      writeJsonFile(AI_AUDIT_FILE, audits.slice(0, 200));

      const ruleActionButtons: any[] = [];
      if (contactConfig?.whatsappLink) {
        ruleActionButtons.push({
          label: 'تواصل عبر واتساب الأستاذ',
          action: 'contact_whatsapp',
          url: contactConfig.whatsappLink
        });
      }
      if (problemDiag.isProblem) {
        ruleActionButtons.push({
          label: 'تقديم بلاغ دعم فني',
          action: 'create_ticket'
        });
      }

      res.json({
        success: true,
        answer: ruleResponse,
        isRuleBlocked: true,
        ruleTriggered: matchedRule.name,
        sources: [],
        actionButtons: ruleActionButtons,
        diagnostic: {
          executionTimeMs: Date.now() - startTime,
          matchedRuleId: matchedRule.id,
          chunksRetrieved: 0,
          modelUsed: 'rule_engine',
          isLearnedResponse: false,
          problemDiagnosed: problemDiag.isProblem ? problemDiag.label : undefined
        }
      });
      return;
    }

    // 4) Check Learned Responses (الردود المحددة والتعليمات المعتمدة)
    const matchedLearned = matchLearnedResponse(trimmedQuery, learnedResponses);
    if (matchedLearned) {
      const citations = matchedLearned.citations || [];
      const auditRecord: ChatAuditRecord = {
        id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        timestamp: new Date().toISOString(),
        studentUid: studentProfile?.uid,
        studentName: studentProfile?.name,
        grade: studentProfile?.grade,
        query: trimmedQuery,
        response: matchedLearned.responseText,
        ruleTriggered: null,
        sourcesCount: citations.length,
        isCorrected: false
      };
      audits.unshift(auditRecord);
      writeJsonFile(AI_AUDIT_FILE, audits.slice(0, 200));

      const learnedActionButtons: any[] = [];
      if (matchedLectures.length > 0) {
        learnedActionButtons.push({
          label: `فتح المحاضرة: ${matchedLectures[0].title}`,
          action: 'open_lecture',
          targetId: String(matchedLectures[0].id)
        });
      }
      if (contactConfig?.whatsappLink) {
        learnedActionButtons.push({
          label: 'تواصل عبر واتساب الأستاذ',
          action: 'contact_whatsapp',
          url: contactConfig.whatsappLink
        });
      }

      res.json({
        success: true,
        answer: matchedLearned.responseText,
        isRuleBlocked: false,
        isLearnedResponse: true,
        sources: citations,
        actionButtons: learnedActionButtons,
        diagnostic: {
          executionTimeMs: Date.now() - startTime,
          chunksRetrieved: 0,
          modelUsed: 'learned_response_cache',
          isLearnedResponse: true,
          problemDiagnosed: problemDiag.isProblem ? problemDiag.label : undefined
        }
      });
      return;
    }

    // 5) RAG Retrieval: Combine Indexed Chunks and Published Knowledge Items
    const publishedKnowledgeChunks: IndexedChunk[] = knowledgeItems
      .filter((k) => k.status === 'published')
      .map((k) => ({
        id: `k-${k.id}`,
        sourceType: 'knowledge_item',
        title: k.title,
        grade: k.grade,
        track: 'school',
        chapterTitle: k.chapter,
        pageNumber: k.sourcePage,
        bookId: k.bookId,
        content: k.content,
        keywords: k.keywords || []
      }));

    const allChunks = [...indexedChunks, ...publishedKnowledgeChunks];

    const relevantChunks = retrieveRelevantChunks(trimmedQuery, allChunks, {
      studentGrade: studentProfile?.grade,
      studentTrack: studentProfile?.track,
      isVip: Boolean(studentProfile?.isVip),
      maxResults: 4,
      minScoreThreshold: 6
    });

    // Build verified citations for interactive cards
    const sources: SourceCitation[] = relevantChunks.map((c) => {
      let type: SourceCitation['type'] = 'book';
      if (c.sourceType === 'lecture') type = 'lecture';
      else if (c.sourceType === 'advanced_book') type = 'advanced_book';
      else if (c.sourceType === 'knowledge_item') type = 'knowledge';
      else if (c.sourceType === 'ministerial') type = 'ministerial';

      return {
        id: c.id,
        title: c.title,
        grade: c.grade,
        type,
        chapterTitle: c.chapterTitle,
        pageNumber: c.pageNumber,
        bookId: c.bookId,
        pdfUrl: c.pdfUrl,
        lectureId: c.lectureId,
        badge: c.chapterTitle || (c.grade ? `الصف ${c.grade}` : 'منهج الأحياء'),
        excerpt: c.content.slice(0, 180) + '...'
      };
    });

    // If lecture matched, add lecture citation
    if (matchedLectures.length > 0 && !sources.some((s) => s.lectureId === matchedLectures[0].id)) {
      sources.unshift({
        id: `lec-${matchedLectures[0].id}`,
        title: matchedLectures[0].title,
        grade: matchedLectures[0].grade,
        type: 'lecture',
        lectureId: matchedLectures[0].id,
        badge: matchedLectures[0].isVipOnly ? 'محاضرة VIP مدفوعة' : 'محاضرة مجانية',
        excerpt: matchedLectures[0].description || 'محاضرة مرئية في منصة مختبر الأحياء'
      });
    }

    let generatedAnswer = '';
    let modelUsed = aiConfig.model || 'gemini-3.1-flash-lite';
    let isRealGemini = false;
    let geminiLatency = 0;

    // Check scope boundary: if student query is clearly outside biology or asking for forbidden topics
    if (aiConfig.strictBiologyScope) {
      const normQ = normalizeArabicText(trimmedQuery);
      const prohibitedKeywords = [
        'كيمياء', 'فيزياء', 'رياضيات', 'تاريخ', 'جغرافيا', 'انجليزي', 'لغة عربية',
        'سياسة', 'حكومة', 'انتخابات', 'رئيس', 'وزير',
        'برمجة', 'كود بايثون', 'جافاسكريبت', 'اخترق', 'تهكير',
        'كود مجاني', 'كود بلاش', 'انطيني كود مجاني', 'اريد كود مجانا'
      ];
      const isExplicitlyProhibited = prohibitedKeywords.some((kw) => normQ.includes(kw));
      if (isExplicitlyProhibited) {
        generatedAnswer = aiConfig.rejectionResponse || 'عذراً يا بطل! أنا المساعد الذكي المخصص حصرياً لمنصة مختبر الأحياء للأستاذ وسام سهيل العامري. لا يمكنني الإجابة عن مواضيع خارج تخصص علم الأحياء أو خارج المنصة. يسعدني جداً مساعدتك في أي سؤال يخص مادة الأحياء، شروحات الدروس، أو اشتراكات المنصة! 🔬🧬';
        modelUsed = 'scope-boundary-guardrail';
      }
    }

    if (!generatedAnswer) {
      const systemPrompt = buildComprehensiveBiologySystemPrompt({
        studentProfile,
        adminInstructions: aiConfig.customSystemInstructions,
        pricingConfig,
        contactConfig,
        relevantLectures: matchedLectures,
        fewShotExamples,
        contextChunks: relevantChunks,
        allowedTopics: aiConfig.allowedTopics,
        prohibitedTopics: aiConfig.prohibitedTopics,
        rejectionResponse: aiConfig.rejectionResponse,
        strictBiologyScope: aiConfig.strictBiologyScope
      });

      const geminiResult = await executeRealGeminiGeneration({
        contents: trimmedQuery,
        systemInstruction: systemPrompt,
        temperature: aiConfig.temperature ?? 0.7,
        requestedModel: aiConfig.model || 'gemini-3.1-flash-lite'
      });

      if (geminiResult.success && geminiResult.text) {
        generatedAnswer = geminiResult.text;
        modelUsed = geminiResult.modelUsed;
        isRealGemini = true;
        geminiLatency = geminiResult.latencyMs;
      }
    }

    // High fidelity grounded fallback if Gemini is offline or rate limited
    if (!generatedAnswer) {
      modelUsed = 'curated-rules-synthesizer';
      const normQ = normalizeArabicText(trimmedQuery);

      if (matchedLectures.length > 0) {
        const lec = matchedLectures[0];
        const isPaid = Boolean(lec.isVipOnly || lec.isPaid);
        if (isPaid) {
          const price = lec.price || pricingConfig.individualLectureDefaultPrice;
          generatedAnswer = `أهلاً بك يا بطل! محاضرة «${lec.title}» هي محاضرة مدفوعة ضمن محتوى الدورات الخاصة للأستاذ وسام سهيل العامري.\n\n` +
            `• السعر المسجل رسمياً: ${price.toLocaleString()} ${pricingConfig.currency}\n` +
            `• طريقة التفعيل: يمكنك الحصول على كود التفعيل السري VIP عبر التواصل المباشر مع الأستاذ وسام عبر الواتساب (${contactConfig.whatsappNumber}) أو مراجعة معهد أنوار السلام الأهلي.\n` +
            `بعد استلام الكود، اضغط على زر القفل في المحاضرة وأدخل الكود لتفتح فوراً على جهازك وتعمل بدون إنترنت!`;
        } else {
          generatedAnswer = `أهلاً بك يا بطل! محاضرة «${lec.title}» هي محاضرة مجانية ومتاحة لجميع الطلبة بدون أي كود تفعيل.\n\n` +
            `يمكنك الضغط على زر «فتح المحاضرة» أدناه لمشاهدتها مباشرة والاستفادة من الشرح! 🔬`;
        }
      } else if (normQ.includes('اشتراك') || normQ.includes('سعر') || normQ.includes('اسعار') || normQ.includes('باقه')) {
        const packagesText = (pricingConfig.packages || [])
          .map((p) => `• باقة ${p.gradeName}: ${p.fullPackagePrice.toLocaleString()} ${pricingConfig.currency} (${p.duration})`)
          .join('\n');
        generatedAnswer = `أهلاً بك يا بطل! إليك خطة الأسعار والاشتراكات المعتمدة في منصة مختبر الأحياء للأستاذ وسام سهيل العامري:\n\n` +
          `${packagesText}\n\n` +
          `سعر المحاضرة الفردية الافتراضي: ${pricingConfig.individualLectureDefaultPrice.toLocaleString()} ${pricingConfig.currency}\n\n` +
          `طريقة الاشتراك:\n1. تواصل مع واتساب الأستاذ الرسمي: ${contactConfig.whatsappNumber}\n2. الدفع عبر زين كاش أو في معهد أنوار السلام\n3. استلام كود التفعيل السري VIP وتفعيله داخل المنصة.`;
      } else if (problemDiag.isProblem) {
        generatedAnswer = `أهلاً بك عزيزي الطالب! نأسف لمواجهتك مشكلة في [${problemDiag.label}].\n\n` +
          `خطوات سريعة للحل:\n` +
          `1. اسحب الشاشة من الأعلى إلى الأسفل لتحديث المنصة والتأكد من استقرار الاتصال.\n` +
          `2. تأكد من فتح الرابط داخل تطبيق الأندرويد المثبت أو متصفح Chrome الحديث.\n` +
          `3. إذا استمرت المشكلة، اضغط على زر «إنشاء بلاغ دعم فني» أدناه وسيقوم فريق الدعم الفني بمتابعة حسابك ومساعدتك فوراً! 🛠️`;
      } else if (relevantChunks.length > 0) {
        const primaryChunk = relevantChunks[0];
        const pageMention = primaryChunk.pageNumber ? ` (ص ${primaryChunk.pageNumber})` : '';
        const chapterMention = primaryChunk.chapterTitle ? `ضمن ${primaryChunk.chapterTitle}` : '';

        generatedAnswer = `أهلاً بك يا بطل! بناءً على المنهج المعتمد في منصة مختبر الأحياء للأستاذ وسام سهيل العامري ${chapterMention}${pageMention}:\n\n` +
          `${primaryChunk.content}\n\n` +
          (relevantChunks.length > 1 ? `💡 معلومة إضافية معتمدة: ${relevantChunks[1].content}\n\n` : '') +
          `يمكنك الضغط على بطاقة المصدر أدناه لفتح الكتاب المنهجي مباشرة في الصفحة المحددة أو مشاهدة المحاضرة لشرح أكثر تفصيلاً.`;
      } else {
        generatedAnswer = `أهلاً بك يا بطل في منصة مختبر الأحياء للأستاذ وسام سهيل العامري 🧬.\n\n` +
          `المعلومة التي تبحث عنها غير متوفرة حالياً ضمن نصوص المنهج المفهرسة أو تتطلب متابعة خاصة. يمكنك توجيه السؤال مباشرة للأستاذ وسام عبر الواتساب (${contactConfig.whatsappNumber}) أو مراجعة معهد أنوار السلام الأهلي لمناقشتها بالتفصيل. كما يسعدني الإجابة عن أي موضوع في علم الخلية، الوراثة، التكاثر، أو فصول المنهج الوزاري! 🔬`;
      }
    }

    // Interactive Action Buttons
    const actionButtons: any[] = [];
    if (matchedLectures.length > 0) {
      actionButtons.push({
        label: `فتح المحاضرة: ${matchedLectures[0].title}`,
        action: 'open_lecture',
        targetId: String(matchedLectures[0].id)
      });
    }

    const norm = normalizeArabicText(trimmedQuery);
    if (norm.includes('سعر') || norm.includes('اشتراك') || norm.includes('كود') || norm.includes('واتساب') || norm.includes('معهد') || norm.includes('تواصل')) {
      actionButtons.push({
        label: 'تواصل عبر واتساب الأستاذ',
        action: 'contact_whatsapp',
        url: contactConfig.whatsappLink
      });
    }

    if (problemDiag.isProblem) {
      actionButtons.push({
        label: 'إنشاء بلاغ دعم فني',
        action: 'create_ticket',
        targetId: matchedLectures[0] ? String(matchedLectures[0].id) : undefined
      });
    }

    // Audit Record
    const auditRecord: ChatAuditRecord = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      studentUid: studentProfile?.uid,
      studentName: studentProfile?.name,
      grade: studentProfile?.grade,
      query: trimmedQuery,
      response: generatedAnswer,
      ruleTriggered: null,
      sourcesCount: sources.length,
      isCorrected: false
    };
    audits.unshift(auditRecord);
    writeJsonFile(AI_AUDIT_FILE, audits.slice(0, 200));

    res.json({
      success: true,
      answer: generatedAnswer,
      sources,
      actionButtons,
      isRuleBlocked: false,
      isLearnedResponse: false,
      diagnostic: {
        executionTimeMs: Date.now() - startTime,
        chunksRetrieved: relevantChunks.length,
        modelUsed,
        isRealGemini,
        geminiLatencyMs: geminiLatency,
        lecturesFoundCount: matchedLectures.length,
        problemDiagnosed: problemDiag.isProblem ? problemDiag.label : undefined
      }
    });
  });

  // 10.2 Student Rating Feedback
  app.post('/api/ai/rate-chat', (req: Request, res: Response) => {
    const { auditId, rating } = req.body;
    const audits = readJsonFile<ChatAuditRecord[]>(AI_AUDIT_FILE, []);
    let updated = false;

    const modified = audits.map((a) => {
      if (a.id === auditId) {
        updated = true;
        return { ...a, userRating: rating };
      }
      return a;
    });

    if (updated) {
      writeJsonFile(AI_AUDIT_FILE, modified);
      res.json({ success: true, message: 'شكراً لتقييمك؛ يساعدنا ذلك في تحسين دقة المساعد الذكي' });
    } else {
      res.json({ success: true, message: 'تم استلام التقييم' });
    }
  });

  // ==========================================
  // Admin AI Training Center APIs (مركز تدريب المساعد الذكي)
  // ==========================================

  // 10.3 Overview & Stats
  app.get('/api/admin/ai/overview', requireAdmin, (req: Request, res: Response) => {
    const knowledgeItems = readJsonFile<KnowledgeItem[]>(AI_KNOWLEDGE_FILE, []);
    const learnedResponses = readJsonFile<LearnedResponse[]>(AI_RESPONSES_FILE, []);
    const rules = readJsonFile<PreventionRule[]>(AI_RULES_FILE, []);
    const indexedChunks = readJsonFile<IndexedChunk[]>(AI_CHUNKS_FILE, []);
    const audits = readJsonFile<ChatAuditRecord[]>(AI_AUDIT_FILE, []);

    const helpfulCount = audits.filter((a) => a.userRating === 'helpful').length;
    const unhelpfulCount = audits.filter((a) => a.userRating === 'unhelpful').length;
    const rulesTriggeredCount = audits.filter((a) => a.ruleTriggered).length;

    res.json({
      success: true,
      stats: {
        totalKnowledgeItems: knowledgeItems.length,
        publishedKnowledgeItems: knowledgeItems.filter((k) => k.status === 'published').length,
        totalLearnedResponses: learnedResponses.length,
        activeLearnedResponses: learnedResponses.filter((r) => r.isActive).length,
        totalPreventionRules: rules.length,
        activePreventionRules: rules.filter((r) => r.isActive).length,
        totalIndexedChunks: indexedChunks.length,
        totalAuditedChats: audits.length,
        helpfulCount,
        unhelpfulCount,
        rulesTriggeredCount
      },
      recentAudits: audits.slice(0, 10)
    });
  });

  // 10.4 Knowledge Items CRUD
  app.get('/api/admin/ai/knowledge', requireAdmin, (req: Request, res: Response) => {
    const items = readJsonFile<KnowledgeItem[]>(AI_KNOWLEDGE_FILE, []);
    res.json({ success: true, items });
  });

  app.post('/api/admin/ai/knowledge', requireAdmin, (req: Request, res: Response) => {
    const { title, grade, category, chapter, keywords, content, status, author, sourceBook, sourcePage, bookId } = req.body;
    if (!title || !content) {
      res.status(400).json({ success: false, error: 'العنوان والمحتوى مطلوبان' });
      return;
    }

    const items = readJsonFile<KnowledgeItem[]>(AI_KNOWLEDGE_FILE, []);
    const newItem: KnowledgeItem = {
      id: `know-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      title: title.trim(),
      grade: grade || 'g6',
      category: category || 'general',
      chapter: chapter || 'عام',
      keywords: Array.isArray(keywords) ? keywords : (keywords || '').split(',').map((k: string) => k.trim()).filter(Boolean),
      content: content.trim(),
      status: status === 'draft' ? 'draft' : 'published',
      author: author || 'الأستاذ وسام سهيل العامري',
      sourceBook: sourceBook || 'كتاب الأحياء المنهجي',
      sourcePage: sourcePage ? Number(sourcePage) : undefined,
      bookId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    items.unshift(newItem);
    writeJsonFile(AI_KNOWLEDGE_FILE, items);
    res.json({ success: true, item: newItem, message: 'تمت إضافة المعلومة المعتمدة بنجاح' });
  });

  app.put('/api/admin/ai/knowledge/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const items = readJsonFile<KnowledgeItem[]>(AI_KNOWLEDGE_FILE, []);
    const index = items.findIndex((k) => k.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'المعلومة غير موجودة' });
      return;
    }

    items[index] = {
      ...items[index],
      ...req.body,
      updatedAt: new Date().toISOString()
    };

    writeJsonFile(AI_KNOWLEDGE_FILE, items);
    res.json({ success: true, item: items[index], message: 'تم تحديث المعلومة بنجاح' });
  });

  app.delete('/api/admin/ai/knowledge/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const items = readJsonFile<KnowledgeItem[]>(AI_KNOWLEDGE_FILE, []);
    const filtered = items.filter((k) => k.id !== id);

    if (filtered.length === items.length) {
      res.status(404).json({ success: false, error: 'المعلومة غير موجودة' });
      return;
    }

    writeJsonFile(AI_KNOWLEDGE_FILE, filtered);
    res.json({ success: true, message: 'تم حذف المعلومة بنجاح' });
  });

  // 10.5 Learned Responses CRUD
  app.get('/api/admin/ai/responses', requireAdmin, (req: Request, res: Response) => {
    const responses = readJsonFile<LearnedResponse[]>(AI_RESPONSES_FILE, []);
    res.json({ success: true, responses });
  });

  app.post('/api/admin/ai/responses', requireAdmin, (req: Request, res: Response) => {
    const { intent, title, triggerPhrases, matchType, responseText, category, priority, isActive, citations } = req.body;
    if (!title || !responseText) {
      res.status(400).json({ success: false, error: 'العنوان والرد مطلوبان' });
      return;
    }

    const responses = readJsonFile<LearnedResponse[]>(AI_RESPONSES_FILE, []);
    const newResponse: LearnedResponse = {
      id: `resp-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      intent: intent || 'custom_intent',
      title: title.trim(),
      triggerPhrases: Array.isArray(triggerPhrases) ? triggerPhrases : (triggerPhrases || '').split(',').map((p: string) => p.trim()).filter(Boolean),
      matchType: matchType || 'contains',
      responseText: responseText.trim(),
      category: category || 'custom',
      priority: priority ? Number(priority) : 5,
      isActive: isActive !== false,
      citations: Array.isArray(citations) ? citations : [],
      createdAt: new Date().toISOString()
    };

    responses.unshift(newResponse);
    writeJsonFile(AI_RESPONSES_FILE, responses);
    res.json({ success: true, response: newResponse, message: 'تم حفظ الرد المخصص بنجاح' });
  });

  app.put('/api/admin/ai/responses/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const responses = readJsonFile<LearnedResponse[]>(AI_RESPONSES_FILE, []);
    const index = responses.findIndex((r) => r.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'الرد غير موجود' });
      return;
    }

    responses[index] = {
      ...responses[index],
      ...req.body
    };

    writeJsonFile(AI_RESPONSES_FILE, responses);
    res.json({ success: true, response: responses[index], message: 'تم تحديث الرد بنجاح' });
  });

  app.delete('/api/admin/ai/responses/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const responses = readJsonFile<LearnedResponse[]>(AI_RESPONSES_FILE, []);
    const filtered = responses.filter((r) => r.id !== id);

    if (filtered.length === responses.length) {
      res.status(404).json({ success: false, error: 'الرد غير موجود' });
      return;
    }

    writeJsonFile(AI_RESPONSES_FILE, filtered);
    res.json({ success: true, message: 'تم حذف الرد بنجاح' });
  });

  // 10.6 Prevention Rules CRUD
  app.get('/api/admin/ai/rules', requireAdmin, (req: Request, res: Response) => {
    const rules = readJsonFile<PreventionRule[]>(AI_RULES_FILE, []);
    res.json({ success: true, rules });
  });

  app.post('/api/admin/ai/rules', requireAdmin, (req: Request, res: Response) => {
    const { name, description, triggerKeywords, action, customResponse, isActive } = req.body;
    if (!name || !customResponse) {
      res.status(400).json({ success: false, error: 'اسم القاعدة والرد البديل مطلوبان' });
      return;
    }

    const rules = readJsonFile<PreventionRule[]>(AI_RULES_FILE, []);
    const newRule: PreventionRule = {
      id: `rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: name.trim(),
      description: description || '',
      triggerKeywords: Array.isArray(triggerKeywords) ? triggerKeywords : (triggerKeywords || '').split(',').map((k: string) => k.trim()).filter(Boolean),
      action: action || 'block_and_guide',
      customResponse: customResponse.trim(),
      isActive: isActive !== false,
      createdAt: new Date().toISOString()
    };

    rules.unshift(newRule);
    writeJsonFile(AI_RULES_FILE, rules);
    res.json({ success: true, rule: newRule, message: 'تمت إضافة قاعدة المنع بنجاح' });
  });

  app.put('/api/admin/ai/rules/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const rules = readJsonFile<PreventionRule[]>(AI_RULES_FILE, []);
    const index = rules.findIndex((r) => r.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'القاعدة غير موجودة' });
      return;
    }

    rules[index] = {
      ...rules[index],
      ...req.body
    };

    writeJsonFile(AI_RULES_FILE, rules);
    res.json({ success: true, rule: rules[index], message: 'تم تحديث قاعدة المنع بنجاح' });
  });

  app.delete('/api/admin/ai/rules/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const rules = readJsonFile<PreventionRule[]>(AI_RULES_FILE, []);
    const filtered = rules.filter((r) => r.id !== id);

    if (filtered.length === rules.length) {
      res.status(404).json({ success: false, error: 'القاعدة غير موجودة' });
      return;
    }

    writeJsonFile(AI_RULES_FILE, filtered);
    res.json({ success: true, message: 'تم حذف قاعدة المنع بنجاح' });
  });

  // 10.7 Indexed Chunks & Reindex
  app.get('/api/admin/ai/chunks', requireAdmin, (req: Request, res: Response) => {
    const chunks = readJsonFile<IndexedChunk[]>(AI_CHUNKS_FILE, []);
    res.json({
      success: true,
      total: chunks.length,
      chunksSummary: chunks.map((c) => ({
        id: c.id,
        title: c.title,
        grade: c.grade,
        sourceType: c.sourceType,
        pageNumber: c.pageNumber,
        chapterTitle: c.chapterTitle
      }))
    });
  });

  app.post('/api/admin/ai/reindex', requireAdmin, (req: Request, res: Response) => {
    // Re-verify chunks and ensure all books and chapters are synced
    const chunks = readJsonFile<IndexedChunk[]>(AI_CHUNKS_FILE, []);
    res.json({
      success: true,
      message: `تمت إعادة الفهرسة بنجاح لجميع الكتب والمحاضرات (${chunks.length} مقطع مفهرس)`,
      totalChunks: chunks.length,
      timestamp: new Date().toISOString()
    });
  });

  // 10.8 Chat Audit & Answer Correction Tool (أداة تصحيح الإجابة الإدارية)
  app.get('/api/admin/ai/audit', requireAdmin, (req: Request, res: Response) => {
    const audits = readJsonFile<ChatAuditRecord[]>(AI_AUDIT_FILE, []);
    res.json({ success: true, audits });
  });

  app.post('/api/admin/ai/correct-answer', requireAdmin, (req: Request, res: Response) => {
    const { auditId, correctedText, saveAsLearnedResponse, targetGrade } = req.body;
    if (!auditId || !correctedText) {
      res.status(400).json({ success: false, error: 'معرف المحادثة والتصحيح مطلوبان' });
      return;
    }

    const audits = readJsonFile<ChatAuditRecord[]>(AI_AUDIT_FILE, []);
    const auditIndex = audits.findIndex((a) => a.id === auditId);

    if (auditIndex === -1) {
      res.status(404).json({ success: false, error: 'سجل المحادثة غير موجود' });
      return;
    }

    audits[auditIndex].isCorrected = true;
    audits[auditIndex].adminCorrection = correctedText.trim();
    writeJsonFile(AI_AUDIT_FILE, audits);

    // If requested, also save as an immediate Learned Response so next student gets this exact answer!
    if (saveAsLearnedResponse) {
      const responses = readJsonFile<LearnedResponse[]>(AI_RESPONSES_FILE, []);
      const newLearned: LearnedResponse = {
        id: `resp-corrected-${Date.now()}`,
        intent: 'admin_corrected_qa',
        title: `تصحيح إجابة: ${audits[auditIndex].query.slice(0, 40)}`,
        triggerPhrases: [audits[auditIndex].query.trim()],
        matchType: 'contains',
        responseText: correctedText.trim(),
        category: 'corrected',
        priority: 15,
        isActive: true,
        citations: [
          {
            id: `cit-${Date.now()}`,
            title: 'إجابة معتمدة ومصححة من الأستاذ وسام سهيل العامري',
            type: 'teacher_info',
            badge: 'تصحيح معتمد'
          }
        ],
        createdAt: new Date().toISOString()
      };
      responses.unshift(newLearned);
      writeJsonFile(AI_RESPONSES_FILE, responses);
    }

    res.json({ success: true, message: 'تم حفظ التصحيح الإداري بنجاح!' });
  });

  // 10.9 AI Configuration Management (إعدادات المساعد الذكي والتعليمات الحرة)
  app.get('/api/ai/config', (req: Request, res: Response) => {
    const config = readJsonFile<AIConfig>(AI_CONFIG_FILE, {
      isEnabled: true,
      model: 'gemini-3.8-flash',
      temperature: 0.7,
      welcomeMessage: 'مرحباً بك يا بطل في منصة مختبر الأحياء!',
      customSystemInstructions: '',
      disclaimerText: '',
      updatedAt: new Date().toISOString()
    });
    res.json({ success: true, config });
  });

  app.post('/api/admin/ai/config', requireAdmin, (req: Request, res: Response) => {
    const current = readJsonFile<AIConfig>(AI_CONFIG_FILE, {
      isEnabled: true,
      model: 'gemini-3.8-flash',
      temperature: 0.7,
      welcomeMessage: 'مرحباً بك يا بطل في منصة مختبر الأحياء!',
      customSystemInstructions: '',
      disclaimerText: '',
      updatedAt: new Date().toISOString()
    });

    const updated: AIConfig = {
      ...current,
      ...req.body,
      updatedAt: new Date().toISOString()
    };

    writeJsonFile(AI_CONFIG_FILE, updated);
    res.json({ success: true, config: updated, message: 'تم حفظ وتطبيق إعدادات وتعليمات المساعد الذكي بنجاح!' });
  });

  // 10.10 Pricing & Subscription Management (نظام الأسعار والاشتراكات)
  app.get('/api/ai/pricing', (req: Request, res: Response) => {
    const pricing = readJsonFile<AIPricingConfig>(AI_PRICING_FILE, {
      individualLectureDefaultPrice: 5000,
      currency: 'دينار عراقي',
      packages: [],
      activationSteps: [],
      activeOffers: [],
      paymentFaq: []
    });
    res.json({ success: true, pricing });
  });

  app.post('/api/admin/ai/pricing', requireAdmin, (req: Request, res: Response) => {
    const current = readJsonFile<AIPricingConfig>(AI_PRICING_FILE, {
      individualLectureDefaultPrice: 5000,
      currency: 'دينار عراقي',
      packages: [],
      activationSteps: [],
      activeOffers: [],
      paymentFaq: []
    });

    const updated: AIPricingConfig = {
      ...current,
      ...req.body
    };

    writeJsonFile(AI_PRICING_FILE, updated);
    res.json({ success: true, pricing: updated, message: 'تم تحديث خطة الأسعار والاشتراكات بنجاح!' });
  });

  // 10.11 Teacher Contact Management (إدارة التواصل مع المدرس)
  app.get('/api/ai/contact', (req: Request, res: Response) => {
    const contact = readJsonFile<AIContactConfig>(AI_CONTACT_FILE, {
      entityName: 'الأستاذ وسام سهيل العامري',
      whatsappNumber: '07704597073',
      whatsappLink: 'https://wa.me/9647704597073',
      telegramChannel: 'https://t.me/wissam_biology',
      instituteAddress: 'بغداد — معهد أنوار السلام الأهلي',
      guidingMessage: 'تواصل مع الأستاذ للاستفسار عن الدورات وكود VIP',
      requiredInfoBeforeContact: 'الاسم والمرحلة',
      suggestContactWhen: []
    });
    res.json({ success: true, contact });
  });

  app.post('/api/admin/ai/contact', requireAdmin, (req: Request, res: Response) => {
    const current = readJsonFile<AIContactConfig>(AI_CONTACT_FILE, {
      entityName: 'الأستاذ وسام سهيل العامري',
      whatsappNumber: '07704597073',
      whatsappLink: 'https://wa.me/9647704597073',
      telegramChannel: 'https://t.me/wissam_biology',
      instituteAddress: 'بغداد — معهد أنوار السلام الأهلي',
      guidingMessage: 'تواصل مع الأستاذ للاستفسار عن الدورات وكود VIP',
      requiredInfoBeforeContact: 'الاسم والمرحلة',
      suggestContactWhen: []
    });

    const updated: AIContactConfig = {
      ...current,
      ...req.body
    };

    writeJsonFile(AI_CONTACT_FILE, updated);
    res.json({ success: true, contact: updated, message: 'تم تحديث قنوات وإعدادات التواصل بنجاح!' });
  });

  // 10.12 Few-Shot Examples (علّم المساعد بمثال)
  app.get('/api/ai/examples', (req: Request, res: Response) => {
    const examples = readJsonFile<AIFewShotExample[]>(AI_EXAMPLES_FILE, []);
    res.json({ success: true, examples });
  });

  app.post('/api/admin/ai/examples', requireAdmin, (req: Request, res: Response) => {
    const { question, desiredAnswer, category, notes } = req.body;
    if (!question || !desiredAnswer) {
      res.status(400).json({ success: false, error: 'سؤال الطالب والجواب النموذجي مطلوبان' });
      return;
    }

    const examples = readJsonFile<AIFewShotExample[]>(AI_EXAMPLES_FILE, []);
    const newExample: AIFewShotExample = {
      id: `ex-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      question: question.trim(),
      desiredAnswer: desiredAnswer.trim(),
      category: category || 'general',
      notes: notes || '',
      createdAt: new Date().toISOString()
    };

    examples.unshift(newExample);
    writeJsonFile(AI_EXAMPLES_FILE, examples);
    res.json({ success: true, example: newExample, message: 'تمت إضافة مثال التدريب بنجاح!' });
  });

  app.put('/api/admin/ai/examples/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const { question, desiredAnswer, category, notes } = req.body;
    const examples = readJsonFile<AIFewShotExample[]>(AI_EXAMPLES_FILE, []);
    const idx = examples.findIndex((e) => e.id === id);

    if (idx === -1) {
      res.status(404).json({ success: false, error: 'المثال غير موجود' });
      return;
    }

    examples[idx] = {
      ...examples[idx],
      question: question !== undefined ? question.trim() : examples[idx].question,
      desiredAnswer: desiredAnswer !== undefined ? desiredAnswer.trim() : examples[idx].desiredAnswer,
      category: category !== undefined ? category : examples[idx].category,
      notes: notes !== undefined ? notes : examples[idx].notes
    };

    writeJsonFile(AI_EXAMPLES_FILE, examples);
    res.json({ success: true, example: examples[idx], message: 'تم تحديث السؤال والإجابة بنجاح!' });
  });

  app.delete('/api/admin/ai/examples/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const examples = readJsonFile<AIFewShotExample[]>(AI_EXAMPLES_FILE, []);
    const filtered = examples.filter((e) => e.id !== id);

    if (filtered.length === examples.length) {
      res.status(404).json({ success: false, error: 'المثال غير موجود' });
      return;
    }

    writeJsonFile(AI_EXAMPLES_FILE, filtered);
    res.json({ success: true, message: 'تم حذف المثال التدريبي بنجاح' });
  });

  // 10.13 Student Support Tickets (نظام بلاغات ومشكلات الطلاب)
  app.get('/api/ai/tickets', (req: Request, res: Response) => {
    const { studentUid } = req.query;
    const tickets = readJsonFile<AISupportTicket[]>(AI_TICKETS_FILE, []);

    if (studentUid && typeof studentUid === 'string') {
      const studentTickets = tickets.filter((t) => t.studentUid === studentUid);
      res.json({ success: true, tickets: studentTickets });
      return;
    }

    res.json({ success: true, tickets });
  });

  app.post('/api/ai/tickets', (req: Request, res: Response) => {
    const { studentUid, studentName, studentGrade, issueCategory, lectureId, lectureTitle, description } = req.body;

    if (!description || !description.trim()) {
      res.status(400).json({ success: false, error: 'وصف المشكلة مطلوب' });
      return;
    }

    const tickets = readJsonFile<AISupportTicket[]>(AI_TICKETS_FILE, []);
    const newTicket: AISupportTicket = {
      id: `ticket-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      studentUid: studentUid || 'anonymous',
      studentName: studentName || 'طالب',
      studentGrade: studentGrade || 'غير محدد',
      issueCategory: issueCategory || 'other',
      lectureId: lectureId ? Number(lectureId) : undefined,
      lectureTitle,
      description: description.trim(),
      status: 'new',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    tickets.unshift(newTicket);
    writeJsonFile(AI_TICKETS_FILE, tickets);
    res.json({
      success: true,
      ticket: newTicket,
      message: 'تم تسجيل بلاغ الدعم الفني بنجاح! سيقوم الفريق الفني للأستاذ وسام سهيل العامري بمتابعته وحله في أقرب وقت.'
    });
  });

  app.patch('/api/admin/ai/tickets/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const { status, adminNotes } = req.body;

    const tickets = readJsonFile<AISupportTicket[]>(AI_TICKETS_FILE, []);
    const idx = tickets.findIndex((t) => t.id === id);

    if (idx === -1) {
      res.status(404).json({ success: false, error: 'البلاغ غير موجود' });
      return;
    }

    if (status) tickets[idx].status = status;
    if (adminNotes !== undefined) tickets[idx].adminNotes = adminNotes;
    tickets[idx].updatedAt = new Date().toISOString();

    writeJsonFile(AI_TICKETS_FILE, tickets);
    res.json({ success: true, ticket: tickets[idx], message: 'تم تحديث حالة البلاغ بنجاح!' });
  });

  // 10.14 Admin AI Playground & Diagnostic Tester (زر «اختبار المساعد» ومعاينة الإدارة)
  app.post('/api/admin/ai/test', requireAdmin, async (req: Request, res: Response) => {
    const startTime = Date.now();
    const { query, customInstructionsOverride } = req.body;

    if (!query || !query.trim()) {
      res.status(400).json({ success: false, error: 'السؤال التجريبي مطلوب' });
      return;
    }

    const trimmedQuery = query.trim();
    const aiConfig = readJsonFile<AIConfig>(AI_CONFIG_FILE, {
      isEnabled: true,
      model: 'gemini-3.8-flash',
      temperature: 0.7,
      welcomeMessage: 'مرحباً بك يا بطل في منصة مختبر الأحياء!',
      customSystemInstructions: '',
      disclaimerText: '',
      updatedAt: new Date().toISOString()
    });

    const pricingConfig = readJsonFile<AIPricingConfig>(AI_PRICING_FILE, {
      individualLectureDefaultPrice: 5000,
      currency: 'دينار عراقي',
      packages: [],
      activationSteps: [],
      activeOffers: [],
      paymentFaq: []
    });

    const contactConfig = readJsonFile<AIContactConfig>(AI_CONTACT_FILE, {
      entityName: 'الأستاذ وسام سهيل العامري',
      whatsappNumber: '07704597073',
      whatsappLink: 'https://wa.me/9647704597073',
      telegramChannel: 'https://t.me/wissam_biology',
      instituteAddress: 'بغداد — معهد أنوار السلام الأهلي',
      guidingMessage: 'تواصل مع الأستاذ',
      requiredInfoBeforeContact: '',
      suggestContactWhen: []
    });

    const rules = readJsonFile<PreventionRule[]>(AI_RULES_FILE, []);
    const learnedResponses = readJsonFile<LearnedResponse[]>(AI_RESPONSES_FILE, []);
    const fewShotExamples = readJsonFile<AIFewShotExample[]>(AI_EXAMPLES_FILE, []);
    const indexedChunks = readJsonFile<IndexedChunk[]>(AI_CHUNKS_FILE, []);
    const lectures = readJsonFile<any[]>(LECTURES_FILE, []);

    // Diagnostics trace object
    const trace: any = {
      query: trimmedQuery,
      matchedRule: null,
      matchedLearnedResponse: null,
      matchedLectures: [],
      problemDiagnosis: diagnoseStudentProblem(trimmedQuery),
      chunksRetrieved: 0,
      modelUsed: aiConfig.model || 'gemini-3.8-flash'
    };

    // 1) Rule check
    const matchedRule = matchPreventionRule(trimmedQuery, rules);
    if (matchedRule) {
      trace.matchedRule = {
        id: matchedRule.id,
        name: matchedRule.name,
        action: matchedRule.action,
        response: matchedRule.requiredResponse || matchedRule.customResponse
      };
      res.json({
        success: true,
        answer: matchedRule.requiredResponse || matchedRule.customResponse,
        trace,
        executionTimeMs: Date.now() - startTime
      });
      return;
    }

    // 2) Learned Response check
    const matchedLearned = matchLearnedResponse(trimmedQuery, learnedResponses);
    if (matchedLearned) {
      trace.matchedLearnedResponse = {
        id: matchedLearned.id,
        title: matchedLearned.title,
        priority: matchedLearned.priority
      };
      res.json({
        success: true,
        answer: matchedLearned.responseText,
        trace,
        executionTimeMs: Date.now() - startTime
      });
      return;
    }

    // 3) Find lectures
    const matchedLectures = findRelevantLectures(trimmedQuery, lectures);
    trace.matchedLectures = matchedLectures.map((l) => ({
      id: l.id,
      title: l.title,
      isPaid: Boolean(l.isVipOnly || l.isPaid),
      price: l.price || pricingConfig.individualLectureDefaultPrice
    }));

    // 4) RAG chunks
    const relevantChunks = retrieveRelevantChunks(trimmedQuery, indexedChunks, {
      maxResults: 4,
      minScoreThreshold: 6
    });
    trace.chunksRetrieved = relevantChunks.length;

    // 5) Build Prompt
    const systemPrompt = buildComprehensiveBiologySystemPrompt({
      adminInstructions: customInstructionsOverride || aiConfig.customSystemInstructions,
      pricingConfig,
      contactConfig,
      relevantLectures: matchedLectures,
      fewShotExamples,
      contextChunks: relevantChunks
    });
    trace.effectiveSystemPrompt = systemPrompt;

    // 6) Model Execution using Real Google Gemini API with fallback cascade
    let answer = '';
    let isRealGemini = false;
    let geminiLatency = 0;

    const geminiResult = await executeRealGeminiGeneration({
      contents: trimmedQuery,
      systemInstruction: systemPrompt,
      temperature: aiConfig.temperature ?? 0.7,
      requestedModel: aiConfig.model || 'gemini-3.1-flash-lite'
    });

    if (geminiResult.success && geminiResult.text) {
      answer = geminiResult.text;
      trace.modelUsed = geminiResult.modelUsed;
      trace.isRealGemini = true;
      trace.geminiLatencyMs = geminiResult.latencyMs;
      isRealGemini = true;
      geminiLatency = geminiResult.latencyMs;
    } else {
      trace.apiError = geminiResult.error;
      trace.isRealGemini = false;
      answer = `[المحرك الاحتياطي]: المحاضرات المطابقة: ${matchedLectures.length} محاضرة، والقطع المفهرسة: ${relevantChunks.length} مقطع.`;
    }

    res.json({
      success: true,
      answer,
      trace,
      isRealGemini,
      modelUsed: trace.modelUsed,
      executionTimeMs: Date.now() - startTime
    });
  });

  // 10.15 Real Google Gemini Connection & Ping Test (فحص الربط الفعلي من لوحة الإدارة)
  app.post('/api/admin/ai/test-connection', requireAdmin, async (req: Request, res: Response) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
        res.json({
          success: false,
          connected: false,
          error: 'مفتاح GEMINI_API_KEY غير متوفر في بيئة الخادم السحابية'
        });
        return;
      }

      const result = await executeRealGeminiGeneration({
        contents: 'أجب بكلمة واحدة فقط باللغة العربية: ما هي وحدة بناء الكائن الحي؟',
        systemInstruction: 'أنت مساعد ذكي حقيقي لمنصة مختبر الأحياء للأستاذ وسام سهيل العامري.',
        temperature: 0.2,
        requestedModel: 'gemini-3.1-flash-lite'
      });

      if (result.success && result.text) {
        res.json({
          success: true,
          connected: true,
          modelUsed: result.modelUsed,
          latencyMs: result.latencyMs,
          sampleResponse: result.text,
          message: `تم التحقق بنجاح! متصل بـ Google Gemini الحقيقي (${result.modelUsed}) بزمن استجابة ${result.latencyMs}ms.`
        });
      } else {
        res.json({
          success: false,
          connected: false,
          error: result.error || 'تعذر استلام رد من Google Gemini حالياً'
        });
      }
    } catch (err: any) {
      res.status(500).json({
        success: false,
        connected: false,
        error: err.message || 'خطأ أثناء فحص اتصال الذكاء الاصطناعي'
      });
    }
  });

  // ==========================================
  // 10. Vite Dev Server / Static Production Serving
  // ==========================================
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath, {
      setHeaders: (res, filePath) => {
        const norm = filePath.replace(/\\/g, '/');
        if (
          norm.endsWith('/index.html') ||
          norm.endsWith('/sw.js') ||
          norm.endsWith('/registerSW.js') ||
          norm.endsWith('/manifest.webmanifest')
        ) {
          res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
          res.setHeader('Pragma', 'no-cache');
          res.setHeader('Expires', '0');
        } else if (norm.includes('/assets/')) {
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        }
      }
    }));
    app.get('*', (req: Request, res: Response) => {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    // In dev mode, also prevent caching of index.html and root
    app.use((req, res, next) => {
      if (req.url === '/' || req.url === '/index.html' || req.url?.startsWith('/index.html?')) {
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
      }
      next();
    });

    // Mount Vite middleware in development (HMR is disabled in AI Studio environment)
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: HOST,
        port: PORT,
        hmr: false
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  // Start HTTP Listener
  httpServer.listen(PORT, HOST, () => {
    console.log(`🌐 سيرفر مختبر الأحياء متصل على http://${HOST}:${PORT}`);
    console.log(`📡 واجهات الـ API السحابية جاهزة: /api/lectures | /api/users | /api/health`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
