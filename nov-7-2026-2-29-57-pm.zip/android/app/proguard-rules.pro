# Proguard rules for BioLab Wissam Android App
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class com.wissam.biolab.** { *; }
-dontwarn com.wissam.biolab.**
