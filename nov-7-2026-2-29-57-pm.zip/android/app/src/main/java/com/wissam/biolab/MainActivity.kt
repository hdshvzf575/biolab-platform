package com.wissam.biolab

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val appUrl = "https://ais-pre-nfi6ylkjfpyhtecegt2a2a-378445351099.europe-west1.run.app"
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        const val CHANNEL_LECTURES = "channel_lectures"
        const val CHANNEL_ANNOUNCEMENTS = "channel_announcements"
        const val CHANNEL_UPDATES = "channel_updates"
        const val CHANNEL_DOWNLOADS = "channel_downloads"
    }

    // 1. Native File Chooser Launcher (PDF uploads, Cover photos, Videos)
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val intent = result.data
            var results = WebChromeClient.FileChooserParams.parseResult(result.resultCode, intent)
            if (results == null && intent != null) {
                if (intent.data != null) {
                    results = arrayOf(intent.data!!)
                } else if (intent.clipData != null) {
                    val count = intent.clipData!!.itemCount
                    val list = mutableListOf<Uri>()
                    for (i in 0 until count) {
                        intent.clipData!!.getItemAt(i).uri?.let { list.add(it) }
                    }
                    if (list.isNotEmpty()) {
                        results = list.toTypedArray()
                    }
                }
            }
            fileUploadCallback?.onReceiveValue(results)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    // 2. Android 13+ (API 33+) Runtime Notification Permission Launcher
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        runOnUiThread {
            notifyJsNotificationPermissionResult(isGranted)
        }
    }

    // 3. Storage Runtime Permission Launcher (Legacy Android 9 and lower, API <= 28)
    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        runOnUiThread {
            notifyJsStoragePermissionResult(isGranted)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Hardware acceleration for high-performance rendering
        window.setFlags(
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        )

        // Initialize Official Notification Channels (Android 8.0+)
        createNotificationChannels()

        webView = WebView(this)
        setContentView(webView)

        configureWebView()

        // Handle hardware back button in web navigation
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        // Check if opened via notification deep link
        val initialTarget = intent?.getStringExtra("targetUrl")
        val targetToLoad = if (!initialTarget.isNullOrEmpty()) {
            if (initialTarget.startsWith("http")) initialTarget else "$appUrl$initialTarget"
        } else {
            appUrl
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(targetToLoad)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val target = intent.getStringExtra("targetUrl")
        if (!target.isNullOrEmpty()) {
            val destination = if (target.startsWith("http")) target else "$appUrl$target"
            webView.loadUrl(destination)
        }
    }

    // Register Notification Channels with high / default importance
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val channels = listOf(
                NotificationChannel(
                    CHANNEL_LECTURES,
                    "المحاضرات والدروس الجديدة",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "إشعارات عند نشر محاضرات أو مراجعات مركزة جديدة"
                    enableLights(true)
                    enableVibration(true)
                },
                NotificationChannel(
                    CHANNEL_ANNOUNCEMENTS,
                    "إعلانات وتنبيهات الأستاذ",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "تنبيهات مباشرة ومواعيد الامتحانات من الأستاذ وسام العامري"
                    enableLights(true)
                    enableVibration(true)
                },
                NotificationChannel(
                    CHANNEL_UPDATES,
                    "تحديثات المنصة والتطبيق",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "إشعارات تحديثات الميزات والإصدارات الجديدة"
                },
                NotificationChannel(
                    CHANNEL_DOWNLOADS,
                    "تنزيل الكتب والملازم",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "حالة واكتمال تنزيل ملفات المنهج والكتب الدراسية"
                }
            )

            notificationManager.createNotificationChannels(channels)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = false
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        // Bridge registration allowing bidirectional communication
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false

                // External intents for WhatsApp, Telegram, Phone calls, Maps
                if (url.startsWith("tel:") || url.startsWith("whatsapp:") || url.startsWith("https://wa.me/") || 
                    url.startsWith("https://t.me/") || url.startsWith("geo:") || url.startsWith("mailto:")) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                        return true
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "التطبيق المطلوب غير متوفر على الهاتف", Toast.LENGTH_SHORT).show()
                        return true
                    }
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback

                val intent = try {
                    fileChooserParams?.createIntent()?.apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                    } ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                } catch (e: Exception) {
                    Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                }

                return try {
                    filePickerLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = null
                    false
                }
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                super.onShowCustomView(view, callback)
            }
            override fun onHideCustomView() {
                super.onHideCustomView()
            }
        }

        // Fallback webView download listener
        webView.setDownloadListener { url, _, _, mimetype, _ ->
            enqueueDownload(url, "biology_curriculum.pdf", mimetype, "تحميل كتاب الأحياء")
        }
    }

    // Helper to start DownloadManager request safely with Scoped Storage support
    private fun enqueueDownload(url: String, fileName: String, mimeType: String?, description: String?): Boolean {
        return try {
            val fullUrl = if (url.startsWith("http://") || url.startsWith("https://")) {
                url
            } else if (url.startsWith("/")) {
                "$appUrl$url"
            } else {
                "$appUrl/$url"
            }

            val safeFileName = if (fileName.isNotBlank()) fileName else "biology_document.pdf"
            val safeMime = if (!mimeType.isNullOrBlank()) mimeType else "application/pdf"
            val safeDesc = if (!description.isNullOrBlank()) description else "منصة الكائنات | الأستاذ وسام سهيل العامري"

            val request = DownloadManager.Request(Uri.parse(fullUrl)).apply {
                setMimeType(safeMime)
                setDescription(safeDesc)
                setTitle(safeFileName)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeFileName)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    @Suppress("DEPRECATION")
                    allowScanningByMediaScanner()
                }
            }

            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(this, "بدأ تنزيل $safeFileName في مجلد التنزيلات 📥", Toast.LENGTH_LONG).show()
            true
        } catch (e: Exception) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)
                true
            } catch (err: Exception) {
                Toast.makeText(this, "تعذر بدء التنزيل: ${e.message}", Toast.LENGTH_SHORT).show()
                false
            }
        }
    }

    private fun notifyJsNotificationPermissionResult(granted: Boolean) {
        val js = """
            try {
                window.dispatchEvent(new CustomEvent('androidNotificationPermissionResult', { detail: { granted: $granted } }));
                if (window.onAndroidNotificationPermissionResult) {
                    window.onAndroidNotificationPermissionResult($granted);
                }
            } catch(e) {}
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun notifyJsStoragePermissionResult(granted: Boolean) {
        val js = """
            try {
                window.dispatchEvent(new CustomEvent('androidStoragePermissionResult', { detail: { granted: $granted } }));
                if (window.onAndroidStoragePermissionResult) {
                    window.onAndroidStoragePermissionResult($granted);
                }
            } catch(e) {}
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    // =========================================================================
    // JavaScript Interface: Real Android Runtime Permissions & Native Services
    // =========================================================================
    inner class AndroidBridge {

        @JavascriptInterface
        fun isAndroidApp(): Boolean = true

        @JavascriptInterface
        fun getAndroidVersion(): Int = Build.VERSION.SDK_INT

        @JavascriptInterface
        fun checkNotificationPermission(): String {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED

                if (granted) {
                    "granted"
                } else {
                    val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                        this@MainActivity,
                        Manifest.permission.POST_NOTIFICATIONS
                    )
                    if (shouldShowRationale) "denied" else "prompt"
                }
            } else {
                val enabled = NotificationManagerCompat.from(this@MainActivity).areNotificationsEnabled()
                if (enabled) "granted" else "denied"
            }
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val isGranted = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED

                    if (isGranted) {
                        notifyJsNotificationPermissionResult(true)
                    } else {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                } else {
                    val enabled = NotificationManagerCompat.from(this@MainActivity).areNotificationsEnabled()
                    if (!enabled) {
                        openNotificationSettings()
                    }
                    notifyJsNotificationPermissionResult(enabled)
                }
            }
        }

        @JavascriptInterface
        fun checkStoragePermission(): String {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ (API 29+) uses Scoped Storage (Environment.DIRECTORY_DOWNLOADS works without storage permission)
                "granted"
            } else {
                val granted = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                if (granted) "granted" else "prompt"
            }
        }

        @JavascriptInterface
        fun checkStorageAccess(): String = checkStoragePermission()

        @JavascriptInterface
        fun requestStoragePermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    notifyJsStoragePermissionResult(true)
                } else {
                    val isGranted = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) == PackageManager.PERMISSION_GRANTED

                    if (isGranted) {
                        notifyJsStoragePermissionResult(true)
                    } else {
                        storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    }
                }
            }
        }

        @JavascriptInterface
        fun requestStorageAccess() {
            requestStoragePermission()
        }

        @JavascriptInterface
        fun downloadFile(url: String, fileName: String, mimeType: String, description: String): Boolean {
            return enqueueDownload(url, fileName, mimeType, description)
        }

        @JavascriptInterface
        fun showLocalNotification(title: String, message: String, channelType: String, targetUrl: String) {
            runOnUiThread {
                try {
                    val channelId = when (channelType) {
                        "lectures" -> CHANNEL_LECTURES
                        "announcements" -> CHANNEL_ANNOUNCEMENTS
                        "downloads" -> CHANNEL_DOWNLOADS
                        else -> CHANNEL_UPDATES
                    }

                    val intent = Intent(this@MainActivity, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        putExtra("targetUrl", targetUrl)
                    }

                    val pendingIntent = PendingIntent.getActivity(
                        this@MainActivity,
                        System.currentTimeMillis().toInt(),
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
                    )

                    val notification = NotificationCompat.Builder(this@MainActivity, channelId)
                        .setSmallIcon(android.R.drawable.ic_popup_reminder)
                        .setContentTitle(title)
                        .setContentText(message)
                        .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true)
                        .build()

                    val notificationManager = NotificationManagerCompat.from(this@MainActivity)
                    if (ActivityCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) == PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                    ) {
                        notificationManager.notify((System.currentTimeMillis() % 100000).toInt(), notification)
                    }
                } catch (e: Exception) {
                    // Handled safely
                }
            }
        }

        @JavascriptInterface
        fun openAppSettings() {
            runOnUiThread {
                try {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", packageName, null)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر فتح إعدادات التطبيق", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun openNotificationSettings() {
            runOnUiThread {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                    } else {
                        openAppSettings()
                    }
                } catch (e: Exception) {
                    openAppSettings()
                }
            }
        }

        @JavascriptInterface
        fun clearCacheAndReload() {
            runOnUiThread {
                try {
                    webView.clearCache(true)
                    webView.reload()
                } catch (e: Exception) {}
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }
}
